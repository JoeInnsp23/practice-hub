--
-- PostgreSQL database dump
--

\restrict heqFcjMCWBiWikpDNwmySyGkz7WD8sdMsfmeAgqLuPyXov9MArvV4w2EG9eaEjm

-- Dumped from database version 16.10 (Debian 16.10-1.pgdg13+1)
-- Dumped by pg_dump version 16.10 (Debian 16.10-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.xero_connections DROP CONSTRAINT IF EXISTS xero_connections_tenant_id_tenants_id_fk;
ALTER TABLE IF EXISTS ONLY public.xero_connections DROP CONSTRAINT IF EXISTS xero_connections_connected_by_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.xero_connections DROP CONSTRAINT IF EXISTS xero_connections_client_id_clients_id_fk;
ALTER TABLE IF EXISTS ONLY public.workflows DROP CONSTRAINT IF EXISTS workflows_tenant_id_tenants_id_fk;
ALTER TABLE IF EXISTS ONLY public.workflows DROP CONSTRAINT IF EXISTS workflows_service_component_id_service_components_id_fk;
ALTER TABLE IF EXISTS ONLY public.workflows DROP CONSTRAINT IF EXISTS workflows_created_by_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.workflow_stages DROP CONSTRAINT IF EXISTS workflow_stages_workflow_id_workflows_id_fk;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_tenant_id_tenants_id_fk;
ALTER TABLE IF EXISTS ONLY public.user_permissions DROP CONSTRAINT IF EXISTS user_permissions_user_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.user_permissions DROP CONSTRAINT IF EXISTS user_permissions_tenant_id_tenants_id_fk;
ALTER TABLE IF EXISTS ONLY public.user_favorites DROP CONSTRAINT IF EXISTS user_favorites_user_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.user_favorites DROP CONSTRAINT IF EXISTS user_favorites_link_id_portal_links_id_fk;
ALTER TABLE IF EXISTS ONLY public.time_entries DROP CONSTRAINT IF EXISTS time_entries_user_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.time_entries DROP CONSTRAINT IF EXISTS time_entries_tenant_id_tenants_id_fk;
ALTER TABLE IF EXISTS ONLY public.time_entries DROP CONSTRAINT IF EXISTS time_entries_task_id_tasks_id_fk;
ALTER TABLE IF EXISTS ONLY public.time_entries DROP CONSTRAINT IF EXISTS time_entries_service_component_id_service_components_id_fk;
ALTER TABLE IF EXISTS ONLY public.time_entries DROP CONSTRAINT IF EXISTS time_entries_client_id_clients_id_fk;
ALTER TABLE IF EXISTS ONLY public.time_entries DROP CONSTRAINT IF EXISTS time_entries_approved_by_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.tasks DROP CONSTRAINT IF EXISTS tasks_tenant_id_tenants_id_fk;
ALTER TABLE IF EXISTS ONLY public.tasks DROP CONSTRAINT IF EXISTS tasks_reviewer_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.tasks DROP CONSTRAINT IF EXISTS tasks_created_by_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.tasks DROP CONSTRAINT IF EXISTS tasks_client_id_clients_id_fk;
ALTER TABLE IF EXISTS ONLY public.tasks DROP CONSTRAINT IF EXISTS tasks_assigned_to_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.task_workflow_instances DROP CONSTRAINT IF EXISTS task_workflow_instances_workflow_id_workflows_id_fk;
ALTER TABLE IF EXISTS ONLY public.task_workflow_instances DROP CONSTRAINT IF EXISTS task_workflow_instances_task_id_tasks_id_fk;
ALTER TABLE IF EXISTS ONLY public.task_workflow_instances DROP CONSTRAINT IF EXISTS task_workflow_instances_current_stage_id_workflow_stages_id_fk;
ALTER TABLE IF EXISTS ONLY public.session DROP CONSTRAINT IF EXISTS session_user_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.services DROP CONSTRAINT IF EXISTS services_tenant_id_tenants_id_fk;
ALTER TABLE IF EXISTS ONLY public.service_components DROP CONSTRAINT IF EXISTS service_components_tenant_id_tenants_id_fk;
ALTER TABLE IF EXISTS ONLY public.role_permissions DROP CONSTRAINT IF EXISTS role_permissions_tenant_id_tenants_id_fk;
ALTER TABLE IF EXISTS ONLY public.proposals DROP CONSTRAINT IF EXISTS proposals_tenant_id_tenants_id_fk;
ALTER TABLE IF EXISTS ONLY public.proposals DROP CONSTRAINT IF EXISTS proposals_lead_id_leads_id_fk;
ALTER TABLE IF EXISTS ONLY public.proposals DROP CONSTRAINT IF EXISTS proposals_created_by_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.proposals DROP CONSTRAINT IF EXISTS proposals_client_id_clients_id_fk;
ALTER TABLE IF EXISTS ONLY public.proposal_signatures DROP CONSTRAINT IF EXISTS proposal_signatures_tenant_id_tenants_id_fk;
ALTER TABLE IF EXISTS ONLY public.proposal_signatures DROP CONSTRAINT IF EXISTS proposal_signatures_proposal_id_proposals_id_fk;
ALTER TABLE IF EXISTS ONLY public.proposal_services DROP CONSTRAINT IF EXISTS proposal_services_tenant_id_tenants_id_fk;
ALTER TABLE IF EXISTS ONLY public.proposal_services DROP CONSTRAINT IF EXISTS proposal_services_proposal_id_proposals_id_fk;
ALTER TABLE IF EXISTS ONLY public.pricing_rules DROP CONSTRAINT IF EXISTS pricing_rules_tenant_id_tenants_id_fk;
ALTER TABLE IF EXISTS ONLY public.pricing_rules DROP CONSTRAINT IF EXISTS pricing_rules_component_id_service_components_id_fk;
ALTER TABLE IF EXISTS ONLY public.portal_links DROP CONSTRAINT IF EXISTS portal_links_tenant_id_tenants_id_fk;
ALTER TABLE IF EXISTS ONLY public.portal_links DROP CONSTRAINT IF EXISTS portal_links_created_by_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.portal_links DROP CONSTRAINT IF EXISTS portal_links_category_id_portal_categories_id_fk;
ALTER TABLE IF EXISTS ONLY public.portal_categories DROP CONSTRAINT IF EXISTS portal_categories_tenant_id_tenants_id_fk;
ALTER TABLE IF EXISTS ONLY public.portal_categories DROP CONSTRAINT IF EXISTS portal_categories_created_by_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.onboarding_tasks DROP CONSTRAINT IF EXISTS onboarding_tasks_tenant_id_tenants_id_fk;
ALTER TABLE IF EXISTS ONLY public.onboarding_tasks DROP CONSTRAINT IF EXISTS onboarding_tasks_session_id_onboarding_sessions_id_fk;
ALTER TABLE IF EXISTS ONLY public.onboarding_tasks DROP CONSTRAINT IF EXISTS onboarding_tasks_assigned_to_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.onboarding_sessions DROP CONSTRAINT IF EXISTS onboarding_sessions_tenant_id_tenants_id_fk;
ALTER TABLE IF EXISTS ONLY public.onboarding_sessions DROP CONSTRAINT IF EXISTS onboarding_sessions_client_id_clients_id_fk;
ALTER TABLE IF EXISTS ONLY public.onboarding_sessions DROP CONSTRAINT IF EXISTS onboarding_sessions_assigned_to_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.onboarding_responses DROP CONSTRAINT IF EXISTS onboarding_responses_tenant_id_tenants_id_fk;
ALTER TABLE IF EXISTS ONLY public.onboarding_responses DROP CONSTRAINT IF EXISTS onboarding_responses_onboarding_session_id_onboarding_sessions_;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_user_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_tenant_id_tenants_id_fk;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_user_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_thread_id_message_threads_id_fk;
ALTER TABLE IF EXISTS ONLY public.message_threads DROP CONSTRAINT IF EXISTS message_threads_tenant_id_tenants_id_fk;
ALTER TABLE IF EXISTS ONLY public.message_threads DROP CONSTRAINT IF EXISTS message_threads_created_by_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.message_threads DROP CONSTRAINT IF EXISTS message_threads_client_id_clients_id_fk;
ALTER TABLE IF EXISTS ONLY public.message_thread_participants DROP CONSTRAINT IF EXISTS message_thread_participants_user_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.message_thread_participants DROP CONSTRAINT IF EXISTS message_thread_participants_thread_id_message_threads_id_fk;
ALTER TABLE IF EXISTS ONLY public.leads DROP CONSTRAINT IF EXISTS leads_tenant_id_tenants_id_fk;
ALTER TABLE IF EXISTS ONLY public.leads DROP CONSTRAINT IF EXISTS leads_created_by_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.leads DROP CONSTRAINT IF EXISTS leads_converted_to_client_id_clients_id_fk;
ALTER TABLE IF EXISTS ONLY public.leads DROP CONSTRAINT IF EXISTS leads_assigned_to_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.kyc_verifications DROP CONSTRAINT IF EXISTS kyc_verifications_tenant_id_tenants_id_fk;
ALTER TABLE IF EXISTS ONLY public.kyc_verifications DROP CONSTRAINT IF EXISTS kyc_verifications_onboarding_session_id_onboarding_sessions_id_;
ALTER TABLE IF EXISTS ONLY public.kyc_verifications DROP CONSTRAINT IF EXISTS kyc_verifications_client_id_clients_id_fk;
ALTER TABLE IF EXISTS ONLY public.kyc_verifications DROP CONSTRAINT IF EXISTS kyc_verifications_approved_by_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.invoices DROP CONSTRAINT IF EXISTS invoices_tenant_id_tenants_id_fk;
ALTER TABLE IF EXISTS ONLY public.invoices DROP CONSTRAINT IF EXISTS invoices_created_by_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.invoices DROP CONSTRAINT IF EXISTS invoices_client_id_clients_id_fk;
ALTER TABLE IF EXISTS ONLY public.invoice_items DROP CONSTRAINT IF EXISTS invoice_items_time_entry_id_time_entries_id_fk;
ALTER TABLE IF EXISTS ONLY public.invoice_items DROP CONSTRAINT IF EXISTS invoice_items_service_component_id_service_components_id_fk;
ALTER TABLE IF EXISTS ONLY public.invoice_items DROP CONSTRAINT IF EXISTS invoice_items_invoice_id_invoices_id_fk;
ALTER TABLE IF EXISTS ONLY public.invitations DROP CONSTRAINT IF EXISTS invitations_tenant_id_tenants_id_fk;
ALTER TABLE IF EXISTS ONLY public.invitations DROP CONSTRAINT IF EXISTS invitations_invited_by_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.feedback DROP CONSTRAINT IF EXISTS feedback_tenant_id_tenants_id_fk;
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS documents_uploaded_by_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS documents_tenant_id_tenants_id_fk;
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS documents_task_id_tasks_id_fk;
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS documents_client_id_clients_id_fk;
ALTER TABLE IF EXISTS ONLY public.document_signatures DROP CONSTRAINT IF EXISTS document_signatures_tenant_id_tenants_id_fk;
ALTER TABLE IF EXISTS ONLY public.document_signatures DROP CONSTRAINT IF EXISTS document_signatures_document_id_documents_id_fk;
ALTER TABLE IF EXISTS ONLY public.compliance DROP CONSTRAINT IF EXISTS compliance_tenant_id_tenants_id_fk;
ALTER TABLE IF EXISTS ONLY public.compliance DROP CONSTRAINT IF EXISTS compliance_created_by_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.compliance DROP CONSTRAINT IF EXISTS compliance_client_id_clients_id_fk;
ALTER TABLE IF EXISTS ONLY public.compliance DROP CONSTRAINT IF EXISTS compliance_assigned_to_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.clients DROP CONSTRAINT IF EXISTS clients_tenant_id_tenants_id_fk;
ALTER TABLE IF EXISTS ONLY public.clients DROP CONSTRAINT IF EXISTS clients_created_by_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.clients DROP CONSTRAINT IF EXISTS clients_account_manager_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.client_transaction_data DROP CONSTRAINT IF EXISTS client_transaction_data_tenant_id_tenants_id_fk;
ALTER TABLE IF EXISTS ONLY public.client_transaction_data DROP CONSTRAINT IF EXISTS client_transaction_data_lead_id_leads_id_fk;
ALTER TABLE IF EXISTS ONLY public.client_transaction_data DROP CONSTRAINT IF EXISTS client_transaction_data_client_id_clients_id_fk;
ALTER TABLE IF EXISTS ONLY public.client_services DROP CONSTRAINT IF EXISTS client_services_tenant_id_tenants_id_fk;
ALTER TABLE IF EXISTS ONLY public.client_services DROP CONSTRAINT IF EXISTS client_services_service_component_id_service_components_id_fk;
ALTER TABLE IF EXISTS ONLY public.client_services DROP CONSTRAINT IF EXISTS client_services_client_id_clients_id_fk;
ALTER TABLE IF EXISTS ONLY public.client_pscs DROP CONSTRAINT IF EXISTS client_pscs_tenant_id_tenants_id_fk;
ALTER TABLE IF EXISTS ONLY public.client_pscs DROP CONSTRAINT IF EXISTS client_pscs_client_id_clients_id_fk;
ALTER TABLE IF EXISTS ONLY public.client_portal_verification DROP CONSTRAINT IF EXISTS client_portal_verification_tenant_id_tenants_id_fk;
ALTER TABLE IF EXISTS ONLY public.client_portal_verification DROP CONSTRAINT IF EXISTS client_portal_verification_client_id_clients_id_fk;
ALTER TABLE IF EXISTS ONLY public.client_portal_users DROP CONSTRAINT IF EXISTS client_portal_users_tenant_id_tenants_id_fk;
ALTER TABLE IF EXISTS ONLY public.client_portal_users DROP CONSTRAINT IF EXISTS client_portal_users_invited_by_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.client_portal_session DROP CONSTRAINT IF EXISTS client_portal_session_user_id_client_portal_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.client_portal_session DROP CONSTRAINT IF EXISTS client_portal_session_tenant_id_tenants_id_fk;
ALTER TABLE IF EXISTS ONLY public.client_portal_session DROP CONSTRAINT IF EXISTS client_portal_session_client_id_clients_id_fk;
ALTER TABLE IF EXISTS ONLY public.client_portal_invitations DROP CONSTRAINT IF EXISTS client_portal_invitations_tenant_id_tenants_id_fk;
ALTER TABLE IF EXISTS ONLY public.client_portal_invitations DROP CONSTRAINT IF EXISTS client_portal_invitations_revoked_by_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.client_portal_invitations DROP CONSTRAINT IF EXISTS client_portal_invitations_invited_by_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.client_portal_account DROP CONSTRAINT IF EXISTS client_portal_account_user_id_client_portal_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.client_portal_account DROP CONSTRAINT IF EXISTS client_portal_account_tenant_id_tenants_id_fk;
ALTER TABLE IF EXISTS ONLY public.client_portal_account DROP CONSTRAINT IF EXISTS client_portal_account_client_id_clients_id_fk;
ALTER TABLE IF EXISTS ONLY public.client_portal_access DROP CONSTRAINT IF EXISTS client_portal_access_tenant_id_tenants_id_fk;
ALTER TABLE IF EXISTS ONLY public.client_portal_access DROP CONSTRAINT IF EXISTS client_portal_access_portal_user_id_client_portal_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.client_portal_access DROP CONSTRAINT IF EXISTS client_portal_access_granted_by_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.client_portal_access DROP CONSTRAINT IF EXISTS client_portal_access_client_id_clients_id_fk;
ALTER TABLE IF EXISTS ONLY public.client_directors DROP CONSTRAINT IF EXISTS client_directors_tenant_id_tenants_id_fk;
ALTER TABLE IF EXISTS ONLY public.client_directors DROP CONSTRAINT IF EXISTS client_directors_client_id_clients_id_fk;
ALTER TABLE IF EXISTS ONLY public.client_contacts DROP CONSTRAINT IF EXISTS client_contacts_tenant_id_tenants_id_fk;
ALTER TABLE IF EXISTS ONLY public.client_contacts DROP CONSTRAINT IF EXISTS client_contacts_client_id_clients_id_fk;
ALTER TABLE IF EXISTS ONLY public.calendar_events DROP CONSTRAINT IF EXISTS calendar_events_tenant_id_tenants_id_fk;
ALTER TABLE IF EXISTS ONLY public.calendar_events DROP CONSTRAINT IF EXISTS calendar_events_task_id_tasks_id_fk;
ALTER TABLE IF EXISTS ONLY public.calendar_events DROP CONSTRAINT IF EXISTS calendar_events_created_by_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.calendar_events DROP CONSTRAINT IF EXISTS calendar_events_compliance_id_compliance_id_fk;
ALTER TABLE IF EXISTS ONLY public.calendar_events DROP CONSTRAINT IF EXISTS calendar_events_client_id_clients_id_fk;
ALTER TABLE IF EXISTS ONLY public.calendar_event_attendees DROP CONSTRAINT IF EXISTS calendar_event_attendees_user_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.calendar_event_attendees DROP CONSTRAINT IF EXISTS calendar_event_attendees_event_id_calendar_events_id_fk;
ALTER TABLE IF EXISTS ONLY public.aml_checks DROP CONSTRAINT IF EXISTS aml_checks_tenant_id_tenants_id_fk;
ALTER TABLE IF EXISTS ONLY public.aml_checks DROP CONSTRAINT IF EXISTS aml_checks_onboarding_session_id_onboarding_sessions_id_fk;
ALTER TABLE IF EXISTS ONLY public.aml_checks DROP CONSTRAINT IF EXISTS aml_checks_client_id_clients_id_fk;
ALTER TABLE IF EXISTS ONLY public.aml_checks DROP CONSTRAINT IF EXISTS aml_checks_approved_by_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.activity_logs DROP CONSTRAINT IF EXISTS activity_logs_user_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.activity_logs DROP CONSTRAINT IF EXISTS activity_logs_tenant_id_tenants_id_fk;
ALTER TABLE IF EXISTS ONLY public.account DROP CONSTRAINT IF EXISTS account_user_id_users_id_fk;
DROP INDEX IF EXISTS public.notifications_user_is_read_idx;
DROP INDEX IF EXISTS public.notifications_tenant_idx;
DROP INDEX IF EXISTS public.notifications_created_at_idx;
DROP INDEX IF EXISTS public.messages_user_idx;
DROP INDEX IF EXISTS public.messages_thread_idx;
DROP INDEX IF EXISTS public.messages_sender_idx;
DROP INDEX IF EXISTS public.messages_created_at_idx;
DROP INDEX IF EXISTS public.message_threads_type_idx;
DROP INDEX IF EXISTS public.message_threads_tenant_idx;
DROP INDEX IF EXISTS public.message_threads_last_message_idx;
DROP INDEX IF EXISTS public.message_threads_client_idx;
DROP INDEX IF EXISTS public.message_thread_participants_user_idx;
DROP INDEX IF EXISTS public.message_thread_participants_thread_participant_idx;
DROP INDEX IF EXISTS public.message_thread_participants_participant_idx;
DROP INDEX IF EXISTS public.idx_xero_tenant;
DROP INDEX IF EXISTS public.idx_xero_client;
DROP INDEX IF EXISTS public.idx_workflow_type;
DROP INDEX IF EXISTS public.idx_workflow_service;
DROP INDEX IF EXISTS public.idx_workflow_instance_status;
DROP INDEX IF EXISTS public.idx_workflow_instance;
DROP INDEX IF EXISTS public.idx_workflow_active;
DROP INDEX IF EXISTS public.idx_user_role;
DROP INDEX IF EXISTS public.idx_user_module;
DROP INDEX IF EXISTS public.idx_user_link_favorite;
DROP INDEX IF EXISTS public.idx_user_favorites_user;
DROP INDEX IF EXISTS public.idx_user_favorites_link;
DROP INDEX IF EXISTS public.idx_transaction_data_tenant;
DROP INDEX IF EXISTS public.idx_transaction_data_lead;
DROP INDEX IF EXISTS public.idx_transaction_data_client;
DROP INDEX IF EXISTS public.idx_time_entry_user_date;
DROP INDEX IF EXISTS public.idx_time_entry_task;
DROP INDEX IF EXISTS public.idx_time_entry_status;
DROP INDEX IF EXISTS public.idx_time_entry_client;
DROP INDEX IF EXISTS public.idx_time_entry_billable;
DROP INDEX IF EXISTS public.idx_tenant_service_code;
DROP INDEX IF EXISTS public.idx_tenant_invoice_number;
DROP INDEX IF EXISTS public.idx_tenant_email;
DROP INDEX IF EXISTS public.idx_tenant_client_code;
DROP INDEX IF EXISTS public.idx_task_workflow_instance;
DROP INDEX IF EXISTS public.idx_task_status;
DROP INDEX IF EXISTS public.idx_task_reviewer;
DROP INDEX IF EXISTS public.idx_task_progress;
DROP INDEX IF EXISTS public.idx_task_due_status;
DROP INDEX IF EXISTS public.idx_task_due_date;
DROP INDEX IF EXISTS public.idx_task_client;
DROP INDEX IF EXISTS public.idx_task_assignee;
DROP INDEX IF EXISTS public.idx_stage_workflow;
DROP INDEX IF EXISTS public.idx_stage_order;
DROP INDEX IF EXISTS public.idx_signature_proposal;
DROP INDEX IF EXISTS public.idx_signature_docuseal;
DROP INDEX IF EXISTS public.idx_service_component_code;
DROP INDEX IF EXISTS public.idx_service_component_category;
DROP INDEX IF EXISTS public.idx_service_component_active;
DROP INDEX IF EXISTS public.idx_service_category;
DROP INDEX IF EXISTS public.idx_role_module;
DROP INDEX IF EXISTS public.idx_psc_active;
DROP INDEX IF EXISTS public.idx_proposal_tenant;
DROP INDEX IF EXISTS public.idx_proposal_status;
DROP INDEX IF EXISTS public.idx_proposal_service_proposal;
DROP INDEX IF EXISTS public.idx_proposal_service_code;
DROP INDEX IF EXISTS public.idx_proposal_number;
DROP INDEX IF EXISTS public.idx_proposal_lead;
DROP INDEX IF EXISTS public.idx_proposal_created;
DROP INDEX IF EXISTS public.idx_proposal_client_status;
DROP INDEX IF EXISTS public.idx_proposal_client;
DROP INDEX IF EXISTS public.idx_primary_contact;
DROP INDEX IF EXISTS public.idx_pricing_rule_type;
DROP INDEX IF EXISTS public.idx_pricing_rule_component;
DROP INDEX IF EXISTS public.idx_pricing_rule_active;
DROP INDEX IF EXISTS public.idx_portal_links_tenant;
DROP INDEX IF EXISTS public.idx_portal_links_sort;
DROP INDEX IF EXISTS public.idx_portal_links_internal;
DROP INDEX IF EXISTS public.idx_portal_links_category;
DROP INDEX IF EXISTS public.idx_portal_links_active;
DROP INDEX IF EXISTS public.idx_portal_categories_tenant;
DROP INDEX IF EXISTS public.idx_portal_categories_sort;
DROP INDEX IF EXISTS public.idx_portal_categories_active;
DROP INDEX IF EXISTS public.idx_permissions_tenant;
DROP INDEX IF EXISTS public.idx_parent_task;
DROP INDEX IF EXISTS public.idx_onboarding_task_session;
DROP INDEX IF EXISTS public.idx_onboarding_task_sequence;
DROP INDEX IF EXISTS public.idx_onboarding_task_done;
DROP INDEX IF EXISTS public.idx_onboarding_task_assigned;
DROP INDEX IF EXISTS public.idx_onboarding_session_tenant;
DROP INDEX IF EXISTS public.idx_onboarding_session_status;
DROP INDEX IF EXISTS public.idx_onboarding_session_client;
DROP INDEX IF EXISTS public.idx_onboarding_session_assigned;
DROP INDEX IF EXISTS public.idx_onboarding_response_tenant;
DROP INDEX IF EXISTS public.idx_onboarding_response_session;
DROP INDEX IF EXISTS public.idx_message_thread_time;
DROP INDEX IF EXISTS public.idx_lead_tenant;
DROP INDEX IF EXISTS public.idx_lead_status;
DROP INDEX IF EXISTS public.idx_lead_email;
DROP INDEX IF EXISTS public.idx_lead_created;
DROP INDEX IF EXISTS public.idx_lead_assigned;
DROP INDEX IF EXISTS public.idx_kyc_verification_tenant;
DROP INDEX IF EXISTS public.idx_kyc_verification_status;
DROP INDEX IF EXISTS public.idx_kyc_verification_session;
DROP INDEX IF EXISTS public.idx_kyc_verification_lemverify_id;
DROP INDEX IF EXISTS public.idx_kyc_verification_client;
DROP INDEX IF EXISTS public.idx_invoice_status;
DROP INDEX IF EXISTS public.idx_invoice_item_invoice;
DROP INDEX IF EXISTS public.idx_invoice_due_status;
DROP INDEX IF EXISTS public.idx_invoice_due_date;
DROP INDEX IF EXISTS public.idx_invoice_client;
DROP INDEX IF EXISTS public.idx_invitation_token;
DROP INDEX IF EXISTS public.idx_invitation_status;
DROP INDEX IF EXISTS public.idx_invitation_email_tenant;
DROP INDEX IF EXISTS public.idx_feedback_user;
DROP INDEX IF EXISTS public.idx_feedback_type;
DROP INDEX IF EXISTS public.idx_feedback_tenant_status;
DROP INDEX IF EXISTS public.idx_feedback_created_at;
DROP INDEX IF EXISTS public.idx_document_task;
DROP INDEX IF EXISTS public.idx_document_signature_submission;
DROP INDEX IF EXISTS public.idx_document_signature_document;
DROP INDEX IF EXISTS public.idx_document_share_token;
DROP INDEX IF EXISTS public.idx_document_path;
DROP INDEX IF EXISTS public.idx_document_parent;
DROP INDEX IF EXISTS public.idx_document_client;
DROP INDEX IF EXISTS public.idx_director_active;
DROP INDEX IF EXISTS public.idx_compliance_type;
DROP INDEX IF EXISTS public.idx_compliance_status;
DROP INDEX IF EXISTS public.idx_compliance_due_date;
DROP INDEX IF EXISTS public.idx_compliance_client;
DROP INDEX IF EXISTS public.idx_compliance_assignee;
DROP INDEX IF EXISTS public.idx_client_status;
DROP INDEX IF EXISTS public.idx_client_service;
DROP INDEX IF EXISTS public.idx_client_psc;
DROP INDEX IF EXISTS public.idx_client_name;
DROP INDEX IF EXISTS public.idx_client_manager;
DROP INDEX IF EXISTS public.idx_client_director;
DROP INDEX IF EXISTS public.idx_client_contact;
DROP INDEX IF EXISTS public.idx_aml_check_tenant;
DROP INDEX IF EXISTS public.idx_aml_check_status;
DROP INDEX IF EXISTS public.idx_aml_check_session;
DROP INDEX IF EXISTS public.idx_aml_check_client;
DROP INDEX IF EXISTS public.idx_aml_check_check_id;
DROP INDEX IF EXISTS public.idx_activity_user;
DROP INDEX IF EXISTS public.idx_activity_tenant_entity;
DROP INDEX IF EXISTS public.idx_activity_entity;
DROP INDEX IF EXISTS public.idx_activity_created_at;
DROP INDEX IF EXISTS public.idx_activity_created;
DROP INDEX IF EXISTS public.client_portal_users_tenant_idx;
DROP INDEX IF EXISTS public.client_portal_users_email_idx;
DROP INDEX IF EXISTS public.client_portal_invitations_token_idx;
DROP INDEX IF EXISTS public.client_portal_invitations_tenant_idx;
DROP INDEX IF EXISTS public.client_portal_invitations_status_idx;
DROP INDEX IF EXISTS public.client_portal_invitations_email_idx;
DROP INDEX IF EXISTS public.client_portal_access_user_client_idx;
DROP INDEX IF EXISTS public.client_portal_access_tenant_idx;
DROP INDEX IF EXISTS public.client_portal_access_client_idx;
DROP INDEX IF EXISTS public.calendar_events_type_idx;
DROP INDEX IF EXISTS public.calendar_events_tenant_idx;
DROP INDEX IF EXISTS public.calendar_events_task_idx;
DROP INDEX IF EXISTS public.calendar_events_start_time_idx;
DROP INDEX IF EXISTS public.calendar_events_client_idx;
DROP INDEX IF EXISTS public.calendar_event_attendees_user_idx;
DROP INDEX IF EXISTS public.calendar_event_attendees_status_idx;
DROP INDEX IF EXISTS public.calendar_event_attendees_event_user_idx;
ALTER TABLE IF EXISTS ONLY public.xero_connections DROP CONSTRAINT IF EXISTS xero_connections_pkey;
ALTER TABLE IF EXISTS ONLY public.workflows DROP CONSTRAINT IF EXISTS workflows_pkey;
ALTER TABLE IF EXISTS ONLY public.workflow_stages DROP CONSTRAINT IF EXISTS workflow_stages_pkey;
ALTER TABLE IF EXISTS ONLY public.verification DROP CONSTRAINT IF EXISTS verification_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_unique;
ALTER TABLE IF EXISTS ONLY public.user_permissions DROP CONSTRAINT IF EXISTS user_permissions_pkey;
ALTER TABLE IF EXISTS ONLY public.user_favorites DROP CONSTRAINT IF EXISTS user_favorites_pkey;
ALTER TABLE IF EXISTS ONLY public.time_entries DROP CONSTRAINT IF EXISTS time_entries_pkey;
ALTER TABLE IF EXISTS ONLY public.tenants DROP CONSTRAINT IF EXISTS tenants_slug_unique;
ALTER TABLE IF EXISTS ONLY public.tenants DROP CONSTRAINT IF EXISTS tenants_pkey;
ALTER TABLE IF EXISTS ONLY public.tasks DROP CONSTRAINT IF EXISTS tasks_pkey;
ALTER TABLE IF EXISTS ONLY public.task_workflow_instances DROP CONSTRAINT IF EXISTS task_workflow_instances_pkey;
ALTER TABLE IF EXISTS ONLY public.session DROP CONSTRAINT IF EXISTS session_token_unique;
ALTER TABLE IF EXISTS ONLY public.session DROP CONSTRAINT IF EXISTS session_pkey;
ALTER TABLE IF EXISTS ONLY public.services DROP CONSTRAINT IF EXISTS services_pkey;
ALTER TABLE IF EXISTS ONLY public.service_components DROP CONSTRAINT IF EXISTS service_components_pkey;
ALTER TABLE IF EXISTS ONLY public.role_permissions DROP CONSTRAINT IF EXISTS role_permissions_pkey;
ALTER TABLE IF EXISTS ONLY public.proposals DROP CONSTRAINT IF EXISTS proposals_pkey;
ALTER TABLE IF EXISTS ONLY public.proposal_signatures DROP CONSTRAINT IF EXISTS proposal_signatures_pkey;
ALTER TABLE IF EXISTS ONLY public.proposal_signatures DROP CONSTRAINT IF EXISTS proposal_signatures_docuseal_submission_id_unique;
ALTER TABLE IF EXISTS ONLY public.proposal_services DROP CONSTRAINT IF EXISTS proposal_services_pkey;
ALTER TABLE IF EXISTS ONLY public.pricing_rules DROP CONSTRAINT IF EXISTS pricing_rules_pkey;
ALTER TABLE IF EXISTS ONLY public.portal_links DROP CONSTRAINT IF EXISTS portal_links_pkey;
ALTER TABLE IF EXISTS ONLY public.portal_categories DROP CONSTRAINT IF EXISTS portal_categories_pkey;
ALTER TABLE IF EXISTS ONLY public.onboarding_tasks DROP CONSTRAINT IF EXISTS onboarding_tasks_pkey;
ALTER TABLE IF EXISTS ONLY public.onboarding_sessions DROP CONSTRAINT IF EXISTS onboarding_sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.onboarding_responses DROP CONSTRAINT IF EXISTS onboarding_responses_pkey;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_pkey;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_pkey;
ALTER TABLE IF EXISTS ONLY public.message_threads DROP CONSTRAINT IF EXISTS message_threads_pkey;
ALTER TABLE IF EXISTS ONLY public.message_thread_participants DROP CONSTRAINT IF EXISTS message_thread_participants_pkey;
ALTER TABLE IF EXISTS ONLY public.leads DROP CONSTRAINT IF EXISTS leads_pkey;
ALTER TABLE IF EXISTS ONLY public.kyc_verifications DROP CONSTRAINT IF EXISTS kyc_verifications_pkey;
ALTER TABLE IF EXISTS ONLY public.invoices DROP CONSTRAINT IF EXISTS invoices_pkey;
ALTER TABLE IF EXISTS ONLY public.invoice_items DROP CONSTRAINT IF EXISTS invoice_items_pkey;
ALTER TABLE IF EXISTS ONLY public.invitations DROP CONSTRAINT IF EXISTS invitations_token_unique;
ALTER TABLE IF EXISTS ONLY public.invitations DROP CONSTRAINT IF EXISTS invitations_pkey;
ALTER TABLE IF EXISTS ONLY public.feedback DROP CONSTRAINT IF EXISTS feedback_pkey;
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS documents_pkey;
ALTER TABLE IF EXISTS ONLY public.document_signatures DROP CONSTRAINT IF EXISTS document_signatures_pkey;
ALTER TABLE IF EXISTS ONLY public.compliance DROP CONSTRAINT IF EXISTS compliance_pkey;
ALTER TABLE IF EXISTS ONLY public.clients DROP CONSTRAINT IF EXISTS clients_pkey;
ALTER TABLE IF EXISTS ONLY public.client_transaction_data DROP CONSTRAINT IF EXISTS client_transaction_data_pkey;
ALTER TABLE IF EXISTS ONLY public.client_services DROP CONSTRAINT IF EXISTS client_services_pkey;
ALTER TABLE IF EXISTS ONLY public.client_pscs DROP CONSTRAINT IF EXISTS client_pscs_pkey;
ALTER TABLE IF EXISTS ONLY public.client_portal_verification DROP CONSTRAINT IF EXISTS client_portal_verification_pkey;
ALTER TABLE IF EXISTS ONLY public.client_portal_users DROP CONSTRAINT IF EXISTS client_portal_users_pkey;
ALTER TABLE IF EXISTS ONLY public.client_portal_session DROP CONSTRAINT IF EXISTS client_portal_session_token_unique;
ALTER TABLE IF EXISTS ONLY public.client_portal_session DROP CONSTRAINT IF EXISTS client_portal_session_pkey;
ALTER TABLE IF EXISTS ONLY public.client_portal_invitations DROP CONSTRAINT IF EXISTS client_portal_invitations_token_unique;
ALTER TABLE IF EXISTS ONLY public.client_portal_invitations DROP CONSTRAINT IF EXISTS client_portal_invitations_pkey;
ALTER TABLE IF EXISTS ONLY public.client_portal_account DROP CONSTRAINT IF EXISTS client_portal_account_pkey;
ALTER TABLE IF EXISTS ONLY public.client_portal_access DROP CONSTRAINT IF EXISTS client_portal_access_pkey;
ALTER TABLE IF EXISTS ONLY public.client_directors DROP CONSTRAINT IF EXISTS client_directors_pkey;
ALTER TABLE IF EXISTS ONLY public.client_contacts DROP CONSTRAINT IF EXISTS client_contacts_pkey;
ALTER TABLE IF EXISTS ONLY public.calendar_events DROP CONSTRAINT IF EXISTS calendar_events_pkey;
ALTER TABLE IF EXISTS ONLY public.calendar_event_attendees DROP CONSTRAINT IF EXISTS calendar_event_attendees_pkey;
ALTER TABLE IF EXISTS ONLY public.aml_checks DROP CONSTRAINT IF EXISTS aml_checks_pkey;
ALTER TABLE IF EXISTS ONLY public.activity_logs DROP CONSTRAINT IF EXISTS activity_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.account DROP CONSTRAINT IF EXISTS account_pkey;
ALTER TABLE IF EXISTS ONLY drizzle.__drizzle_migrations DROP CONSTRAINT IF EXISTS __drizzle_migrations_pkey;
ALTER TABLE IF EXISTS drizzle.__drizzle_migrations ALTER COLUMN id DROP DEFAULT;
DROP TABLE IF EXISTS public.xero_connections;
DROP TABLE IF EXISTS public.verification;
DROP TABLE IF EXISTS public.user_permissions;
DROP TABLE IF EXISTS public.user_favorites;
DROP VIEW IF EXISTS public.transaction_data_summary_view;
DROP VIEW IF EXISTS public.time_entries_view;
DROP VIEW IF EXISTS public.task_workflow_view;
DROP TABLE IF EXISTS public.workflow_stages;
DROP TABLE IF EXISTS public.task_workflow_instances;
DROP VIEW IF EXISTS public.task_details_view;
DROP TABLE IF EXISTS public.workflows;
DROP TABLE IF EXISTS public.session;
DROP TABLE IF EXISTS public.services;
DROP TABLE IF EXISTS public.role_permissions;
DROP VIEW IF EXISTS public.proposals_details_view;
DROP TABLE IF EXISTS public.proposals;
DROP TABLE IF EXISTS public.proposal_signatures;
DROP TABLE IF EXISTS public.proposal_services;
DROP TABLE IF EXISTS public.pricing_rules;
DROP TABLE IF EXISTS public.portal_links;
DROP TABLE IF EXISTS public.portal_categories;
DROP VIEW IF EXISTS public.onboarding_sessions_view;
DROP TABLE IF EXISTS public.onboarding_tasks;
DROP TABLE IF EXISTS public.onboarding_sessions;
DROP TABLE IF EXISTS public.onboarding_responses;
DROP TABLE IF EXISTS public.notifications;
DROP VIEW IF EXISTS public.monthly_revenue_view;
DROP TABLE IF EXISTS public.messages;
DROP TABLE IF EXISTS public.message_threads;
DROP TABLE IF EXISTS public.message_thread_participants;
DROP VIEW IF EXISTS public.leads_details_view;
DROP TABLE IF EXISTS public.leads;
DROP TABLE IF EXISTS public.kyc_verifications;
DROP VIEW IF EXISTS public.invoice_items_view;
DROP TABLE IF EXISTS public.invoice_items;
DROP VIEW IF EXISTS public.invoice_details_view;
DROP TABLE IF EXISTS public.invitations;
DROP TABLE IF EXISTS public.feedback;
DROP TABLE IF EXISTS public.documents;
DROP TABLE IF EXISTS public.document_signatures;
DROP VIEW IF EXISTS public.dashboard_kpi_view;
DROP TABLE IF EXISTS public.time_entries;
DROP TABLE IF EXISTS public.tenants;
DROP VIEW IF EXISTS public.compliance_details_view;
DROP TABLE IF EXISTS public.client_transaction_data;
DROP VIEW IF EXISTS public.client_services_view;
DROP TABLE IF EXISTS public.service_components;
DROP TABLE IF EXISTS public.client_services;
DROP VIEW IF EXISTS public.client_revenue_view;
DROP TABLE IF EXISTS public.client_pscs;
DROP TABLE IF EXISTS public.client_portal_verification;
DROP TABLE IF EXISTS public.client_portal_users;
DROP TABLE IF EXISTS public.client_portal_session;
DROP TABLE IF EXISTS public.client_portal_invitations;
DROP TABLE IF EXISTS public.client_portal_account;
DROP TABLE IF EXISTS public.client_portal_access;
DROP TABLE IF EXISTS public.client_directors;
DROP VIEW IF EXISTS public.client_details_view;
DROP TABLE IF EXISTS public.client_contacts;
DROP TABLE IF EXISTS public.calendar_events;
DROP TABLE IF EXISTS public.calendar_event_attendees;
DROP TABLE IF EXISTS public.aml_checks;
DROP VIEW IF EXISTS public.activity_feed_view;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.tasks;
DROP TABLE IF EXISTS public.invoices;
DROP TABLE IF EXISTS public.compliance;
DROP TABLE IF EXISTS public.clients;
DROP TABLE IF EXISTS public.activity_logs;
DROP TABLE IF EXISTS public.account;
DROP SEQUENCE IF EXISTS drizzle.__drizzle_migrations_id_seq;
DROP TABLE IF EXISTS drizzle.__drizzle_migrations;
DROP TYPE IF EXISTS public.work_type;
DROP TYPE IF EXISTS public.transaction_data_source;
DROP TYPE IF EXISTS public.time_entry_status;
DROP TYPE IF EXISTS public.task_status;
DROP TYPE IF EXISTS public.task_priority;
DROP TYPE IF EXISTS public.service_price_type;
DROP TYPE IF EXISTS public.service_component_category;
DROP TYPE IF EXISTS public.proposal_status;
DROP TYPE IF EXISTS public.pricing_rule_type;
DROP TYPE IF EXISTS public.pricing_model;
DROP TYPE IF EXISTS public.onboarding_status;
DROP TYPE IF EXISTS public.onboarding_priority;
DROP TYPE IF EXISTS public.lead_status;
DROP TYPE IF EXISTS public.invoice_status;
DROP TYPE IF EXISTS public.document_type;
DROP TYPE IF EXISTS public.compliance_status;
DROP TYPE IF EXISTS public.compliance_priority;
DROP TYPE IF EXISTS public.client_type;
DROP TYPE IF EXISTS public.client_status;
-- *not* dropping schema, since initdb creates it
DROP SCHEMA IF EXISTS drizzle;
--
-- Name: drizzle; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA drizzle;


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS '';


--
-- Name: client_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.client_status AS ENUM (
    'prospect',
    'onboarding',
    'active',
    'inactive',
    'archived'
);


--
-- Name: client_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.client_type AS ENUM (
    'individual',
    'company',
    'limited_company',
    'sole_trader',
    'partnership',
    'llp',
    'trust',
    'charity',
    'other'
);


--
-- Name: compliance_priority; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.compliance_priority AS ENUM (
    'low',
    'medium',
    'high',
    'urgent'
);


--
-- Name: compliance_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.compliance_status AS ENUM (
    'pending',
    'in_progress',
    'completed',
    'overdue'
);


--
-- Name: document_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.document_type AS ENUM (
    'file',
    'folder'
);


--
-- Name: invoice_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.invoice_status AS ENUM (
    'draft',
    'sent',
    'paid',
    'overdue',
    'cancelled'
);


--
-- Name: lead_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.lead_status AS ENUM (
    'new',
    'contacted',
    'qualified',
    'proposal_sent',
    'negotiating',
    'converted',
    'lost'
);


--
-- Name: onboarding_priority; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.onboarding_priority AS ENUM (
    'low',
    'medium',
    'high'
);


--
-- Name: onboarding_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.onboarding_status AS ENUM (
    'not_started',
    'in_progress',
    'pending_questionnaire',
    'pending_approval',
    'approved',
    'rejected',
    'completed'
);


--
-- Name: pricing_model; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.pricing_model AS ENUM (
    'turnover',
    'transaction',
    'both',
    'fixed'
);


--
-- Name: pricing_rule_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.pricing_rule_type AS ENUM (
    'turnover_band',
    'transaction_band',
    'employee_band',
    'per_unit',
    'fixed'
);


--
-- Name: proposal_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.proposal_status AS ENUM (
    'draft',
    'sent',
    'viewed',
    'signed',
    'rejected',
    'expired'
);


--
-- Name: service_component_category; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.service_component_category AS ENUM (
    'compliance',
    'vat',
    'bookkeeping',
    'payroll',
    'management',
    'secretarial',
    'tax_planning',
    'addon'
);


--
-- Name: service_price_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.service_price_type AS ENUM (
    'hourly',
    'fixed',
    'retainer',
    'project',
    'percentage'
);


--
-- Name: task_priority; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.task_priority AS ENUM (
    'low',
    'medium',
    'high',
    'urgent',
    'critical'
);


--
-- Name: task_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.task_status AS ENUM (
    'pending',
    'in_progress',
    'review',
    'completed',
    'cancelled',
    'blocked',
    'records_received',
    'queries_sent',
    'queries_received'
);


--
-- Name: time_entry_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.time_entry_status AS ENUM (
    'draft',
    'submitted',
    'approved',
    'rejected'
);


--
-- Name: transaction_data_source; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.transaction_data_source AS ENUM (
    'xero',
    'manual',
    'estimated'
);


--
-- Name: work_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.work_type AS ENUM (
    'work',
    'admin',
    'training',
    'meeting',
    'business_development',
    'research',
    'holiday',
    'sick',
    'time_off_in_lieu'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: __drizzle_migrations; Type: TABLE; Schema: drizzle; Owner: -
--

CREATE TABLE drizzle.__drizzle_migrations (
    id integer NOT NULL,
    hash text NOT NULL,
    created_at bigint
);


--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE; Schema: drizzle; Owner: -
--

CREATE SEQUENCE drizzle.__drizzle_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: drizzle; Owner: -
--

ALTER SEQUENCE drizzle.__drizzle_migrations_id_seq OWNED BY drizzle.__drizzle_migrations.id;


--
-- Name: account; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.account (
    id text NOT NULL,
    account_id text NOT NULL,
    provider_id text NOT NULL,
    user_id text NOT NULL,
    access_token text,
    refresh_token text,
    id_token text,
    access_token_expires_at timestamp without time zone,
    refresh_token_expires_at timestamp without time zone,
    scope text,
    password text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: activity_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.activity_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    entity_type character varying(50) NOT NULL,
    entity_id uuid NOT NULL,
    action character varying(50) NOT NULL,
    description text,
    user_id text,
    user_name character varying(255),
    old_values jsonb,
    new_values jsonb,
    ip_address character varying(45),
    user_agent text,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: clients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clients (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    client_code character varying(50) NOT NULL,
    name character varying(255) NOT NULL,
    type public.client_type NOT NULL,
    status public.client_status DEFAULT 'onboarding'::public.client_status NOT NULL,
    email character varying(255),
    phone character varying(50),
    website character varying(255),
    vat_registered boolean DEFAULT false NOT NULL,
    vat_number character varying(50),
    registration_number character varying(50),
    address_line1 character varying(255),
    address_line2 character varying(255),
    city character varying(100),
    state character varying(100),
    postal_code character varying(20),
    country character varying(100),
    account_manager_id text,
    parent_client_id uuid,
    incorporation_date date,
    year_end character varying(10),
    notes text,
    health_score integer DEFAULT 50,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    created_by text
);


--
-- Name: compliance; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.compliance (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    title character varying(255) NOT NULL,
    type character varying(100) NOT NULL,
    description text,
    client_id uuid NOT NULL,
    assigned_to_id text,
    due_date timestamp without time zone NOT NULL,
    completed_date timestamp without time zone,
    reminder_date timestamp without time zone,
    status public.compliance_status DEFAULT 'pending'::public.compliance_status NOT NULL,
    priority public.compliance_priority DEFAULT 'medium'::public.compliance_priority NOT NULL,
    notes text,
    attachments jsonb,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    created_by_id text
);


--
-- Name: invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoices (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    invoice_number character varying(50) NOT NULL,
    client_id uuid NOT NULL,
    issue_date date NOT NULL,
    due_date date NOT NULL,
    paid_date date,
    subtotal numeric(10,2) NOT NULL,
    tax_rate numeric(5,2) DEFAULT '0'::numeric,
    tax_amount numeric(10,2) DEFAULT '0'::numeric,
    discount numeric(10,2) DEFAULT '0'::numeric,
    total numeric(10,2) NOT NULL,
    amount_paid numeric(10,2) DEFAULT '0'::numeric,
    status public.invoice_status DEFAULT 'draft'::public.invoice_status NOT NULL,
    currency character varying(3) DEFAULT 'GBP'::character varying,
    notes text,
    terms text,
    po_number character varying(100),
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    created_by_id text
);


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tasks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    status public.task_status DEFAULT 'pending'::public.task_status NOT NULL,
    priority public.task_priority DEFAULT 'medium'::public.task_priority NOT NULL,
    client_id uuid,
    assigned_to_id text,
    reviewer_id text,
    created_by_id text NOT NULL,
    due_date timestamp without time zone,
    target_date timestamp without time zone,
    completed_at timestamp without time zone,
    estimated_hours numeric(5,2),
    actual_hours numeric(5,2),
    progress integer DEFAULT 0,
    task_type character varying(100),
    category character varying(100),
    tags jsonb,
    parent_task_id uuid,
    workflow_id uuid,
    is_recurring boolean DEFAULT false,
    recurring_pattern jsonb,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id text NOT NULL,
    tenant_id text NOT NULL,
    email text NOT NULL,
    email_verified boolean DEFAULT false NOT NULL,
    name text,
    first_name character varying(100),
    last_name character varying(100),
    image text,
    role character varying(50) DEFAULT 'member'::character varying NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    hourly_rate numeric(10,2),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: activity_feed_view; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.activity_feed_view AS
 SELECT al.id,
    al.tenant_id,
    al.entity_type,
    al.entity_id,
    al.action,
    al.description,
    al.user_id,
    al.user_name,
    al.old_values,
    al.new_values,
    al.ip_address,
    al.user_agent,
    al.metadata,
    al.created_at,
        CASE
            WHEN ((al.entity_type)::text = 'client'::text) THEN ( SELECT clients.name
               FROM public.clients
              WHERE (clients.id = al.entity_id))
            WHEN ((al.entity_type)::text = 'task'::text) THEN ( SELECT tasks.title
               FROM public.tasks
              WHERE (tasks.id = al.entity_id))
            WHEN ((al.entity_type)::text = 'invoice'::text) THEN ( SELECT invoices.invoice_number
               FROM public.invoices
              WHERE (invoices.id = al.entity_id))
            WHEN ((al.entity_type)::text = 'compliance'::text) THEN ( SELECT compliance.title
               FROM public.compliance
              WHERE (compliance.id = al.entity_id))
            ELSE NULL::character varying
        END AS entity_name,
    u.email AS user_email,
    concat(u.first_name, ' ', u.last_name) AS user_display_name
   FROM (public.activity_logs al
     LEFT JOIN public.users u ON ((al.user_id = u.id)))
  ORDER BY al.created_at DESC;


--
-- Name: aml_checks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aml_checks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    client_id uuid NOT NULL,
    onboarding_session_id uuid,
    provider character varying(50) DEFAULT 'complycube'::character varying NOT NULL,
    check_id character varying(255) NOT NULL,
    status character varying(50) NOT NULL,
    risk_level character varying(50),
    outcome character varying(50),
    report_url text,
    checked_at timestamp without time zone,
    approved_by text,
    approved_at timestamp without time zone,
    rejection_reason text,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: calendar_event_attendees; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calendar_event_attendees (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    event_id uuid NOT NULL,
    user_id text NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    is_optional boolean DEFAULT false NOT NULL,
    responded_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: calendar_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calendar_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    type character varying(30) NOT NULL,
    start_time timestamp without time zone NOT NULL,
    end_time timestamp without time zone NOT NULL,
    all_day boolean DEFAULT false NOT NULL,
    location character varying(255),
    client_id uuid,
    task_id uuid,
    compliance_id uuid,
    created_by text NOT NULL,
    metadata jsonb,
    reminder_minutes integer,
    is_recurring boolean DEFAULT false NOT NULL,
    recurrence_rule text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: client_contacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_contacts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    client_id uuid NOT NULL,
    is_primary boolean DEFAULT false NOT NULL,
    title character varying(50),
    first_name character varying(100) NOT NULL,
    middle_name character varying(100),
    last_name character varying(100) NOT NULL,
    email character varying(255),
    phone character varying(50),
    mobile character varying(50),
    job_title character varying(100),
    "position" character varying(100),
    department character varying(100),
    address_line_1 character varying(255),
    address_line_2 character varying(255),
    city character varying(100),
    region character varying(100),
    postal_code character varying(20),
    country character varying(100),
    notes text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: client_details_view; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.client_details_view AS
 SELECT c.id,
    c.tenant_id,
    c.client_code,
    c.name,
    c.type,
    c.status,
    c.email,
    c.phone,
    c.website,
    c.vat_registered,
    c.vat_number,
    c.registration_number,
    c.address_line1,
    c.address_line2,
    c.city,
    c.state,
    c.postal_code,
    c.country,
    c.account_manager_id,
    c.parent_client_id,
    c.incorporation_date,
    c.year_end,
    c.notes,
    c.health_score,
    c.metadata,
    c.created_at,
    c.updated_at,
    c.created_by,
    u.first_name AS account_manager_first_name,
    u.last_name AS account_manager_last_name,
    concat(u.first_name, ' ', u.last_name) AS account_manager_name,
    u.email AS account_manager_email
   FROM (public.clients c
     LEFT JOIN public.users u ON ((c.account_manager_id = u.id)));


--
-- Name: client_directors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_directors (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    client_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    officer_role character varying(100),
    appointed_on date,
    resigned_on date,
    is_active boolean DEFAULT true NOT NULL,
    nationality character varying(100),
    occupation character varying(100),
    date_of_birth character varying(20),
    address text,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: client_portal_access; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_portal_access (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    portal_user_id text NOT NULL,
    client_id uuid NOT NULL,
    role character varying(50) DEFAULT 'viewer'::character varying NOT NULL,
    granted_by text,
    granted_at timestamp without time zone DEFAULT now() NOT NULL,
    expires_at timestamp without time zone,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: client_portal_account; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_portal_account (
    id text NOT NULL,
    tenant_id text NOT NULL,
    client_id uuid NOT NULL,
    account_id text NOT NULL,
    provider_id text NOT NULL,
    user_id text NOT NULL,
    access_token text,
    refresh_token text,
    id_token text,
    access_token_expires_at timestamp without time zone,
    refresh_token_expires_at timestamp without time zone,
    scope text,
    password text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: client_portal_invitations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_portal_invitations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    email text NOT NULL,
    first_name character varying(100),
    last_name character varying(100),
    client_ids jsonb NOT NULL,
    role character varying(50) DEFAULT 'viewer'::character varying NOT NULL,
    token text NOT NULL,
    invited_by text NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    sent_at timestamp without time zone DEFAULT now() NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    accepted_at timestamp without time zone,
    revoked_at timestamp without time zone,
    revoked_by text,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: client_portal_session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_portal_session (
    id text NOT NULL,
    tenant_id text NOT NULL,
    client_id uuid NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    token text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    ip_address text,
    user_agent text,
    user_id text NOT NULL
);


--
-- Name: client_portal_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_portal_users (
    id text NOT NULL,
    tenant_id text NOT NULL,
    email text NOT NULL,
    first_name character varying(100),
    last_name character varying(100),
    phone character varying(50),
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    last_login_at timestamp without time zone,
    invited_by text,
    invited_at timestamp without time zone,
    accepted_at timestamp without time zone,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: client_portal_verification; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_portal_verification (
    id text NOT NULL,
    tenant_id text NOT NULL,
    client_id uuid NOT NULL,
    identifier text NOT NULL,
    value text NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: client_pscs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_pscs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    client_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    kind character varying(100),
    notified_on date,
    ceased_on date,
    is_active boolean DEFAULT true NOT NULL,
    nationality character varying(100),
    date_of_birth character varying(20),
    natures_of_control jsonb,
    address text,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: client_revenue_view; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.client_revenue_view AS
 SELECT i.tenant_id,
    i.client_id,
    c.name AS client_name,
    c.client_code,
    sum(i.total) AS total_invoiced,
    sum(i.amount_paid) AS total_paid,
    sum((i.total - i.amount_paid)) AS outstanding,
    count(i.id) AS invoice_count,
    min(i.issue_date) AS first_invoice_date,
    max(i.issue_date) AS last_invoice_date
   FROM (public.invoices i
     LEFT JOIN public.clients c ON ((i.client_id = c.id)))
  WHERE (i.status = ANY (ARRAY['sent'::public.invoice_status, 'paid'::public.invoice_status, 'overdue'::public.invoice_status]))
  GROUP BY i.tenant_id, i.client_id, c.name, c.client_code;


--
-- Name: client_services; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_services (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    client_id uuid NOT NULL,
    service_component_id uuid NOT NULL,
    custom_rate numeric(10,2),
    start_date date,
    end_date date,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: service_components; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_components (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    code character varying(50) NOT NULL,
    name character varying(255) NOT NULL,
    category public.service_component_category NOT NULL,
    description text,
    pricing_model public.pricing_model NOT NULL,
    base_price numeric(10,2),
    price numeric(10,2),
    price_type public.service_price_type DEFAULT 'fixed'::public.service_price_type,
    default_rate numeric(10,2),
    duration integer,
    supports_complexity boolean DEFAULT false NOT NULL,
    tags jsonb,
    is_active boolean DEFAULT true NOT NULL,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: client_services_view; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.client_services_view AS
 SELECT cs.id,
    cs.tenant_id,
    cs.client_id,
    cs.service_component_id,
    cs.custom_rate,
    cs.start_date,
    cs.end_date,
    cs.is_active,
    cs.created_at,
    cs.updated_at,
    c.name AS client_name,
    c.client_code,
    s.name AS service_name,
    s.code AS service_code,
    s.description AS service_description,
    s.category AS service_category,
    COALESCE(cs.custom_rate, s.price) AS effective_rate
   FROM ((public.client_services cs
     LEFT JOIN public.clients c ON ((cs.client_id = c.id)))
     LEFT JOIN public.service_components s ON ((cs.service_component_id = s.id)));


--
-- Name: client_transaction_data; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_transaction_data (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    lead_id uuid,
    client_id uuid,
    monthly_transactions integer NOT NULL,
    data_source public.transaction_data_source NOT NULL,
    xero_data_json jsonb,
    last_updated timestamp without time zone DEFAULT now() NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: compliance_details_view; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.compliance_details_view AS
 SELECT comp.id,
    comp.tenant_id,
    comp.title,
    comp.type,
    comp.description,
    comp.client_id,
    comp.assigned_to_id,
    comp.due_date,
    comp.completed_date,
    comp.reminder_date,
    comp.status,
    comp.priority,
    comp.notes,
    comp.attachments,
    comp.metadata,
    comp.created_at,
    comp.updated_at,
    comp.created_by_id,
    c.name AS client_name,
    c.client_code,
    concat(u1.first_name, ' ', u1.last_name) AS assignee_name,
    u1.email AS assignee_email,
    concat(u2.first_name, ' ', u2.last_name) AS creator_name,
        CASE
            WHEN ((comp.due_date < CURRENT_DATE) AND (comp.status <> 'completed'::public.compliance_status)) THEN true
            ELSE false
        END AS is_overdue
   FROM (((public.compliance comp
     LEFT JOIN public.clients c ON ((comp.client_id = c.id)))
     LEFT JOIN public.users u1 ON ((comp.assigned_to_id = u1.id)))
     LEFT JOIN public.users u2 ON ((comp.created_by_id = u2.id)));


--
-- Name: tenants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenants (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: time_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.time_entries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    user_id text NOT NULL,
    client_id uuid,
    task_id uuid,
    service_component_id uuid,
    date date NOT NULL,
    start_time character varying(8),
    end_time character varying(8),
    hours numeric(5,2) NOT NULL,
    work_type public.work_type DEFAULT 'work'::public.work_type NOT NULL,
    billable boolean DEFAULT true NOT NULL,
    billed boolean DEFAULT false NOT NULL,
    rate numeric(10,2),
    amount numeric(10,2),
    invoice_id uuid,
    description text,
    notes text,
    status public.time_entry_status DEFAULT 'draft'::public.time_entry_status NOT NULL,
    submitted_at timestamp without time zone,
    approved_by_id text,
    approved_at timestamp without time zone,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: dashboard_kpi_view; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.dashboard_kpi_view AS
 SELECT id AS tenant_id,
    ( SELECT COALESCE(sum(invoices.total), (0)::numeric) AS "coalesce"
           FROM public.invoices
          WHERE ((invoices.tenant_id = t.id) AND (invoices.status = ANY (ARRAY['paid'::public.invoice_status, 'sent'::public.invoice_status])))) AS total_revenue,
    ( SELECT COALESCE(sum(invoices.total), (0)::numeric) AS "coalesce"
           FROM public.invoices
          WHERE ((invoices.tenant_id = t.id) AND (invoices.status = 'paid'::public.invoice_status))) AS collected_revenue,
    ( SELECT COALESCE(sum((invoices.total - invoices.amount_paid)), (0)::numeric) AS "coalesce"
           FROM public.invoices
          WHERE ((invoices.tenant_id = t.id) AND (invoices.status = ANY (ARRAY['sent'::public.invoice_status, 'overdue'::public.invoice_status])))) AS outstanding_revenue,
    ( SELECT count(*) AS count
           FROM public.clients
          WHERE ((clients.tenant_id = t.id) AND (clients.status = 'active'::public.client_status))) AS active_clients,
    ( SELECT count(*) AS count
           FROM public.clients
          WHERE ((clients.tenant_id = t.id) AND (clients.created_at >= (CURRENT_DATE - '30 days'::interval)))) AS new_clients_30d,
    ( SELECT count(*) AS count
           FROM public.tasks
          WHERE ((tasks.tenant_id = t.id) AND (tasks.status = 'pending'::public.task_status))) AS pending_tasks,
    ( SELECT count(*) AS count
           FROM public.tasks
          WHERE ((tasks.tenant_id = t.id) AND (tasks.status = 'in_progress'::public.task_status))) AS in_progress_tasks,
    ( SELECT count(*) AS count
           FROM public.tasks
          WHERE ((tasks.tenant_id = t.id) AND (tasks.status = 'completed'::public.task_status) AND (tasks.completed_at >= (CURRENT_DATE - '30 days'::interval)))) AS completed_tasks_30d,
    ( SELECT count(*) AS count
           FROM public.tasks
          WHERE ((tasks.tenant_id = t.id) AND (tasks.due_date < CURRENT_DATE) AND (tasks.status <> ALL (ARRAY['completed'::public.task_status, 'cancelled'::public.task_status])))) AS overdue_tasks,
    ( SELECT COALESCE(sum(time_entries.hours), (0)::numeric) AS "coalesce"
           FROM public.time_entries
          WHERE ((time_entries.tenant_id = t.id) AND (time_entries.date >= (CURRENT_DATE - '30 days'::interval)))) AS total_hours_30d,
    ( SELECT COALESCE(sum(time_entries.hours), (0)::numeric) AS "coalesce"
           FROM public.time_entries
          WHERE ((time_entries.tenant_id = t.id) AND (time_entries.billable = true) AND (time_entries.date >= (CURRENT_DATE - '30 days'::interval)))) AS billable_hours_30d,
    ( SELECT count(*) AS count
           FROM public.compliance
          WHERE ((compliance.tenant_id = t.id) AND (compliance.status <> 'completed'::public.compliance_status) AND ((compliance.due_date >= CURRENT_DATE) AND (compliance.due_date <= (CURRENT_DATE + '30 days'::interval))))) AS upcoming_compliance_30d,
    ( SELECT count(*) AS count
           FROM public.compliance
          WHERE ((compliance.tenant_id = t.id) AND (compliance.status <> 'completed'::public.compliance_status) AND (compliance.due_date < CURRENT_DATE))) AS overdue_compliance
   FROM public.tenants t;


--
-- Name: document_signatures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_signatures (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    document_id uuid NOT NULL,
    tenant_id text NOT NULL,
    signer_email character varying(255) NOT NULL,
    signer_name character varying(255) NOT NULL,
    docuseal_submission_id text NOT NULL,
    audit_trail jsonb NOT NULL,
    document_hash text,
    signed_pdf_url text,
    signed_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.documents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    name character varying(255) NOT NULL,
    type public.document_type NOT NULL,
    mime_type character varying(100),
    size integer,
    url text,
    thumbnail_url text,
    parent_id uuid,
    path text,
    client_id uuid,
    task_id uuid,
    description text,
    tags jsonb,
    version integer DEFAULT 1,
    is_archived boolean DEFAULT false,
    is_public boolean DEFAULT false,
    share_token character varying(100),
    share_expires_at timestamp without time zone,
    uploaded_by_id text NOT NULL,
    requires_signature boolean DEFAULT false NOT NULL,
    signature_status character varying(20) DEFAULT 'none'::character varying,
    docuseal_submission_id text,
    docuseal_template_id text,
    signed_pdf_url text,
    signed_at timestamp without time zone,
    signed_by character varying(255),
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: feedback; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feedback (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    user_id character varying(255) NOT NULL,
    user_email character varying(255) NOT NULL,
    user_name character varying(255),
    user_role character varying(50),
    type character varying(50) NOT NULL,
    title character varying(255) NOT NULL,
    description text NOT NULL,
    category character varying(50),
    page_url character varying(500),
    user_agent text,
    console_logs text,
    screenshot text,
    status character varying(50) DEFAULT 'new'::character varying,
    priority character varying(20) DEFAULT 'medium'::character varying,
    assigned_to character varying(255),
    admin_notes text,
    resolution text,
    resolved_at timestamp without time zone,
    resolved_by character varying(255),
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: invitations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invitations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    email text NOT NULL,
    role character varying(50) DEFAULT 'member'::character varying NOT NULL,
    token text NOT NULL,
    invited_by text NOT NULL,
    custom_message text,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    accepted_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: invoice_details_view; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.invoice_details_view AS
 SELECT i.id,
    i.tenant_id,
    i.invoice_number,
    i.client_id,
    i.issue_date,
    i.due_date,
    i.paid_date,
    i.subtotal,
    i.tax_rate,
    i.tax_amount,
    i.discount,
    i.total,
    i.amount_paid,
    i.status,
    i.currency,
    i.notes,
    i.terms,
    i.po_number,
    i.metadata,
    i.created_at,
    i.updated_at,
    i.created_by_id,
    c.name AS client_name,
    c.client_code,
    c.email AS client_email,
    c.vat_number AS client_vat_number,
    c.address_line1 AS client_address_line1,
    c.address_line2 AS client_address_line2,
    c.city AS client_city,
    c.postal_code AS client_postal_code,
    c.country AS client_country,
    concat(u.first_name, ' ', u.last_name) AS created_by_name,
    (i.total - i.amount_paid) AS balance_due
   FROM ((public.invoices i
     LEFT JOIN public.clients c ON ((i.client_id = c.id)))
     LEFT JOIN public.users u ON ((i.created_by_id = u.id)));


--
-- Name: invoice_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoice_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    invoice_id uuid NOT NULL,
    description text NOT NULL,
    quantity numeric(10,2) NOT NULL,
    rate numeric(10,2) NOT NULL,
    amount numeric(10,2) NOT NULL,
    time_entry_id uuid,
    service_component_id uuid,
    sort_order integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: invoice_items_view; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.invoice_items_view AS
 SELECT ii.id,
    ii.invoice_id,
    ii.description,
    ii.quantity,
    ii.rate,
    ii.amount,
    ii.time_entry_id,
    ii.service_component_id,
    ii.sort_order,
    ii.created_at,
    ii.updated_at,
    i.invoice_number,
    i.client_id,
    i.status AS invoice_status,
    s.name AS service_name,
    s.code AS service_code,
    s.category AS service_category
   FROM ((public.invoice_items ii
     LEFT JOIN public.invoices i ON ((ii.invoice_id = i.id)))
     LEFT JOIN public.service_components s ON ((ii.service_component_id = s.id)));


--
-- Name: kyc_verifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kyc_verifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    client_id uuid NOT NULL,
    onboarding_session_id uuid,
    lemverify_id character varying(255) NOT NULL,
    client_ref character varying(255) NOT NULL,
    status character varying(50) NOT NULL,
    outcome character varying(50),
    document_type character varying(50),
    document_verified boolean DEFAULT false,
    document_data jsonb,
    facematch_result character varying(50),
    facematch_score numeric(5,2),
    liveness_result character varying(50),
    liveness_score numeric(5,2),
    aml_result jsonb,
    aml_status character varying(50),
    pep_match boolean DEFAULT false,
    sanctions_match boolean DEFAULT false,
    watchlist_match boolean DEFAULT false,
    adverse_media_match boolean DEFAULT false,
    report_url text,
    documents_url jsonb,
    approved_by text,
    approved_at timestamp without time zone,
    rejection_reason text,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    completed_at timestamp without time zone,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: leads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.leads (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    first_name character varying(100) NOT NULL,
    last_name character varying(100) NOT NULL,
    email character varying(255) NOT NULL,
    phone character varying(50),
    mobile character varying(50),
    company_name character varying(255),
    "position" character varying(100),
    website character varying(255),
    status public.lead_status DEFAULT 'new'::public.lead_status NOT NULL,
    source character varying(100),
    industry character varying(100),
    estimated_turnover numeric(15,2),
    estimated_employees integer,
    qualification_score integer,
    interested_services jsonb,
    notes text,
    last_contacted_at timestamp without time zone,
    next_follow_up_at timestamp without time zone,
    assigned_to_id text,
    converted_to_client_id uuid,
    converted_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    created_by text
);


--
-- Name: leads_details_view; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.leads_details_view AS
 SELECT l.id,
    l.tenant_id,
    l.first_name,
    l.last_name,
    l.email,
    l.phone,
    l.mobile,
    l.company_name,
    l."position",
    l.website,
    l.status,
    l.source,
    l.industry,
    l.estimated_turnover,
    l.estimated_employees,
    l.qualification_score,
    l.interested_services,
    l.notes,
    l.last_contacted_at,
    l.next_follow_up_at,
    l.assigned_to_id,
    l.converted_to_client_id,
    l.converted_at,
    l.created_at,
    l.updated_at,
    l.created_by,
    concat(u.first_name, ' ', u.last_name) AS assigned_to_name,
    u.email AS assigned_to_email,
    c.name AS converted_client_name,
    c.client_code AS converted_client_code
   FROM ((public.leads l
     LEFT JOIN public.users u ON ((l.assigned_to_id = u.id)))
     LEFT JOIN public.clients c ON ((l.converted_to_client_id = c.id)));


--
-- Name: message_thread_participants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message_thread_participants (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    thread_id uuid NOT NULL,
    participant_type character varying(20) DEFAULT 'staff'::character varying NOT NULL,
    participant_id text NOT NULL,
    user_id text,
    role character varying(20) DEFAULT 'member'::character varying NOT NULL,
    joined_at timestamp without time zone DEFAULT now() NOT NULL,
    last_read_at timestamp without time zone,
    muted_until timestamp without time zone
);


--
-- Name: message_threads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message_threads (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    type character varying(20) NOT NULL,
    name character varying(255),
    description text,
    is_private boolean DEFAULT false NOT NULL,
    client_id uuid,
    created_by text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    last_message_at timestamp without time zone
);


--
-- Name: messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    thread_id uuid NOT NULL,
    sender_type character varying(20) DEFAULT 'staff'::character varying NOT NULL,
    sender_id text NOT NULL,
    user_id text,
    content text NOT NULL,
    type character varying(20) DEFAULT 'text'::character varying NOT NULL,
    metadata jsonb,
    reply_to_id uuid,
    is_edited boolean DEFAULT false NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: monthly_revenue_view; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.monthly_revenue_view AS
 SELECT tenant_id,
    date_trunc('month'::text, (issue_date)::timestamp with time zone) AS month,
    sum(
        CASE
            WHEN (status = ANY (ARRAY['sent'::public.invoice_status, 'paid'::public.invoice_status, 'overdue'::public.invoice_status])) THEN total
            ELSE (0)::numeric
        END) AS invoiced,
    sum(
        CASE
            WHEN (status = 'paid'::public.invoice_status) THEN total
            ELSE (0)::numeric
        END) AS collected,
    count(*) AS invoice_count,
    count(DISTINCT client_id) AS unique_clients
   FROM public.invoices
  GROUP BY tenant_id, (date_trunc('month'::text, (issue_date)::timestamp with time zone))
  ORDER BY tenant_id, (date_trunc('month'::text, (issue_date)::timestamp with time zone)) DESC;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    user_id text NOT NULL,
    type character varying(50) NOT NULL,
    title character varying(255) NOT NULL,
    message text NOT NULL,
    action_url text,
    entity_type character varying(50),
    entity_id uuid,
    is_read boolean DEFAULT false NOT NULL,
    read_at timestamp without time zone,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: onboarding_responses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.onboarding_responses (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    onboarding_session_id uuid NOT NULL,
    question_key character varying(255) NOT NULL,
    answer_value jsonb,
    extracted_from_ai boolean DEFAULT false,
    verified_by_user boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: onboarding_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.onboarding_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    client_id uuid NOT NULL,
    start_date timestamp without time zone NOT NULL,
    target_completion_date timestamp without time zone,
    actual_completion_date timestamp without time zone,
    status public.onboarding_status DEFAULT 'not_started'::public.onboarding_status NOT NULL,
    priority public.onboarding_priority DEFAULT 'medium'::public.onboarding_priority NOT NULL,
    assigned_to_id text,
    progress integer DEFAULT 0 NOT NULL,
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: onboarding_tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.onboarding_tasks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    session_id uuid NOT NULL,
    task_name character varying(255) NOT NULL,
    description text,
    required boolean DEFAULT true NOT NULL,
    sequence integer NOT NULL,
    days integer DEFAULT 0 NOT NULL,
    due_date timestamp without time zone,
    completion_date timestamp without time zone,
    done boolean DEFAULT false NOT NULL,
    notes text,
    assigned_to_id text,
    progress_weight integer DEFAULT 5 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: onboarding_sessions_view; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.onboarding_sessions_view AS
 SELECT os.id,
    os.tenant_id,
    os.client_id,
    os.start_date,
    os.target_completion_date,
    os.actual_completion_date,
    os.status,
    os.priority,
    os.assigned_to_id,
    os.progress,
    os.notes,
    os.created_at,
    os.updated_at,
    c.name AS client_name,
    c.client_code,
    c.email AS client_email,
    c.phone AS client_phone,
    c.created_at AS client_created_at,
    concat(u.first_name, ' ', u.last_name) AS account_manager_name,
    u.email AS account_manager_email,
    ( SELECT count(*) AS count
           FROM public.onboarding_tasks
          WHERE (onboarding_tasks.session_id = os.id)) AS total_tasks,
    ( SELECT count(*) AS count
           FROM public.onboarding_tasks
          WHERE ((onboarding_tasks.session_id = os.id) AND (onboarding_tasks.done = true))) AS completed_tasks
   FROM ((public.onboarding_sessions os
     LEFT JOIN public.clients c ON ((os.client_id = c.id)))
     LEFT JOIN public.users u ON ((os.assigned_to_id = u.id)));


--
-- Name: portal_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.portal_categories (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    icon_name character varying(50),
    color_hex character varying(7),
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_by_id text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: portal_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.portal_links (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    category_id uuid NOT NULL,
    title character varying(200) NOT NULL,
    description text,
    url text NOT NULL,
    is_internal boolean DEFAULT false NOT NULL,
    icon_name character varying(50),
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    target_blank boolean DEFAULT true NOT NULL,
    requires_auth boolean DEFAULT false NOT NULL,
    allowed_roles jsonb,
    created_by_id text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: pricing_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pricing_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    component_id uuid NOT NULL,
    rule_type public.pricing_rule_type NOT NULL,
    min_value numeric(15,2),
    max_value numeric(15,2),
    price numeric(10,2) NOT NULL,
    complexity_level character varying(50),
    metadata jsonb,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: proposal_services; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.proposal_services (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    proposal_id uuid NOT NULL,
    component_code character varying(50) NOT NULL,
    component_name character varying(255) NOT NULL,
    calculation text,
    price character varying(50) NOT NULL,
    config jsonb,
    sort_order integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: proposal_signatures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.proposal_signatures (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    proposal_id uuid NOT NULL,
    docuseal_submission_id text,
    signature_type character varying(50) DEFAULT 'electronic'::character varying NOT NULL,
    signature_method character varying(50) NOT NULL,
    signer_email character varying(255) NOT NULL,
    signer_name character varying(255) NOT NULL,
    signing_capacity character varying(100),
    company_info jsonb,
    audit_trail jsonb NOT NULL,
    document_hash text,
    signature_data text NOT NULL,
    signed_at timestamp without time zone NOT NULL,
    viewed_at timestamp without time zone,
    ip_address character varying(45),
    user_agent text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: proposals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.proposals (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    lead_id uuid,
    quote_id uuid,
    client_id uuid,
    proposal_number character varying(50) NOT NULL,
    title character varying(255) NOT NULL,
    status public.proposal_status DEFAULT 'draft'::public.proposal_status NOT NULL,
    turnover character varying(100),
    industry character varying(100),
    monthly_transactions integer,
    pricing_model_used character varying(10),
    monthly_total numeric(10,2) NOT NULL,
    annual_total numeric(10,2) NOT NULL,
    pdf_url text,
    signed_pdf_url text,
    docuseal_template_id text,
    docuseal_submission_id text,
    docuseal_signed_pdf_url text,
    document_hash text,
    template_id uuid,
    custom_terms text,
    terms_and_conditions text,
    notes text,
    valid_until timestamp without time zone,
    version integer DEFAULT 1 NOT NULL,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    sent_at timestamp without time zone,
    viewed_at timestamp without time zone,
    signed_at timestamp without time zone,
    expires_at timestamp without time zone,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    created_by_id text
);


--
-- Name: proposals_details_view; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.proposals_details_view AS
 SELECT p.id,
    p.tenant_id,
    p.lead_id,
    p.quote_id,
    p.client_id,
    p.proposal_number,
    p.title,
    p.status,
    p.turnover,
    p.industry,
    p.monthly_transactions,
    p.pricing_model_used,
    p.monthly_total,
    p.annual_total,
    p.pdf_url,
    p.signed_pdf_url,
    p.docuseal_template_id,
    p.docuseal_submission_id,
    p.docuseal_signed_pdf_url,
    p.document_hash,
    p.template_id,
    p.custom_terms,
    p.terms_and_conditions,
    p.notes,
    p.valid_until,
    p.version,
    p.metadata,
    p.created_at,
    p.sent_at,
    p.viewed_at,
    p.signed_at,
    p.expires_at,
    p.updated_at,
    p.created_by_id,
    COALESCE(c.name, l.company_name, (concat(l.first_name, ' ', l.last_name))::character varying) AS prospect_name,
    c.client_code,
    c.email AS client_email,
    l.email AS lead_email,
    concat(u.first_name, ' ', u.last_name) AS created_by_name,
    u.email AS created_by_email
   FROM (((public.proposals p
     LEFT JOIN public.clients c ON ((p.client_id = c.id)))
     LEFT JOIN public.leads l ON ((p.lead_id = l.id)))
     LEFT JOIN public.users u ON ((p.created_by_id = u.id)));


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_permissions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    role character varying(50) NOT NULL,
    module character varying(50) NOT NULL,
    can_view boolean DEFAULT true NOT NULL,
    can_create boolean DEFAULT false NOT NULL,
    can_edit boolean DEFAULT false NOT NULL,
    can_delete boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: services; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.services (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    code character varying(50) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    category character varying(100),
    default_rate numeric(10,2),
    price numeric(10,2),
    price_type public.service_price_type DEFAULT 'fixed'::public.service_price_type,
    duration integer,
    tags jsonb,
    is_active boolean DEFAULT true NOT NULL,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session (
    id text NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    token text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    ip_address text,
    user_agent text,
    user_id text NOT NULL,
    active_organization_id text
);


--
-- Name: workflows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workflows (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    type character varying(50) NOT NULL,
    trigger character varying(100),
    is_active boolean DEFAULT true NOT NULL,
    estimated_days integer,
    service_component_id uuid,
    config jsonb NOT NULL,
    conditions jsonb,
    actions jsonb,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    created_by_id text
);


--
-- Name: task_details_view; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.task_details_view AS
 SELECT t.id,
    t.tenant_id,
    t.title,
    t.description,
    t.status,
    t.priority,
    t.client_id,
    t.assigned_to_id,
    t.reviewer_id,
    t.created_by_id,
    t.due_date,
    t.target_date,
    t.completed_at,
    t.estimated_hours,
    t.actual_hours,
    t.progress,
    t.task_type,
    t.category,
    t.tags,
    t.parent_task_id,
    t.workflow_id,
    t.is_recurring,
    t.recurring_pattern,
    t.metadata,
    t.created_at,
    t.updated_at,
    c.name AS client_name,
    c.client_code,
    concat(u1.first_name, ' ', u1.last_name) AS assignee_name,
    u1.email AS assignee_email,
    concat(u2.first_name, ' ', u2.last_name) AS reviewer_name,
    u2.email AS reviewer_email,
    concat(u3.first_name, ' ', u3.last_name) AS creator_name,
    w.name AS workflow_name,
    pt.title AS parent_task_title
   FROM ((((((public.tasks t
     LEFT JOIN public.clients c ON ((t.client_id = c.id)))
     LEFT JOIN public.users u1 ON ((t.assigned_to_id = u1.id)))
     LEFT JOIN public.users u2 ON ((t.reviewer_id = u2.id)))
     LEFT JOIN public.users u3 ON ((t.created_by_id = u3.id)))
     LEFT JOIN public.workflows w ON ((t.workflow_id = w.id)))
     LEFT JOIN public.tasks pt ON ((t.parent_task_id = pt.id)));


--
-- Name: task_workflow_instances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_workflow_instances (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    task_id uuid NOT NULL,
    workflow_id uuid NOT NULL,
    current_stage_id uuid,
    status character varying(50) DEFAULT 'active'::character varying NOT NULL,
    stage_progress jsonb,
    started_at timestamp without time zone DEFAULT now() NOT NULL,
    completed_at timestamp without time zone,
    paused_at timestamp without time zone,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: workflow_stages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workflow_stages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workflow_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    stage_order integer NOT NULL,
    is_required boolean DEFAULT true NOT NULL,
    estimated_hours numeric(5,2),
    checklist_items jsonb,
    auto_complete boolean DEFAULT false,
    requires_approval boolean DEFAULT false,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: task_workflow_view; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.task_workflow_view AS
 SELECT t.id AS task_id,
    t.title AS task_title,
    t.status AS task_status,
    t.progress AS task_progress,
    w.name AS workflow_name,
    w.type AS workflow_type,
    twi.status AS workflow_status,
    ws.name AS current_stage_name,
    ws.stage_order AS current_stage_order,
    twi.stage_progress,
    count(DISTINCT ws2.id) AS total_stages
   FROM ((((public.tasks t
     LEFT JOIN public.task_workflow_instances twi ON ((t.id = twi.task_id)))
     LEFT JOIN public.workflows w ON ((twi.workflow_id = w.id)))
     LEFT JOIN public.workflow_stages ws ON ((twi.current_stage_id = ws.id)))
     LEFT JOIN public.workflow_stages ws2 ON ((ws2.workflow_id = w.id)))
  WHERE (t.workflow_id IS NOT NULL)
  GROUP BY t.id, t.title, t.status, t.progress, w.name, w.type, twi.status, ws.name, ws.stage_order, twi.stage_progress;


--
-- Name: time_entries_view; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.time_entries_view AS
 SELECT te.id,
    te.tenant_id,
    te.user_id,
    te.client_id,
    te.task_id,
    te.service_component_id,
    te.date,
    te.start_time,
    te.end_time,
    te.hours,
    te.work_type,
    te.billable,
    te.billed,
    te.rate,
    te.amount,
    te.invoice_id,
    te.description,
    te.notes,
    te.status,
    te.submitted_at,
    te.approved_by_id,
    te.approved_at,
    te.metadata,
    te.created_at,
    te.updated_at,
    concat(u.first_name, ' ', u.last_name) AS user_name,
    u.email AS user_email,
    c.name AS client_name,
    c.client_code,
    t.title AS task_title,
    s.name AS service_name,
    s.code AS service_code,
    concat(a.first_name, ' ', a.last_name) AS approver_name
   FROM (((((public.time_entries te
     LEFT JOIN public.users u ON ((te.user_id = u.id)))
     LEFT JOIN public.clients c ON ((te.client_id = c.id)))
     LEFT JOIN public.tasks t ON ((te.task_id = t.id)))
     LEFT JOIN public.service_components s ON ((te.service_component_id = s.id)))
     LEFT JOIN public.users a ON ((te.approved_by_id = a.id)));


--
-- Name: transaction_data_summary_view; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.transaction_data_summary_view AS
 SELECT td.id,
    td.tenant_id,
    td.lead_id,
    td.client_id,
    td.monthly_transactions,
    td.data_source,
    td.xero_data_json,
    td.last_updated,
    td.created_at,
    c.name AS client_name,
    c.client_code,
    l.company_name AS lead_company_name
   FROM ((public.client_transaction_data td
     LEFT JOIN public.clients c ON ((td.client_id = c.id)))
     LEFT JOIN public.leads l ON ((td.lead_id = l.id)));


--
-- Name: user_favorites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_favorites (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id text NOT NULL,
    link_id uuid NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: user_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_permissions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    user_id text NOT NULL,
    module character varying(50) NOT NULL,
    can_view boolean DEFAULT true NOT NULL,
    can_create boolean DEFAULT false NOT NULL,
    can_edit boolean DEFAULT false NOT NULL,
    can_delete boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: verification; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.verification (
    id text NOT NULL,
    identifier text NOT NULL,
    value text NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: xero_connections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.xero_connections (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    client_id uuid NOT NULL,
    access_token text NOT NULL,
    refresh_token text NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    xero_tenant_id text NOT NULL,
    xero_tenant_name text,
    xero_organisation_id text,
    is_active boolean DEFAULT true NOT NULL,
    last_sync_at timestamp without time zone,
    sync_status character varying(50) DEFAULT 'connected'::character varying,
    sync_error text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    connected_by text
);


--
-- Name: __drizzle_migrations id; Type: DEFAULT; Schema: drizzle; Owner: -
--

ALTER TABLE ONLY drizzle.__drizzle_migrations ALTER COLUMN id SET DEFAULT nextval('drizzle.__drizzle_migrations_id_seq'::regclass);


--
-- Data for Name: __drizzle_migrations; Type: TABLE DATA; Schema: drizzle; Owner: -
--

COPY drizzle.__drizzle_migrations (id, hash, created_at) FROM stdin;
2	f4c65cb31e52179feed17b01522a38b3a258fae95372daf3ddf2d31a26c82a06	1759248706784
\.


--
-- Data for Name: account; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.account (id, account_id, provider_id, user_id, access_token, refresh_token, id_token, access_token_expires_at, refresh_token_expires_at, scope, password, created_at, updated_at) FROM stdin;
d8af0dc0-3218-4852-994f-bd30b1404365	joe@pageivy.com	credential	a2adaa31-8f59-409a-b39b-72568022adb4	\N	\N	\N	\N	\N	\N	$2b$10$3/zf76qYqqfFYfi8PPFEBOLinKVAmvhSHtXNyurGXDYlnf2QZhU1S	2025-10-19 18:00:44.322	2025-10-19 18:00:44.322
34a1c10a-087c-40a5-a415-feff47c0a441	sarah.johnson@demo.com	credential	d6f36046-e274-4776-a3d7-58eadb9d96b0	\N	\N	\N	\N	\N	\N	$2b$10$glS.Uye1N5KYAfuQ1V5GwuEvQa0BNJCW38EzC790XocIwtmBDgnKS	2025-10-19 18:00:44.578	2025-10-19 18:00:44.578
798141b5-2eae-4f45-91a7-7c090f0159c8	mike.chen@demo.com	credential	c4f75303-a973-43e1-8f69-dfc6500c302c	\N	\N	\N	\N	\N	\N	$2b$10$CfHFzGVcOsKkFHJ6upHmlOqyFeADPt0xSEm799BIDaV710hE/sZRS	2025-10-19 18:00:44.827	2025-10-19 18:00:44.827
a764535b-8a23-4544-9c17-6baa208cbc03	emily.davis@demo.com	credential	0409f8de-7e1d-4245-96c2-02a3b1c90a81	\N	\N	\N	\N	\N	\N	$2b$10$6pSSPI1d75zBU2Edtw2nMuaRUEYCW/BfV5tILBtpKVAViL7w1I8u2	2025-10-19 18:00:45.077	2025-10-19 18:00:45.077
\.


--
-- Data for Name: activity_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.activity_logs (id, tenant_id, entity_type, entity_id, action, description, user_id, user_name, old_values, new_values, ip_address, user_agent, metadata, created_at) FROM stdin;
30f602b0-4dd8-4326-86d9-d8043201f02b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	invoice	1a1104d8-8f8f-460f-af83-425f3b1dc821	updated	Joe Test updated invoice "Invoice #7035"	a2adaa31-8f59-409a-b39b-72568022adb4	Joe Test	\N	\N	\N	\N	{"os": "Windows", "browser": "Safari"}	2025-10-16 01:32:46.276
2e1f904c-f0f7-47f6-a399-7a45418fe21d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	invoice	28f60e68-ad6e-4621-b5c3-667d6a115b60	assigned	Joe Test assigned invoice "Invoice #7244"	a2adaa31-8f59-409a-b39b-72568022adb4	Joe Test	\N	\N	\N	\N	{"os": "Linux", "browser": "Chrome"}	2025-10-02 23:09:19.074
1778c20c-f86b-43c7-a473-250079812152	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	compliance	33fccd46-a7f3-4b41-b572-57f548e76523	created	Joe Test created compliance "compliance Item"	a2adaa31-8f59-409a-b39b-72568022adb4	Joe Test	\N	\N	\N	\N	{"os": "MacOS", "browser": "Chrome"}	2025-09-30 18:35:03.086
7b45976a-abce-4116-aec5-f5e489518b32	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	compliance	e7ce680c-518a-4add-b21a-c47aa1ba8fa4	status_changed	Mike Chen status_changed compliance "compliance Item"	c4f75303-a973-43e1-8f69-dfc6500c302c	Mike Chen	\N	\N	\N	\N	{"os": "Linux", "browser": "Chrome"}	2025-10-12 01:37:16.098
d0363714-8f12-4f82-98d3-96b04881bff1	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	client	04465623-29cb-4298-8828-d1839e9cc00d	completed	Joe Test completed client "Legros - Turcotte"	a2adaa31-8f59-409a-b39b-72568022adb4	Joe Test	\N	\N	\N	\N	{"os": "Linux", "browser": "Edge"}	2025-09-29 21:16:46.435
4007bd89-081c-42b3-804c-d7ab5fdab9df	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	client	b7295600-5c20-4de2-8782-af87987c2bee	assigned	Emily Davis assigned client "Dana Dickens"	0409f8de-7e1d-4245-96c2-02a3b1c90a81	Emily Davis	\N	\N	\N	\N	{"os": "Linux", "browser": "Chrome"}	2025-10-01 11:08:53.34
d0623ce6-2a44-4669-b90c-6f16cddda566	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	compliance	9be6ad9d-f461-422a-8b7e-9611701a797e	status_changed	Mike Chen status_changed compliance "compliance Item"	c4f75303-a973-43e1-8f69-dfc6500c302c	Mike Chen	\N	\N	\N	\N	{"os": "Windows", "browser": "Chrome"}	2025-10-17 16:11:43.006
5d15aa06-07a7-4468-9dae-158284f33401	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	compliance	d9d85f11-8033-4b5f-908b-b4dbcac1a72b	status_changed	Mike Chen status_changed compliance "compliance Item"	c4f75303-a973-43e1-8f69-dfc6500c302c	Mike Chen	\N	\N	\N	\N	{"os": "Linux", "browser": "Safari"}	2025-09-30 23:58:13.256
93b7f8ea-f578-4441-9960-3f9180bc4ab3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	compliance	cd82a335-92db-4853-be5e-c1a851c503c2	created	Emily Davis created compliance "compliance Item"	0409f8de-7e1d-4245-96c2-02a3b1c90a81	Emily Davis	\N	\N	\N	\N	{"os": "Windows", "browser": "Chrome"}	2025-10-13 20:13:30.225
32507d41-e69b-411a-aeb7-c79a9f422270	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	document	67bad0e1-e328-4ee6-8da4-0c662507d66e	updated	Mike Chen updated document "document Item"	c4f75303-a973-43e1-8f69-dfc6500c302c	Mike Chen	\N	\N	\N	\N	{"os": "Windows", "browser": "Edge"}	2025-09-30 04:45:45.88
1dfa5e93-135b-4391-9365-06218ee64723	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	compliance	3faf31c4-2171-45ac-aa75-8bd110e96482	completed	Emily Davis completed compliance "compliance Item"	0409f8de-7e1d-4245-96c2-02a3b1c90a81	Emily Davis	\N	\N	\N	\N	{"os": "MacOS", "browser": "Firefox"}	2025-09-27 17:44:32.809
f02fa6f7-c015-4d4f-ab39-10bfe7621772	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	invoice	18f56f76-cf40-4501-91f2-f4a282f94cb2	assigned	Sarah Johnson assigned invoice "Invoice #4551"	d6f36046-e274-4776-a3d7-58eadb9d96b0	Sarah Johnson	\N	\N	\N	\N	{"os": "MacOS", "browser": "Firefox"}	2025-10-11 23:32:03.432
bd53a9d5-c35b-4792-8b42-f14839cc4a56	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	compliance	1f587dff-9f20-4d7c-89c0-8511d92b0304	status_changed	Mike Chen status_changed compliance "compliance Item"	c4f75303-a973-43e1-8f69-dfc6500c302c	Mike Chen	\N	\N	\N	\N	{"os": "Windows", "browser": "Chrome"}	2025-09-22 22:36:45.721
9296525f-0f49-4385-a640-47b6553e0e15	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	invoice	295df7de-1669-4e9a-817d-a2cbb9906f6d	created	Joe Test created invoice "Invoice #2511"	a2adaa31-8f59-409a-b39b-72568022adb4	Joe Test	\N	\N	\N	\N	{"os": "MacOS", "browser": "Safari"}	2025-10-13 23:25:20.753
4635249d-b174-41dd-9e2b-5180803d47eb	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	document	2c969b04-c5b7-4f11-87b8-d8aae3c301a0	completed	Joe Test completed document "document Item"	a2adaa31-8f59-409a-b39b-72568022adb4	Joe Test	\N	\N	\N	\N	{"os": "Linux", "browser": "Firefox"}	2025-10-01 17:06:42.725
c60f16da-7758-42e6-9e4a-1f6a5865e9e0	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	invoice	b107f9ce-426b-45eb-953a-b121741904f4	completed	Joe Test completed invoice "Invoice #9124"	a2adaa31-8f59-409a-b39b-72568022adb4	Joe Test	\N	\N	\N	\N	{"os": "MacOS", "browser": "Chrome"}	2025-09-26 22:31:44.302
746535a3-0324-4841-846c-6ccc8a3a5da6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	task	1c9d17d2-a153-4f42-9604-129a162a1f0f	completed	Mike Chen completed task "Annual Accounts - Jeremy Larson"	c4f75303-a973-43e1-8f69-dfc6500c302c	Mike Chen	\N	\N	\N	\N	{"os": "MacOS", "browser": "Edge"}	2025-10-13 21:07:15.597
612cbdcb-eb47-45db-9793-d8b3c779439b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	document	b6387d18-6585-40bd-a189-46fc0c290676	created	Emily Davis created document "document Item"	0409f8de-7e1d-4245-96c2-02a3b1c90a81	Emily Davis	\N	\N	\N	\N	{"os": "MacOS", "browser": "Safari"}	2025-09-30 16:28:27.995
23b47080-ed92-4e1d-82f1-e9f79dcb4a5a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	invoice	c4761622-a20a-432e-abb9-36c135ea2070	updated	Mike Chen updated invoice "Invoice #3781"	c4f75303-a973-43e1-8f69-dfc6500c302c	Mike Chen	\N	\N	\N	\N	{"os": "Linux", "browser": "Chrome"}	2025-10-15 03:21:24.786
bdfeab6a-2f2b-44da-b75e-c78b450a2804	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	compliance	49bc3332-7931-40f2-97b8-f0a552888e3a	assigned	Joe Test assigned compliance "compliance Item"	a2adaa31-8f59-409a-b39b-72568022adb4	Joe Test	\N	\N	\N	\N	{"os": "Windows", "browser": "Edge"}	2025-10-17 16:12:29.579
89cb2f5f-379b-42de-b683-fbd5eefebb60	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	compliance	c4278a94-0bb9-4b60-9f4d-611dc0689855	status_changed	Mike Chen status_changed compliance "compliance Item"	c4f75303-a973-43e1-8f69-dfc6500c302c	Mike Chen	\N	\N	\N	\N	{"os": "MacOS", "browser": "Safari"}	2025-10-02 22:47:59.217
793751ae-125d-430e-a977-c90c055f0ec6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	compliance	86203094-db53-4aa4-a1a2-4fcd51990313	completed	Mike Chen completed compliance "compliance Item"	c4f75303-a973-43e1-8f69-dfc6500c302c	Mike Chen	\N	\N	\N	\N	{"os": "Linux", "browser": "Safari"}	2025-09-22 15:35:21.915
dabfd9f7-b3bd-47e3-aa84-cf5690a16214	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	task	b3d1095b-3d51-444b-be35-f485afdb174f	updated	Sarah Johnson updated task "Bookkeeping - Gilberto Mante"	d6f36046-e274-4776-a3d7-58eadb9d96b0	Sarah Johnson	\N	\N	\N	\N	{"os": "Linux", "browser": "Firefox"}	2025-10-16 11:46:54.615
43155d92-c3e7-4b49-83d0-25dcc36fe55a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	task	088446c4-4542-4007-9887-b512bd3db05d	assigned	Joe Test assigned task "Tax Return - Pacocha - Ziemann"	a2adaa31-8f59-409a-b39b-72568022adb4	Joe Test	\N	\N	\N	\N	{"os": "Linux", "browser": "Edge"}	2025-10-14 17:59:04.666
1899cb00-58e4-48d5-a328-fb28a615b8c3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	client	46859340-c8cf-4144-aa6c-28fbaf53fa0e	completed	Mike Chen completed client "Noah Walsh V"	c4f75303-a973-43e1-8f69-dfc6500c302c	Mike Chen	\N	\N	\N	\N	{"os": "MacOS", "browser": "Safari"}	2025-10-01 07:01:09.52
c1db7240-8154-471b-bddc-e57a1d1dd40f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	invoice	8bf970b8-03c1-4925-b228-dd2da9ae3fd3	created	Sarah Johnson created invoice "Invoice #8568"	d6f36046-e274-4776-a3d7-58eadb9d96b0	Sarah Johnson	\N	\N	\N	\N	{"os": "Linux", "browser": "Safari"}	2025-09-26 05:21:33.986
c5bc0d8d-3aa5-4a34-b00a-3319c54cbe67	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	invoice	54ef029d-135f-40fb-a2eb-0b43b9c5ed9b	assigned	Mike Chen assigned invoice "Invoice #3352"	c4f75303-a973-43e1-8f69-dfc6500c302c	Mike Chen	\N	\N	\N	\N	{"os": "Linux", "browser": "Safari"}	2025-10-11 22:32:54.119
704b02be-8ff6-423d-a185-6f3f6b67bd44	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	client	702b5a48-f7a9-464c-8833-1ff6577e50e6	created	Sarah Johnson created client "Terry, Carter and Kshlerin"	d6f36046-e274-4776-a3d7-58eadb9d96b0	Sarah Johnson	\N	\N	\N	\N	{"os": "Linux", "browser": "Safari"}	2025-09-27 09:15:45.436
381f838c-9688-4cdf-94e2-d8c314b3bd26	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	compliance	738b695f-55ec-4141-b913-8a5d5ba1588e	updated	Emily Davis updated compliance "compliance Item"	0409f8de-7e1d-4245-96c2-02a3b1c90a81	Emily Davis	\N	\N	\N	\N	{"os": "Linux", "browser": "Chrome"}	2025-10-01 22:46:59.098
a69bdb24-ff6f-4f6f-a991-363a53846e89	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	invoice	a084313c-fea8-4c2f-b91e-2e66461bb626	status_changed	Joe Test status_changed invoice "Invoice #3937"	a2adaa31-8f59-409a-b39b-72568022adb4	Joe Test	\N	\N	\N	\N	{"os": "Linux", "browser": "Firefox"}	2025-10-08 02:46:35.342
2fb83da5-3a5e-40a5-9d6e-f5721818fb16	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	document	7a6f649c-c441-4141-a460-b50b30048e8a	status_changed	Emily Davis status_changed document "document Item"	0409f8de-7e1d-4245-96c2-02a3b1c90a81	Emily Davis	\N	\N	\N	\N	{"os": "Linux", "browser": "Safari"}	2025-10-13 15:07:40.198
61837722-6f99-4e1b-a749-ee1429cfbef1	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	document	5f0141d6-39bb-4150-b04d-3898e0375f26	completed	Emily Davis completed document "document Item"	0409f8de-7e1d-4245-96c2-02a3b1c90a81	Emily Davis	\N	\N	\N	\N	{"os": "Windows", "browser": "Safari"}	2025-10-15 20:20:13.032
42fdd719-c21f-43fa-bf40-7864628cdf68	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	document	e8856e80-b497-4d62-80d3-c4cb6f477bd6	updated	Mike Chen updated document "document Item"	c4f75303-a973-43e1-8f69-dfc6500c302c	Mike Chen	\N	\N	\N	\N	{"os": "Linux", "browser": "Chrome"}	2025-09-29 00:02:34.271
ff98b3ab-9211-48e7-9bc9-a6d2559ba703	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	document	b56e1553-922b-47c6-babc-f6333b888e40	updated	Mike Chen updated document "document Item"	c4f75303-a973-43e1-8f69-dfc6500c302c	Mike Chen	\N	\N	\N	\N	{"os": "Windows", "browser": "Edge"}	2025-10-14 20:36:59.222
2a5f7060-0a30-47b2-adef-1277931ba9cf	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	task	fe24fe87-1db5-4f06-9a5c-46757a20518d	updated	Joe Test updated task "Bookkeeping - Skiles - Bernier"	a2adaa31-8f59-409a-b39b-72568022adb4	Joe Test	\N	\N	\N	\N	{"os": "MacOS", "browser": "Safari"}	2025-10-06 18:24:06.668
670ddd59-19d2-4209-8495-f1c32f1079bc	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	invoice	5ebef123-3fcd-48d2-8aea-39529d99a785	assigned	Sarah Johnson assigned invoice "Invoice #6980"	d6f36046-e274-4776-a3d7-58eadb9d96b0	Sarah Johnson	\N	\N	\N	\N	{"os": "Linux", "browser": "Firefox"}	2025-10-03 05:16:27.548
1ed49d63-2d2f-4d09-b418-2cfa6a489e53	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	invoice	f278a666-9975-4799-921a-127569718268	completed	Joe Test completed invoice "Invoice #3400"	a2adaa31-8f59-409a-b39b-72568022adb4	Joe Test	\N	\N	\N	\N	{"os": "MacOS", "browser": "Edge"}	2025-10-02 23:29:40.865
caea83f7-2298-42c7-b5f7-51ed08ee9faa	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	document	451a6e88-a2cf-4158-b86f-9a9be98d89d1	updated	Emily Davis updated document "document Item"	0409f8de-7e1d-4245-96c2-02a3b1c90a81	Emily Davis	\N	\N	\N	\N	{"os": "Linux", "browser": "Firefox"}	2025-10-05 06:39:07.825
0e354ab4-0ddc-4390-9006-cfa8039ab1d6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	compliance	312cad23-5f67-41ec-bb64-14f411367a6b	created	Sarah Johnson created compliance "compliance Item"	d6f36046-e274-4776-a3d7-58eadb9d96b0	Sarah Johnson	\N	\N	\N	\N	{"os": "Windows", "browser": "Edge"}	2025-10-09 14:58:03.89
557be9a6-c41d-4a53-9536-9355b04bf0e5	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	client	12edb785-268b-4219-840d-15b8f0df1198	status_changed	Sarah Johnson status_changed client "Schamberger LLC"	d6f36046-e274-4776-a3d7-58eadb9d96b0	Sarah Johnson	\N	\N	\N	\N	{"os": "MacOS", "browser": "Firefox"}	2025-10-07 01:10:50.855
14470b92-875f-4536-93b7-39c2dd15728f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	document	eb413eb8-377f-425b-84e3-9c2e40664c74	assigned	Joe Test assigned document "document Item"	a2adaa31-8f59-409a-b39b-72568022adb4	Joe Test	\N	\N	\N	\N	{"os": "Linux", "browser": "Edge"}	2025-10-01 09:36:45.841
70cfaba6-3554-4347-984a-c9d8017b57b4	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	invoice	9474abb3-2626-40ae-8bc9-1534fcbd2d76	completed	Sarah Johnson completed invoice "Invoice #9914"	d6f36046-e274-4776-a3d7-58eadb9d96b0	Sarah Johnson	\N	\N	\N	\N	{"os": "MacOS", "browser": "Firefox"}	2025-10-12 16:25:16.58
e6f4295a-7f5f-4366-8b01-160a89c7400f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	document	10e42e7a-c3b7-417c-b00f-3a45d0ad3f9f	created	Mike Chen created document "document Item"	c4f75303-a973-43e1-8f69-dfc6500c302c	Mike Chen	\N	\N	\N	\N	{"os": "MacOS", "browser": "Chrome"}	2025-09-20 02:30:21.303
cac5e25d-5f54-43b2-a4c7-aba38a0884d6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	compliance	56c65d66-cfc9-456f-b2d6-22df5f0bf1ac	created	Sarah Johnson created compliance "compliance Item"	d6f36046-e274-4776-a3d7-58eadb9d96b0	Sarah Johnson	\N	\N	\N	\N	{"os": "Linux", "browser": "Firefox"}	2025-10-15 19:13:37.162
7e8acc96-5a27-4d5f-894b-21b91b224169	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	compliance	5242ebf0-7dfc-4cd0-8a8e-cb94bc5b5860	status_changed	Sarah Johnson status_changed compliance "compliance Item"	d6f36046-e274-4776-a3d7-58eadb9d96b0	Sarah Johnson	\N	\N	\N	\N	{"os": "Windows", "browser": "Safari"}	2025-09-22 10:28:02.161
3d4ff33e-89c7-4a49-a24e-0c87a97c4a7b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	compliance	1448f48b-e328-4090-9878-9c0802fbc398	created	Joe Test created compliance "compliance Item"	a2adaa31-8f59-409a-b39b-72568022adb4	Joe Test	\N	\N	\N	\N	{"os": "MacOS", "browser": "Chrome"}	2025-10-04 07:19:18.556
a62bc352-7102-4063-a63f-27343525f188	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	invoice	437cad2d-656e-45ee-a642-a9065e884055	created	Sarah Johnson created invoice "Invoice #6179"	d6f36046-e274-4776-a3d7-58eadb9d96b0	Sarah Johnson	\N	\N	\N	\N	{"os": "MacOS", "browser": "Firefox"}	2025-10-06 09:05:40.496
cb7524ad-4144-4f74-a67c-ecd83d518546	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	invoice	5fc6c021-8228-469e-9052-c693a9dd7644	completed	Sarah Johnson completed invoice "Invoice #9887"	d6f36046-e274-4776-a3d7-58eadb9d96b0	Sarah Johnson	\N	\N	\N	\N	{"os": "Linux", "browser": "Edge"}	2025-09-26 06:13:56.228
c481f426-6032-4a44-9f90-78d8fef50030	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	task	49ae64ac-de52-4d18-a5d6-d73c5d5605c5	updated	Joe Test updated task "Tax Return - Strosin - Runte"	a2adaa31-8f59-409a-b39b-72568022adb4	Joe Test	\N	\N	\N	\N	{"os": "Windows", "browser": "Safari"}	2025-10-10 08:04:14.696
ef653fe3-7324-4436-9fd7-ec97be1dddb6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	document	fe55ff44-5e95-4cb8-9920-0bc1b10619ef	status_changed	Emily Davis status_changed document "document Item"	0409f8de-7e1d-4245-96c2-02a3b1c90a81	Emily Davis	\N	\N	\N	\N	{"os": "Windows", "browser": "Safari"}	2025-10-09 03:47:01.444
086cfd03-fa8c-458e-9585-85b2d26e58bf	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	compliance	790f4565-e88f-4704-a68d-cbb0f737d103	updated	Sarah Johnson updated compliance "compliance Item"	d6f36046-e274-4776-a3d7-58eadb9d96b0	Sarah Johnson	\N	\N	\N	\N	{"os": "Linux", "browser": "Edge"}	2025-09-28 12:04:38.219
a324351f-82e6-4578-beef-08538d3c08b0	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	client	d69d0436-37d7-42a4-b907-3d9c3a091ea6	created	Mike Chen created client "Skiles - Bernier"	c4f75303-a973-43e1-8f69-dfc6500c302c	Mike Chen	\N	\N	\N	\N	{"os": "Linux", "browser": "Edge"}	2025-09-22 19:54:50.903
5996ac50-f6d1-4acb-bc44-de6a75fbd8c6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	compliance	5170834d-7ba6-42de-a1a6-3a72701eadc3	created	Mike Chen created compliance "compliance Item"	c4f75303-a973-43e1-8f69-dfc6500c302c	Mike Chen	\N	\N	\N	\N	{"os": "MacOS", "browser": "Firefox"}	2025-09-26 16:39:00.625
9d5b5407-6f98-4e55-8e29-b05331af6445	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	compliance	1aefdc8b-836b-471a-9694-76321ec20ccb	completed	Joe Test completed compliance "compliance Item"	a2adaa31-8f59-409a-b39b-72568022adb4	Joe Test	\N	\N	\N	\N	{"os": "MacOS", "browser": "Safari"}	2025-10-10 08:01:18.878
7ac8e38a-e090-45ea-a34c-377625eaeb19	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	compliance	0be909b0-a5d3-4628-8454-ad4fc42aca35	updated	Joe Test updated compliance "compliance Item"	a2adaa31-8f59-409a-b39b-72568022adb4	Joe Test	\N	\N	\N	\N	{"os": "Linux", "browser": "Chrome"}	2025-10-18 01:18:44.781
7c7990bd-3dd5-4b10-a067-3bb54ea00cc5	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	compliance	c0ec8867-36d7-4459-a9ec-cb3112131a0e	assigned	Joe Test assigned compliance "compliance Item"	a2adaa31-8f59-409a-b39b-72568022adb4	Joe Test	\N	\N	\N	\N	{"os": "MacOS", "browser": "Firefox"}	2025-10-16 14:47:21.453
1ba86570-565c-4cda-aca5-89501f7fd585	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	client	8538cc30-f9e7-4b63-a885-56b23e16ecef	completed	Emily Davis completed client "Gilberto Mante"	0409f8de-7e1d-4245-96c2-02a3b1c90a81	Emily Davis	\N	\N	\N	\N	{"os": "MacOS", "browser": "Firefox"}	2025-09-28 13:37:03.21
7acd23b6-fcb7-4ebb-8c19-8a8427bc37c6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	invoice	06aa0663-4ebe-4e72-b75b-6dc604e087d8	created	Joe Test created invoice "Invoice #8777"	a2adaa31-8f59-409a-b39b-72568022adb4	Joe Test	\N	\N	\N	\N	{"os": "MacOS", "browser": "Edge"}	2025-09-21 10:36:14.319
70d2fabf-f668-45a9-b497-bef53c33b119	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	invoice	62389a89-344c-450c-be26-95ab0ecaa186	assigned	Sarah Johnson assigned invoice "Invoice #6569"	d6f36046-e274-4776-a3d7-58eadb9d96b0	Sarah Johnson	\N	\N	\N	\N	{"os": "MacOS", "browser": "Safari"}	2025-10-05 00:29:10.453
0f89bea2-4597-4265-bf91-296c689c9152	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	document	459a0f41-c72f-450e-bad8-136200c596a7	assigned	Sarah Johnson assigned document "document Item"	d6f36046-e274-4776-a3d7-58eadb9d96b0	Sarah Johnson	\N	\N	\N	\N	{"os": "Linux", "browser": "Firefox"}	2025-09-21 11:04:06.707
2d365d70-d8c4-4d75-b3cd-4f72dc53e34e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	task	96a103f5-bc5b-43e1-b321-62fedda6eaa1	updated	Sarah Johnson updated task "Compliance Check - Constance Mante"	d6f36046-e274-4776-a3d7-58eadb9d96b0	Sarah Johnson	\N	\N	\N	\N	{"os": "Windows", "browser": "Firefox"}	2025-10-10 14:52:20.3
9ce65d40-3e49-46dc-9951-ab1873e2ec41	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	invoice	a223c268-9665-46ed-9552-c4d3a637e26d	status_changed	Emily Davis status_changed invoice "Invoice #9924"	0409f8de-7e1d-4245-96c2-02a3b1c90a81	Emily Davis	\N	\N	\N	\N	{"os": "Linux", "browser": "Chrome"}	2025-10-13 04:58:01.037
38b4e101-ed48-4b8b-949c-0c0cb05ca55d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	compliance	f0d1d1d5-7e01-410f-af60-7c4f8cde9f91	updated	Emily Davis updated compliance "compliance Item"	0409f8de-7e1d-4245-96c2-02a3b1c90a81	Emily Davis	\N	\N	\N	\N	{"os": "Windows", "browser": "Firefox"}	2025-10-07 13:35:45.741
3cad3eb3-b2a2-43a8-9940-70e9ed3f76f0	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	client	584bab37-ccf2-484c-9a7f-7394e4b30ec6	completed	Emily Davis completed client "Latoya Crooks"	0409f8de-7e1d-4245-96c2-02a3b1c90a81	Emily Davis	\N	\N	\N	\N	{"os": "Linux", "browser": "Safari"}	2025-09-20 10:57:21.432
c2e80e4c-f7dc-4071-a7d3-32c6e58cf971	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	task	20222077-caa4-4444-b803-1f75d617ee85	assigned	Mike Chen assigned task "Annual Accounts - Skiles - Bernier"	c4f75303-a973-43e1-8f69-dfc6500c302c	Mike Chen	\N	\N	\N	\N	{"os": "MacOS", "browser": "Edge"}	2025-10-16 06:21:03.625
3f6835f4-957b-4b27-8492-8ed7fdf19826	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	document	5337d6a3-950e-4bfa-9315-2120b352a3ae	updated	Mike Chen updated document "document Item"	c4f75303-a973-43e1-8f69-dfc6500c302c	Mike Chen	\N	\N	\N	\N	{"os": "MacOS", "browser": "Firefox"}	2025-10-09 00:57:11.75
7a628425-6c42-46a3-9172-c6f768271a0e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	document	2564a066-d375-4e67-aa58-931c707b444c	updated	Emily Davis updated document "document Item"	0409f8de-7e1d-4245-96c2-02a3b1c90a81	Emily Davis	\N	\N	\N	\N	{"os": "MacOS", "browser": "Edge"}	2025-10-01 12:02:01.946
efcc8293-64f4-4f7d-a0d7-56449d64f5b5	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	invoice	abeb8e03-255f-4135-96f2-6f2060956a5f	status_changed	Joe Test status_changed invoice "Invoice #5144"	a2adaa31-8f59-409a-b39b-72568022adb4	Joe Test	\N	\N	\N	\N	{"os": "MacOS", "browser": "Safari"}	2025-10-06 19:41:52.464
a771ca22-4fc4-4b2b-83e9-34c58fd53026	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	compliance	67b7bd9f-26ce-45e3-b348-d5d17834f9c4	updated	Emily Davis updated compliance "compliance Item"	0409f8de-7e1d-4245-96c2-02a3b1c90a81	Emily Davis	\N	\N	\N	\N	{"os": "Windows", "browser": "Edge"}	2025-10-16 19:11:22.275
dc2a4b73-01bd-4400-b0b0-42be61f0b4f0	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	document	4039b84b-8869-46c5-b318-b325bd1cde1a	assigned	Mike Chen assigned document "document Item"	c4f75303-a973-43e1-8f69-dfc6500c302c	Mike Chen	\N	\N	\N	\N	{"os": "Windows", "browser": "Safari"}	2025-09-30 20:11:48.889
585bf3b4-69c1-4e61-8a45-83ba6746bba1	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	client	6ecda653-6094-4502-9d1d-6e90d9ea99ed	assigned	Emily Davis assigned client "Boyer - Dibbert"	0409f8de-7e1d-4245-96c2-02a3b1c90a81	Emily Davis	\N	\N	\N	\N	{"os": "Linux", "browser": "Safari"}	2025-10-16 07:19:31.551
03c8d26e-b6ca-4ad6-9b33-b53b11f56b74	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	compliance	c099d2e6-7e18-4e00-9cbf-aa40ae5af050	created	Joe Test created compliance "compliance Item"	a2adaa31-8f59-409a-b39b-72568022adb4	Joe Test	\N	\N	\N	\N	{"os": "MacOS", "browser": "Firefox"}	2025-09-26 15:24:40.488
0c6c3f18-72ac-4392-8faa-114ce0386500	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	task	43f46d13-e4e7-4e0f-a62d-25d47b569d15	status_changed	Emily Davis status_changed task "Compliance Check - Ernser and Sons"	0409f8de-7e1d-4245-96c2-02a3b1c90a81	Emily Davis	\N	\N	\N	\N	{"os": "Windows", "browser": "Chrome"}	2025-10-04 17:27:10.231
6bf7a63d-78b0-4ef1-b0cc-7c58237e50ce	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	task	2c1d5d5c-be1c-427c-b2ac-da3cc28b1680	completed	Mike Chen completed task "Payroll - Ruecker - Jerde"	c4f75303-a973-43e1-8f69-dfc6500c302c	Mike Chen	\N	\N	\N	\N	{"os": "Linux", "browser": "Edge"}	2025-10-10 19:26:37.971
b5744465-4df0-41c7-9eff-d76530540ad6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	client	6a032ece-4f9e-405a-b48a-b28516d15fe1	assigned	Sarah Johnson assigned client "Ernser and Sons"	d6f36046-e274-4776-a3d7-58eadb9d96b0	Sarah Johnson	\N	\N	\N	\N	{"os": "Linux", "browser": "Chrome"}	2025-10-01 13:40:47.204
38bb49dd-c285-4f6e-acb7-bd274341f73c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	client	4554e09d-4391-42a8-a2cd-9702bce80511	created	Sarah Johnson created client "Abel Shanahan"	d6f36046-e274-4776-a3d7-58eadb9d96b0	Sarah Johnson	\N	\N	\N	\N	{"os": "Linux", "browser": "Firefox"}	2025-10-08 14:03:30.332
58c56367-6342-4f52-9bd3-740146fe4021	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	compliance	af9cdb8a-9b0b-47bf-afdc-b9ae7a76fe1b	updated	Mike Chen updated compliance "compliance Item"	c4f75303-a973-43e1-8f69-dfc6500c302c	Mike Chen	\N	\N	\N	\N	{"os": "MacOS", "browser": "Chrome"}	2025-10-07 02:29:33.004
47f1b1ab-62e5-448e-a7d5-1112cf065e22	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	task	2c1d5d5c-be1c-427c-b2ac-da3cc28b1680	assigned	Mike Chen assigned task "Payroll - Ruecker - Jerde"	c4f75303-a973-43e1-8f69-dfc6500c302c	Mike Chen	\N	\N	\N	\N	{"os": "Windows", "browser": "Chrome"}	2025-10-13 10:04:08.745
ebb3953f-14ae-4603-b78a-aa5885345877	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	compliance	d6cadf56-22ba-4878-960a-79e9aad9b662	status_changed	Sarah Johnson status_changed compliance "compliance Item"	d6f36046-e274-4776-a3d7-58eadb9d96b0	Sarah Johnson	\N	\N	\N	\N	{"os": "MacOS", "browser": "Firefox"}	2025-10-08 00:02:36.276
f1b58a1f-aee1-4b6a-8d6f-a94026fce927	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	client	46859340-c8cf-4144-aa6c-28fbaf53fa0e	completed	Sarah Johnson completed client "Noah Walsh V"	d6f36046-e274-4776-a3d7-58eadb9d96b0	Sarah Johnson	\N	\N	\N	\N	{"os": "Windows", "browser": "Firefox"}	2025-10-13 12:30:01.149
b7e358cd-a0c6-4222-b678-a0d37b90c43b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	client	584bab37-ccf2-484c-9a7f-7394e4b30ec6	assigned	Emily Davis assigned client "Latoya Crooks"	0409f8de-7e1d-4245-96c2-02a3b1c90a81	Emily Davis	\N	\N	\N	\N	{"os": "MacOS", "browser": "Chrome"}	2025-10-06 20:21:22.872
2eeebc7a-84f4-4235-86d8-b831310c6fa3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	invoice	5a58b2fd-225e-49af-bc18-cb8f2195e0e4	completed	Mike Chen completed invoice "Invoice #7984"	c4f75303-a973-43e1-8f69-dfc6500c302c	Mike Chen	\N	\N	\N	\N	{"os": "MacOS", "browser": "Safari"}	2025-10-15 01:10:53.641
ee22dc39-c050-4685-bd7c-417bf3ae414b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	invoice	ecdf048d-4d92-40fc-8a2a-16b5ecfd40f5	completed	Joe Test completed invoice "Invoice #7066"	a2adaa31-8f59-409a-b39b-72568022adb4	Joe Test	\N	\N	\N	\N	{"os": "Windows", "browser": "Edge"}	2025-10-02 14:22:46.493
7fb0b7dd-8b73-410c-8a6c-411433a2a3e2	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	task	1c9d17d2-a153-4f42-9604-129a162a1f0f	status_changed	Emily Davis status_changed task "Annual Accounts - Jeremy Larson"	0409f8de-7e1d-4245-96c2-02a3b1c90a81	Emily Davis	\N	\N	\N	\N	{"os": "MacOS", "browser": "Safari"}	2025-10-18 17:19:05.173
e3afaaec-2582-4a32-8d1c-e31a00946f06	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	compliance	ee84311b-294a-4341-a06a-c401c746e54d	updated	Mike Chen updated compliance "compliance Item"	c4f75303-a973-43e1-8f69-dfc6500c302c	Mike Chen	\N	\N	\N	\N	{"os": "Windows", "browser": "Safari"}	2025-09-23 06:34:02.772
97fa85d7-7869-46e5-97bd-641ea02477bb	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	document	9b888cf4-6571-4410-a777-89507186d457	completed	Sarah Johnson completed document "document Item"	d6f36046-e274-4776-a3d7-58eadb9d96b0	Sarah Johnson	\N	\N	\N	\N	{"os": "MacOS", "browser": "Chrome"}	2025-09-24 15:48:28.651
88ae48db-b3a3-4a09-b578-5bbea0eec9b8	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	invoice	a021b02f-84cf-4dd3-a12f-15ce29b0e625	assigned	Sarah Johnson assigned invoice "Invoice #5513"	d6f36046-e274-4776-a3d7-58eadb9d96b0	Sarah Johnson	\N	\N	\N	\N	{"os": "Linux", "browser": "Chrome"}	2025-10-19 10:59:49.368
babfcc51-f805-407d-8c1d-0602f7c5a9bc	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	invoice	88bc716b-d580-4c6f-bb99-03ab62cc072f	completed	Joe Test completed invoice "Invoice #1360"	a2adaa31-8f59-409a-b39b-72568022adb4	Joe Test	\N	\N	\N	\N	{"os": "Linux", "browser": "Edge"}	2025-10-11 14:05:46.04
f647ade7-65c7-48d5-90ab-05a6327d3d41	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	task	2849d1a9-72a4-4287-8114-b604140c71aa	created	Emily Davis created task "Document Review - Dana Dickens"	0409f8de-7e1d-4245-96c2-02a3b1c90a81	Emily Davis	\N	\N	\N	\N	{"os": "MacOS", "browser": "Firefox"}	2025-10-06 21:52:45.244
da0be1e1-ea17-4335-8f10-87c641cde831	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	compliance	8db987d0-f69b-4360-919c-4e3f632940a8	completed	Joe Test completed compliance "compliance Item"	a2adaa31-8f59-409a-b39b-72568022adb4	Joe Test	\N	\N	\N	\N	{"os": "Windows", "browser": "Firefox"}	2025-09-29 14:19:35.978
8ad90bf7-8d81-48e6-b5e0-9ec6e3ff5543	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	compliance	4f652c09-f0da-44ee-93be-1d666daa05b8	updated	Sarah Johnson updated compliance "compliance Item"	d6f36046-e274-4776-a3d7-58eadb9d96b0	Sarah Johnson	\N	\N	\N	\N	{"os": "Linux", "browser": "Edge"}	2025-09-20 03:09:15.002
fce7f7d0-c3d2-4602-b8fe-46d08dcf22d5	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	invoice	058c7504-4a44-448e-bee7-6b37f5f6a2e6	assigned	Emily Davis assigned invoice "Invoice #3627"	0409f8de-7e1d-4245-96c2-02a3b1c90a81	Emily Davis	\N	\N	\N	\N	{"os": "Linux", "browser": "Firefox"}	2025-09-27 07:45:34.808
0eb7268a-fd46-4a65-a0dd-cdbfbb72cfbd	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	compliance	c265ed76-6724-41ca-a12c-575ee9f896b4	created	Sarah Johnson created compliance "compliance Item"	d6f36046-e274-4776-a3d7-58eadb9d96b0	Sarah Johnson	\N	\N	\N	\N	{"os": "MacOS", "browser": "Edge"}	2025-10-18 08:14:54.708
1b0b6de7-e061-4f75-9efd-4401e42d18c3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	invoice	c12847fb-ecb5-4f6f-a554-8b64645ace15	assigned	Joe Test assigned invoice "Invoice #5763"	a2adaa31-8f59-409a-b39b-72568022adb4	Joe Test	\N	\N	\N	\N	{"os": "Linux", "browser": "Edge"}	2025-10-18 12:02:03.281
3a7263b8-2b94-4976-b40d-3d4e73e1e6c6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	compliance	4a950784-e004-4bb1-a672-dee099ea30b6	assigned	Joe Test assigned compliance "compliance Item"	a2adaa31-8f59-409a-b39b-72568022adb4	Joe Test	\N	\N	\N	\N	{"os": "Windows", "browser": "Firefox"}	2025-09-23 13:49:23.341
a18a7157-90b7-442c-8d0d-eefbb0c01965	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	compliance	99aec383-3ca4-472e-a5db-e9b8372133e3	created	Sarah Johnson created compliance "compliance Item"	d6f36046-e274-4776-a3d7-58eadb9d96b0	Sarah Johnson	\N	\N	\N	\N	{"os": "MacOS", "browser": "Chrome"}	2025-09-26 07:43:29.4
4b272ccf-d8de-4831-bc33-efb4afc96c88	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	task	6c88f260-519e-41e9-9fac-18a28b9a7901	assigned	Mike Chen assigned task "VAT Return - Boyer - Dibbert"	c4f75303-a973-43e1-8f69-dfc6500c302c	Mike Chen	\N	\N	\N	\N	{"os": "Windows", "browser": "Safari"}	2025-10-11 09:54:42.386
30566665-a07b-4ffa-813a-6ae130d2e6d4	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	compliance	d37dc4d1-e63c-421b-9298-d8f473f2e15b	assigned	Mike Chen assigned compliance "compliance Item"	c4f75303-a973-43e1-8f69-dfc6500c302c	Mike Chen	\N	\N	\N	\N	{"os": "Windows", "browser": "Safari"}	2025-10-15 16:30:31.776
964e53f0-4086-4a37-a9d8-f8fab6c4949a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	invoice	42e81a9e-0e62-43e5-b46d-36a8536154e2	completed	Joe Test completed invoice "Invoice #6333"	a2adaa31-8f59-409a-b39b-72568022adb4	Joe Test	\N	\N	\N	\N	{"os": "Windows", "browser": "Chrome"}	2025-10-11 20:09:39.827
7de82bc1-b6c7-4112-9968-3b0d6384a1f4	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	compliance	fffaf7b8-7a7d-49dc-b2bf-d98dc3602e14	status_changed	Emily Davis status_changed compliance "compliance Item"	0409f8de-7e1d-4245-96c2-02a3b1c90a81	Emily Davis	\N	\N	\N	\N	{"os": "Windows", "browser": "Safari"}	2025-10-10 21:05:17.579
\.


--
-- Data for Name: aml_checks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.aml_checks (id, tenant_id, client_id, onboarding_session_id, provider, check_id, status, risk_level, outcome, report_url, checked_at, approved_by, approved_at, rejection_reason, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: calendar_event_attendees; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.calendar_event_attendees (id, event_id, user_id, status, is_optional, responded_at, created_at) FROM stdin;
18d4783d-774e-4ec7-a414-f89b3e1b24c3	692303a8-e007-423a-b205-4e13ce7c4288	a2adaa31-8f59-409a-b39b-72568022adb4	accepted	f	2025-10-18 23:05:05.327	2025-10-19 18:00:42.327873
60f1e6ad-7d72-4c66-8b70-2b6b81baf925	692303a8-e007-423a-b205-4e13ce7c4288	d6f36046-e274-4776-a3d7-58eadb9d96b0	accepted	f	2025-10-19 05:39:31.325	2025-10-19 18:00:42.327873
dd11ac3d-2821-4992-b4d2-b090ed4d76ae	f258d08b-b418-49b9-bef5-3bd4e1ed4c89	a2adaa31-8f59-409a-b39b-72568022adb4	accepted	f	2025-10-19 15:22:49.652	2025-10-19 18:00:42.327873
70115ef1-bff6-4a08-af1f-7f1694d9e3c9	f258d08b-b418-49b9-bef5-3bd4e1ed4c89	d6f36046-e274-4776-a3d7-58eadb9d96b0	accepted	f	2025-10-18 14:35:24.963	2025-10-19 18:00:42.327873
9e533af5-8fce-47b0-8892-8aacc6a16ebf	f258d08b-b418-49b9-bef5-3bd4e1ed4c89	c4f75303-a973-43e1-8f69-dfc6500c302c	accepted	f	2025-10-19 00:27:51.137	2025-10-19 18:00:42.327873
9c27de1f-a253-421f-b3a7-a9013520e2fb	f258d08b-b418-49b9-bef5-3bd4e1ed4c89	0409f8de-7e1d-4245-96c2-02a3b1c90a81	accepted	f	2025-10-18 13:03:50.141	2025-10-19 18:00:42.327873
5d2d9dc7-94e2-4697-ab05-249b1eefef35	7ecad21c-c7b9-415a-b9dc-8294c7d8fd4d	a2adaa31-8f59-409a-b39b-72568022adb4	pending	f	\N	2025-10-19 18:00:42.327873
0be406ff-c26b-4fc7-a106-d83640d45e5c	7ecad21c-c7b9-415a-b9dc-8294c7d8fd4d	d6f36046-e274-4776-a3d7-58eadb9d96b0	pending	f	\N	2025-10-19 18:00:42.327873
7bc090bc-4ac1-40c7-b99a-644242c39595	7ecad21c-c7b9-415a-b9dc-8294c7d8fd4d	c4f75303-a973-43e1-8f69-dfc6500c302c	pending	f	\N	2025-10-19 18:00:42.327873
53a4028c-d7a4-4a75-a218-7914fe4b0f9e	7ecad21c-c7b9-415a-b9dc-8294c7d8fd4d	0409f8de-7e1d-4245-96c2-02a3b1c90a81	pending	f	\N	2025-10-19 18:00:42.327873
\.


--
-- Data for Name: calendar_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.calendar_events (id, tenant_id, title, description, type, start_time, end_time, all_day, location, client_id, task_id, compliance_id, created_by, metadata, reminder_minutes, is_recurring, recurrence_rule, created_at, updated_at) FROM stdin;
692303a8-e007-423a-b205-4e13ce7c4288	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Client Meeting: TechStart Solutions	Quarterly review meeting to discuss financials and tax planning	meeting	2025-10-20 10:00:00	2025-10-20 11:00:00	f	Conference Room A	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	\N	\N	a2adaa31-8f59-409a-b39b-72568022adb4	\N	30	f	\N	2025-10-19 18:00:42.322415	2025-10-19 18:00:42.322415
f258d08b-b418-49b9-bef5-3bd4e1ed4c89	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Team Planning Session	Monthly planning and review	meeting	2025-10-26 14:00:00	2025-10-26 16:00:00	f	Main Office	\N	\N	\N	a2adaa31-8f59-409a-b39b-72568022adb4	\N	60	f	\N	2025-10-19 18:00:42.322415	2025-10-19 18:00:42.322415
66211bd0-f694-4972-85d9-80d18856c9c7	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	VAT Return Deadline	Submit VAT returns for all registered clients	deadline	2025-10-29 16:00:00	2025-10-29 16:00:00	t	\N	\N	\N	\N	a2adaa31-8f59-409a-b39b-72568022adb4	\N	1440	f	\N	2025-10-19 18:00:42.322415	2025-10-19 18:00:42.322415
7ecad21c-c7b9-415a-b9dc-8294c7d8fd4d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Training: New Tax Regulations	Mandatory training session on updated tax regulations	event	2025-10-31 16:00:00	2025-10-31 18:00:00	f	Virtual - Zoom	\N	\N	\N	a2adaa31-8f59-409a-b39b-72568022adb4	{"meetingLink": "https://zoom.us/j/1234567890"}	120	f	\N	2025-10-19 18:00:42.322415	2025-10-19 18:00:42.322415
c7672d70-1f7c-41dd-8edf-bf042071d717	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Annual Leave	Out of office	out_of_office	2025-11-09 16:00:00	2025-11-16 16:00:00	t	\N	\N	\N	\N	c4f75303-a973-43e1-8f69-dfc6500c302c	\N	\N	f	\N	2025-10-19 18:00:42.322415	2025-10-19 18:00:42.322415
\.


--
-- Data for Name: client_contacts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_contacts (id, tenant_id, client_id, is_primary, title, first_name, middle_name, last_name, email, phone, mobile, job_title, "position", department, address_line_1, address_line_2, city, region, postal_code, country, notes, is_active, created_at, updated_at) FROM stdin;
e479dcf7-6a62-4860-b2c0-6851a2335940	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	t	\N	Melisa	\N	Hackett	Cole.Lowe@gmail.com	375.484.9826	(480) 395-6607 x7940	Principal Implementation Liaison	Principal Implementation Liaison	Garden	5412 Poplar Road	Apt. 289	Volkmanshire	Ohio	YT6 2GS	United Kingdom	\N	t	2025-10-19 18:00:34.041071	2025-10-19 18:00:34.041071
fddde26c-f9af-449a-bfd1-ae9a6d508226	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	8538cc30-f9e7-4b63-a885-56b23e16ecef	t	\N	Prince	\N	Cremin	Piper_Hessel@gmail.com	1-511-334-9389	831-565-7999 x9191	Investor Solutions Consultant	Investor Solutions Consultant	Music	7009 Altenwerth Circles	\N	North Amari	Arkansas	UR6 3MG	United Kingdom	\N	t	2025-10-19 18:00:34.044604	2025-10-19 18:00:34.044604
ba052dd9-78cf-45f9-a714-66e29ce0c1bf	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	8538cc30-f9e7-4b63-a885-56b23e16ecef	f	\N	Lukas	\N	Schumm	Kailee9@yahoo.com	523-567-9154 x936	1-857-271-8986 x740	Regional Accounts Engineer	Regional Accounts Engineer	Shoes	6204 Arianna Point	Suite 418	Jeantown	California	RY9 3YB	United Kingdom	\N	t	2025-10-19 18:00:34.047072	2025-10-19 18:00:34.047072
407f3125-0894-492a-ba87-28cd558666e1	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	8538cc30-f9e7-4b63-a885-56b23e16ecef	f	\N	Danny	\N	Ledner	Monica_Schimmel66@gmail.com	(508) 939-0596 x93836	1-264-963-5601 x0383	Central Optimization Liaison	Central Optimization Liaison	Garden	4359 Johnson Street	Suite 196	Pittsburgh	Florida	UM3 6UP	United Kingdom	\N	t	2025-10-19 18:00:34.051543	2025-10-19 18:00:34.051543
7845a84e-f946-4c4c-b168-0d130434e1d9	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	7ef8af5a-1080-42a2-988f-ddfa799c8070	t	\N	Macy	Anderson	Jast	Cecile_Ryan68@gmail.com	(244) 845-5964 x48942	473-835-6386 x32638	Chief Web Technician	Chief Web Technician	Jewelry	628 Oakfield Road	\N	North Eva	Rhode Island	VX5 5DY	United Kingdom	\N	t	2025-10-19 18:00:34.054602	2025-10-19 18:00:34.054602
09b6a581-5ddd-4ff8-abd3-b556d5ed947e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	7ef8af5a-1080-42a2-988f-ddfa799c8070	f	\N	Stephany	\N	Stamm	Coleman_Roberts@hotmail.com	990-601-1750 x4111	544.787.2951 x7535	Direct Paradigm Executive	Direct Paradigm Executive	Electronics	56560 Kling Ridge	\N	Gaithersburg	Massachusetts	BS3 4EN	United Kingdom	\N	t	2025-10-19 18:00:34.056968	2025-10-19 18:00:34.056968
d8f6f3ba-c941-483d-93ac-63ebfc9aa665	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	7ef8af5a-1080-42a2-988f-ddfa799c8070	f	\N	Alanna	\N	Schumm	Taurean.Swaniawski70@hotmail.com	(956) 394-1089	972-420-6435	Global Infrastructure Planner	Global Infrastructure Planner	Movies	23199 Alfred Street	\N	West Madisonton	Oklahoma	UQ3 0KY	United Kingdom	\N	t	2025-10-19 18:00:34.059476	2025-10-19 18:00:34.059476
f1094904-f4e7-45db-99a2-c1ae6ce054ea	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b0a95e11-90ac-4ab3-b099-c4de69f498b8	t	\N	Marlen	Logan	Boyle	Wilson_Roob29@yahoo.com	(414) 354-4369 x76160	666.844.5832 x2794	Customer Paradigm Assistant	Customer Paradigm Assistant	Tools	45741 Serenity Points	\N	Brandon	Indiana	UW6 1FO	United Kingdom	\N	t	2025-10-19 18:00:34.062077	2025-10-19 18:00:34.062077
c8b33d9f-cc9a-4a5e-b975-3643da420476	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b0a95e11-90ac-4ab3-b099-c4de69f498b8	f	\N	Leatha	\N	O'Conner	Iva.Bradtke36@hotmail.com	(273) 964-8012 x8552	1-863-858-5369	Investor Optimization Architect	Investor Optimization Architect	Tools	3546 S 14th Street	Suite 164	Jeffersonville	Texas	MF1 9FE	United Kingdom	\N	t	2025-10-19 18:00:34.067832	2025-10-19 18:00:34.067832
8c802e35-8432-43c3-8477-d089fef7d8bc	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b0a95e11-90ac-4ab3-b099-c4de69f498b8	f	\N	Jonathan	\N	Rolfson	Braxton_Pouros@gmail.com	(910) 688-3307 x892	847.200.3506 x003	Regional Creative Associate	Regional Creative Associate	Grocery	75146 Beahan Prairie	\N	Waterloo	Kansas	AK6 5GJ	United Kingdom	\N	t	2025-10-19 18:00:34.072786	2025-10-19 18:00:34.072786
90791fc9-8384-4e2b-94d5-85acec599138	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	17f141c2-e297-4c93-9178-0fd819259c50	t	\N	Sienna	North	O'Connell	Junior.Rutherford44@hotmail.com	1-782-497-3198 x3994	(382) 767-7162	Investor Operations Supervisor	Investor Operations Supervisor	Sports	68229 Lockman Shoals	Apt. 391	Cassinstead	Utah	RU8 1CK	United Kingdom	\N	t	2025-10-19 18:00:34.076358	2025-10-19 18:00:34.076358
d5bb991d-8cbd-477d-b554-a568310d68a0	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	17f141c2-e297-4c93-9178-0fd819259c50	f	\N	Theo	\N	Mraz	Carson.Ryan90@gmail.com	1-329-578-2655 x620	(738) 685-9852	Customer Integration Engineer	Customer Integration Engineer	Electronics	5966 Commercial Road	\N	New River	Florida	AV9 3MO	United Kingdom	\N	t	2025-10-19 18:00:34.079635	2025-10-19 18:00:34.079635
82e2b8ef-6035-4ce1-b349-82378152e2a4	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	17f141c2-e297-4c93-9178-0fd819259c50	f	\N	Helga	\N	Ledner	Duncan.Homenick28@yahoo.com	(948) 936-1154 x64286	1-528-651-4734 x3053	International Solutions Planner	International Solutions Planner	Industrial	7217 Stehr Trace	Suite 243	Atascocita	Idaho	JX2 9WL	United Kingdom	\N	t	2025-10-19 18:00:34.082811	2025-10-19 18:00:34.082811
2380aeda-4413-4acf-baa2-6461569c5c5b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	t	\N	Vivien	\N	Hegmann	Francis.Schuppe17@gmail.com	1-252-778-0817 x02185	243.291.1817	Customer Response Executive	Customer Response Executive	Movies	4398 Field Close	\N	Port Marilou	Hawaii	JB8 3DW	United Kingdom	\N	t	2025-10-19 18:00:34.086067	2025-10-19 18:00:34.086067
9e40fa46-38d7-4b3d-862c-291094c2eef2	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	f	\N	Wendell	\N	Powlowski	Santino.Kuphal14@yahoo.com	1-551-958-7239 x93633	829-625-3928 x39551	Product Security Planner	Product Security Planner	Electronics	1957 Commercial Street	Suite 174	Avondale	Kentucky	PN3 2PA	United Kingdom	\N	t	2025-10-19 18:00:34.089625	2025-10-19 18:00:34.089625
09c21331-86e3-4fb6-915b-671e4742732d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	584bab37-ccf2-484c-9a7f-7394e4b30ec6	t	\N	Modesto	Phoenix	Ritchie	Braxton38@gmail.com	1-912-889-3528 x929	374-866-1401	Product Quality Agent	Product Quality Agent	Outdoors	42152 Angel Valley	Suite 840	Port Enos	New York	HT1 7HZ	United Kingdom	\N	t	2025-10-19 18:00:34.094061	2025-10-19 18:00:34.094061
1b786d4c-79af-4606-92b3-1feda8a5b2a8	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	584bab37-ccf2-484c-9a7f-7394e4b30ec6	f	\N	Shanelle	\N	Hegmann	Chaz59@yahoo.com	871.231.6122 x9568	1-365-867-5838 x92727	Central Metrics Consultant	Central Metrics Consultant	Movies	37416 Geovany Tunnel	\N	Merced	Florida	WO9 0RL	United Kingdom	\N	t	2025-10-19 18:00:34.098574	2025-10-19 18:00:34.098574
b0b792e3-2e08-4b1a-ac6b-48dcd1bb3833	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	584bab37-ccf2-484c-9a7f-7394e4b30ec6	f	\N	Lizeth	\N	Pfeffer	Retta_Collins62@yahoo.com	(447) 571-4579 x653	1-384-231-8880 x850	Central Mobility Coordinator	Central Mobility Coordinator	Electronics	973 Garrison Cove	Apt. 231	Cerritos	California	AT6 8SU	United Kingdom	\N	t	2025-10-19 18:00:34.103365	2025-10-19 18:00:34.103365
4d295bb8-bcbe-4cca-8250-16b6c1d32baa	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	12edb785-268b-4219-840d-15b8f0df1198	t	\N	Aliyah	\N	Kertzmann	Cruz.Rolfson@gmail.com	(730) 564-0812 x11088	264-729-2268 x09110	International Brand Officer	International Brand Officer	Clothing	43334 Rodolfo Neck	\N	Roxanneworth	Mississippi	DM2 2QC	United Kingdom	\N	t	2025-10-19 18:00:34.106005	2025-10-19 18:00:34.106005
489afc3d-ba3d-4c9f-9bad-b71370bcf095	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	12edb785-268b-4219-840d-15b8f0df1198	f	\N	Reilly	Bailey	Cartwright	Payton4@hotmail.com	(746) 492-6455 x7724	615.593.2955 x964	Corporate Integration Agent	Corporate Integration Agent	Outdoors	45676 Richmond Close	\N	South Denis	Nebraska	IT6 4FY	United Kingdom	\N	t	2025-10-19 18:00:34.108841	2025-10-19 18:00:34.108841
31553fbc-b308-4016-9e70-fa961bb83104	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0d0329f4-4b80-4899-8807-5854e9db312b	t	\N	Reagan	\N	Durgan	Kareem67@yahoo.com	573-238-4182 x42005	371.597.8887 x8517	Corporate Integration Architect	Corporate Integration Architect	Computers	2495 Wisoky Brooks	Suite 732	Terrybury	New Hampshire	CC0 8YX	United Kingdom	\N	t	2025-10-19 18:00:34.11169	2025-10-19 18:00:34.11169
d12d7afe-9e87-43c3-b45c-a91bdcb5ddf0	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0d0329f4-4b80-4899-8807-5854e9db312b	f	\N	Jerrod	\N	Lehner	Jefferey30@hotmail.com	541-466-5668 x061	(292) 366-6413 x72299	Senior Optimization Administrator	Senior Optimization Administrator	Clothing	265 Claudine Crescent	\N	Lulaboro	Indiana	FG0 9UA	United Kingdom	\N	t	2025-10-19 18:00:34.11684	2025-10-19 18:00:34.11684
8432f905-c2d0-410f-ad69-4ffcd496f99a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0d0329f4-4b80-4899-8807-5854e9db312b	f	\N	Isidro	\N	Kshlerin	Hal73@gmail.com	301-749-1226 x28273	284-943-4161 x8324	International Tactics Consultant	International Tactics Consultant	Grocery	933 The Maltings	\N	Port Orville	Utah	CL9 9FX	United Kingdom	\N	t	2025-10-19 18:00:34.120565	2025-10-19 18:00:34.120565
7cbba1ac-d6a8-45a6-a2f8-629a14bd8b85	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	45b3d726-e151-4770-9b64-4653914bdaa5	t	\N	Raphael	\N	Nienow	Lennie_Cartwright4@gmail.com	400-823-3699 x10994	304-335-1784 x4164	National Tactics Executive	National Tactics Executive	Computers	785 Mante Points	\N	Nitzscheville	Nebraska	SO9 4NW	United Kingdom	\N	t	2025-10-19 18:00:34.124079	2025-10-19 18:00:34.124079
acde64c9-3cb8-4a18-b838-3cfb254f703e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	6a032ece-4f9e-405a-b48a-b28516d15fe1	t	\N	Lonnie	Corey	Pfannerstill	Kareem_Pollich61@hotmail.com	327.933.2747 x026	1-884-507-2579 x489	Customer Tactics Facilitator	Customer Tactics Facilitator	Electronics	1452 Hagenes Roads	\N	Apple Valley	Vermont	SJ1 5AC	United Kingdom	\N	t	2025-10-19 18:00:34.126748	2025-10-19 18:00:34.126748
eba4e3b8-5b73-4243-af5b-772158b8de44	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	6a032ece-4f9e-405a-b48a-b28516d15fe1	f	\N	Vaughn	\N	VonRueden	Gussie_Simonis@hotmail.com	884.884.4135 x98649	1-947-959-8776 x299	International Quality Executive	International Quality Executive	Kids	506 Mount Street	Apt. 423	Camden	Kentucky	MC7 5XX	United Kingdom	\N	t	2025-10-19 18:00:34.129887	2025-10-19 18:00:34.129887
766b53cc-8c6f-4f83-9ba3-0fbceff51933	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	t	\N	Abbey	\N	Friesen	Marilie19@hotmail.com	1-328-282-0808 x475	716.421.5884 x5229	District Infrastructure Officer	District Infrastructure Officer	Outdoors	74709 America Shoals	Apt. 757	Lake Araceli	Mississippi	JT9 4QP	United Kingdom	\N	t	2025-10-19 18:00:34.132917	2025-10-19 18:00:34.132917
aa4ee666-c6b4-4e4f-9190-0e2faf21095e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	f	\N	Chaim	\N	Hahn	Cynthia6@yahoo.com	516-503-7515 x826	348-285-8042 x557	Legacy Applications Analyst	Legacy Applications Analyst	Outdoors	35562 E Elm Street	\N	Somerville	Georgia	WS7 4BQ	United Kingdom	\N	t	2025-10-19 18:00:34.135386	2025-10-19 18:00:34.135386
f893756f-8d27-410e-99d9-3eba8e20558e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	f	\N	Philip	\N	Cassin	June32@yahoo.com	830-254-1591	1-312-804-6102 x1631	Chief Functionality Orchestrator	Chief Functionality Orchestrator	Shoes	129 O'Connell Ways	\N	East Leopoldofort	Oregon	IH2 3XH	United Kingdom	\N	t	2025-10-19 18:00:34.13808	2025-10-19 18:00:34.13808
209c2d7b-bdb9-49dc-94a3-27f2d15a04a6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	46859340-c8cf-4144-aa6c-28fbaf53fa0e	t	\N	Garrick	\N	Hermiston	Margie18@hotmail.com	682.813.2294 x509	689.760.8874 x6710	Legacy Group Architect	Legacy Group Architect	Toys	84270 Steuber Station	Suite 319	Fort Mathilde	Georgia	FY3 0SY	United Kingdom	\N	t	2025-10-19 18:00:34.142654	2025-10-19 18:00:34.142654
4c6e14db-e2d6-4d99-abb1-7ecd88221857	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	65a6152e-a261-4a70-99fb-82f044e87d05	t	\N	Dedric	\N	Borer	Dariana72@gmail.com	537.720.6166 x36341	376-615-7841 x3965	Direct Communications Consultant	Direct Communications Consultant	Jewelry	772 Kuhic Parks	Suite 716	Clemensshire	Virginia	YO6 5DM	United Kingdom	\N	t	2025-10-19 18:00:34.146087	2025-10-19 18:00:34.146087
6b03f52d-bc5e-4bc0-b02a-0a2e37784015	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	t	\N	Mack	\N	Dach	Thurman_Gorczany@gmail.com	1-478-906-5173 x6215	748.303.0800 x49231	Dynamic Solutions Engineer	Dynamic Solutions Engineer	Toys	648 West Street	\N	Port Mariamchester	Utah	NG8 3BI	United Kingdom	\N	t	2025-10-19 18:00:34.148375	2025-10-19 18:00:34.148375
820df9ec-bf69-4857-8133-1b228fbd2731	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	04465623-29cb-4298-8828-d1839e9cc00d	t	\N	Rudy	\N	Wolf	Allan9@hotmail.com	1-405-708-1977	856-505-0727 x2559	Forward Applications Director	Forward Applications Director	Jewelry	2109 Terry Ports	\N	Spokane Valley	West Virginia	GM5 2XY	United Kingdom	\N	t	2025-10-19 18:00:34.150909	2025-10-19 18:00:34.150909
270aa712-a2de-43ab-aef3-3a3ad9ce8ab7	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	4554e09d-4391-42a8-a2cd-9702bce80511	t	\N	Yasmeen	\N	Quitzon	Dejuan1@hotmail.com	(814) 593-6636	(509) 553-5237 x0913	District Functionality Assistant	District Functionality Assistant	Books	86630 E Washington Street	\N	Port Averybury	Nevada	PH8 8XL	United Kingdom	\N	t	2025-10-19 18:00:34.153754	2025-10-19 18:00:34.153754
bc5f7eaf-4660-417e-8292-04ef169b7daa	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	405d4d05-841b-437d-af7d-70b66dda4cbc	t	\N	Camylle	\N	Leffler	Zaria.Lowe10@yahoo.com	1-677-614-1062	857.529.7238 x7092	Internal Quality Officer	Internal Quality Officer	Garden	97088 Finn Ferry	\N	Beierside	Mississippi	MP7 8WD	United Kingdom	\N	t	2025-10-19 18:00:34.156744	2025-10-19 18:00:34.156744
859974cb-6cdb-4e4b-84fe-433990dacddc	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	405d4d05-841b-437d-af7d-70b66dda4cbc	f	\N	Shaina	Bowie	Walsh	Lauriane.Lindgren@hotmail.com	(688) 797-4037 x5661	283.678.8715 x3236	Chief Branding Consultant	Chief Branding Consultant	Baby	5094 Jesse Shoal	\N	Toledo	Oregon	XS6 0WZ	United Kingdom	\N	t	2025-10-19 18:00:34.159666	2025-10-19 18:00:34.159666
a29898c4-fec8-473f-804a-ebbeb03a999f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	405d4d05-841b-437d-af7d-70b66dda4cbc	f	\N	Penelope	\N	Reinger	Yasmeen39@hotmail.com	944.551.9363	373-617-7704 x96999	Investor Functionality Consultant	Investor Functionality Consultant	Beauty	218 Kautzer Estate	\N	Lafayettefort	Louisiana	EM6 4HT	United Kingdom	\N	t	2025-10-19 18:00:34.162103	2025-10-19 18:00:34.162103
416d01f7-410e-47f3-b26d-e2bdc7de0cd4	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	67f62599-7f9f-44e8-bc18-d2ce08ea9919	t	\N	Vaughn	\N	Quigley	Germaine.Thiel10@gmail.com	(237) 505-7236	(415) 617-4845 x5946	Global Usability Analyst	Global Usability Analyst	Music	48451 E 5th Street	\N	Altadena	Oregon	QB2 6EH	United Kingdom	\N	t	2025-10-19 18:00:34.16433	2025-10-19 18:00:34.16433
dd62819c-cacc-4c35-94b7-d77548c9eb9e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	67f62599-7f9f-44e8-bc18-d2ce08ea9919	f	\N	Alfonso	Greer	Russel	Adolfo_Stark22@yahoo.com	736-954-7118 x7286	422.902.5974 x495	Senior Infrastructure Architect	Senior Infrastructure Architect	Health	444 Chapel Hill	Apt. 155	Elkhart	Arizona	GE5 5UA	United Kingdom	\N	t	2025-10-19 18:00:34.16686	2025-10-19 18:00:34.16686
c0eef9ab-caf3-465d-bf2e-0f7083ff8ec8	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	67f62599-7f9f-44e8-bc18-d2ce08ea9919	f	\N	Marcel	Leslie	Denesik	Serenity.Swift@hotmail.com	938-330-2497 x413	384.917.2277 x246	Corporate Accountability Representative	Corporate Accountability Representative	Computers	72820 Market Square	\N	North Antoneville	New Hampshire	HJ2 6UZ	United Kingdom	\N	t	2025-10-19 18:00:34.169861	2025-10-19 18:00:34.169861
0e31c016-a001-4730-8c80-7df32b8da1b7	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	t	\N	Florence	\N	Funk	Casandra.Pagac39@gmail.com	801-660-7361 x9660	916.229.6299 x76805	National Creative Manager	National Creative Manager	Garden	823 Araceli Union	\N	East Filibertoview	Wisconsin	JU5 8KS	United Kingdom	\N	t	2025-10-19 18:00:34.17492	2025-10-19 18:00:34.17492
a36f86a3-a0c6-497e-bf00-88d002670f16	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	f	\N	Millie	Drew	Langosh	Jaleel55@gmail.com	1-661-302-9526 x11487	895.330.8656 x821	Internal Marketing Coordinator	Internal Marketing Coordinator	Beauty	5090 Wyman Grove	\N	Lake Kayton	Ohio	MT4 0PV	United Kingdom	\N	t	2025-10-19 18:00:34.181656	2025-10-19 18:00:34.181656
8fa97542-b28d-4dc2-94bf-68c3ebaec6bf	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	702b5a48-f7a9-464c-8833-1ff6577e50e6	t	\N	Kolby	Kennedy	Steuber	Obie_Senger@gmail.com	413-382-0092	489.444.8368 x282	Legacy Mobility Associate	Legacy Mobility Associate	Music	6402 Reichel Junctions	\N	Fort Hendersoncester	Montana	YQ1 3ZG	United Kingdom	\N	t	2025-10-19 18:00:34.188429	2025-10-19 18:00:34.188429
0c55eb61-2e80-430c-a02a-0382393155bc	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d69d0436-37d7-42a4-b907-3d9c3a091ea6	t	\N	Waino	Reese	Lynch	Roberta_Altenwerth5@yahoo.com	(334) 300-0873 x90374	302-402-8951	District Accountability Engineer	District Accountability Engineer	Toys	40500 Hazel Close	\N	Lake Alphonsoboro	Indiana	GL6 0NU	United Kingdom	\N	t	2025-10-19 18:00:34.193536	2025-10-19 18:00:34.193536
666123e1-e24b-4932-b133-7eeca8ab333e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d69d0436-37d7-42a4-b907-3d9c3a091ea6	f	\N	Luis	\N	Erdman-Schultz	Leo.Goldner@hotmail.com	317-508-2270 x389	1-984-845-4354	Central Optimization Producer	Central Optimization Producer	Health	6020 Derby Road	\N	New Nolan	South Dakota	JO4 1ZS	United Kingdom	\N	t	2025-10-19 18:00:34.202241	2025-10-19 18:00:34.202241
86a1afd2-9607-43aa-98d3-9741fca79036	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a4464f5a-2125-46d9-9f58-7252c9adc16b	t	\N	Wilhelmine	North	Johns	Johathan_Mante@hotmail.com	716.679.3117 x3329	318.848.0488 x2121	Product Factors Representative	Product Factors Representative	Music	643 N 7th Street	\N	Orem	Wisconsin	KO5 0MT	United Kingdom	\N	t	2025-10-19 18:00:34.20543	2025-10-19 18:00:34.20543
d719c5a6-e820-4a2b-9a9e-67fd5bbd3ae7	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	6ecda653-6094-4502-9d1d-6e90d9ea99ed	t	\N	Elvera	\N	Champlin	Brice_Kerluke29@hotmail.com	743.633.0864 x2911	602-884-8376 x110	Corporate Functionality Liaison	Corporate Functionality Liaison	Computers	551 Kilback Rest	Apt. 988	Lake Christellefield	Indiana	AV3 9WQ	United Kingdom	\N	t	2025-10-19 18:00:34.208494	2025-10-19 18:00:34.208494
dfee97c3-f512-4a58-948a-0cf69c86faf6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	6ecda653-6094-4502-9d1d-6e90d9ea99ed	f	\N	Noelia	\N	Lebsack	Marcia_Howe37@hotmail.com	734.989.8901 x33971	570.816.1138 x279	Senior Accountability Specialist	Senior Accountability Specialist	Tools	53500 Schiller Common	Apt. 564	Fort Abdul	Ohio	CY5 1QZ	United Kingdom	\N	t	2025-10-19 18:00:34.21158	2025-10-19 18:00:34.21158
0a02a398-d8d6-4ae3-8413-958702ecc45f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b7295600-5c20-4de2-8782-af87987c2bee	t	\N	Eliseo	Bowie	Corkery	Jennifer22@yahoo.com	691-632-7095 x92268	(352) 728-5548	Dynamic Research Planner	Dynamic Research Planner	Books	3454 Boyer Fords	\N	East Annettaside	Massachusetts	PW2 9AX	United Kingdom	\N	t	2025-10-19 18:00:34.214394	2025-10-19 18:00:34.214394
d292aeac-c8ea-4530-b627-a81e8e172ab5	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b7295600-5c20-4de2-8782-af87987c2bee	f	\N	Wilton	Skyler	Weimann	Vada95@hotmail.com	(597) 801-2197 x065	896.955.7215 x58500	Corporate Integration Specialist	Corporate Integration Specialist	Toys	939 Kamryn Islands	Suite 185	South Kenyattaton	Florida	NL3 1UH	United Kingdom	\N	t	2025-10-19 18:00:34.217829	2025-10-19 18:00:34.217829
\.


--
-- Data for Name: client_directors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_directors (id, tenant_id, client_id, name, officer_role, appointed_on, resigned_on, is_active, nationality, occupation, date_of_birth, address, metadata, created_at, updated_at) FROM stdin;
85e51fa3-7731-4d3d-a228-c2500bc44163	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	17f141c2-e297-4c93-9178-0fd819259c50	Dr. Seth Morar	member	2024-03-04	\N	t	Australian	Director	1977-11	9889 South View Apt. 121	\N	2025-10-19 18:00:34.221704	2025-10-19 18:00:34.221704
eb644c29-16fe-4705-9de8-5ffffef2ff0b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	Anita Rice-Bayer	member	2024-08-23	2025-03-08	f	American	Representative	1994-07	68638 Bath Road Suite 594	\N	2025-10-19 18:00:34.227119	2025-10-19 18:00:34.227119
76af36b4-43e7-40a1-aeba-294de8db1ea8	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	Phyllis Kulas	director	2023-05-09	\N	t	Canadian	Supervisor	1972-07	6941 Myrtice Radial Suite 604	\N	2025-10-19 18:00:34.231186	2025-10-19 18:00:34.231186
c8d5ae8e-5c89-4bf3-9d35-4cc33f8a6f61	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	Miss Rose Wehner	director	2020-05-04	\N	t	Irish	Supervisor	1987-05	8834 South Avenue Suite 686	\N	2025-10-19 18:00:34.234466	2025-10-19 18:00:34.234466
bb2789c3-6079-48bf-aa4d-7f4a02b7b912	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	Rosa Wolf	director	2020-09-12	\N	t	Irish	Representative	1997-06	4964 Faustino Corner Suite 667	\N	2025-10-19 18:00:34.237776	2025-10-19 18:00:34.237776
c56aa2f8-91a8-456d-b461-786c4b39849e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	12edb785-268b-4219-840d-15b8f0df1198	Rolando Hegmann	member	2016-04-07	\N	t	British	Designer	1950-01	466 Conn Loaf Apt. 129	\N	2025-10-19 18:00:34.241692	2025-10-19 18:00:34.241692
c56c2e70-0948-42a6-962f-c497f13415c6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	12edb785-268b-4219-840d-15b8f0df1198	Andre Carroll	secretary	2016-08-14	\N	t	British	Administrator	1970-03	7077 Mariam Ramp Suite 864	\N	2025-10-19 18:00:34.2446	2025-10-19 18:00:34.2446
108ae626-0987-41bc-af66-34b18fdcc089	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	45b3d726-e151-4770-9b64-4653914bdaa5	Ms. June Klocko	secretary	2017-01-10	\N	t	British	Executive	1958-10	91475 Ruecker Drives Suite 124	\N	2025-10-19 18:00:34.24715	2025-10-19 18:00:34.24715
390a31f0-0b5d-4341-b07b-2dfc6420bee2	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	45b3d726-e151-4770-9b64-4653914bdaa5	John Fadel	member	2017-10-22	2023-09-30	f	Canadian	Orchestrator	1971-05	948 Commerce Street Apt. 879	\N	2025-10-19 18:00:34.249633	2025-10-19 18:00:34.249633
efb839bd-a80b-487f-9cdc-ab90d0ec09a5	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	45b3d726-e151-4770-9b64-4653914bdaa5	Molly Turcotte	director	2023-03-07	\N	t	Irish	Consultant	1982-08	2390 Hickle Hill Suite 663	\N	2025-10-19 18:00:34.251862	2025-10-19 18:00:34.251862
b1c4b373-dc92-49e0-bb25-b5f0443df3a1	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	45b3d726-e151-4770-9b64-4653914bdaa5	Gayle Steuber	director	2021-07-04	2024-05-04	f	Canadian	Producer	1950-06	92231 Monahan Glen Suite 421	\N	2025-10-19 18:00:34.254429	2025-10-19 18:00:34.254429
d0cbd760-8197-4057-8d80-b3c5b11f62a5	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	6a032ece-4f9e-405a-b48a-b28516d15fe1	Yvette Considine	director	2019-07-29	\N	t	British	Coordinator	1997-02	832 Furman Throughway Suite 796	\N	2025-10-19 18:00:34.258779	2025-10-19 18:00:34.258779
cba60811-23c3-426b-8f42-4b9fb87a566a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	Jeff Walsh	director	2023-06-12	\N	t	Australian	Developer	1991-12	652 S 4th Street Apt. 235	\N	2025-10-19 18:00:34.263075	2025-10-19 18:00:34.263075
22c600dd-b867-4475-887a-e91636c2c05d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	Ismael Walter	member	2016-07-26	\N	t	Canadian	Engineer	1969-07	45639 Bertrand Hill Apt. 760	\N	2025-10-19 18:00:34.266016	2025-10-19 18:00:34.266016
a860a141-14d3-4489-92a4-42d5c0c7f989	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	Sam Schulist	member	2017-11-18	\N	t	American	Specialist	1991-10	1639 Clair Spur Apt. 295	\N	2025-10-19 18:00:34.268608	2025-10-19 18:00:34.268608
12b5fdda-40f4-4e27-a2e8-ae78c7b5bf23	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	04465623-29cb-4298-8828-d1839e9cc00d	Abel Blick	secretary	2020-03-28	2024-08-08	f	Australian	Officer	1966-03	5390 8th Avenue Suite 240	\N	2025-10-19 18:00:34.271189	2025-10-19 18:00:34.271189
6213caf3-3b64-4286-961b-7ae30bc150d5	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	04465623-29cb-4298-8828-d1839e9cc00d	Shirley Corkery	director	2024-03-31	\N	t	Canadian	Executive	1982-11	6444 7th Street Suite 856	\N	2025-10-19 18:00:34.273692	2025-10-19 18:00:34.273692
5f66f1a8-ed77-4606-bf0f-add803d57d4a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	04465623-29cb-4298-8828-d1839e9cc00d	Marco Baumbach	member	2023-01-28	\N	t	British	Director	1978-03	781 Warren Road Apt. 785	\N	2025-10-19 18:00:34.275842	2025-10-19 18:00:34.275842
7294aef6-a890-4807-8917-19009eebb490	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	04465623-29cb-4298-8828-d1839e9cc00d	Calvin Hodkiewicz	member	2018-06-25	\N	t	British	Facilitator	1967-04	16121 Reichel Ford Apt. 702	\N	2025-10-19 18:00:34.278292	2025-10-19 18:00:34.278292
468a2ec5-e98f-4552-bcad-6d625767a012	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	405d4d05-841b-437d-af7d-70b66dda4cbc	Troy Maggio	secretary	2019-01-24	\N	t	British	Analyst	1975-06	75326 Mertz Fort Suite 901	\N	2025-10-19 18:00:34.282775	2025-10-19 18:00:34.282775
ea9f7234-20e8-4bcf-a442-84807e469355	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	405d4d05-841b-437d-af7d-70b66dda4cbc	Terry Corkery IV	member	2017-04-07	\N	t	American	Producer	1982-02	6952 Nolan Forges Apt. 901	\N	2025-10-19 18:00:34.287684	2025-10-19 18:00:34.287684
6c5a19c0-ae0a-4eb5-b1f5-7a739cbc75c3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	67f62599-7f9f-44e8-bc18-d2ce08ea9919	Jesus Sauer	secretary	2017-02-04	\N	t	Irish	Administrator	1959-12	95471 Will Place Suite 684	\N	2025-10-19 18:00:34.292083	2025-10-19 18:00:34.292083
870cca0a-a60e-4e42-9d57-dc3ed4331df6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	67f62599-7f9f-44e8-bc18-d2ce08ea9919	Jan Miller	director	2025-09-24	\N	t	Canadian	Developer	1991-08	9158 Maureen Shores Suite 756	\N	2025-10-19 18:00:34.296216	2025-10-19 18:00:34.296216
61f441e2-482b-4b97-96cf-804e4d5db5bc	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	67f62599-7f9f-44e8-bc18-d2ce08ea9919	Hubert Metz III	member	2023-09-22	2025-01-10	f	British	Officer	1988-03	6371 Kristy Canyon Suite 207	\N	2025-10-19 18:00:34.300423	2025-10-19 18:00:34.300423
e2b1f2a8-b2a6-4c68-8907-1deea1559c8d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	67f62599-7f9f-44e8-bc18-d2ce08ea9919	Christian Kuhic	secretary	2016-06-26	\N	t	Australian	Strategist	1985-12	577 River Road Apt. 811	\N	2025-10-19 18:00:34.303391	2025-10-19 18:00:34.303391
f8c624ed-1c8b-401f-b554-23ee9cd956a6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	Jerome Dibbert	director	2022-02-23	\N	t	American	Strategist	1971-02	8905 Russel Lodge Apt. 137	\N	2025-10-19 18:00:34.306203	2025-10-19 18:00:34.306203
6e75c99d-40f8-4006-ae1a-fbc723a5606c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	702b5a48-f7a9-464c-8833-1ff6577e50e6	Mr. Brendan Wolff	director	2025-08-21	\N	t	Australian	Specialist	1995-11	368 Makenna Mall Apt. 399	\N	2025-10-19 18:00:34.309576	2025-10-19 18:00:34.309576
9bb48650-ad0b-4170-8cbf-a791b65f4c12	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	702b5a48-f7a9-464c-8833-1ff6577e50e6	Elvira Zemlak	secretary	2023-12-14	\N	t	British	Representative	1985-05	39084 Kirlin Trace Apt. 906	\N	2025-10-19 18:00:34.312609	2025-10-19 18:00:34.312609
37b71699-3f3f-4a18-b3f2-eef591403133	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d69d0436-37d7-42a4-b907-3d9c3a091ea6	Sylvia Witting	member	2023-10-25	\N	t	British	Technician	1996-05	28554 Hunter Village Apt. 679	\N	2025-10-19 18:00:34.316362	2025-10-19 18:00:34.316362
2d159b7d-0bce-45e5-9899-a594066888a7	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d69d0436-37d7-42a4-b907-3d9c3a091ea6	Elaine Runte	director	2019-01-10	\N	t	Canadian	Technician	1977-02	85620 Muriel Freeway Suite 129	\N	2025-10-19 18:00:34.318999	2025-10-19 18:00:34.318999
93e4940c-b728-4958-86e9-db2cf5f216de	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d69d0436-37d7-42a4-b907-3d9c3a091ea6	Casey Schamberger	member	2017-06-02	\N	t	Australian	Consultant	1950-11	59204 6th Street Apt. 973	\N	2025-10-19 18:00:34.321239	2025-10-19 18:00:34.321239
49d3ac6f-7f71-4bdd-b537-a83e384b41a2	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a4464f5a-2125-46d9-9f58-7252c9adc16b	Desiree Auer	secretary	2022-02-10	\N	t	Canadian	Liaison	1990-03	3320 Ephraim Manor Apt. 148	\N	2025-10-19 18:00:34.324178	2025-10-19 18:00:34.324178
d9df9168-ea50-484d-a888-453c6b0c739c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a4464f5a-2125-46d9-9f58-7252c9adc16b	Ms. Madeline Roob	member	2022-10-15	\N	t	Irish	Planner	1957-06	25885 Nannie Keys Apt. 421	\N	2025-10-19 18:00:34.327443	2025-10-19 18:00:34.327443
3b6271b3-2ae0-4db3-80e1-e3d9ada632ca	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	6ecda653-6094-4502-9d1d-6e90d9ea99ed	Mercedes Becker	member	2021-12-14	\N	t	Australian	Technician	1981-10	55885 Gregorio Key Apt. 661	\N	2025-10-19 18:00:34.330288	2025-10-19 18:00:34.330288
\.


--
-- Data for Name: client_portal_access; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_portal_access (id, tenant_id, portal_user_id, client_id, role, granted_by, granted_at, expires_at, is_active, created_at, updated_at) FROM stdin;
c6b42df5-435c-4f72-8507-e932bc5b5455	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	e96ba1d3-31dc-438c-aa14-de5883792a0b	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	admin	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-19 18:00:42.256067	\N	t	2025-10-19 18:00:42.256067	2025-10-19 18:00:42.256067
a6b54459-874e-4028-9c7b-7fb6add36020	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	e96ba1d3-31dc-438c-aa14-de5883792a0b	8538cc30-f9e7-4b63-a885-56b23e16ecef	viewer	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-19 18:00:42.256067	\N	t	2025-10-19 18:00:42.256067	2025-10-19 18:00:42.256067
da964127-de85-4890-8570-919501ddd69e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	624e5ccd-ba85-4742-adea-148662d8328b	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	viewer	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-19 18:00:42.261471	\N	t	2025-10-19 18:00:42.261471	2025-10-19 18:00:42.261471
\.


--
-- Data for Name: client_portal_account; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_portal_account (id, tenant_id, client_id, account_id, provider_id, user_id, access_token, refresh_token, id_token, access_token_expires_at, refresh_token_expires_at, scope, password, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: client_portal_invitations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_portal_invitations (id, tenant_id, email, first_name, last_name, client_ids, role, token, invited_by, status, sent_at, expires_at, accepted_at, revoked_at, revoked_by, metadata, created_at, updated_at) FROM stdin;
095b37c7-9806-48bf-be91-50b1cd145de6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	finance@retailco.com	Michael	Brown	["7ef8af5a-1080-42a2-988f-ddfa799c8070"]	admin	aed9e0d3af915c1b659a205491b59dbb27489877d389c24fd1059b976b9469de	a2adaa31-8f59-409a-b39b-72568022adb4	pending	2025-10-19 18:00:42.267192	2025-10-26 18:00:42.265	\N	\N	\N	\N	2025-10-19 18:00:42.267192	2025-10-19 18:00:42.267192
\.


--
-- Data for Name: client_portal_session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_portal_session (id, tenant_id, client_id, expires_at, token, created_at, updated_at, ip_address, user_agent, user_id) FROM stdin;
\.


--
-- Data for Name: client_portal_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_portal_users (id, tenant_id, email, first_name, last_name, phone, status, last_login_at, invited_by, invited_at, accepted_at, metadata, created_at, updated_at) FROM stdin;
e96ba1d3-31dc-438c-aa14-de5883792a0b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	john.smith@techstart.com	John	Smith	+44 20 1234 5678	active	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-17 11:28:08.306	2025-09-29 00:48:03.797	\N	2025-10-19 18:00:42.249422	2025-10-19 18:00:42.249422
624e5ccd-ba85-4742-adea-148662d8328b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	sarah.williams@techstart.com	Sarah	Williams	+44 20 1234 5679	active	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-21 00:46:48.615	2025-10-05 11:55:25.665	\N	2025-10-19 18:00:42.249422	2025-10-19 18:00:42.249422
\.


--
-- Data for Name: client_portal_verification; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_portal_verification (id, tenant_id, client_id, identifier, value, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: client_pscs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_pscs (id, tenant_id, client_id, name, kind, notified_on, ceased_on, is_active, nationality, date_of_birth, natures_of_control, address, metadata, created_at, updated_at) FROM stdin;
4ef1ae1a-85da-4785-8a86-0b55ac1d0556	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	17f141c2-e297-4c93-9178-0fd819259c50	Winston Walker	individual-person-with-significant-control	2019-04-25	\N	t	American	1952-08	["voting-rights-75-to-100-percent"]	889 Martin Luther King Drive Apt. 444	\N	2025-10-19 18:00:34.333492	2025-10-19 18:00:34.333492
2d83587b-a556-46aa-8438-22cdaa0c577a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	17f141c2-e297-4c93-9178-0fd819259c50	William Cartwright	individual-person-with-significant-control	2020-02-25	\N	t	Canadian	1999-05	["voting-rights-75-to-100-percent"]	49758 Kent Road Suite 397	\N	2025-10-19 18:00:34.337183	2025-10-19 18:00:34.337183
339fbf6e-569c-4674-8800-e83dbdd44276	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	17f141c2-e297-4c93-9178-0fd819259c50	Paul Denesik	individual-person-with-significant-control	2025-03-24	\N	t	Australian	1960-02	["voting-rights-75-to-100-percent", "ownership-of-shares-75-to-100-percent", "significant-influence-or-control"]	4328 Hartmann Locks Suite 413	\N	2025-10-19 18:00:34.340386	2025-10-19 18:00:34.340386
df0873cf-ef2d-4007-b559-746d2df4d3ef	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	Frederick Ledner	corporate-entity-person-with-significant-control	2020-12-24	\N	t	American	1991-06	["ownership-of-shares-75-to-100-percent"]	583 Ankunding Causeway Suite 819	\N	2025-10-19 18:00:34.343753	2025-10-19 18:00:34.343753
86d0b7ae-e522-40dc-ab83-a80891349c9a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	Carol Marvin	individual-person-with-significant-control	2019-09-02	\N	t	American	1956-01	["voting-rights-75-to-100-percent", "ownership-of-shares-25-to-50-percent", "significant-influence-or-control"]	49953 Enrico Extension Suite 672	\N	2025-10-19 18:00:34.346385	2025-10-19 18:00:34.346385
1fa5374c-7dc8-44e5-9938-480c22194ab3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	12edb785-268b-4219-840d-15b8f0df1198	Rebecca Rutherford	corporate-entity-person-with-significant-control	2024-01-07	\N	t	Irish	1990-06	["voting-rights-25-to-50-percent", "voting-rights-50-to-75-percent"]	32435 Dooley Well Apt. 787	\N	2025-10-19 18:00:34.349036	2025-10-19 18:00:34.349036
9a0f7b6d-4cfc-4db6-975b-f96807889975	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	45b3d726-e151-4770-9b64-4653914bdaa5	Jimmie Robel	individual-person-with-significant-control	2023-05-04	\N	t	Canadian	1991-10	["voting-rights-50-to-75-percent", "ownership-of-shares-75-to-100-percent", "right-to-appoint-and-remove-directors"]	1762 Glen Forest Apt. 924	\N	2025-10-19 18:00:34.351562	2025-10-19 18:00:34.351562
8df7cde7-63d7-4076-9ef4-93a67fcb242f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	6a032ece-4f9e-405a-b48a-b28516d15fe1	Doug Borer	individual-person-with-significant-control	2020-03-29	\N	t	Irish	1998-04	["ownership-of-shares-25-to-50-percent", "ownership-of-shares-50-to-75-percent"]	462 Coy Place Apt. 501	\N	2025-10-19 18:00:34.354131	2025-10-19 18:00:34.354131
b243e30b-1a6a-4264-a966-cacfbfeb15b9	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	6a032ece-4f9e-405a-b48a-b28516d15fe1	Kathy Torp	corporate-entity-person-with-significant-control	2024-01-26	\N	t	Australian	1999-02	["significant-influence-or-control", "ownership-of-shares-50-to-75-percent"]	5848 E Walnut Street Apt. 510	\N	2025-10-19 18:00:34.356605	2025-10-19 18:00:34.356605
87746cdf-d191-40a5-8642-173b49683bac	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	6a032ece-4f9e-405a-b48a-b28516d15fe1	Danielle Tromp	corporate-entity-person-with-significant-control	2019-07-05	\N	t	British	1972-08	["right-to-appoint-and-remove-directors", "voting-rights-75-to-100-percent", "ownership-of-shares-75-to-100-percent"]	86957 Dina Union Suite 502	\N	2025-10-19 18:00:34.358905	2025-10-19 18:00:34.358905
7a8291d9-c188-4fc5-bbe4-c34f2ee69bf4	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	Fredrick Zboncak	corporate-entity-person-with-significant-control	2020-09-09	\N	t	Irish	1993-07	["voting-rights-75-to-100-percent"]	5205 State Road Suite 931	\N	2025-10-19 18:00:34.361141	2025-10-19 18:00:34.361141
21c4256c-6d08-4226-809b-59abcade1f28	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	Shelia Friesen	corporate-entity-person-with-significant-control	2024-11-29	\N	t	Australian	1998-01	["right-to-appoint-and-remove-directors", "ownership-of-shares-75-to-100-percent", "significant-influence-or-control"]	8203 Connelly Creek Suite 857	\N	2025-10-19 18:00:34.363285	2025-10-19 18:00:34.363285
3ee26818-213f-494b-b867-af20442453d0	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	04465623-29cb-4298-8828-d1839e9cc00d	Dianna Shields	individual-person-with-significant-control	2020-10-01	\N	t	Irish	1981-07	["ownership-of-shares-75-to-100-percent"]	6963 Ward Heights Apt. 401	\N	2025-10-19 18:00:34.365396	2025-10-19 18:00:34.365396
b55fec0f-3a0c-4854-b0ac-2d9128f915d3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	04465623-29cb-4298-8828-d1839e9cc00d	Herbert Macejkovic	corporate-entity-person-with-significant-control	2018-06-01	\N	t	Irish	1976-12	["ownership-of-shares-75-to-100-percent"]	808 Fourth Avenue Apt. 136	\N	2025-10-19 18:00:34.367635	2025-10-19 18:00:34.367635
b81560d7-95e9-46fb-8841-ca350276753e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	405d4d05-841b-437d-af7d-70b66dda4cbc	Jenny Nikolaus	individual-person-with-significant-control	2024-01-05	\N	t	Irish	1988-12	["significant-influence-or-control", "voting-rights-50-to-75-percent"]	297 Greenholt Grove Apt. 735	\N	2025-10-19 18:00:34.36988	2025-10-19 18:00:34.36988
697c0484-0828-4e41-8422-f4f762680225	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	405d4d05-841b-437d-af7d-70b66dda4cbc	Benjamin Turcotte I	corporate-entity-person-with-significant-control	2021-01-15	2021-12-12	f	Canadian	1997-12	["significant-influence-or-control"]	78812 Lonny Field Suite 437	\N	2025-10-19 18:00:34.372371	2025-10-19 18:00:34.372371
2390beef-58b6-49b2-bef0-106332000037	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	67f62599-7f9f-44e8-bc18-d2ce08ea9919	Dr. Gilbert Stark	individual-person-with-significant-control	2023-09-22	\N	t	British	1958-02	["significant-influence-or-control"]	9161 Corwin Points Suite 242	\N	2025-10-19 18:00:34.374661	2025-10-19 18:00:34.374661
ebcebeeb-d054-4d69-9dee-2763bacbd964	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	67f62599-7f9f-44e8-bc18-d2ce08ea9919	Kim MacGyver	corporate-entity-person-with-significant-control	2022-06-03	2023-02-09	f	Irish	1990-05	["ownership-of-shares-25-to-50-percent", "voting-rights-75-to-100-percent", "right-to-appoint-and-remove-directors"]	67705 Lelia Trail Apt. 983	\N	2025-10-19 18:00:34.376887	2025-10-19 18:00:34.376887
bf1f87be-9fc8-48d3-8f05-0fd492a65a31	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	67f62599-7f9f-44e8-bc18-d2ce08ea9919	Josh Crist	individual-person-with-significant-control	2019-04-28	\N	t	British	1970-10	["ownership-of-shares-50-to-75-percent", "significant-influence-or-control", "voting-rights-25-to-50-percent"]	86469 Keeling Creek Suite 723	\N	2025-10-19 18:00:34.379056	2025-10-19 18:00:34.379056
2b29a3cf-6c3f-4b25-b766-3427eee2a46b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	Carroll Kris	individual-person-with-significant-control	2018-05-15	\N	t	British	1965-03	["right-to-appoint-and-remove-directors", "ownership-of-shares-25-to-50-percent", "ownership-of-shares-50-to-75-percent"]	100 Lake Street Apt. 774	\N	2025-10-19 18:00:34.381444	2025-10-19 18:00:34.381444
b7447b1f-1ee6-4de6-932f-a33b4b50bc57	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	Jackie Bruen	corporate-entity-person-with-significant-control	2018-09-01	\N	t	American	1958-07	["ownership-of-shares-25-to-50-percent"]	669 Kuhn Knoll Apt. 924	\N	2025-10-19 18:00:34.384428	2025-10-19 18:00:34.384428
f9906282-2994-4e4e-ab59-efcd3ce210c7	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	702b5a48-f7a9-464c-8833-1ff6577e50e6	Juana Veum	individual-person-with-significant-control	2023-07-23	\N	t	British	1970-07	["ownership-of-shares-50-to-75-percent", "voting-rights-25-to-50-percent", "voting-rights-50-to-75-percent"]	931 Herman Unions Suite 928	\N	2025-10-19 18:00:34.388358	2025-10-19 18:00:34.388358
17591014-6277-4959-8ff9-e4c48d138a8b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d69d0436-37d7-42a4-b907-3d9c3a091ea6	Jack Stark	corporate-entity-person-with-significant-control	2021-04-18	\N	t	Canadian	1985-02	["ownership-of-shares-75-to-100-percent", "voting-rights-75-to-100-percent"]	721 Brandyn Haven Apt. 946	\N	2025-10-19 18:00:34.390824	2025-10-19 18:00:34.390824
97663a0d-7063-4e79-96a1-fdcf58f7d554	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d69d0436-37d7-42a4-b907-3d9c3a091ea6	Eva Kassulke	corporate-entity-person-with-significant-control	2022-08-07	\N	t	Canadian	1986-11	["voting-rights-50-to-75-percent", "voting-rights-75-to-100-percent", "voting-rights-25-to-50-percent"]	70179 Somerset Road Apt. 111	\N	2025-10-19 18:00:34.392957	2025-10-19 18:00:34.392957
3211b981-1c64-4849-a281-3fe06b7492e2	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d69d0436-37d7-42a4-b907-3d9c3a091ea6	Kathy Paucek	individual-person-with-significant-control	2020-01-18	\N	t	Irish	1994-01	["significant-influence-or-control", "voting-rights-25-to-50-percent", "voting-rights-75-to-100-percent"]	9283 Schowalter Port Apt. 750	\N	2025-10-19 18:00:34.395042	2025-10-19 18:00:34.395042
2a847c7c-8efc-477b-8bee-299d45e3c7e8	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a4464f5a-2125-46d9-9f58-7252c9adc16b	Ryan Oberbrunner	corporate-entity-person-with-significant-control	2017-12-11	\N	t	Australian	1969-08	["right-to-appoint-and-remove-directors", "ownership-of-shares-50-to-75-percent"]	92501 Poplar Avenue Suite 136	\N	2025-10-19 18:00:34.397019	2025-10-19 18:00:34.397019
fe2a8b67-637b-4a7d-b18d-7d7a60428edd	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a4464f5a-2125-46d9-9f58-7252c9adc16b	Alfredo Johnson	individual-person-with-significant-control	2025-05-28	\N	t	British	1965-12	["significant-influence-or-control"]	352 Cartwright Squares Apt. 310	\N	2025-10-19 18:00:34.399533	2025-10-19 18:00:34.399533
25eb6211-b7e2-4d3c-b489-954b90db4017	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	6ecda653-6094-4502-9d1d-6e90d9ea99ed	Miss Vicky Mraz	corporate-entity-person-with-significant-control	2024-07-03	\N	t	Canadian	1952-01	["right-to-appoint-and-remove-directors"]	488 Main Street W Apt. 608	\N	2025-10-19 18:00:34.401526	2025-10-19 18:00:34.401526
72bd344e-40cd-4903-bab7-f34a4480e4f3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	6ecda653-6094-4502-9d1d-6e90d9ea99ed	Mary Lueilwitz	individual-person-with-significant-control	2022-05-08	\N	t	British	1957-07	["ownership-of-shares-25-to-50-percent"]	19249 3rd Street Apt. 871	\N	2025-10-19 18:00:34.403682	2025-10-19 18:00:34.403682
\.


--
-- Data for Name: client_services; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_services (id, tenant_id, client_id, service_component_id, custom_rate, start_date, end_date, is_active, created_at, updated_at) FROM stdin;
6ddc7b86-01a8-4419-aafa-b988cfc618b9	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	d04961e2-5af7-4b9c-bb44-c37031dd6bfa	\N	2024-06-10	\N	t	2025-10-19 18:00:34.405777	2025-10-19 18:00:34.405777
63cf8743-511a-46c5-92f9-41b0fc03af92	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	1ede1cc0-3627-404e-bb8a-487e028f4732	\N	2025-03-05	\N	t	2025-10-19 18:00:34.409638	2025-10-19 18:00:34.409638
1079d2dc-0f31-4cca-bfb8-4eea35a2119d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	3f2e9a8e-bdfe-4d09-aced-e88cdc710462	\N	2024-02-25	\N	t	2025-10-19 18:00:34.413227	2025-10-19 18:00:34.413227
b26b903b-5288-46be-a781-ca11b71e0dab	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	\N	2025-06-22	\N	t	2025-10-19 18:00:34.416744	2025-10-19 18:00:34.416744
d3433132-0c62-4425-bc0a-d81b78d98af6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	8538cc30-f9e7-4b63-a885-56b23e16ecef	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	48.88	2025-05-24	\N	t	2025-10-19 18:00:34.419955	2025-10-19 18:00:34.419955
594adc71-d032-40b9-a283-b5f3e74c306f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	8538cc30-f9e7-4b63-a885-56b23e16ecef	109283c7-55ef-4e05-bf53-c6efd1be486f	\N	2024-12-18	\N	t	2025-10-19 18:00:34.423864	2025-10-19 18:00:34.423864
692acb7e-3f14-4b89-9236-4d47e92ddfde	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	8538cc30-f9e7-4b63-a885-56b23e16ecef	a49c064a-0890-4c02-8734-07a3185e6c03	\N	2024-02-19	\N	t	2025-10-19 18:00:34.427618	2025-10-19 18:00:34.427618
6eee452e-4779-431c-a2b3-37b5f5d0cbb4	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	8538cc30-f9e7-4b63-a885-56b23e16ecef	18c91d63-8f9d-4974-ba97-a4079c7457d5	82.49	2025-06-09	\N	t	2025-10-19 18:00:34.43098	2025-10-19 18:00:34.43098
ea7cd72e-6e48-49cc-8dde-68f4f00b6d6a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	7ef8af5a-1080-42a2-988f-ddfa799c8070	79d01aa5-b680-4830-ab3a-5e3cb66edcfa	\N	2025-04-05	\N	t	2025-10-19 18:00:34.434531	2025-10-19 18:00:34.434531
e5064eb1-f7f3-4c9d-8e80-ecd58bc38b3a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	7ef8af5a-1080-42a2-988f-ddfa799c8070	cbf9b499-276b-4a28-999c-27388562c4f4	\N	2024-01-13	\N	t	2025-10-19 18:00:34.437924	2025-10-19 18:00:34.437924
c9fc8684-1ef5-4341-9c2d-74e69e6db764	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b0a95e11-90ac-4ab3-b099-c4de69f498b8	e4487405-7859-40e9-8008-056d32fe6f10	\N	2024-01-04	\N	t	2025-10-19 18:00:34.441248	2025-10-19 18:00:34.441248
3202374f-f650-4612-b1ff-94210133ee2c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	17f141c2-e297-4c93-9178-0fd819259c50	ecfd2c2c-905b-4ef4-99a4-8949632b9ae9	\N	2025-01-25	\N	t	2025-10-19 18:00:34.444612	2025-10-19 18:00:34.444612
1a4c5269-c3d4-4006-9c0a-3cb5cdd0f3a8	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	17f141c2-e297-4c93-9178-0fd819259c50	235b548d-f0a0-4899-9a7e-d6e9bec6db40	\N	2024-09-20	\N	t	2025-10-19 18:00:34.447821	2025-10-19 18:00:34.447821
747371ab-7bc1-4697-a657-14c745d14d4d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	17f141c2-e297-4c93-9178-0fd819259c50	9362cf11-827c-459a-8ffc-6634bd023508	\N	2024-10-26	\N	t	2025-10-19 18:00:34.451225	2025-10-19 18:00:34.451225
bef7cd49-c3fb-4075-b8c9-bdd6953df1bd	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	17f141c2-e297-4c93-9178-0fd819259c50	29a61f52-d957-4207-b54b-7fc565a57541	\N	2024-06-20	\N	t	2025-10-19 18:00:34.454661	2025-10-19 18:00:34.454661
f3ff4277-a484-4ad2-8138-41df441afb45	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	9362cf11-827c-459a-8ffc-6634bd023508	\N	2024-02-12	\N	t	2025-10-19 18:00:34.458238	2025-10-19 18:00:34.458238
ee65b904-5160-4454-8076-5edb1da2bbb9	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	a49c064a-0890-4c02-8734-07a3185e6c03	\N	2024-03-13	\N	t	2025-10-19 18:00:34.462201	2025-10-19 18:00:34.462201
677ae07f-3327-4a13-bd6d-525ab421d072	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	584bab37-ccf2-484c-9a7f-7394e4b30ec6	08ee5378-067c-4708-886c-34df4c200b23	28.16	2025-08-28	\N	t	2025-10-19 18:00:34.466094	2025-10-19 18:00:34.466094
01b6ee4a-178f-4ce5-afa0-8970a691ef08	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	12edb785-268b-4219-840d-15b8f0df1198	e2cd4da6-f171-436c-9c7e-a9c1c5436b98	\N	2024-06-04	\N	t	2025-10-19 18:00:34.471171	2025-10-19 18:00:34.471171
d1d3da60-85ff-4c56-a9bd-beabea1b69b2	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	12edb785-268b-4219-840d-15b8f0df1198	996aa78c-cfd1-477f-8c30-d9489225b29e	\N	2025-03-30	\N	t	2025-10-19 18:00:34.475971	2025-10-19 18:00:34.475971
31c9bb3b-b385-499e-8aec-87889004cf60	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	12edb785-268b-4219-840d-15b8f0df1198	cbf9b499-276b-4a28-999c-27388562c4f4	72.29	2023-11-16	\N	t	2025-10-19 18:00:34.48047	2025-10-19 18:00:34.48047
ab200675-ac1e-49e3-ba00-2417e11242ff	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0d0329f4-4b80-4899-8807-5854e9db312b	996aa78c-cfd1-477f-8c30-d9489225b29e	\N	2025-10-12	\N	t	2025-10-19 18:00:34.484312	2025-10-19 18:00:34.484312
9508e168-bd1c-4c08-8346-06c4b2beadc5	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0d0329f4-4b80-4899-8807-5854e9db312b	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	\N	2023-11-29	\N	t	2025-10-19 18:00:34.488565	2025-10-19 18:00:34.488565
cd41b6b7-a675-436a-84a5-2438d9807198	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0d0329f4-4b80-4899-8807-5854e9db312b	ff4a2600-29fe-4448-bec3-ea868988a9ed	\N	2024-08-28	\N	t	2025-10-19 18:00:34.491937	2025-10-19 18:00:34.491937
ce9b423f-ff07-4fed-aefd-febde1054bda	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0d0329f4-4b80-4899-8807-5854e9db312b	a96c9f4d-dc33-4af3-818d-8d729f0f8c1f	1310.38	2023-11-29	\N	t	2025-10-19 18:00:34.495171	2025-10-19 18:00:34.495171
061cffdf-57be-44f9-8b4b-daaad1097392	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	45b3d726-e151-4770-9b64-4653914bdaa5	d04961e2-5af7-4b9c-bb44-c37031dd6bfa	4.83	2024-12-05	\N	t	2025-10-19 18:00:34.499813	2025-10-19 18:00:34.499813
0dbf11cd-c03f-4146-9686-1554b8e163c5	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	45b3d726-e151-4770-9b64-4653914bdaa5	78882562-2120-44d2-9286-03e696abbf02	31.35	2024-09-08	\N	t	2025-10-19 18:00:34.503624	2025-10-19 18:00:34.503624
131cc55d-834d-48b4-af8b-0776e86bf87d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	45b3d726-e151-4770-9b64-4653914bdaa5	391f7d87-df5d-4538-9b3e-31e07ac9347e	\N	2025-07-05	\N	t	2025-10-19 18:00:34.507745	2025-10-19 18:00:34.507745
5dc4cca3-5e88-4e7c-a956-a682b3d310d1	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	45b3d726-e151-4770-9b64-4653914bdaa5	08ee5378-067c-4708-886c-34df4c200b23	\N	2025-03-12	\N	t	2025-10-19 18:00:34.510367	2025-10-19 18:00:34.510367
1f0ad88d-a815-48c4-982b-90cc65d0cb14	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	6a032ece-4f9e-405a-b48a-b28516d15fe1	a49c064a-0890-4c02-8734-07a3185e6c03	122.70	2023-11-06	\N	t	2025-10-19 18:00:34.512617	2025-10-19 18:00:34.512617
e5ce296c-0e44-40e8-ae0e-841f1d3c9fb0	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	6a032ece-4f9e-405a-b48a-b28516d15fe1	d04961e2-5af7-4b9c-bb44-c37031dd6bfa	5.31	2024-10-25	\N	t	2025-10-19 18:00:34.514652	2025-10-19 18:00:34.514652
ba07a328-be43-47bb-a506-8f4f07a361b9	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	6a032ece-4f9e-405a-b48a-b28516d15fe1	9362cf11-827c-459a-8ffc-6634bd023508	\N	2025-01-31	\N	t	2025-10-19 18:00:34.516907	2025-10-19 18:00:34.516907
c2ce53f4-441f-46d6-81cb-bb2cecfe4495	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	e4487405-7859-40e9-8008-056d32fe6f10	37.51	2025-03-31	\N	t	2025-10-19 18:00:34.52137	2025-10-19 18:00:34.52137
bd0772e2-b839-4f1d-bc74-b2f5f60ebba9	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	46859340-c8cf-4144-aa6c-28fbaf53fa0e	e2cd4da6-f171-436c-9c7e-a9c1c5436b98	45.46	2024-08-06	\N	t	2025-10-19 18:00:34.523958	2025-10-19 18:00:34.523958
acf71dcb-e9f8-4415-84ff-6ba4244a3534	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	46859340-c8cf-4144-aa6c-28fbaf53fa0e	ecfd2c2c-905b-4ef4-99a4-8949632b9ae9	\N	2025-09-05	\N	t	2025-10-19 18:00:34.526752	2025-10-19 18:00:34.526752
cc6a1732-3af4-498a-b78b-de3579d92293	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	65a6152e-a261-4a70-99fb-82f044e87d05	ef53422c-1305-4831-bf41-d85b2a76b0d5	4.11	2024-03-13	\N	t	2025-10-19 18:00:34.529358	2025-10-19 18:00:34.529358
03863a91-462e-4796-b1e2-e0466520618a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	65a6152e-a261-4a70-99fb-82f044e87d05	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	\N	2025-03-06	\N	t	2025-10-19 18:00:34.532126	2025-10-19 18:00:34.532126
a780d5d8-d6ae-4444-94b7-d151c555a55d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	65a6152e-a261-4a70-99fb-82f044e87d05	29a61f52-d957-4207-b54b-7fc565a57541	5.19	2025-02-17	\N	t	2025-10-19 18:00:34.534977	2025-10-19 18:00:34.534977
09034da7-ad0b-4d15-9cba-9a58e3aa2b90	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	29a61f52-d957-4207-b54b-7fc565a57541	\N	2024-10-01	\N	t	2025-10-19 18:00:34.537632	2025-10-19 18:00:34.537632
3cd354f0-4761-4112-91b5-57bcd51c8cc4	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	1ede1cc0-3627-404e-bb8a-487e028f4732	\N	2024-02-03	\N	t	2025-10-19 18:00:34.540926	2025-10-19 18:00:34.540926
e06ed022-732a-45cf-ba57-bd24a5bb9a05	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	04465623-29cb-4298-8828-d1839e9cc00d	78882562-2120-44d2-9286-03e696abbf02	\N	2025-08-29	\N	t	2025-10-19 18:00:34.544131	2025-10-19 18:00:34.544131
3ef21d38-57bf-43dd-9786-bd64fe39a289	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	04465623-29cb-4298-8828-d1839e9cc00d	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	54.47	2024-06-22	\N	t	2025-10-19 18:00:34.546953	2025-10-19 18:00:34.546953
594fb625-68f5-4439-920d-72279cf16ac7	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	04465623-29cb-4298-8828-d1839e9cc00d	a0801828-5c53-41ef-9b3e-06db89d72e90	\N	2025-05-28	\N	t	2025-10-19 18:00:34.549497	2025-10-19 18:00:34.549497
dbc97f8b-f53e-4362-a044-a4fa39482212	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	4554e09d-4391-42a8-a2cd-9702bce80511	3f2e9a8e-bdfe-4d09-aced-e88cdc710462	\N	2023-11-26	\N	t	2025-10-19 18:00:34.551822	2025-10-19 18:00:34.551822
453a43b3-747a-455b-8890-6e143779631c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	4554e09d-4391-42a8-a2cd-9702bce80511	391f7d87-df5d-4538-9b3e-31e07ac9347e	\N	2024-02-09	\N	t	2025-10-19 18:00:34.554823	2025-10-19 18:00:34.554823
25e03906-4ba0-4a55-b9ec-bca3bf7dbe94	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	405d4d05-841b-437d-af7d-70b66dda4cbc	ff4a2600-29fe-4448-bec3-ea868988a9ed	19.98	2024-08-02	\N	t	2025-10-19 18:00:34.556769	2025-10-19 18:00:34.556769
688e8cd9-9581-4cbf-a71a-9e8be006f74e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	67f62599-7f9f-44e8-bc18-d2ce08ea9919	9362cf11-827c-459a-8ffc-6634bd023508	\N	2024-05-28	\N	t	2025-10-19 18:00:34.55838	2025-10-19 18:00:34.55838
3cc64fcb-84f3-4ec3-8a11-6ab744b8ec7a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	a96c9f4d-dc33-4af3-818d-8d729f0f8c1f	\N	2024-03-30	\N	t	2025-10-19 18:00:34.56017	2025-10-19 18:00:34.56017
205711ff-4ab9-4d11-9073-c804b9616dbc	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	702b5a48-f7a9-464c-8833-1ff6577e50e6	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	59.17	2025-01-20	\N	t	2025-10-19 18:00:34.562596	2025-10-19 18:00:34.562596
88680f55-231a-4fd6-9f01-f2fc8243c618	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d69d0436-37d7-42a4-b907-3d9c3a091ea6	a96c9f4d-dc33-4af3-818d-8d729f0f8c1f	1526.46	2025-06-27	\N	t	2025-10-19 18:00:34.565758	2025-10-19 18:00:34.565758
001f5255-37da-4658-862a-05be0c0dca8d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d69d0436-37d7-42a4-b907-3d9c3a091ea6	ca413110-b7e3-4734-a185-d21ea0960708	57.68	2023-11-28	\N	t	2025-10-19 18:00:34.569438	2025-10-19 18:00:34.569438
ad58aa65-4dba-41c8-bcc4-347774fd5134	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a4464f5a-2125-46d9-9f58-7252c9adc16b	9362cf11-827c-459a-8ffc-6634bd023508	174.47	2025-07-16	\N	t	2025-10-19 18:00:34.572713	2025-10-19 18:00:34.572713
d0cb7307-42d7-40ea-ab16-fbbe952e603e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a4464f5a-2125-46d9-9f58-7252c9adc16b	e4487405-7859-40e9-8008-056d32fe6f10	\N	2024-11-23	\N	t	2025-10-19 18:00:34.576359	2025-10-19 18:00:34.576359
990ed159-13bf-4d4c-a6ea-c2eb769e17f2	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a4464f5a-2125-46d9-9f58-7252c9adc16b	ecfd2c2c-905b-4ef4-99a4-8949632b9ae9	10.17	2025-06-24	\N	t	2025-10-19 18:00:34.579808	2025-10-19 18:00:34.579808
4b6606c8-f906-4d20-bc8e-70b12bc6b9cd	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a4464f5a-2125-46d9-9f58-7252c9adc16b	08ee5378-067c-4708-886c-34df4c200b23	26.70	2024-03-30	\N	t	2025-10-19 18:00:34.583082	2025-10-19 18:00:34.583082
c973ab7e-4eb8-4727-9ab9-62672fc0a0dc	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	6ecda653-6094-4502-9d1d-6e90d9ea99ed	78882562-2120-44d2-9286-03e696abbf02	\N	2024-08-09	\N	t	2025-10-19 18:00:34.587538	2025-10-19 18:00:34.587538
3f37e7e1-224e-4655-b988-23b035e8c46b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	6ecda653-6094-4502-9d1d-6e90d9ea99ed	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	70.51	2025-03-07	\N	t	2025-10-19 18:00:34.591696	2025-10-19 18:00:34.591696
6b778793-c169-4cc3-ad66-1a5baf1492e6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	6ecda653-6094-4502-9d1d-6e90d9ea99ed	d6d7e47b-cd48-48d8-a45a-fa75af1f9a52	\N	2023-11-10	\N	t	2025-10-19 18:00:34.59522	2025-10-19 18:00:34.59522
22e5231d-9200-4735-bf91-7837505957cc	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b7295600-5c20-4de2-8782-af87987c2bee	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	\N	2024-03-07	\N	t	2025-10-19 18:00:34.599933	2025-10-19 18:00:34.599933
22ce82db-97e1-4472-aea6-844624a0cbb8	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b7295600-5c20-4de2-8782-af87987c2bee	a8a65b80-dc4c-49f9-9c8d-0dc4a336cf55	\N	2025-02-24	\N	t	2025-10-19 18:00:34.604074	2025-10-19 18:00:34.604074
5de428b0-d9af-45ee-a995-8d94592bc4ba	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b7295600-5c20-4de2-8782-af87987c2bee	29a61f52-d957-4207-b54b-7fc565a57541	4.36	2025-06-04	\N	t	2025-10-19 18:00:34.60785	2025-10-19 18:00:34.60785
13cc4fed-2077-4a47-9078-8761dc205257	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b7295600-5c20-4de2-8782-af87987c2bee	18c91d63-8f9d-4974-ba97-a4079c7457d5	115.94	2024-04-15	\N	t	2025-10-19 18:00:34.611846	2025-10-19 18:00:34.611846
\.


--
-- Data for Name: client_transaction_data; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_transaction_data (id, tenant_id, lead_id, client_id, monthly_transactions, data_source, xero_data_json, last_updated, created_at) FROM stdin;
\.


--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clients (id, tenant_id, client_code, name, type, status, email, phone, website, vat_registered, vat_number, registration_number, address_line1, address_line2, city, state, postal_code, country, account_manager_id, parent_client_id, incorporation_date, year_end, notes, health_score, metadata, created_at, updated_at, created_by) FROM stdin;
bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	CLI-0001	Constance Mante	trust	prospect	Madalyn.Willms10@yahoo.com	1-889-767-4347 x9671	\N	f	\N	\N	89045 Bechtelar Turnpike	\N	Schuppemouth	\N	VC2 2ML	United Kingdom	c4f75303-a973-43e1-8f69-dfc6500c302c	\N	\N	\N	Aspicio tenus vestrum peior arcus depraedor cotidie.	42	\N	2025-10-19 18:00:34.026992	2025-10-19 18:00:34.026992	a2adaa31-8f59-409a-b39b-72568022adb4
8538cc30-f9e7-4b63-a885-56b23e16ecef	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	CLI-0002	Gilberto Mante	individual	prospect	Kiera35@yahoo.com	327-599-5273 x4236	\N	f	\N	\N	77891 Grove Street	\N	Tigard	\N	BF2 6CD	United Kingdom	c4f75303-a973-43e1-8f69-dfc6500c302c	\N	\N	\N	Sit non sum casus velut decimus accusator vitiosus solio.	78	\N	2025-10-19 18:00:34.026992	2025-10-19 18:00:34.026992	a2adaa31-8f59-409a-b39b-72568022adb4
7ef8af5a-1080-42a2-988f-ddfa799c8070	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	CLI-0003	Jeremy Larson	trust	prospect	Hassie.Boyle46@yahoo.com	774.297.1363 x1182	\N	f	\N	\N	5486 Anita Drives	\N	St. George	\N	YB5 4AJ	United Kingdom	d6f36046-e274-4776-a3d7-58eadb9d96b0	\N	\N	\N	Tumultus tergum cui thalassinus varietas celebrer vox ultio.	72	\N	2025-10-19 18:00:34.026992	2025-10-19 18:00:34.026992	a2adaa31-8f59-409a-b39b-72568022adb4
b0a95e11-90ac-4ab3-b099-c4de69f498b8	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	CLI-0004	Silvia Will	individual	onboarding	Calista.Rosenbaum@yahoo.com	871-272-2425	\N	f	\N	\N	448 Bauch Motorway	\N	Mohammadbury	\N	VM5 6MQ	United Kingdom	a2adaa31-8f59-409a-b39b-72568022adb4	\N	\N	\N	Autem cerno carpo argentum tepidus cattus.	82	\N	2025-10-19 18:00:34.026992	2025-10-19 18:00:34.026992	a2adaa31-8f59-409a-b39b-72568022adb4
17f141c2-e297-4c93-9178-0fd819259c50	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	CLI-0005	Jerde LLC	partnership	onboarding	Dalton.Bashirian23@gmail.com	(977) 431-9583 x7179	https://good-natured-disconnection.info	t	GB440677374	IBQPPB1H	4798 Pierce Ports	\N	Sammiefort	\N	CI4 0PR	United Kingdom	d6f36046-e274-4776-a3d7-58eadb9d96b0	\N	2019-10-08	04-11	Xiphias dignissimos depromo audentia.	71	\N	2025-10-19 18:00:34.026992	2025-10-19 18:00:34.026992	a2adaa31-8f59-409a-b39b-72568022adb4
46f2f706-8455-47eb-9d08-a3a8fea6bf0b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	CLI-0006	Grimes, Predovic and Goodwin	partnership	onboarding	Ubaldo_Herzog92@yahoo.com	(590) 360-3626	https://respectful-jet.com/	t	GB292813954	1CLH3K40	40529 Marilou Meadow	\N	Maidaville	\N	UD6 2AQ	United Kingdom	c4f75303-a973-43e1-8f69-dfc6500c302c	\N	2022-03-23	08-31	Pel vilicus argentum auctus arma summisse.	53	\N	2025-10-19 18:00:34.026992	2025-10-19 18:00:34.026992	a2adaa31-8f59-409a-b39b-72568022adb4
584bab37-ccf2-484c-9a7f-7394e4b30ec6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	CLI-0007	Latoya Crooks	trust	inactive	Miguel.Brown-Rosenbaum@hotmail.com	(944) 761-3690 x0425	\N	f	\N	\N	5222 Stamm Viaduct	\N	Perth Amboy	\N	FT6 3WN	United Kingdom	0409f8de-7e1d-4245-96c2-02a3b1c90a81	\N	\N	\N	Tracto aptus dens arcesso.	88	\N	2025-10-19 18:00:34.026992	2025-10-19 18:00:34.026992	a2adaa31-8f59-409a-b39b-72568022adb4
12edb785-268b-4219-840d-15b8f0df1198	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	CLI-0008	Schamberger LLC	partnership	inactive	Cale_Bartoletti@gmail.com	(926) 208-4334 x8445	https://babyish-operating.name	t	GB060543922	VEY2QAJA	5836 Neva Haven	\N	Germantown	\N	RV4 9PT	United Kingdom	c4f75303-a973-43e1-8f69-dfc6500c302c	\N	2025-02-15	10-01	Voluptatibus calco audax dolor.	100	\N	2025-10-19 18:00:34.026992	2025-10-19 18:00:34.026992	a2adaa31-8f59-409a-b39b-72568022adb4
0d0329f4-4b80-4899-8807-5854e9db312b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	CLI-0009	Faye Gleichner	individual	active	Chadrick.Yundt@gmail.com	1-733-888-1349 x5805	\N	f	\N	\N	9391 Wava Views	\N	Americaton	\N	IJ7 8OI	United Kingdom	d6f36046-e274-4776-a3d7-58eadb9d96b0	\N	\N	\N	Tamdiu utor caute stillicidium.	37	\N	2025-10-19 18:00:34.026992	2025-10-19 18:00:34.026992	a2adaa31-8f59-409a-b39b-72568022adb4
45b3d726-e151-4770-9b64-4653914bdaa5	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	CLI-0010	Ruecker - Jerde	company	onboarding	Era_Boyer56@hotmail.com	(378) 266-0714 x05457	https://hungry-embarrassment.name	t	GB510680728	ISVU8WCC	3153 Kendrick Parkways	\N	Fort Beauview	\N	RF2 6UO	United Kingdom	a2adaa31-8f59-409a-b39b-72568022adb4	\N	2023-08-23	08-12	Umbra vix delego deorsum occaecati vilitas corrigo patrocinor placeat laborum.	80	\N	2025-10-19 18:00:34.026992	2025-10-19 18:00:34.026992	a2adaa31-8f59-409a-b39b-72568022adb4
6a032ece-4f9e-405a-b48a-b28516d15fe1	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	CLI-0011	Ernser and Sons	partnership	onboarding	Thurman.Veum@yahoo.com	328.869.1638	https://insidious-provision.com	t	GB026471999	3JB5ZYFI	5124 Nils Greens	\N	Tempe	\N	YT0 3AB	United Kingdom	c4f75303-a973-43e1-8f69-dfc6500c302c	\N	2025-09-01	06-19	Varius suffragium demum.	59	\N	2025-10-19 18:00:34.026992	2025-10-19 18:00:34.026992	a2adaa31-8f59-409a-b39b-72568022adb4
d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	CLI-0012	Pacocha - Ziemann	partnership	inactive	Selena_Wyman9@gmail.com	262-672-2396 x902	https://tangible-signature.com/	t	GB640753227	QHGHQAFA	127 Terrill Mall	\N	Mertiefurt	\N	HA5 8MU	United Kingdom	d6f36046-e274-4776-a3d7-58eadb9d96b0	\N	2019-08-09	09-12	Cinis conforto cinis tergum abeo ago decet casso.	93	\N	2025-10-19 18:00:34.026992	2025-10-19 18:00:34.026992	a2adaa31-8f59-409a-b39b-72568022adb4
46859340-c8cf-4144-aa6c-28fbaf53fa0e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	CLI-0013	Noah Walsh V	individual	onboarding	Orville.OReilly@hotmail.com	504-643-7107 x82602	\N	f	\N	\N	6249 Kovacek Plaza	\N	Desmondfield	\N	DE1 3CK	United Kingdom	0409f8de-7e1d-4245-96c2-02a3b1c90a81	\N	\N	\N	Vitae tum amplus libero amitto utique consectetur velit ante reprehenderit.	55	\N	2025-10-19 18:00:34.026992	2025-10-19 18:00:34.026992	a2adaa31-8f59-409a-b39b-72568022adb4
65a6152e-a261-4a70-99fb-82f044e87d05	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	CLI-0014	Evelyn Lubowitz	trust	onboarding	Noel4@gmail.com	(884) 237-9218 x36536	\N	f	\N	\N	7114 Runte Drive	\N	Fort Worth	\N	VV9 7IA	United Kingdom	c4f75303-a973-43e1-8f69-dfc6500c302c	\N	\N	\N	Templum adhuc autem eius.	97	\N	2025-10-19 18:00:34.026992	2025-10-19 18:00:34.026992	a2adaa31-8f59-409a-b39b-72568022adb4
4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	CLI-0015	Champlin, Trantow and Dare	company	onboarding	Rashad_Mayert47@yahoo.com	460.952.8469 x8980	https://dirty-handover.info/	t	GB999395521	RLWX0IAX	87572 Poplar Avenue	\N	Creminland	\N	YK6 9VD	United Kingdom	c4f75303-a973-43e1-8f69-dfc6500c302c	\N	2017-08-16	11-07	Adnuo deserunt termes iusto appono.	93	\N	2025-10-19 18:00:34.026992	2025-10-19 18:00:34.026992	a2adaa31-8f59-409a-b39b-72568022adb4
04465623-29cb-4298-8828-d1839e9cc00d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	CLI-0016	Legros - Turcotte	partnership	inactive	Bret.Swift38@gmail.com	1-890-673-3778 x986	https://minty-metabolite.org/	t	GB495930875	CPTR6PRF	6338 Terry Cape	\N	Smithamstead	\N	RS9 8ER	United Kingdom	a2adaa31-8f59-409a-b39b-72568022adb4	\N	2023-09-15	08-12	Tersus dicta vulgaris demitto defluo universe venia.	44	\N	2025-10-19 18:00:34.026992	2025-10-19 18:00:34.026992	a2adaa31-8f59-409a-b39b-72568022adb4
4554e09d-4391-42a8-a2cd-9702bce80511	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	CLI-0017	Abel Shanahan	trust	onboarding	Evan_Reynolds-Wisoky20@hotmail.com	863.261.2274 x9622	\N	f	\N	\N	1236 Yundt Square	\N	North Olaf	\N	NQ0 7XR	United Kingdom	a2adaa31-8f59-409a-b39b-72568022adb4	\N	\N	\N	Tabesco mollitia tamdiu ambulo velociter cado.	48	\N	2025-10-19 18:00:34.026992	2025-10-19 18:00:34.026992	a2adaa31-8f59-409a-b39b-72568022adb4
405d4d05-841b-437d-af7d-70b66dda4cbc	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	CLI-0018	Hand - Stamm	company	onboarding	Moses.Mraz58@gmail.com	(787) 936-7281 x2375	https://anguished-verve.name	t	GB925211113	JLM9XVY3	88220 Stroman Spurs	\N	San Jacinto	\N	JX0 6JT	United Kingdom	c4f75303-a973-43e1-8f69-dfc6500c302c	\N	2025-03-20	03-18	Aurum consuasor arto ceno angelus.	57	\N	2025-10-19 18:00:34.026992	2025-10-19 18:00:34.026992	a2adaa31-8f59-409a-b39b-72568022adb4
67f62599-7f9f-44e8-bc18-d2ce08ea9919	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	CLI-0019	Stiedemann, Reichel and Brown	company	onboarding	Raymundo.Haag36@gmail.com	931.643.1982 x081	https://quiet-legging.net	t	GB370622941	HOASA39S	672 Herminia Village	\N	Lake Alford	\N	IY5 6HV	United Kingdom	0409f8de-7e1d-4245-96c2-02a3b1c90a81	\N	2020-03-12	01-24	Admoveo arx adicio abscido cras voluptatum asporto strenuus iste.	68	\N	2025-10-19 18:00:34.026992	2025-10-19 18:00:34.026992	a2adaa31-8f59-409a-b39b-72568022adb4
89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	CLI-0020	Anderson - Kohler	partnership	active	Kennedy.Morar1@gmail.com	1-525-699-5120 x41603	https://front-executor.com/	t	GB933519371	5GFK0BCG	88661 Hoeger River	\N	Council Bluffs	\N	GP4 3GI	United Kingdom	0409f8de-7e1d-4245-96c2-02a3b1c90a81	\N	2023-12-11	04-04	Testimonium appono nisi aequus somniculosus decens coaegresco deleniti volubilis subvenio.	91	\N	2025-10-19 18:00:34.026992	2025-10-19 18:00:34.026992	a2adaa31-8f59-409a-b39b-72568022adb4
702b5a48-f7a9-464c-8833-1ff6577e50e6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	CLI-0021	Terry, Carter and Kshlerin	company	onboarding	Jillian29@gmail.com	(639) 518-9408 x4324	https://unlucky-hovel.org	t	GB856021587	WRCW61DZ	68145 Turcotte Expressway	\N	Mobile	\N	PZ8 0QZ	United Kingdom	0409f8de-7e1d-4245-96c2-02a3b1c90a81	\N	2021-02-22	11-05	Alter amissio adversus corrupti aveho creta ambitus aequus.	80	\N	2025-10-19 18:00:34.026992	2025-10-19 18:00:34.026992	a2adaa31-8f59-409a-b39b-72568022adb4
d69d0436-37d7-42a4-b907-3d9c3a091ea6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	CLI-0022	Skiles - Bernier	company	onboarding	Austyn90@yahoo.com	1-256-315-2162	https://trusty-minor.info	t	GB162816119	SOTCO9IT	64120 Hilda Burgs	\N	Pricemouth	\N	IO2 5FG	United Kingdom	a2adaa31-8f59-409a-b39b-72568022adb4	\N	2020-01-31	12-24	Deleo corrigo sequi spargo spoliatio verbum.	87	\N	2025-10-19 18:00:34.026992	2025-10-19 18:00:34.026992	a2adaa31-8f59-409a-b39b-72568022adb4
a4464f5a-2125-46d9-9f58-7252c9adc16b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	CLI-0023	Strosin - Runte	company	onboarding	Aracely.Greenfelder@hotmail.com	374-887-8609 x534	https://frightened-custom.info/	t	GB041832102	LXJ6O0JW	1269 Hirthe Stream	\N	Adamsstead	\N	TA1 7WX	United Kingdom	d6f36046-e274-4776-a3d7-58eadb9d96b0	\N	2017-07-12	09-08	Alioqui alter tyrannus tenus vicissitudo sto.	85	\N	2025-10-19 18:00:34.026992	2025-10-19 18:00:34.026992	a2adaa31-8f59-409a-b39b-72568022adb4
6ecda653-6094-4502-9d1d-6e90d9ea99ed	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	CLI-0024	Boyer - Dibbert	partnership	onboarding	Alexane.Prosacco@yahoo.com	1-922-708-6460 x0754	https://yellowish-vision.info/	t	GB960354667	CCHPGGVV	9735 Medhurst Lakes	\N	Gaetanoview	\N	MP4 1VI	United Kingdom	c4f75303-a973-43e1-8f69-dfc6500c302c	\N	2019-12-19	02-22	Celer adiuvo conservo demitto comprehendo ascit similique defaeco vitiosus quis.	40	\N	2025-10-19 18:00:34.026992	2025-10-19 18:00:34.026992	a2adaa31-8f59-409a-b39b-72568022adb4
b7295600-5c20-4de2-8782-af87987c2bee	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	CLI-0025	Dana Dickens	trust	onboarding	Emmitt_Deckow46@hotmail.com	1-367-463-3786 x2928	\N	f	\N	\N	8293 Birch Avenue	\N	West Clementinaborough	\N	SS2 3GR	United Kingdom	c4f75303-a973-43e1-8f69-dfc6500c302c	\N	\N	\N	Vado attonbitus reiciendis patrocinor cupiditas.	84	\N	2025-10-19 18:00:34.026992	2025-10-19 18:00:34.026992	a2adaa31-8f59-409a-b39b-72568022adb4
\.


--
-- Data for Name: compliance; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.compliance (id, tenant_id, title, type, description, client_id, assigned_to_id, due_date, completed_date, reminder_date, status, priority, notes, attachments, metadata, created_at, updated_at, created_by_id) FROM stdin;
8c798a62-f9e9-40bb-951b-d652d3f8baf2	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	VAT Return - Ruecker - Jerde	VAT Return	Careo attollo derelinquo libero.	45b3d726-e151-4770-9b64-4653914bdaa5	0409f8de-7e1d-4245-96c2-02a3b1c90a81	2026-03-16 09:27:12.002	\N	2026-03-09 09:27:12.002	in_progress	low	\N	\N	\N	2025-10-19 18:00:38.197292	2025-10-19 18:00:38.197292	a2adaa31-8f59-409a-b39b-72568022adb4
7fcc82cf-1c24-4c30-82dd-a15319257cbd	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Corporation Tax Return - Ruecker - Jerde	Corporation Tax Return	Abstergo creator alioqui.	45b3d726-e151-4770-9b64-4653914bdaa5	0409f8de-7e1d-4245-96c2-02a3b1c90a81	2025-11-06 21:07:49.427	\N	2025-10-30 21:07:49.427	in_progress	low	\N	\N	\N	2025-10-19 18:00:38.202081	2025-10-19 18:00:38.202081	a2adaa31-8f59-409a-b39b-72568022adb4
5b263f0d-53d1-40a2-abd0-e0f2c5e51e07	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Confirmation Statement - Ruecker - Jerde	Confirmation Statement	Sursum ante deorsum tabesco viridis textor sonitus.	45b3d726-e151-4770-9b64-4653914bdaa5	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-26 21:04:11.162	2025-09-29 05:24:12.686	2025-10-19 21:04:11.162	in_progress	high	\N	\N	\N	2025-10-19 18:00:38.204726	2025-10-19 18:00:38.204726	a2adaa31-8f59-409a-b39b-72568022adb4
4c94246b-8169-4bd0-9134-d32fe9c99ad1	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Annual Accounts - Champlin, Trantow and Dare	Annual Accounts	Arbustum corporis quod fuga depopulo veritas cohaero ascisco una cruentus.	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-29 12:16:54.7	\N	2025-10-22 12:16:54.7	in_progress	medium	\N	\N	\N	2025-10-19 18:00:38.207499	2025-10-19 18:00:38.207499	a2adaa31-8f59-409a-b39b-72568022adb4
bb8d7e4b-631c-48a8-af61-8d9f634c4ab6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Confirmation Statement - Champlin, Trantow and Dare	Confirmation Statement	Arbor volo animi aegrotatio depromo error velit.	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	a2adaa31-8f59-409a-b39b-72568022adb4	2025-11-23 21:54:21.492	2025-09-25 22:31:46.241	2025-11-16 21:54:21.492	pending	medium	\N	\N	\N	2025-10-19 18:00:38.21215	2025-10-19 18:00:38.21215	a2adaa31-8f59-409a-b39b-72568022adb4
8aba49a5-f739-4ada-83f8-8352ac906608	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Corporation Tax Return - Champlin, Trantow and Dare	Corporation Tax Return	Caecus spargo amissio.	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	a2adaa31-8f59-409a-b39b-72568022adb4	2026-03-04 14:24:06.222	\N	2026-02-25 14:24:06.222	in_progress	medium	\N	\N	\N	2025-10-19 18:00:38.217056	2025-10-19 18:00:38.217056	a2adaa31-8f59-409a-b39b-72568022adb4
b9127bb4-2d4e-4087-bbd9-418265c84585	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	VAT Return - Hand - Stamm	VAT Return	Copia ante vorago.	405d4d05-841b-437d-af7d-70b66dda4cbc	c4f75303-a973-43e1-8f69-dfc6500c302c	2025-10-09 11:23:24.724	\N	2025-10-02 11:23:24.724	overdue	urgent	\N	\N	\N	2025-10-19 18:00:38.220505	2025-10-19 18:00:38.220505	a2adaa31-8f59-409a-b39b-72568022adb4
a3c0fee1-dc4f-4454-9cff-ded89e005872	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	PAYE Submission - Hand - Stamm	PAYE Submission	Consectetur dicta viridis.	405d4d05-841b-437d-af7d-70b66dda4cbc	0409f8de-7e1d-4245-96c2-02a3b1c90a81	2026-02-18 02:16:00.176	\N	2026-02-11 02:16:00.176	completed	high	\N	\N	\N	2025-10-19 18:00:38.223865	2025-10-19 18:00:38.223865	a2adaa31-8f59-409a-b39b-72568022adb4
823f9e35-3d99-4f86-8416-20bca8b2a743	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Corporation Tax Return - Hand - Stamm	Corporation Tax Return	Surculus amor conturbo supplanto cumque carcer ambulo viscus spes despecto.	405d4d05-841b-437d-af7d-70b66dda4cbc	c4f75303-a973-43e1-8f69-dfc6500c302c	2026-01-16 22:26:53.911	\N	2026-01-09 22:26:53.911	completed	high	\N	\N	\N	2025-10-19 18:00:38.227536	2025-10-19 18:00:38.227536	a2adaa31-8f59-409a-b39b-72568022adb4
176bf2ca-16cf-4cb5-8112-bee75a8c35f9	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Confirmation Statement - Hand - Stamm	Confirmation Statement	Audentia cervus cometes triumphus urbs dolorum teneo suspendo umerus.	405d4d05-841b-437d-af7d-70b66dda4cbc	d6f36046-e274-4776-a3d7-58eadb9d96b0	2025-10-22 19:28:51.442	\N	2025-10-15 19:28:51.442	completed	high	\N	\N	\N	2025-10-19 18:00:38.231854	2025-10-19 18:00:38.231854	a2adaa31-8f59-409a-b39b-72568022adb4
cedfa01f-eab0-4d15-b524-1f23cbcc40db	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Annual Accounts - Stiedemann, Reichel and Brown	Annual Accounts	Cubitum carpo alii statua viscus unus adiuvo atrox.	67f62599-7f9f-44e8-bc18-d2ce08ea9919	c4f75303-a973-43e1-8f69-dfc6500c302c	2025-11-08 01:12:10.937	2025-09-22 17:49:29.205	2025-11-01 01:12:10.937	overdue	medium	\N	\N	\N	2025-10-19 18:00:38.235399	2025-10-19 18:00:38.235399	a2adaa31-8f59-409a-b39b-72568022adb4
89dd2ff9-8a77-4d86-ae2f-aff5b985bbff	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	VAT Return - Stiedemann, Reichel and Brown	VAT Return	Curia theca curo crur deduco vinum aspicio tero accommodo.	67f62599-7f9f-44e8-bc18-d2ce08ea9919	a2adaa31-8f59-409a-b39b-72568022adb4	2026-03-23 16:21:12.785	\N	2026-03-16 16:21:12.785	pending	low	\N	\N	\N	2025-10-19 18:00:38.238757	2025-10-19 18:00:38.238757	a2adaa31-8f59-409a-b39b-72568022adb4
4fda213c-1e12-49cc-949b-ad325b7fc5d4	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Confirmation Statement - Terry, Carter and Kshlerin	Confirmation Statement	Ver thermae vespillo theatrum aequus attero villa vesper decipio.	702b5a48-f7a9-464c-8833-1ff6577e50e6	a2adaa31-8f59-409a-b39b-72568022adb4	2026-03-20 09:34:38.392	\N	2026-03-13 09:34:38.392	in_progress	high	\N	\N	\N	2025-10-19 18:00:38.241794	2025-10-19 18:00:38.241794	a2adaa31-8f59-409a-b39b-72568022adb4
31fe063c-f3e9-42da-afda-82163b33a4ac	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Corporation Tax Return - Terry, Carter and Kshlerin	Corporation Tax Return	Sequi agnitio vis ver aiunt pauci verus.	702b5a48-f7a9-464c-8833-1ff6577e50e6	c4f75303-a973-43e1-8f69-dfc6500c302c	2026-03-26 22:52:04.467	\N	2026-03-19 22:52:04.467	completed	high	\N	\N	\N	2025-10-19 18:00:38.245551	2025-10-19 18:00:38.245551	a2adaa31-8f59-409a-b39b-72568022adb4
877e0c49-3f47-4314-86e3-cc7a70cf3404	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	PAYE Submission - Terry, Carter and Kshlerin	PAYE Submission	Voluptatem consectetur degusto depulso.	702b5a48-f7a9-464c-8833-1ff6577e50e6	d6f36046-e274-4776-a3d7-58eadb9d96b0	2026-02-25 06:21:34.403	\N	2026-02-18 06:21:34.403	completed	low	\N	\N	\N	2025-10-19 18:00:38.248127	2025-10-19 18:00:38.248127	a2adaa31-8f59-409a-b39b-72568022adb4
e8751eec-4205-4a47-b1c8-f09fc306c91d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Self Assessment - Terry, Carter and Kshlerin	Self Assessment	Utor vestigium canto provident omnis atqui quo sustineo.	702b5a48-f7a9-464c-8833-1ff6577e50e6	0409f8de-7e1d-4245-96c2-02a3b1c90a81	2026-03-13 08:27:44.537	\N	2026-03-06 08:27:44.537	completed	medium	\N	\N	\N	2025-10-19 18:00:38.250705	2025-10-19 18:00:38.250705	a2adaa31-8f59-409a-b39b-72568022adb4
3fd6f2e8-38c1-4541-acc6-bffcc9fe33e6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	PAYE Submission - Skiles - Bernier	PAYE Submission	Soleo combibo tergo eveniet vorax deserunt triduana acer.	d69d0436-37d7-42a4-b907-3d9c3a091ea6	c4f75303-a973-43e1-8f69-dfc6500c302c	2025-12-05 04:20:20.722	2025-10-04 12:38:15.546	2025-11-28 04:20:20.722	completed	medium	\N	\N	\N	2025-10-19 18:00:38.252944	2025-10-19 18:00:38.252944	a2adaa31-8f59-409a-b39b-72568022adb4
f78d0d98-1f0c-4a90-9c28-0fa894800747	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	VAT Return - Skiles - Bernier	VAT Return	Aequus verto textilis commodi cunctatio cimentarius tendo vestrum.	d69d0436-37d7-42a4-b907-3d9c3a091ea6	d6f36046-e274-4776-a3d7-58eadb9d96b0	2026-04-13 07:32:28.349	\N	2026-04-06 07:32:28.349	overdue	medium	\N	\N	\N	2025-10-19 18:00:38.255311	2025-10-19 18:00:38.255311	a2adaa31-8f59-409a-b39b-72568022adb4
259eb6a4-6394-44e1-9fb3-d91b70e8729e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Self Assessment - Skiles - Bernier	Self Assessment	Baiulus timor assumenda sulum vulgus excepturi arbor socius.	d69d0436-37d7-42a4-b907-3d9c3a091ea6	d6f36046-e274-4776-a3d7-58eadb9d96b0	2025-10-03 08:20:16.487	\N	2025-09-26 08:20:16.487	overdue	low	\N	\N	\N	2025-10-19 18:00:38.25786	2025-10-19 18:00:38.25786	a2adaa31-8f59-409a-b39b-72568022adb4
a5cbe7c3-0d06-469d-96d3-1a3f02d5a600	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Corporation Tax Return - Skiles - Bernier	Corporation Tax Return	Considero thermae degenero balbus caritas agnitio summopere adicio uxor sapiente.	d69d0436-37d7-42a4-b907-3d9c3a091ea6	d6f36046-e274-4776-a3d7-58eadb9d96b0	2025-12-19 02:38:39.217	\N	2025-12-12 02:38:39.217	completed	high	\N	\N	\N	2025-10-19 18:00:38.260339	2025-10-19 18:00:38.260339	a2adaa31-8f59-409a-b39b-72568022adb4
a46de206-fe50-476c-b98d-d810af343005	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Corporation Tax Return - Strosin - Runte	Corporation Tax Return	Deduco verto alii crur accusamus aureus.	a4464f5a-2125-46d9-9f58-7252c9adc16b	c4f75303-a973-43e1-8f69-dfc6500c302c	2026-04-10 18:57:24.976	\N	2026-04-03 18:57:24.976	pending	low	\N	\N	\N	2025-10-19 18:00:38.262659	2025-10-19 18:00:38.262659	a2adaa31-8f59-409a-b39b-72568022adb4
d268f408-f1b8-4bd7-bc5b-e71945b537aa	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Confirmation Statement - Strosin - Runte	Confirmation Statement	Attero depono voluptatum vindico thalassinus ut aut denuncio casus.	a4464f5a-2125-46d9-9f58-7252c9adc16b	0409f8de-7e1d-4245-96c2-02a3b1c90a81	2026-03-29 14:01:34.79	\N	2026-03-22 14:01:34.79	pending	low	\N	\N	\N	2025-10-19 18:00:38.264842	2025-10-19 18:00:38.264842	a2adaa31-8f59-409a-b39b-72568022adb4
\.


--
-- Data for Name: document_signatures; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_signatures (id, document_id, tenant_id, signer_email, signer_name, docuseal_submission_id, audit_trail, document_hash, signed_pdf_url, signed_at, created_at) FROM stdin;
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.documents (id, tenant_id, name, type, mime_type, size, url, thumbnail_url, parent_id, path, client_id, task_id, description, tags, version, is_archived, is_public, share_token, share_expires_at, uploaded_by_id, requires_signature, signature_status, docuseal_submission_id, docuseal_template_id, signed_pdf_url, signed_at, signed_by, metadata, created_at, updated_at) FROM stdin;
ed8ed500-6943-4fdf-821b-556186d8bab4	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Tax Returns	folder	\N	\N	\N	\N	\N	/Tax Returns	\N	\N	\N	\N	1	f	f	\N	\N	a2adaa31-8f59-409a-b39b-72568022adb4	f	none	\N	\N	\N	\N	\N	\N	2025-10-19 18:00:39.721498	2025-10-19 18:00:39.721498
28d80d53-e153-488f-8712-712c415069c0	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Champlin,_Trantow_and_Dare_Invoice_March.pdf	file	application/pdf	570	\N	\N	ed8ed500-6943-4fdf-821b-556186d8bab4	/Tax Returns/Champlin,_Trantow_and_Dare_Invoice_March.pdf	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	\N	Vito delicate delectatio usus argentum.	["archived", "approved"]	1	f	f	\N	\N	0409f8de-7e1d-4245-96c2-02a3b1c90a81	f	none	\N	\N	\N	\N	\N	\N	2025-10-19 18:00:39.930652	2025-10-19 18:00:39.930652
eb54fd57-4625-419a-9a94-9e1eb5ba1ca1	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Gilberto_Mante_Invoice_March.pdf	file	application/pdf	613	\N	\N	ed8ed500-6943-4fdf-821b-556186d8bab4	/Tax Returns/Gilberto_Mante_Invoice_March.pdf	8538cc30-f9e7-4b63-a885-56b23e16ecef	\N	Creptio tenuis sub territo acerbitas terror.	[]	1	f	f	\N	\N	c4f75303-a973-43e1-8f69-dfc6500c302c	f	none	\N	\N	\N	\N	\N	\N	2025-10-19 18:00:39.994345	2025-10-19 18:00:39.994345
8b0f93f9-0521-497f-be36-d45acd871908	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Invoices	folder	\N	\N	\N	\N	\N	/Invoices	\N	\N	\N	\N	1	f	f	\N	\N	a2adaa31-8f59-409a-b39b-72568022adb4	f	none	\N	\N	\N	\N	\N	\N	2025-10-19 18:00:39.998639	2025-10-19 18:00:39.998639
7f2392ca-a511-4a35-825d-c7ffbb1b2a0a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Jeremy_Larson_Invoice_March.pdf	file	application/pdf	667	\N	\N	8b0f93f9-0521-497f-be36-d45acd871908	/Invoices/Jeremy_Larson_Invoice_March.pdf	7ef8af5a-1080-42a2-988f-ddfa799c8070	\N	Vitium atrocitas apostolus celebrer pariatur.	["approved", "pending-review"]	1	f	f	\N	\N	0409f8de-7e1d-4245-96c2-02a3b1c90a81	f	none	\N	\N	\N	\N	\N	\N	2025-10-19 18:00:40.17794	2025-10-19 18:00:40.17794
a3ab07b9-7d01-479c-bca5-e71e8a79498d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Faye_Gleichner_Bank_Statement.pdf	file	application/pdf	660	\N	\N	8b0f93f9-0521-497f-be36-d45acd871908	/Invoices/Faye_Gleichner_Bank_Statement.pdf	0d0329f4-4b80-4899-8807-5854e9db312b	\N	Templum pecus sto denuo vomer incidunt reiciendis aequus.	[]	1	f	f	\N	\N	a2adaa31-8f59-409a-b39b-72568022adb4	f	none	\N	\N	\N	\N	\N	\N	2025-10-19 18:00:40.281622	2025-10-19 18:00:40.281622
82d577a5-a75f-4355-a707-a4bd85adb8bb	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Bank Statements	folder	\N	\N	\N	\N	\N	/Bank Statements	\N	\N	\N	\N	1	f	f	\N	\N	a2adaa31-8f59-409a-b39b-72568022adb4	f	none	\N	\N	\N	\N	\N	\N	2025-10-19 18:00:40.284622	2025-10-19 18:00:40.284622
d8afac96-6341-4c70-9d5e-7413010c72ba	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Jerde_LLC_Receipt.pdf	file	application/pdf	611	\N	\N	82d577a5-a75f-4355-a707-a4bd85adb8bb	/Bank Statements/Jerde_LLC_Receipt.pdf	17f141c2-e297-4c93-9178-0fd819259c50	\N	Solutio terebro clibanus ventito laudantium antepono defluo supplanto.	[]	1	f	f	\N	\N	d6f36046-e274-4776-a3d7-58eadb9d96b0	f	none	\N	\N	\N	\N	\N	\N	2025-10-19 18:00:40.375227	2025-10-19 18:00:40.375227
b4643cf8-9164-4109-b79a-f0750390c72c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Anderson_-_Kohler_Bank_Statement.pdf	file	application/pdf	615	\N	\N	82d577a5-a75f-4355-a707-a4bd85adb8bb	/Bank Statements/Anderson_-_Kohler_Bank_Statement.pdf	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	\N	Aliqua crastinus quaerat exercitationem.	["approved", "archived"]	1	f	f	\N	\N	d6f36046-e274-4776-a3d7-58eadb9d96b0	f	none	\N	\N	\N	\N	\N	\N	2025-10-19 18:00:40.619251	2025-10-19 18:00:40.619251
9b151491-920b-4138-abd7-38415ff73ef1	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Abel_Shanahan_Receipt.pdf	file	application/pdf	560	\N	\N	82d577a5-a75f-4355-a707-a4bd85adb8bb	/Bank Statements/Abel_Shanahan_Receipt.pdf	4554e09d-4391-42a8-a2cd-9702bce80511	\N	Unde arto suus quibusdam deficio.	["archived", "important"]	1	f	f	\N	\N	a2adaa31-8f59-409a-b39b-72568022adb4	f	none	\N	\N	\N	\N	\N	\N	2025-10-19 18:00:40.872935	2025-10-19 18:00:40.872935
b6b139a5-592a-42a2-9d5a-23ceb6105565	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Contracts	folder	\N	\N	\N	\N	\N	/Contracts	\N	\N	\N	\N	1	f	f	\N	\N	a2adaa31-8f59-409a-b39b-72568022adb4	f	none	\N	\N	\N	\N	\N	\N	2025-10-19 18:00:40.877521	2025-10-19 18:00:40.877521
818c83f7-f585-40a6-bed2-f98c3f548d60	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Constance_Mante_Contract.pdf	file	application/pdf	626	\N	\N	b6b139a5-592a-42a2-9d5a-23ceb6105565	/Contracts/Constance_Mante_Contract.pdf	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	\N	Aestus articulus sustineo vomica velociter defluo copiose.	["important", "pending-review"]	1	f	f	\N	\N	c4f75303-a973-43e1-8f69-dfc6500c302c	f	none	\N	\N	\N	\N	\N	\N	2025-10-19 18:00:41.150279	2025-10-19 18:00:41.150279
bcc42d69-87ba-4042-8b38-43533dc367f1	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Silvia_Will_Receipt.pdf	file	application/pdf	575	\N	\N	b6b139a5-592a-42a2-9d5a-23ceb6105565	/Contracts/Silvia_Will_Receipt.pdf	b0a95e11-90ac-4ab3-b099-c4de69f498b8	\N	Venustas tamisium inflammatio.	["approved", "archived"]	1	f	f	\N	\N	c4f75303-a973-43e1-8f69-dfc6500c302c	f	none	\N	\N	\N	\N	\N	\N	2025-10-19 18:00:41.22076	2025-10-19 18:00:41.22076
56a0ab78-d4ee-485e-8ded-9db063d37a35	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Jerde_LLC_Receipt.pdf	file	application/pdf	584	\N	\N	b6b139a5-592a-42a2-9d5a-23ceb6105565	/Contracts/Jerde_LLC_Receipt.pdf	17f141c2-e297-4c93-9178-0fd819259c50	\N	Conor voluptatem derelinquo aestas cruentus.	[]	1	f	f	\N	\N	a2adaa31-8f59-409a-b39b-72568022adb4	f	none	\N	\N	\N	\N	\N	\N	2025-10-19 18:00:41.376668	2025-10-19 18:00:41.376668
31abce0a-74bf-46a3-abb1-1f17f53a7640	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Correspondence	folder	\N	\N	\N	\N	\N	/Correspondence	\N	\N	\N	\N	1	f	f	\N	\N	a2adaa31-8f59-409a-b39b-72568022adb4	f	none	\N	\N	\N	\N	\N	\N	2025-10-19 18:00:41.381995	2025-10-19 18:00:41.381995
b1f981aa-9649-41f2-841a-28c153f21a28	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Ernser_and_Sons_Tax_Return_2023.pdf	file	application/pdf	608	\N	\N	31abce0a-74bf-46a3-abb1-1f17f53a7640	/Correspondence/Ernser_and_Sons_Tax_Return_2023.pdf	6a032ece-4f9e-405a-b48a-b28516d15fe1	\N	Eos coaegresco voluntarius thorax caput substantia attonbitus tolero.	[]	1	f	f	\N	\N	a2adaa31-8f59-409a-b39b-72568022adb4	f	none	\N	\N	\N	\N	\N	\N	2025-10-19 18:00:41.581565	2025-10-19 18:00:41.581565
f5ba9ac4-fb7c-4018-aab7-970a4e6a7598	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Boyer_-_Dibbert_Receipt.pdf	file	application/pdf	623	\N	\N	31abce0a-74bf-46a3-abb1-1f17f53a7640	/Correspondence/Boyer_-_Dibbert_Receipt.pdf	6ecda653-6094-4502-9d1d-6e90d9ea99ed	\N	Vesper bardus bellum repellat veritas.	["pending-review"]	1	f	f	\N	\N	d6f36046-e274-4776-a3d7-58eadb9d96b0	f	none	\N	\N	\N	\N	\N	\N	2025-10-19 18:00:41.808296	2025-10-19 18:00:41.808296
1bfc0ee6-59fe-4cd1-a1f7-f7af8f3864dd	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Gilberto_Mante_Invoice_March.pdf	file	application/pdf	639	\N	\N	31abce0a-74bf-46a3-abb1-1f17f53a7640	/Correspondence/Gilberto_Mante_Invoice_March.pdf	8538cc30-f9e7-4b63-a885-56b23e16ecef	\N	Cultura ciminatio succedo crustulum.	["important", "archived"]	1	f	f	\N	\N	d6f36046-e274-4776-a3d7-58eadb9d96b0	f	none	\N	\N	\N	\N	\N	\N	2025-10-19 18:00:41.953282	2025-10-19 18:00:41.953282
\.


--
-- Data for Name: feedback; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.feedback (id, tenant_id, user_id, user_email, user_name, user_role, type, title, description, category, page_url, user_agent, console_logs, screenshot, status, priority, assigned_to, admin_notes, resolution, resolved_at, resolved_by, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: invitations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invitations (id, tenant_id, email, role, token, invited_by, custom_message, status, expires_at, accepted_at, created_at, updated_at) FROM stdin;
90664571-9486-4bef-96e4-12a36308828a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	newuser@example.com	accountant	82de3729955cdae5e371699fb0915a8c6423688f8b1971e06bb551e5b0e0bf6d	a2adaa31-8f59-409a-b39b-72568022adb4	\N	pending	2025-10-26 18:00:33.896	\N	2025-10-19 18:00:33.899001	2025-10-19 18:00:33.899001
345b6f87-b545-40d5-a3a9-1c0def06aeff	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	teammember@example.com	member	9e3379c768e1c9bbef9971668eae0cad69986ea7c12b5dfbc7aca6807dc6ce5d	a2adaa31-8f59-409a-b39b-72568022adb4	\N	pending	2025-10-26 18:00:33.896	\N	2025-10-19 18:00:33.899001	2025-10-19 18:00:33.899001
\.


--
-- Data for Name: invoice_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoice_items (id, invoice_id, description, quantity, rate, amount, time_entry_id, service_component_id, sort_order, created_at, updated_at) FROM stdin;
b53ee80b-8fe4-4b12-8cb3-dba3b5b471cb	782f47c5-5429-4739-937f-05e83974fc70	New teal Fish with ergonomic design for prime comfort	10.00	372.87	3728.67	\N	ff4a2600-29fe-4448-bec3-ea868988a9ed	0	2025-10-19 18:00:37.907712	2025-10-19 18:00:37.907712
abaed622-4685-4709-95ec-d0d7300516c3	782f47c5-5429-4739-937f-05e83974fc70	Introducing the France-inspired Salad, blending new style with local craftsmanship	4.00	1233.99	4935.95	\N	e4487405-7859-40e9-8008-056d32fe6f10	1	2025-10-19 18:00:37.912302	2025-10-19 18:00:37.912302
cfaecc9a-b78f-48d7-824e-ad33feae6064	56252469-2b56-4b88-97bd-97a6e29b3fa8	Introducing the Comoros-inspired Towels, blending sardonic style with local craftsmanship	8.00	50.85	406.78	\N	cbf9b499-276b-4a28-999c-27388562c4f4	0	2025-10-19 18:00:37.921911	2025-10-19 18:00:37.921911
34c948e6-ec08-4920-a026-875862901d69	56252469-2b56-4b88-97bd-97a6e29b3fa8	Our salty-inspired Mouse brings a taste of luxury to your soupy lifestyle	10.00	95.53	955.31	\N	e2cd4da6-f171-436c-9c7e-a9c1c5436b98	1	2025-10-19 18:00:37.924775	2025-10-19 18:00:37.924775
8c5b4d5c-6c0e-4c23-b3d1-3ea80d3ebdc4	f2eee8ae-82b7-4d29-bc3b-f93eddc5cbbe	Discover the multicolored new Towels with an exciting mix of Wooden ingredients	3.00	121.02	363.06	\N	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	0	2025-10-19 18:00:37.930406	2025-10-19 18:00:37.930406
fab86949-ca87-4552-b5a5-5d51c662b603	f2eee8ae-82b7-4d29-bc3b-f93eddc5cbbe	Ergonomic Bike made with Silk for all-day gigantic support	10.00	529.73	5297.30	\N	d6d7e47b-cd48-48d8-a45a-fa75af1f9a52	1	2025-10-19 18:00:37.93258	2025-10-19 18:00:37.93258
9b0278b9-e86f-44ec-a4d0-5fdbd47cb880	fee34995-9573-4150-93b9-ec3b31866225	Featuring Magnesium-enhanced technology, our Shoes offers unparalleled quick-witted performance	5.00	641.31	3206.53	\N	996aa78c-cfd1-477f-8c30-d9489225b29e	0	2025-10-19 18:00:37.938402	2025-10-19 18:00:37.938402
5417958f-3744-4d48-a381-782022916dc0	c55fbebe-39d0-470f-b430-ec229d329be8	Stylish Computer designed to make you stand out with lavish looks	7.00	578.59	4050.11	\N	391f7d87-df5d-4538-9b3e-31e07ac9347e	0	2025-10-19 18:00:37.945647	2025-10-19 18:00:37.945647
74547429-7358-4aa8-a3b5-fe5d9391c29a	c55fbebe-39d0-470f-b430-ec229d329be8	The Intuitive context-sensitive utilisation Gloves offers reliable performance and yummy design	10.00	189.77	1897.65	\N	e2cd4da6-f171-436c-9c7e-a9c1c5436b98	1	2025-10-19 18:00:37.949158	2025-10-19 18:00:37.949158
ae64a01b-ab7b-40f2-92a4-9b906261c872	c55fbebe-39d0-470f-b430-ec229d329be8	The Lesly Shoes is the latest in a series of buzzing products from Mohr - Marvin	3.00	738.61	2215.82	\N	ecfd2c2c-905b-4ef4-99a4-8949632b9ae9	2	2025-10-19 18:00:37.951874	2025-10-19 18:00:37.951874
6b68ec02-5c65-45a2-87aa-d890a683169a	8087e9cf-c34d-4fde-b5b3-2afa81d6fb17	Discover the elephant-like agility of our Salad, perfect for aggravating users	8.00	168.51	1348.07	\N	18c91d63-8f9d-4974-ba97-a4079c7457d5	0	2025-10-19 18:00:37.957621	2025-10-19 18:00:37.957621
1b139464-dfc3-4737-9d8d-cf22edfd241b	8087e9cf-c34d-4fde-b5b3-2afa81d6fb17	Experience the plum brilliance of our Bacon, perfect for voluminous environments	6.00	121.82	730.91	\N	ca413110-b7e3-4734-a185-d21ea0960708	1	2025-10-19 18:00:37.960005	2025-10-19 18:00:37.960005
3479f180-a658-4dfd-a348-0c9b338ceaf2	8087e9cf-c34d-4fde-b5b3-2afa81d6fb17	Featuring Samarium-enhanced technology, our Fish offers unparalleled ruddy performance	9.00	134.18	1207.58	\N	79d01aa5-b680-4830-ab3a-5e3cb66edcfa	2	2025-10-19 18:00:37.962341	2025-10-19 18:00:37.962341
9dd2317d-3c76-4904-bf71-d72c585eaef9	9948faff-0d45-44a4-99d8-98e83c671a51	Elegant Salad designed with Concrete for excitable performance	5.00	152.98	764.89	\N	79d01aa5-b680-4830-ab3a-5e3cb66edcfa	0	2025-10-19 18:00:37.968504	2025-10-19 18:00:37.968504
93f7bd0e-35cc-477c-8de2-63a90e78601d	9948faff-0d45-44a4-99d8-98e83c671a51	Stylish Ball designed to make you stand out with angelic looks	6.00	126.53	759.20	\N	ca413110-b7e3-4734-a185-d21ea0960708	1	2025-10-19 18:00:37.971352	2025-10-19 18:00:37.971352
c867789b-5bcf-4737-afb4-c2c4066d2325	9948faff-0d45-44a4-99d8-98e83c671a51	Stylish Fish designed to make you stand out with specific looks	7.00	423.47	2964.29	\N	78882562-2120-44d2-9286-03e696abbf02	2	2025-10-19 18:00:37.974058	2025-10-19 18:00:37.974058
e4e11f32-9f73-44aa-af93-a2d5fa4320c4	71607734-0c5b-4fb0-82ca-59f4b015d7d2	Discover the monkey-like agility of our Sausages, perfect for grumpy users	10.00	664.75	6647.46	\N	9362cf11-827c-459a-8ffc-6634bd023508	0	2025-10-19 18:00:37.980526	2025-10-19 18:00:37.980526
235e88a0-08a0-47f5-9b7c-35d2fcfa4696	53d7a76d-9f46-44d3-a41f-cdb840541b42	Our bitter-inspired Hat brings a taste of luxury to your last lifestyle	3.00	1396.36	4189.08	\N	a8a65b80-dc4c-49f9-9c8d-0dc4a336cf55	0	2025-10-19 18:00:37.988138	2025-10-19 18:00:37.988138
97a68865-4d22-4b3e-b5a9-aae4068b66bd	458175f1-d715-4da1-8237-526ded79a29d	Ergonomic Chips made with Plastic for all-day tricky support	9.00	411.68	3705.09	\N	cbf9b499-276b-4a28-999c-27388562c4f4	0	2025-10-19 18:00:37.996801	2025-10-19 18:00:37.996801
b45976fe-8ab2-4b67-bc2a-9c638972b72a	458175f1-d715-4da1-8237-526ded79a29d	Our spicy-inspired Hat brings a taste of luxury to your negligible lifestyle	9.00	644.54	5800.87	\N	235b548d-f0a0-4899-9a7e-d6e9bec6db40	1	2025-10-19 18:00:37.999841	2025-10-19 18:00:37.999841
8880cd89-a692-441b-9313-bf4fa52e0fdd	3bd48724-8a4f-4ddc-b4d0-f433b92ff1c0	Discover the cat-like agility of our Mouse, perfect for self-reliant users	4.00	410.77	1643.09	\N	cbf9b499-276b-4a28-999c-27388562c4f4	0	2025-10-19 18:00:38.006142	2025-10-19 18:00:38.006142
577edb62-9ec5-43bc-b4df-96df7db9077e	3bd48724-8a4f-4ddc-b4d0-f433b92ff1c0	Introducing the Kuwait-inspired Cheese, blending sweet style with local craftsmanship	1.00	309.15	309.15	\N	79d01aa5-b680-4830-ab3a-5e3cb66edcfa	1	2025-10-19 18:00:38.00825	2025-10-19 18:00:38.00825
dfebf919-188d-4cd2-ab61-44d5f5843c93	3bd48724-8a4f-4ddc-b4d0-f433b92ff1c0	Prosacco, Williamson and Champlin's most advanced Bacon technology increases handsome capabilities	1.00	2499.04	2499.04	\N	ca413110-b7e3-4734-a185-d21ea0960708	2	2025-10-19 18:00:38.010239	2025-10-19 18:00:38.010239
492a471a-8afb-487d-86a1-a6ebbc40ef93	3bd48724-8a4f-4ddc-b4d0-f433b92ff1c0	New red Bike with ergonomic design for odd comfort	5.00	535.12	2675.62	\N	08ee5378-067c-4708-886c-34df4c200b23	3	2025-10-19 18:00:38.012279	2025-10-19 18:00:38.012279
12a53e67-636b-425f-b07b-d957c82c1307	5d10ff3b-dfb7-4d2c-8175-26a95d33cd05	New Towels model with 11 GB RAM, 939 GB storage, and edible features	5.00	882.19	4410.95	\N	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	0	2025-10-19 18:00:38.017743	2025-10-19 18:00:38.017743
d43789e2-a752-4929-9299-cec3979d6548	9db4b836-e6d9-4f73-83c1-902a7df98843	Discover the steel new Tuna with an exciting mix of Aluminum ingredients	4.00	593.49	2373.97	\N	a49c064a-0890-4c02-8734-07a3185e6c03	0	2025-10-19 18:00:38.022603	2025-10-19 18:00:38.022603
fcd8fbee-6f11-46d9-bc81-91b1b34fd2ac	9db4b836-e6d9-4f73-83c1-902a7df98843	Our rabbit-friendly Table ensures clear-cut comfort for your pets	9.00	600.70	5406.28	\N	a96c9f4d-dc33-4af3-818d-8d729f0f8c1f	1	2025-10-19 18:00:38.024559	2025-10-19 18:00:38.024559
f36e2be8-390d-4d9b-8f69-3ead9f37cad5	9dab5229-8398-4c6a-95de-c803948a0d38	Discover the joyous new Table with an exciting mix of Granite ingredients	4.00	534.52	2138.06	\N	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	0	2025-10-19 18:00:38.029682	2025-10-19 18:00:38.029682
525b0722-c087-41a7-ae0f-aabbc873c812	9dab5229-8398-4c6a-95de-c803948a0d38	Introducing the Tonga-inspired Towels, blending clear-cut style with local craftsmanship	5.00	647.01	3235.05	\N	78882562-2120-44d2-9286-03e696abbf02	1	2025-10-19 18:00:38.031728	2025-10-19 18:00:38.031728
3bc51b0d-c226-4423-85ee-c706ef2e8581	5164f2bb-c267-4031-97b6-3c24cc330048	Innovative Sausages featuring other technology and Concrete construction	10.00	14.88	148.78	\N	109283c7-55ef-4e05-bf53-c6efd1be486f	0	2025-10-19 18:00:38.036542	2025-10-19 18:00:38.036542
fecfde5e-b25a-44c1-a02e-03bb2cdff4f1	5164f2bb-c267-4031-97b6-3c24cc330048	Rustic Bike designed with Bamboo for crafty performance	9.00	455.60	4100.38	\N	a8a65b80-dc4c-49f9-9c8d-0dc4a336cf55	1	2025-10-19 18:00:38.038649	2025-10-19 18:00:38.038649
bd69c8a8-d1e0-436b-a79d-b1ba0eaca061	b19758e2-db8e-4f7f-b7b3-68c8a8f3cf22	Practical Car designed with Plastic for lawful performance	9.00	296.66	2669.90	\N	d6d7e47b-cd48-48d8-a45a-fa75af1f9a52	0	2025-10-19 18:00:38.044745	2025-10-19 18:00:38.044745
ff1c1c87-b91f-4bc5-8d32-7a134be2577a	b19758e2-db8e-4f7f-b7b3-68c8a8f3cf22	Experience the purple brilliance of our Chair, perfect for second environments	4.00	683.01	2732.02	\N	3f2e9a8e-bdfe-4d09-aced-e88cdc710462	1	2025-10-19 18:00:38.047248	2025-10-19 18:00:38.047248
32e1820a-6c00-4144-9c5e-9bb228c142e0	c851db27-b9a7-4209-a906-a1d5d4faacac	Schiller Group's most advanced Chips technology increases unhappy capabilities	3.00	250.51	751.53	\N	391f7d87-df5d-4538-9b3e-31e07ac9347e	0	2025-10-19 18:00:38.052889	2025-10-19 18:00:38.052889
90011eef-5f09-463b-9c31-19955c15f394	29f4aab4-fb6b-4082-9ff0-d8bd4a5188f2	Innovative Fish featuring easy technology and Bronze construction	7.00	940.97	6586.78	\N	9362cf11-827c-459a-8ffc-6634bd023508	0	2025-10-19 18:00:38.059284	2025-10-19 18:00:38.059284
ae82b32a-f57c-472e-8858-816f711c00e4	11639761-1b64-4d60-83ed-ee4ca9a6daeb	Savor the zesty essence in our Pizza, designed for purple culinary adventures	9.00	239.31	2153.79	\N	a49c064a-0890-4c02-8734-07a3185e6c03	0	2025-10-19 18:00:38.06485	2025-10-19 18:00:38.06485
2311f717-768e-4d80-9332-094f916f98e6	11639761-1b64-4d60-83ed-ee4ca9a6daeb	New Pants model with 19 GB RAM, 207 GB storage, and quixotic features	2.00	394.02	788.03	\N	235b548d-f0a0-4899-9a7e-d6e9bec6db40	1	2025-10-19 18:00:38.06739	2025-10-19 18:00:38.06739
6c1f72c0-7bbb-4a55-abf5-a193a6fd4c12	11639761-1b64-4d60-83ed-ee4ca9a6daeb	Introducing the Luxembourg-inspired Shirt, blending clear style with local craftsmanship	8.00	79.94	639.48	\N	d04961e2-5af7-4b9c-bb44-c37031dd6bfa	2	2025-10-19 18:00:38.069735	2025-10-19 18:00:38.069735
a052c9c4-81f4-4255-9a35-e0df9ac1baad	11639761-1b64-4d60-83ed-ee4ca9a6daeb	Gutkowski and Sons's most advanced Sausages technology increases second capabilities	4.00	202.39	809.54	\N	e2cd4da6-f171-436c-9c7e-a9c1c5436b98	3	2025-10-19 18:00:38.07219	2025-10-19 18:00:38.07219
e6b8e689-3215-4118-b920-4a182491c6c8	4079ba66-04f2-4fc5-85b3-fb38774d0914	Savor the fresh essence in our Keyboard, designed for nutritious culinary adventures	6.00	351.11	2106.64	\N	a8a65b80-dc4c-49f9-9c8d-0dc4a336cf55	0	2025-10-19 18:00:38.07691	2025-10-19 18:00:38.07691
6c92311e-bfee-4405-9eac-79e1b1aaaa64	4079ba66-04f2-4fc5-85b3-fb38774d0914	Our gecko-friendly Towels ensures ample comfort for your pets	4.00	817.20	3268.78	\N	996aa78c-cfd1-477f-8c30-d9489225b29e	1	2025-10-19 18:00:38.078498	2025-10-19 18:00:38.078498
2f97e196-9f95-4c29-ba61-c19d020d3643	c96a5a42-c700-4e1d-8b61-fd3b633d62f9	Stylish Table designed to make you stand out with nimble looks	7.00	220.88	1546.19	\N	9362cf11-827c-459a-8ffc-6634bd023508	0	2025-10-19 18:00:38.082084	2025-10-19 18:00:38.082084
3090c3f0-de5a-4749-b818-4e8149c98147	c96a5a42-c700-4e1d-8b61-fd3b633d62f9	The Synchronised client-server success Cheese offers reliable performance and crafty design	1.00	1416.15	1416.15	\N	109283c7-55ef-4e05-bf53-c6efd1be486f	1	2025-10-19 18:00:38.085825	2025-10-19 18:00:38.085825
f5575a6c-d5d4-4cb7-a0ae-9b168dc2aa5b	c96a5a42-c700-4e1d-8b61-fd3b633d62f9	Featuring Fermium-enhanced technology, our Towels offers unparalleled muffled performance	3.00	515.35	1546.04	\N	235b548d-f0a0-4899-9a7e-d6e9bec6db40	2	2025-10-19 18:00:38.088313	2025-10-19 18:00:38.088313
a0e52360-b594-4865-ba30-d4e39000e1b6	9a096553-f4ca-4e72-a598-b3458053fdff	Luxurious Table designed with Wooden for svelte performance	7.00	67.53	472.74	\N	78882562-2120-44d2-9286-03e696abbf02	0	2025-10-19 18:00:38.094283	2025-10-19 18:00:38.094283
bf4e9159-c811-41ae-889e-95d328ca4f61	9a096553-f4ca-4e72-a598-b3458053fdff	The Gladyce Towels is the latest in a series of fluffy products from Goodwin, Hamill and Schaden	3.00	780.34	2341.03	\N	ff4a2600-29fe-4448-bec3-ea868988a9ed	1	2025-10-19 18:00:38.096773	2025-10-19 18:00:38.096773
b1fb9192-b82b-48b6-af63-9232c8c67d6a	9a096553-f4ca-4e72-a598-b3458053fdff	Discover the parrot-like agility of our Computer, perfect for stable users	7.00	140.46	983.22	\N	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	2	2025-10-19 18:00:38.099863	2025-10-19 18:00:38.099863
2c2c8120-b3ba-4c97-9ea7-563ecf7ab8f7	9a096553-f4ca-4e72-a598-b3458053fdff	The Sustainable full-range matrices Bike offers reliable performance and ethical design	10.00	13.38	133.77	\N	18c91d63-8f9d-4974-ba97-a4079c7457d5	3	2025-10-19 18:00:38.103502	2025-10-19 18:00:38.103502
1e834f43-203f-4622-972f-1bda37299f67	9a096553-f4ca-4e72-a598-b3458053fdff	Our cow-friendly Ball ensures elastic comfort for your pets	5.00	245.49	1227.43	\N	1ede1cc0-3627-404e-bb8a-487e028f4732	4	2025-10-19 18:00:38.106857	2025-10-19 18:00:38.106857
844c2b3c-2547-45cf-8e5d-6b91ed8d7f7d	e547c88a-aa42-4542-a738-6c8eeb7a0ee6	Featuring Protactinium-enhanced technology, our Chips offers unparalleled bare performance	3.00	560.22	1680.65	\N	d04961e2-5af7-4b9c-bb44-c37031dd6bfa	0	2025-10-19 18:00:38.114051	2025-10-19 18:00:38.114051
18962fce-db6c-477c-a510-e287ea39b5fd	e547c88a-aa42-4542-a738-6c8eeb7a0ee6	The sleek and dull Car comes with salmon LED lighting for smart functionality	6.00	282.28	1693.65	\N	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	1	2025-10-19 18:00:38.116712	2025-10-19 18:00:38.116712
68bb70fa-a9e4-4ff1-bb26-b68f3bf05e7a	a45c6e3c-6d93-4e62-8019-7e606919e5ea	The white Sausages combines Algeria aesthetics with Helium-based durability	2.00	3202.95	6405.89	\N	79d01aa5-b680-4830-ab3a-5e3cb66edcfa	0	2025-10-19 18:00:38.123507	2025-10-19 18:00:38.123507
5a191e55-ec5f-4654-bdb8-21e2c1f9b84f	b85b5061-58b4-40f2-a0d9-4636f79f0ac9	Savor the tender essence in our Fish, designed for broken culinary adventures	5.00	141.80	708.99	\N	79d01aa5-b680-4830-ab3a-5e3cb66edcfa	0	2025-10-19 18:00:38.128945	2025-10-19 18:00:38.128945
19927b3b-286d-48bf-9160-128cb93c3fc4	b85b5061-58b4-40f2-a0d9-4636f79f0ac9	Discover the bird-like agility of our Salad, perfect for grave users	7.00	91.24	638.71	\N	e4487405-7859-40e9-8008-056d32fe6f10	1	2025-10-19 18:00:38.13143	2025-10-19 18:00:38.13143
0be62fd1-5a21-4c28-aa8d-326ec07b16c8	b85b5061-58b4-40f2-a0d9-4636f79f0ac9	New Fish model with 82 GB RAM, 146 GB storage, and weary features	2.00	3437.84	6875.67	\N	1ede1cc0-3627-404e-bb8a-487e028f4732	2	2025-10-19 18:00:38.133649	2025-10-19 18:00:38.133649
8c078728-c2a1-4187-ba50-3882bb0ec7e7	d27ad49a-c63b-4428-b632-fa7f40924dd3	The tan Salad combines Saint Vincent and the Grenadines aesthetics with Oxygen-based durability	4.00	332.38	1329.51	\N	a0801828-5c53-41ef-9b3e-06db89d72e90	0	2025-10-19 18:00:38.139127	2025-10-19 18:00:38.139127
806e2e9f-cd6f-48d1-9712-a05eeec8dfca	d27ad49a-c63b-4428-b632-fa7f40924dd3	Introducing the United Arab Emirates-inspired Car, blending calculating style with local craftsmanship	7.00	254.05	1778.37	\N	109283c7-55ef-4e05-bf53-c6efd1be486f	1	2025-10-19 18:00:38.142074	2025-10-19 18:00:38.142074
ba29fcc8-54c4-4a48-9837-3bf629e46a36	78e42166-2e5d-4486-bc40-424a28c60f1b	Stylish Chicken designed to make you stand out with worthy looks	3.00	1117.21	3351.63	\N	e4487405-7859-40e9-8008-056d32fe6f10	0	2025-10-19 18:00:38.15032	2025-10-19 18:00:38.15032
9933e729-1e99-4c2f-b5c5-a3b4b5e26d76	bbc3644e-8323-4f26-acaa-c154dca75518	Professional-grade Computer perfect for soggy training and recreational use	9.00	145.14	1306.22	\N	a49c064a-0890-4c02-8734-07a3185e6c03	0	2025-10-19 18:00:38.156418	2025-10-19 18:00:38.156418
c9f2207d-729a-43e7-8c0b-304875f613a4	bbc3644e-8323-4f26-acaa-c154dca75518	Our ostrich-friendly Tuna ensures mixed comfort for your pets	7.00	174.46	1221.23	\N	79d01aa5-b680-4830-ab3a-5e3cb66edcfa	1	2025-10-19 18:00:38.159287	2025-10-19 18:00:38.159287
cbbc824c-f2ab-4551-8e76-ac63f7d29eb5	bbc3644e-8323-4f26-acaa-c154dca75518	Featuring Krypton-enhanced technology, our Hat offers unparalleled quarterly performance	1.00	993.10	993.10	\N	d6d7e47b-cd48-48d8-a45a-fa75af1f9a52	2	2025-10-19 18:00:38.161851	2025-10-19 18:00:38.161851
d452bf7f-aab9-4227-951a-7034a5f755ea	bbc3644e-8323-4f26-acaa-c154dca75518	Stylish Sausages designed to make you stand out with wide-eyed looks	1.00	957.38	957.38	\N	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	3	2025-10-19 18:00:38.164985	2025-10-19 18:00:38.164985
e901c725-bcf2-4398-811d-d9df38c1fac3	bbc3644e-8323-4f26-acaa-c154dca75518	Ergonomic Gloves made with Ceramic for all-day common support	1.00	1384.83	1384.83	\N	d6d7e47b-cd48-48d8-a45a-fa75af1f9a52	4	2025-10-19 18:00:38.168346	2025-10-19 18:00:38.168346
00b1e8a2-78db-461a-bbdf-f50b5cd6fb4e	0c31985a-abdc-4b1f-8b5f-1356d79c7d6a	The yellow Shirt combines Lebanon aesthetics with Boron-based durability	8.00	32.19	257.49	\N	391f7d87-df5d-4538-9b3e-31e07ac9347e	0	2025-10-19 18:00:38.176989	2025-10-19 18:00:38.176989
bd44354b-a58a-4035-a3ed-4fa22e8b0c6c	0c31985a-abdc-4b1f-8b5f-1356d79c7d6a	Discover the hippopotamus-like agility of our Bike, perfect for shabby users	3.00	112.26	336.79	\N	cbf9b499-276b-4a28-999c-27388562c4f4	1	2025-10-19 18:00:38.179341	2025-10-19 18:00:38.179341
dcdc4735-1d0f-4def-9ce3-d490ecdc2595	0c31985a-abdc-4b1f-8b5f-1356d79c7d6a	The Visionary holistic matrix Hat offers reliable performance and moral design	10.00	362.21	3622.05	\N	ff4a2600-29fe-4448-bec3-ea868988a9ed	2	2025-10-19 18:00:38.181821	2025-10-19 18:00:38.181821
e4b0521d-cf3a-4341-91a5-9f3a4a6e28f5	0c31985a-abdc-4b1f-8b5f-1356d79c7d6a	Experience the ivory brilliance of our Chicken, perfect for spirited environments	7.00	519.67	3637.72	\N	ca413110-b7e3-4734-a185-d21ea0960708	3	2025-10-19 18:00:38.183862	2025-10-19 18:00:38.183862
01c5730f-536d-4155-8ed1-d525bb5dfe4b	4acffda2-9966-4a97-98f0-69b192da3d8e	Professional-grade Shoes perfect for excellent training and recreational use	6.00	119.74	718.43	\N	18c91d63-8f9d-4974-ba97-a4079c7457d5	0	2025-10-19 18:00:38.189149	2025-10-19 18:00:38.189149
0026fd08-0cc9-4d8d-865d-33de2303ec58	4acffda2-9966-4a97-98f0-69b192da3d8e	Our sour-inspired Pants brings a taste of luxury to your paltry lifestyle	5.00	289.32	1446.60	\N	ff4a2600-29fe-4448-bec3-ea868988a9ed	1	2025-10-19 18:00:38.191184	2025-10-19 18:00:38.191184
f2effa27-6131-4a2d-8dc9-927e420c03e8	4acffda2-9966-4a97-98f0-69b192da3d8e	The grey Chicken combines Yemen aesthetics with Bromine-based durability	7.00	29.18	204.29	\N	d6d7e47b-cd48-48d8-a45a-fa75af1f9a52	2	2025-10-19 18:00:38.193006	2025-10-19 18:00:38.193006
45f55948-0e77-4b8e-8b51-9d1be9db7fcc	4acffda2-9966-4a97-98f0-69b192da3d8e	New Chips model with 67 GB RAM, 913 GB storage, and wretched features	10.00	355.78	3557.79	\N	29a61f52-d957-4207-b54b-7fc565a57541	3	2025-10-19 18:00:38.194869	2025-10-19 18:00:38.194869
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoices (id, tenant_id, invoice_number, client_id, issue_date, due_date, paid_date, subtotal, tax_rate, tax_amount, discount, total, amount_paid, status, currency, notes, terms, po_number, metadata, created_at, updated_at, created_by_id) FROM stdin;
782f47c5-5429-4739-937f-05e83974fc70	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	INV-00001	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	2025-08-24	2025-09-23	\N	8664.62	20.00	1732.92	0.00	10397.54	0.00	overdue	GBP	Utpote patior tolero iste aspernatur provident audacia audax amissio ciminatio.	Payment due within 30 days	\N	\N	2025-10-19 18:00:37.902894	2025-10-19 18:00:37.902894	a2adaa31-8f59-409a-b39b-72568022adb4
56252469-2b56-4b88-97bd-97a6e29b3fa8	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	INV-00002	8538cc30-f9e7-4b63-a885-56b23e16ecef	2025-09-08	2025-10-08	\N	1362.09	20.00	272.42	0.00	1634.51	0.00	draft	GBP	Soleo videlicet nisi thema confero.	Payment due within 30 days	\N	\N	2025-10-19 18:00:37.917321	2025-10-19 18:00:37.917321	a2adaa31-8f59-409a-b39b-72568022adb4
f2eee8ae-82b7-4d29-bc3b-f93eddc5cbbe	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	INV-00003	17f141c2-e297-4c93-9178-0fd819259c50	2025-10-10	2025-11-09	\N	5660.36	20.00	1132.07	0.00	6792.43	0.00	draft	GBP	Cotidie vociferor alii cubicularis vester consequatur umbra timidus concido.	Payment due within 30 days	\N	\N	2025-10-19 18:00:37.927586	2025-10-19 18:00:37.927586	a2adaa31-8f59-409a-b39b-72568022adb4
fee34995-9573-4150-93b9-ec3b31866225	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	INV-00004	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	2025-10-04	2025-11-03	\N	3206.53	20.00	641.31	0.00	3847.84	0.00	overdue	GBP	Cavus quam decens tero deserunt amplexus pariatur.	Payment due within 30 days	\N	\N	2025-10-19 18:00:37.934886	2025-10-19 18:00:37.934886	a2adaa31-8f59-409a-b39b-72568022adb4
c55fbebe-39d0-470f-b430-ec229d329be8	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	INV-00005	8538cc30-f9e7-4b63-a885-56b23e16ecef	2025-09-26	2025-10-26	\N	8163.58	20.00	1632.72	0.00	9796.30	0.00	sent	GBP	Ante tubineus tenax odio fugit suggero territo.	Payment due within 30 days	\N	\N	2025-10-19 18:00:37.941375	2025-10-19 18:00:37.941375	a2adaa31-8f59-409a-b39b-72568022adb4
8087e9cf-c34d-4fde-b5b3-2afa81d6fb17	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	INV-00006	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	2025-09-10	2025-10-10	\N	3286.56	20.00	657.31	0.00	3943.87	0.00	sent	GBP	Conculco teneo veniam laboriosam contabesco alius articulus tergeo una acies.	Payment due within 30 days	\N	\N	2025-10-19 18:00:37.954333	2025-10-19 18:00:37.954333	a2adaa31-8f59-409a-b39b-72568022adb4
9948faff-0d45-44a4-99d8-98e83c671a51	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	INV-00007	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	2025-09-30	2025-10-30	\N	4488.38	20.00	897.68	0.00	5386.06	0.00	draft	GBP	Tum viridis aliqua adfectus argentum laudantium aliquam cunae reiciendis arbitro.	Payment due within 30 days	\N	\N	2025-10-19 18:00:37.965501	2025-10-19 18:00:37.965501	a2adaa31-8f59-409a-b39b-72568022adb4
71607734-0c5b-4fb0-82ca-59f4b015d7d2	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	INV-00008	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	2025-08-22	2025-09-21	\N	6647.46	20.00	1329.49	0.00	7976.95	0.00	draft	GBP	Summisse ventosus aranea error cupressus terebro accommodo corrumpo capio.	Payment due within 30 days	\N	\N	2025-10-19 18:00:37.977375	2025-10-19 18:00:37.977375	a2adaa31-8f59-409a-b39b-72568022adb4
53d7a76d-9f46-44d3-a41f-cdb840541b42	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	INV-00009	17f141c2-e297-4c93-9178-0fd819259c50	2025-10-18	2025-11-17	\N	4189.08	20.00	837.82	0.00	5026.90	0.00	draft	GBP	Claustrum acsi uberrime eveniet sursum demonstro consequatur beneficium soleo corrumpo.	Payment due within 30 days	\N	\N	2025-10-19 18:00:37.983758	2025-10-19 18:00:37.983758	a2adaa31-8f59-409a-b39b-72568022adb4
458175f1-d715-4da1-8237-526ded79a29d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	INV-00010	b7295600-5c20-4de2-8782-af87987c2bee	2025-10-18	2025-11-17	\N	9505.96	20.00	1901.19	0.00	11407.15	0.00	sent	GBP	Delinquo quidem demoror casso harum.	Payment due within 30 days	\N	\N	2025-10-19 18:00:37.993336	2025-10-19 18:00:37.993336	a2adaa31-8f59-409a-b39b-72568022adb4
3bd48724-8a4f-4ddc-b4d0-f433b92ff1c0	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	INV-00011	d69d0436-37d7-42a4-b907-3d9c3a091ea6	2025-09-20	2025-10-20	\N	7126.90	20.00	1425.38	0.00	8552.28	0.00	sent	GBP	Decretum decor bellicus concido cimentarius ago coadunatio solus certe delectus.	Payment due within 30 days	\N	\N	2025-10-19 18:00:38.003425	2025-10-19 18:00:38.003425	a2adaa31-8f59-409a-b39b-72568022adb4
5d10ff3b-dfb7-4d2c-8175-26a95d33cd05	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	INV-00012	46859340-c8cf-4144-aa6c-28fbaf53fa0e	2025-09-21	2025-10-21	\N	4410.95	20.00	882.19	0.00	5293.14	0.00	overdue	GBP	Aiunt utor ocer arx vobis.	Payment due within 30 days	\N	\N	2025-10-19 18:00:38.014655	2025-10-19 18:00:38.014655	a2adaa31-8f59-409a-b39b-72568022adb4
9db4b836-e6d9-4f73-83c1-902a7df98843	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	INV-00013	17f141c2-e297-4c93-9178-0fd819259c50	2025-08-22	2025-09-21	\N	7780.25	20.00	1556.05	0.00	9336.30	0.00	overdue	GBP	Confido adnuo abscido cognatus universe.	Payment due within 30 days	\N	\N	2025-10-19 18:00:38.020243	2025-10-19 18:00:38.020243	a2adaa31-8f59-409a-b39b-72568022adb4
9dab5229-8398-4c6a-95de-c803948a0d38	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	INV-00014	67f62599-7f9f-44e8-bc18-d2ce08ea9919	2025-08-26	2025-09-25	\N	5373.11	20.00	1074.62	0.00	6447.73	0.00	draft	GBP	Tolero volva arceo.	Payment due within 30 days	\N	\N	2025-10-19 18:00:38.027087	2025-10-19 18:00:38.027087	a2adaa31-8f59-409a-b39b-72568022adb4
5164f2bb-c267-4031-97b6-3c24cc330048	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	INV-00015	d69d0436-37d7-42a4-b907-3d9c3a091ea6	2025-09-07	2025-10-07	\N	4249.16	20.00	849.83	0.00	5098.99	0.00	overdue	GBP	Angustus iure minima debeo tamisium desipio.	Payment due within 30 days	\N	\N	2025-10-19 18:00:38.034003	2025-10-19 18:00:38.034003	a2adaa31-8f59-409a-b39b-72568022adb4
b19758e2-db8e-4f7f-b7b3-68c8a8f3cf22	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	INV-00016	b0a95e11-90ac-4ab3-b099-c4de69f498b8	2025-08-27	2025-09-26	\N	5401.92	20.00	1080.38	0.00	6482.30	0.00	overdue	GBP	Alveus libero talis.	Payment due within 30 days	\N	\N	2025-10-19 18:00:38.041657	2025-10-19 18:00:38.041657	a2adaa31-8f59-409a-b39b-72568022adb4
c851db27-b9a7-4209-a906-a1d5d4faacac	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	INV-00017	45b3d726-e151-4770-9b64-4653914bdaa5	2025-08-26	2025-09-25	\N	751.53	20.00	150.31	0.00	901.84	0.00	draft	GBP	Decumbo supplanto cultellus spoliatio suppono temporibus aspicio animus depono adulatio.	Payment due within 30 days	\N	\N	2025-10-19 18:00:38.049922	2025-10-19 18:00:38.049922	a2adaa31-8f59-409a-b39b-72568022adb4
29f4aab4-fb6b-4082-9ff0-d8bd4a5188f2	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	INV-00018	8538cc30-f9e7-4b63-a885-56b23e16ecef	2025-10-12	2025-11-11	\N	6586.78	20.00	1317.36	0.00	7904.14	0.00	sent	GBP	Repellendus decipio cogito creber.	Payment due within 30 days	\N	\N	2025-10-19 18:00:38.056243	2025-10-19 18:00:38.056243	a2adaa31-8f59-409a-b39b-72568022adb4
11639761-1b64-4d60-83ed-ee4ca9a6daeb	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	INV-00019	6ecda653-6094-4502-9d1d-6e90d9ea99ed	2025-10-08	2025-11-07	\N	4390.84	20.00	878.17	0.00	5269.01	0.00	overdue	GBP	Caries adipisci aestivus.	Payment due within 30 days	\N	\N	2025-10-19 18:00:38.061994	2025-10-19 18:00:38.061994	a2adaa31-8f59-409a-b39b-72568022adb4
4079ba66-04f2-4fc5-85b3-fb38774d0914	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	INV-00020	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	2025-09-21	2025-10-21	\N	5375.42	20.00	1075.08	0.00	6450.50	0.00	overdue	GBP	Viriliter aequitas quod deinde vulnero cattus ago.	Payment due within 30 days	\N	\N	2025-10-19 18:00:38.07471	2025-10-19 18:00:38.07471	a2adaa31-8f59-409a-b39b-72568022adb4
c96a5a42-c700-4e1d-8b61-fd3b633d62f9	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	INV-00021	17f141c2-e297-4c93-9178-0fd819259c50	2025-09-04	2025-10-04	\N	4508.38	20.00	901.68	0.00	5410.06	0.00	overdue	GBP	Currus est cedo defendo porro ago cupio thalassinus tutis timidus.	Payment due within 30 days	\N	\N	2025-10-19 18:00:38.080427	2025-10-19 18:00:38.080427	a2adaa31-8f59-409a-b39b-72568022adb4
9a096553-f4ca-4e72-a598-b3458053fdff	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	INV-00022	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	2025-10-01	2025-10-31	2025-10-04	5158.19	20.00	1031.64	0.00	6189.83	6189.83	paid	GBP	Brevis ascisco venio pecus.	Payment due within 30 days	\N	\N	2025-10-19 18:00:38.0911	2025-10-19 18:00:38.0911	a2adaa31-8f59-409a-b39b-72568022adb4
e547c88a-aa42-4542-a738-6c8eeb7a0ee6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	INV-00023	12edb785-268b-4219-840d-15b8f0df1198	2025-09-15	2025-10-15	\N	3374.30	20.00	674.86	0.00	4049.16	0.00	sent	GBP	Video thalassinus ceno comburo complectus corrumpo inventore decumbo.	Payment due within 30 days	\N	\N	2025-10-19 18:00:38.109899	2025-10-19 18:00:38.109899	a2adaa31-8f59-409a-b39b-72568022adb4
a45c6e3c-6d93-4e62-8019-7e606919e5ea	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	INV-00024	46859340-c8cf-4144-aa6c-28fbaf53fa0e	2025-09-05	2025-10-05	2025-09-17	6405.89	20.00	1281.18	0.00	7687.07	7687.07	paid	GBP	Stips omnis dicta contra corrumpo.	Payment due within 30 days	\N	\N	2025-10-19 18:00:38.120603	2025-10-19 18:00:38.120603	a2adaa31-8f59-409a-b39b-72568022adb4
b85b5061-58b4-40f2-a0d9-4636f79f0ac9	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	INV-00025	17f141c2-e297-4c93-9178-0fd819259c50	2025-08-21	2025-09-20	\N	8223.37	20.00	1644.67	0.00	9868.04	0.00	draft	GBP	Expedita terror adeptio cenaculum cunae verto sopor.	Payment due within 30 days	\N	\N	2025-10-19 18:00:38.126145	2025-10-19 18:00:38.126145	a2adaa31-8f59-409a-b39b-72568022adb4
d27ad49a-c63b-4428-b632-fa7f40924dd3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	INV-00026	45b3d726-e151-4770-9b64-4653914bdaa5	2025-09-13	2025-10-13	\N	3107.88	20.00	621.58	0.00	3729.46	0.00	overdue	GBP	Confero avarus vitae.	Payment due within 30 days	\N	\N	2025-10-19 18:00:38.136154	2025-10-19 18:00:38.136154	a2adaa31-8f59-409a-b39b-72568022adb4
78e42166-2e5d-4486-bc40-424a28c60f1b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	INV-00027	4554e09d-4391-42a8-a2cd-9702bce80511	2025-09-11	2025-10-11	2025-10-09	3351.63	20.00	670.33	0.00	4021.96	4021.96	paid	GBP	Votum utique nulla iste voluptates assentator varius tergum vilicus.	Payment due within 30 days	\N	\N	2025-10-19 18:00:38.14584	2025-10-19 18:00:38.14584	a2adaa31-8f59-409a-b39b-72568022adb4
bbc3644e-8323-4f26-acaa-c154dca75518	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	INV-00028	46859340-c8cf-4144-aa6c-28fbaf53fa0e	2025-10-14	2025-11-13	\N	5862.76	20.00	1172.55	0.00	7035.31	0.00	draft	GBP	Teres triumphus addo cogito deporto.	Payment due within 30 days	\N	\N	2025-10-19 18:00:38.153436	2025-10-19 18:00:38.153436	a2adaa31-8f59-409a-b39b-72568022adb4
0c31985a-abdc-4b1f-8b5f-1356d79c7d6a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	INV-00029	405d4d05-841b-437d-af7d-70b66dda4cbc	2025-09-07	2025-10-07	\N	7854.05	20.00	1570.81	0.00	9424.86	0.00	draft	GBP	Audacia combibo cursus voluptate adnuo verus adiuvo alioqui universe.	Payment due within 30 days	\N	\N	2025-10-19 18:00:38.172479	2025-10-19 18:00:38.172479	a2adaa31-8f59-409a-b39b-72568022adb4
4acffda2-9966-4a97-98f0-69b192da3d8e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	INV-00030	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	2025-09-21	2025-10-21	\N	5927.11	20.00	1185.42	0.00	7112.53	0.00	overdue	GBP	Vitiosus tabesco stillicidium.	Payment due within 30 days	\N	\N	2025-10-19 18:00:38.186359	2025-10-19 18:00:38.186359	a2adaa31-8f59-409a-b39b-72568022adb4
\.


--
-- Data for Name: kyc_verifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kyc_verifications (id, tenant_id, client_id, onboarding_session_id, lemverify_id, client_ref, status, outcome, document_type, document_verified, document_data, facematch_result, facematch_score, liveness_result, liveness_score, aml_result, aml_status, pep_match, sanctions_match, watchlist_match, adverse_media_match, report_url, documents_url, approved_by, approved_at, rejection_reason, metadata, created_at, completed_at, updated_at) FROM stdin;
\.


--
-- Data for Name: leads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.leads (id, tenant_id, first_name, last_name, email, phone, mobile, company_name, "position", website, status, source, industry, estimated_turnover, estimated_employees, qualification_score, interested_services, notes, last_contacted_at, next_follow_up_at, assigned_to_id, converted_to_client_id, converted_at, created_at, updated_at, created_by) FROM stdin;
e63b2df3-eee0-4503-ad18-9f425ef2c447	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Tom	Cummerata	Tom.Cummerata9@torphy,hayesando'keefe.com	447.934.6063 x22663	956.721.3606 x31643	Torphy, Hayes and O'Keefe	District Brand Agent	https://www.torphy,hayesando'keefe.com	new	Referral	Professional Services	514737.00	156	7	["VAT_STANDARD", "TAX_PLANNING"]	Lead from Networking Event. New lead, needs initial assessment.	\N	2025-10-29 16:46:56.499	c4f75303-a973-43e1-8f69-dfc6500c302c	\N	\N	2025-10-19 18:00:34.620435	2025-10-19 18:00:34.620435	a2adaa31-8f59-409a-b39b-72568022adb4
c019a27b-c317-4a3a-8607-23ca13f856f8	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Benedict	Daniel	Benedict_Daniel69@armstrong,blandaandcollier.com	1-421-817-8661 x97684	237.494.5127 x0245	Armstrong, Blanda and Collier	Legacy Implementation Planner	https://www.armstrong,blandaandcollier.com	negotiating	Networking Event	Technology	2866398.00	49	9	["COMP_ACCOUNTS", "VAT_STANDARD", "PAYROLL"]	Lead from Website Enquiry. In active negotiations on pricing and services.	2025-10-08 17:38:34.544	\N	0409f8de-7e1d-4245-96c2-02a3b1c90a81	\N	\N	2025-10-19 18:00:34.627237	2025-10-19 18:00:34.627237	a2adaa31-8f59-409a-b39b-72568022adb4
405a91b7-467c-4fb4-ad1c-3c08e394ca1f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Shany	Nienow	Shany.Nienow6@tromp-nolan.com	242.407.0976 x02988	686-967-1534	Tromp - Nolan	Regional Solutions Coordinator	https://www.tromp-nolan.com	new	Referral	Manufacturing	3431224.00	98	9	["BOOK_BASIC", "COMP_ACCOUNTS"]	Lead from Website Enquiry. New lead, needs initial assessment.	\N	2025-10-29 04:53:28.456	0409f8de-7e1d-4245-96c2-02a3b1c90a81	\N	\N	2025-10-19 18:00:34.631894	2025-10-19 18:00:34.631894	a2adaa31-8f59-409a-b39b-72568022adb4
4a991b90-36f8-4e15-aabf-0cbf948ffefd	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Tamara	Ratke	Tamara.Ratke60@herzog,grantandmayert.com	1-446-286-0617 x841	793.549.9093 x26982	Herzog, Grant and Mayert	International Marketing Planner	https://www.herzog,grantandmayert.com	negotiating	LinkedIn	Manufacturing	1935777.00	165	6	["BOOK_BASIC", "VAT_STANDARD", "PAYROLL"]	Lead from LinkedIn. In active negotiations on pricing and services.	2025-09-25 16:25:11.374	\N	0409f8de-7e1d-4245-96c2-02a3b1c90a81	\N	\N	2025-10-19 18:00:34.637598	2025-10-19 18:00:34.637598	a2adaa31-8f59-409a-b39b-72568022adb4
06a0a20a-84cc-4b90-865b-9d05a601e071	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Zoe	Schaden	Zoe_Schaden90@conroy-wintheiser.com	1-453-364-2883 x49706	595.902.8876 x9218	Conroy - Wintheiser	Dynamic Research Liaison	https://www.conroy-wintheiser.com	qualified	Google Search	Hospitality	2001068.00	145	9	["TAX_PLANNING", "BOOK_BASIC", "VAT_STANDARD"]	Lead from Referral. High potential client, ready for proposal.	2025-10-16 10:24:27.245	2025-11-02 12:59:23.248	a2adaa31-8f59-409a-b39b-72568022adb4	\N	\N	2025-10-19 18:00:34.643598	2025-10-19 18:00:34.643598	a2adaa31-8f59-409a-b39b-72568022adb4
4b8ef62a-b05f-40ff-8da7-6cf07343b42c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Tanner	Mills	Tanner.Mills@hauckgroup.com	361-338-3425 x77859	1-593-497-5152 x9613	Hauck Group	International Response Analyst	https://www.hauckgroup.com	new	LinkedIn	Hospitality	4713709.00	117	10	["VAT_STANDARD", "PAYROLL", "TAX_PLANNING"]	Lead from Google Search. New lead, needs initial assessment.	\N	2025-11-01 09:43:07.199	a2adaa31-8f59-409a-b39b-72568022adb4	\N	\N	2025-10-19 18:00:34.649178	2025-10-19 18:00:34.649178	a2adaa31-8f59-409a-b39b-72568022adb4
666562bf-4133-4055-91af-9eeb87f340fc	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Candace	Anderson	Candace.Anderson@bergnauminc.com	1-793-422-8829 x02447	844-974-0021	Bergnaum Inc	Principal Creative Agent	https://www.bergnauminc.com	negotiating	Networking Event	Retail	2537850.00	167	4	["TAX_PLANNING"]	Lead from Cold Call. In active negotiations on pricing and services.	2025-10-01 03:36:50.906	\N	c4f75303-a973-43e1-8f69-dfc6500c302c	\N	\N	2025-10-19 18:00:34.654611	2025-10-19 18:00:34.654611	a2adaa31-8f59-409a-b39b-72568022adb4
2271e434-4f4d-4931-b41e-07343eaa316a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Buck	Lehner	Buck_Lehner67@bergnaum-goldner.com	957.840.9854 x034	258.918.1795 x13851	Bergnaum - Goldner	Product Metrics Designer	https://www.bergnaum-goldner.com	qualified	Google Search	Healthcare	3100983.00	66	2	["TAX_PLANNING", "BOOK_BASIC", "PAYROLL"]	Lead from Website Enquiry. High potential client, ready for proposal.	2025-10-06 22:25:47.852	2025-11-02 12:14:42.748	a2adaa31-8f59-409a-b39b-72568022adb4	\N	\N	2025-10-19 18:00:34.65975	2025-10-19 18:00:34.65975	a2adaa31-8f59-409a-b39b-72568022adb4
165da49d-803d-4046-807b-cb354d21fac5	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Fern	Schaden	Fern_Schaden88@vandervort,auerandbashirian.com	(983) 294-1934 x928	1-446-400-8377	Vandervort, Auer and Bashirian	Human Program Designer	https://www.vandervort,auerandbashirian.com	negotiating	Google Search	Construction	1573377.00	115	4	["VAT_STANDARD", "TAX_PLANNING", "PAYROLL"]	Lead from Google Search. In active negotiations on pricing and services.	2025-10-06 10:58:53.383	\N	0409f8de-7e1d-4245-96c2-02a3b1c90a81	\N	\N	2025-10-19 18:00:34.668174	2025-10-19 18:00:34.668174	a2adaa31-8f59-409a-b39b-72568022adb4
62208a88-9036-4044-95ac-e03c60e5afa0	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Keyshawn	Carroll	Keyshawn.Carroll96@bradtke,cartwrightandkris.com	(383) 229-7799 x7149	449.838.2373 x36299	Bradtke, Cartwright and Kris	Regional Program Executive	https://www.bradtke,cartwrightandkris.com	negotiating	Cold Call	E-commerce	1665878.00	16	6	["BOOK_BASIC", "TAX_PLANNING", "PAYROLL"]	Lead from Website Enquiry. In active negotiations on pricing and services.	2025-10-03 15:42:00.11	\N	0409f8de-7e1d-4245-96c2-02a3b1c90a81	\N	\N	2025-10-19 18:00:34.671821	2025-10-19 18:00:34.671821	a2adaa31-8f59-409a-b39b-72568022adb4
69769454-bc45-4303-be20-c92c3bf7f086	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Joana	Welch	Joana.Welch@macejkovic-funk.com	566.516.4069 x9989	671-300-7357 x25852	Macejkovic - Funk	International Functionality Manager	https://www.macejkovic-funk.com	contacted	Google Search	E-commerce	4694294.00	22	3	["BOOK_BASIC"]	Lead from Referral. Initial contact made, awaiting follow-up.	2025-10-09 14:00:38.595	2025-10-27 05:00:50.159	c4f75303-a973-43e1-8f69-dfc6500c302c	\N	\N	2025-10-19 18:00:34.677969	2025-10-19 18:00:34.677969	a2adaa31-8f59-409a-b39b-72568022adb4
546a9e14-3012-4df6-8838-0df2e8dd0e0b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Emerald	Rempel	Emerald_Rempel@runolfsson-maggio.com	279.263.3245 x74675	1-287-639-0702 x2414	Runolfsson - Maggio	Legacy Configuration Representative	https://www.runolfsson-maggio.com	new	Referral	Construction	679502.00	179	7	["COMP_ACCOUNTS", "VAT_STANDARD", "BOOK_BASIC"]	Lead from Referral. New lead, needs initial assessment.	\N	2025-10-30 16:02:24.264	c4f75303-a973-43e1-8f69-dfc6500c302c	\N	\N	2025-10-19 18:00:34.684056	2025-10-19 18:00:34.684056	a2adaa31-8f59-409a-b39b-72568022adb4
98cc4c56-e9cd-475b-a92c-00d2df56c702	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Misael	Hoppe	Misael_Hoppe@schamberger,beattyandhuel.com	208-879-3709 x13115	1-364-760-5425	Schamberger, Beatty and Huel	Principal Quality Agent	https://www.schamberger,beattyandhuel.com	qualified	Referral	Healthcare	2242619.00	163	8	["COMP_ACCOUNTS", "TAX_PLANNING", "VAT_STANDARD"]	Lead from LinkedIn. High potential client, ready for proposal.	2025-10-10 23:55:28.647	2025-10-24 04:47:50.288	0409f8de-7e1d-4245-96c2-02a3b1c90a81	\N	\N	2025-10-19 18:00:34.690162	2025-10-19 18:00:34.690162	a2adaa31-8f59-409a-b39b-72568022adb4
5abce537-fd3c-4b99-b438-976feed0cc6e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Soledad	Fritsch	Soledad_Fritsch44@prohaskallc.com	(341) 920-9295	(423) 244-2027 x26159	Prohaska LLC	Senior Markets Director	https://www.prohaskallc.com	negotiating	Referral	Retail	1763728.00	153	5	["TAX_PLANNING"]	Lead from Referral. In active negotiations on pricing and services.	2025-09-26 11:02:46.485	\N	d6f36046-e274-4776-a3d7-58eadb9d96b0	\N	\N	2025-10-19 18:00:34.695042	2025-10-19 18:00:34.695042	a2adaa31-8f59-409a-b39b-72568022adb4
fd511c4f-c1b9-4a40-b1c2-d7d353503b1f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Will	Ferry	Will_Ferry57@hettinger,labadieandkrajcik.com	686.476.5065	(370) 567-5437 x2066	Hettinger, Labadie and Krajcik	Regional Intranet Strategist	https://www.hettinger,labadieandkrajcik.com	contacted	Referral	Construction	1474076.00	19	10	["BOOK_BASIC"]	Lead from Cold Call. Initial contact made, awaiting follow-up.	2025-10-08 13:44:59.243	2025-10-28 01:51:43.943	0409f8de-7e1d-4245-96c2-02a3b1c90a81	\N	\N	2025-10-19 18:00:34.699247	2025-10-19 18:00:34.699247	a2adaa31-8f59-409a-b39b-72568022adb4
\.


--
-- Data for Name: message_thread_participants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.message_thread_participants (id, thread_id, participant_type, participant_id, user_id, role, joined_at, last_read_at, muted_until) FROM stdin;
2ea62b34-d457-4af0-915b-c0c15f4201ce	e25aabe4-0428-4659-8a8a-09a3b8707431	staff	a2adaa31-8f59-409a-b39b-72568022adb4	a2adaa31-8f59-409a-b39b-72568022adb4	member	2025-10-19 18:00:42.294182	2025-10-19 00:59:14.667	\N
a0d8fb83-3f45-43d7-9c4d-a1f8da6ec913	e25aabe4-0428-4659-8a8a-09a3b8707431	staff	d6f36046-e274-4776-a3d7-58eadb9d96b0	d6f36046-e274-4776-a3d7-58eadb9d96b0	member	2025-10-19 18:00:42.294182	2025-10-19 02:19:10.225	\N
8a4a8cc2-3479-4165-a73b-bc59d6716b00	e25aabe4-0428-4659-8a8a-09a3b8707431	staff	c4f75303-a973-43e1-8f69-dfc6500c302c	c4f75303-a973-43e1-8f69-dfc6500c302c	member	2025-10-19 18:00:42.294182	2025-10-19 11:05:29.668	\N
8d31c38c-67d0-4706-9638-49c591f736a6	e25aabe4-0428-4659-8a8a-09a3b8707431	staff	0409f8de-7e1d-4245-96c2-02a3b1c90a81	0409f8de-7e1d-4245-96c2-02a3b1c90a81	member	2025-10-19 18:00:42.294182	2025-10-18 18:14:39.537	\N
15bce1b1-d793-4431-9683-2e3a66cd63fe	4b258d9b-509e-4b8e-906a-2b5e3df81795	staff	a2adaa31-8f59-409a-b39b-72568022adb4	a2adaa31-8f59-409a-b39b-72568022adb4	admin	2025-10-19 18:00:42.294182	2025-10-18 20:51:02.596	\N
93f915ae-654c-4d5a-b936-162d60139078	4b258d9b-509e-4b8e-906a-2b5e3df81795	staff	d6f36046-e274-4776-a3d7-58eadb9d96b0	d6f36046-e274-4776-a3d7-58eadb9d96b0	member	2025-10-19 18:00:42.294182	2025-10-19 17:58:25.276	\N
a30b5369-7c89-4707-a3c1-87bfc812e828	00a82dac-3aec-497e-b1c1-0dd4bbd8863c	staff	a2adaa31-8f59-409a-b39b-72568022adb4	a2adaa31-8f59-409a-b39b-72568022adb4	member	2025-10-19 18:00:42.294182	2025-10-19 05:19:41.3	\N
aea77c7c-06ee-47e5-a5ad-96390d4372ed	00a82dac-3aec-497e-b1c1-0dd4bbd8863c	staff	d6f36046-e274-4776-a3d7-58eadb9d96b0	d6f36046-e274-4776-a3d7-58eadb9d96b0	member	2025-10-19 18:00:42.294182	2025-10-19 00:00:05.145	\N
f939bda9-1e56-415d-a000-cf603a383e28	96939e7a-bfac-4564-b9d7-179de4fd4ce3	staff	d6f36046-e274-4776-a3d7-58eadb9d96b0	d6f36046-e274-4776-a3d7-58eadb9d96b0	member	2025-10-19 18:00:42.294182	2025-10-19 14:24:25.217	\N
371b438a-94d3-46e6-ab26-8fb176654264	96939e7a-bfac-4564-b9d7-179de4fd4ce3	staff	c4f75303-a973-43e1-8f69-dfc6500c302c	c4f75303-a973-43e1-8f69-dfc6500c302c	member	2025-10-19 18:00:42.294182	2025-10-18 22:18:04.693	\N
8012057b-37ab-44e8-8fd5-f7a86dcfd2d0	e65ca04e-65ba-49b0-9c92-daa331735741	staff	a2adaa31-8f59-409a-b39b-72568022adb4	a2adaa31-8f59-409a-b39b-72568022adb4	member	2025-10-19 18:00:42.294182	2025-10-19 05:16:18.942	\N
f2e26ca4-da3e-4dbc-9857-e5f63a747338	e65ca04e-65ba-49b0-9c92-daa331735741	staff	d6f36046-e274-4776-a3d7-58eadb9d96b0	d6f36046-e274-4776-a3d7-58eadb9d96b0	member	2025-10-19 18:00:42.294182	2025-10-19 11:04:18.146	\N
\.


--
-- Data for Name: message_threads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.message_threads (id, tenant_id, type, name, description, is_private, client_id, created_by, created_at, updated_at, last_message_at) FROM stdin;
e25aabe4-0428-4659-8a8a-09a3b8707431	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	team_channel	General	Team-wide announcements and discussions	f	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-19 18:00:42.280109	2025-10-19 18:00:42.280109	2025-10-18 10:23:51.447
4b258d9b-509e-4b8e-906a-2b5e3df81795	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	team_channel	Tax Team	Tax-specific discussions	t	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-19 18:00:42.280109	2025-10-19 18:00:42.280109	2025-10-18 02:37:22.477
00a82dac-3aec-497e-b1c1-0dd4bbd8863c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	direct	\N	\N	f	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-19 18:00:42.280109	2025-10-19 18:00:42.280109	2025-10-17 19:29:17.32
96939e7a-bfac-4564-b9d7-179de4fd4ce3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	direct	\N	\N	f	\N	d6f36046-e274-4776-a3d7-58eadb9d96b0	2025-10-19 18:00:42.280109	2025-10-19 18:00:42.280109	2025-10-19 06:55:29.963
e65ca04e-65ba-49b0-9c92-daa331735741	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	client	\N	\N	f	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-19 18:00:42.280109	2025-10-19 18:00:42.280109	2025-10-19 07:29:45.374
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.messages (id, thread_id, sender_type, sender_id, user_id, content, type, metadata, reply_to_id, is_edited, is_deleted, created_at, updated_at) FROM stdin;
75d7906a-40f0-4928-ac92-4bdc71305a48	e25aabe4-0428-4659-8a8a-09a3b8707431	staff	a2adaa31-8f59-409a-b39b-72568022adb4	a2adaa31-8f59-409a-b39b-72568022adb4	Welcome to Practice Hub team chat! Let's keep all team communication here.	text	\N	\N	f	f	2025-10-19 10:00:42.308	2025-10-19 18:00:42.310671
9b64dadc-5ffa-4706-be76-7174a0abdb6a	e25aabe4-0428-4659-8a8a-09a3b8707431	staff	d6f36046-e274-4776-a3d7-58eadb9d96b0	d6f36046-e274-4776-a3d7-58eadb9d96b0	Looking forward to using this! Much better than email chains.	text	\N	\N	f	f	2025-10-19 11:00:42.308	2025-10-19 18:00:42.310671
4d6627d1-f544-4939-88ac-942b7911ce4d	e25aabe4-0428-4659-8a8a-09a3b8707431	staff	c4f75303-a973-43e1-8f69-dfc6500c302c	c4f75303-a973-43e1-8f69-dfc6500c302c	Agreed! This will help us stay organized.	text	\N	\N	f	f	2025-10-19 12:00:42.308	2025-10-19 18:00:42.310671
505b8763-e05c-4433-aa42-fb358a0b9669	4b258d9b-509e-4b8e-906a-2b5e3df81795	staff	a2adaa31-8f59-409a-b39b-72568022adb4	a2adaa31-8f59-409a-b39b-72568022adb4	Reminder: Tax filing deadline is next week for Q4 clients.	text	\N	\N	f	f	2025-10-19 13:00:42.308	2025-10-19 18:00:42.310671
b26adbe0-ffea-4ae3-bb22-56c1fc19f745	4b258d9b-509e-4b8e-906a-2b5e3df81795	staff	d6f36046-e274-4776-a3d7-58eadb9d96b0	d6f36046-e274-4776-a3d7-58eadb9d96b0	On it! I'll reach out to anyone who hasn't submitted documents yet.	text	\N	\N	f	f	2025-10-19 14:00:42.308	2025-10-19 18:00:42.310671
040230c5-d3f9-4bea-b4be-d3cfb1923cfa	00a82dac-3aec-497e-b1c1-0dd4bbd8863c	staff	a2adaa31-8f59-409a-b39b-72568022adb4	a2adaa31-8f59-409a-b39b-72568022adb4	Can you review the TechStart Solutions proposal when you have a moment?	text	\N	\N	f	f	2025-10-19 15:00:42.308	2025-10-19 18:00:42.310671
9c5ce74a-8031-4eba-a135-cf4dcf9e9986	00a82dac-3aec-497e-b1c1-0dd4bbd8863c	staff	d6f36046-e274-4776-a3d7-58eadb9d96b0	d6f36046-e274-4776-a3d7-58eadb9d96b0	Sure, I'll take a look this afternoon and send you my feedback.	text	\N	\N	f	f	2025-10-19 16:00:42.308	2025-10-19 18:00:42.310671
217b72e9-4733-4d51-9ebc-c7fe4faa2fc3	e65ca04e-65ba-49b0-9c92-daa331735741	staff	a2adaa31-8f59-409a-b39b-72568022adb4	a2adaa31-8f59-409a-b39b-72568022adb4	Hi! Welcome to your client portal. Feel free to reach out if you have any questions.	text	\N	\N	f	f	2025-10-19 17:00:42.308	2025-10-19 18:00:42.310671
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, tenant_id, user_id, type, title, message, action_url, entity_type, entity_id, is_read, read_at, metadata, created_at) FROM stdin;
21a7f890-101b-48c8-9669-5c3e42c638ca	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	task_assigned	New Task Assigned	Joe Test assigned you a task: Review proposal for TechStart Solutions	/client-hub/tasks/8c04c9d5-2992-4108-bc71-d0210b7972e2	task	8c04c9d5-2992-4108-bc71-d0210b7972e2	f	\N	\N	2025-10-19 10:38:41.059
e189ae05-8282-42e5-b848-e8dfbdc739b6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	mention	Mentioned in Message	Sarah mentioned you in #General	/messages/e25aabe4-0428-4659-8a8a-09a3b8707431	message	e25aabe4-0428-4659-8a8a-09a3b8707431	f	\N	\N	2025-10-16 18:37:51.704
bbc483ea-8e6a-42b2-83c1-2dee3bd01bf7	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	approval_needed	KYC Approval Needed	New KYC verification requires your review	/admin/kyc-review	kyc_verification	\N	t	2025-10-19 05:52:23.495	\N	2025-10-17 20:30:00.995
07555f92-dacb-4601-909b-0a6e54e297ec	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	client_message	New Client Message	TechStart Solutions sent you a message	/messages/e65ca04e-65ba-49b0-9c92-daa331735741	message	e65ca04e-65ba-49b0-9c92-daa331735741	f	\N	\N	2025-10-19 15:57:34.981
614a81cd-2c92-4347-8bf2-8fb08b1b3ad6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	task_assigned	New Task Assigned	You have been assigned to complete tax returns for Green Energy Ltd	/client-hub/tasks/92700c16-c146-4a6e-9610-46ac28f4b4c3	task	92700c16-c146-4a6e-9610-46ac28f4b4c3	t	2025-10-17 23:19:18.164	\N	2025-10-19 01:27:52.779
\.


--
-- Data for Name: onboarding_responses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.onboarding_responses (id, tenant_id, onboarding_session_id, question_key, answer_value, extracted_from_ai, verified_by_user, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: onboarding_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.onboarding_sessions (id, tenant_id, client_id, start_date, target_completion_date, actual_completion_date, status, priority, assigned_to_id, progress, notes, created_at, updated_at) FROM stdin;
dba8a056-5928-41b6-8584-52e517451de7	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	702b5a48-f7a9-464c-8833-1ff6577e50e6	2025-10-19 18:00:34.026	2025-11-02 18:00:34.026	\N	not_started	medium	0409f8de-7e1d-4245-96c2-02a3b1c90a81	38	\N	2025-10-19 18:00:34.702144	2025-10-19 18:00:34.702144
d7a488d0-5f4f-4920-9523-f8497f8c0ee9	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d69d0436-37d7-42a4-b907-3d9c3a091ea6	2025-10-19 18:00:34.026	2025-11-02 18:00:34.026	\N	not_started	high	a2adaa31-8f59-409a-b39b-72568022adb4	45	\N	2025-10-19 18:00:34.730743	2025-10-19 18:00:34.730743
d94454c7-6e27-4891-8a91-e92725e22838	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a4464f5a-2125-46d9-9f58-7252c9adc16b	2025-10-19 18:00:34.026	2025-11-02 18:00:34.026	\N	in_progress	high	d6f36046-e274-4776-a3d7-58eadb9d96b0	15	\N	2025-10-19 18:00:34.750072	2025-10-19 18:00:34.750072
1fa27e81-524c-45d8-932d-dd727a19d6af	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	6ecda653-6094-4502-9d1d-6e90d9ea99ed	2025-10-19 18:00:34.026	2025-11-02 18:00:34.026	\N	in_progress	medium	c4f75303-a973-43e1-8f69-dfc6500c302c	36	\N	2025-10-19 18:00:34.764217	2025-10-19 18:00:34.764217
45e05096-9c95-4378-96f5-da8bac0468a5	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b7295600-5c20-4de2-8782-af87987c2bee	2025-10-19 18:00:34.026	2025-11-02 18:00:34.026	\N	in_progress	low	c4f75303-a973-43e1-8f69-dfc6500c302c	11	\N	2025-10-19 18:00:34.779339	2025-10-19 18:00:34.779339
\.


--
-- Data for Name: onboarding_tasks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.onboarding_tasks (id, tenant_id, session_id, task_name, description, required, sequence, days, due_date, completion_date, done, notes, assigned_to_id, progress_weight, created_at, updated_at) FROM stdin;
83ad6594-9f29-4bb1-9357-7955bbe8bf6c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	dba8a056-5928-41b6-8584-52e517451de7	Ensure Client is Setup in Bright Manager	Check client is in Bright Manager with appropriate client information, services and pricing filled in	t	10	0	2025-10-19 18:00:34.026	2025-10-18 21:29:27.802	t	Vapulus amor utor caute nam audacia defungo casso aut.	0409f8de-7e1d-4245-96c2-02a3b1c90a81	5	2025-10-19 18:00:34.722583	2025-10-19 18:00:34.722583
c57d5e12-02df-42ab-bc74-cbb6dcc2f208	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	dba8a056-5928-41b6-8584-52e517451de7	Request client ID documents	Request passport/driving license and proof of address	t	20	0	2025-10-19 18:00:34.026	\N	f	\N	0409f8de-7e1d-4245-96c2-02a3b1c90a81	5	2025-10-19 18:00:34.722583	2025-10-19 18:00:34.722583
a6dcf074-592e-4c32-aa6a-a6ab9c8ce904	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	dba8a056-5928-41b6-8584-52e517451de7	Receive and Save client ID documents	Save client ID documents to client AML folder on OneDrive	t	25	2	2025-10-21 18:00:34.026	\N	f	\N	0409f8de-7e1d-4245-96c2-02a3b1c90a81	5	2025-10-19 18:00:34.722583	2025-10-19 18:00:34.722583
64575bed-7e08-49bc-9f66-5cc5ecf51992	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	dba8a056-5928-41b6-8584-52e517451de7	Complete AML ID check	Verify identity documents and complete AML compliance check	t	30	4	2025-10-23 18:00:34.026	2025-10-18 16:56:00.655	t	Tutamen cariosus minima.	0409f8de-7e1d-4245-96c2-02a3b1c90a81	6	2025-10-19 18:00:34.722583	2025-10-19 18:00:34.722583
dfa33b4c-836d-493f-b591-b988a34840b5	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	dba8a056-5928-41b6-8584-52e517451de7	Perform client risk assessment and grading	Assess client risk factors and determine risk level (Low/Medium/High), also a assign client a grade based off current communication quality	t	40	4	2025-10-23 18:00:34.026	\N	f	\N	0409f8de-7e1d-4245-96c2-02a3b1c90a81	6	2025-10-19 18:00:34.722583	2025-10-19 18:00:34.722583
8e1dbd87-84e7-49ce-8acc-15c24982291d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	dba8a056-5928-41b6-8584-52e517451de7	Send Letter of Engagement	Send LoE detailing scope of work, from Bright Manager and ensure it is signed	t	50	4	2025-10-23 18:00:34.026	2025-10-17 09:27:07.572	t	Adsidue crapula perferendis summisse.	0409f8de-7e1d-4245-96c2-02a3b1c90a81	8	2025-10-19 18:00:34.722583	2025-10-19 18:00:34.722583
3eaf8a6f-ff86-4f11-bf2f-61778a3492df	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	dba8a056-5928-41b6-8584-52e517451de7	Assign Client Manager	Discuss internally to decide which person will take on the new client	t	51	4	2025-10-23 18:00:34.026	\N	f	\N	0409f8de-7e1d-4245-96c2-02a3b1c90a81	5	2025-10-19 18:00:34.722583	2025-10-19 18:00:34.722583
54d5e6ff-a160-496b-af66-8d45a1c71787	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	dba8a056-5928-41b6-8584-52e517451de7	Confirm Signing of LoE	Confirm the signing of Letter of Engagement before proceeding	t	55	7	2025-10-26 18:00:34.026	\N	f	\N	0409f8de-7e1d-4245-96c2-02a3b1c90a81	5	2025-10-19 18:00:34.722583	2025-10-19 18:00:34.722583
e99d6e38-4a28-46af-818e-0d1624a491fe	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	dba8a056-5928-41b6-8584-52e517451de7	Request previous accountant clearance	Contact previous accountant for professional clearance	f	60	7	2025-10-26 18:00:34.026	\N	f	\N	0409f8de-7e1d-4245-96c2-02a3b1c90a81	5	2025-10-19 18:00:34.722583	2025-10-19 18:00:34.722583
444ded1d-9a9d-40e7-886c-a68b28a8cc14	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	dba8a056-5928-41b6-8584-52e517451de7	Request and confirm relevant UTRs	Ask client for all applicable UTRs, or register if needed	t	70	7	2025-10-26 18:00:34.026	2025-10-14 15:25:03.983	t	Amiculum cariosus depereo velut sollicito agnitio amitto.	0409f8de-7e1d-4245-96c2-02a3b1c90a81	5	2025-10-19 18:00:34.722583	2025-10-19 18:00:34.722583
81925f85-755a-4fc7-9574-ee8deaa87a63	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	dba8a056-5928-41b6-8584-52e517451de7	Request Agent Authorisation Codes	Obtain codes for HMRC agent services	t	80	7	2025-10-26 18:00:34.026	2025-10-17 12:07:11.985	t	Comis concido amplexus stipes libero curia pecus stella sperno.	0409f8de-7e1d-4245-96c2-02a3b1c90a81	5	2025-10-19 18:00:34.722583	2025-10-19 18:00:34.722583
72327b55-5ec8-480d-b292-12a230cc0b59	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	dba8a056-5928-41b6-8584-52e517451de7	Setup GoCardless Direct Debit	Setup client on GoCardless and send DD mandate	t	90	7	2025-10-26 18:00:34.026	\N	f	\N	0409f8de-7e1d-4245-96c2-02a3b1c90a81	10	2025-10-19 18:00:34.722583	2025-10-19 18:00:34.722583
88f39d50-caea-4a62-b16b-92ffcc7857f4	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	dba8a056-5928-41b6-8584-52e517451de7	Confirm information received	Confirm all outstanding information received before proceeding (Professional Clearance, UTRs, Authorisation codes etc)	t	95	10	2025-10-29 18:00:34.026	2025-10-18 16:15:00.006	t	Occaecati demum aiunt impedit curvo.	0409f8de-7e1d-4245-96c2-02a3b1c90a81	5	2025-10-19 18:00:34.722583	2025-10-19 18:00:34.722583
9876aac5-9ceb-446b-83e4-805e1a09c4a2	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	dba8a056-5928-41b6-8584-52e517451de7	Register for necessary taxes	Register for applicable taxes (VAT, PAYE, etc.) Check with client manager for which period the taxes should fall under	f	100	10	2025-10-29 18:00:34.026	\N	f	\N	0409f8de-7e1d-4245-96c2-02a3b1c90a81	5	2025-10-19 18:00:34.722583	2025-10-19 18:00:34.722583
e61e4b86-149b-4e74-868a-831b798378dd	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	dba8a056-5928-41b6-8584-52e517451de7	Register for additional HMRC services	Register for additional services such as Income Tax record, MTD for IT, CIS etc	t	110	10	2025-10-29 18:00:34.026	\N	f	\N	0409f8de-7e1d-4245-96c2-02a3b1c90a81	5	2025-10-19 18:00:34.722583	2025-10-19 18:00:34.722583
5aae3823-4c2e-4bbf-b9c7-5b950bcf752b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	dba8a056-5928-41b6-8584-52e517451de7	Set up tasks for recurring services	Create recurring tasks for ongoing services	t	120	10	2025-10-29 18:00:34.026	\N	f	\N	0409f8de-7e1d-4245-96c2-02a3b1c90a81	5	2025-10-19 18:00:34.722583	2025-10-19 18:00:34.722583
acc6d7c7-d2c5-4812-a066-28a00b21aa28	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	dba8a056-5928-41b6-8584-52e517451de7	Change client status to Active	Update client status when onboarding is complete	t	130	10	2025-10-29 18:00:34.026	\N	f	\N	0409f8de-7e1d-4245-96c2-02a3b1c90a81	10	2025-10-19 18:00:34.722583	2025-10-19 18:00:34.722583
2bc90179-59fc-4237-87de-7080168c7023	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d7a488d0-5f4f-4920-9523-f8497f8c0ee9	Ensure Client is Setup in Bright Manager	Check client is in Bright Manager with appropriate client information, services and pricing filled in	t	10	0	2025-10-19 18:00:34.026	\N	f	\N	a2adaa31-8f59-409a-b39b-72568022adb4	5	2025-10-19 18:00:34.744983	2025-10-19 18:00:34.744983
123daa87-4766-4841-8200-c285447fea27	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d7a488d0-5f4f-4920-9523-f8497f8c0ee9	Request client ID documents	Request passport/driving license and proof of address	t	20	0	2025-10-19 18:00:34.026	2025-10-19 14:45:53.54	t	Cubicularis provident supellex celo arceo.	a2adaa31-8f59-409a-b39b-72568022adb4	5	2025-10-19 18:00:34.744983	2025-10-19 18:00:34.744983
8cbac0ab-b6a3-4cfa-b1dc-f241f09529e3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d7a488d0-5f4f-4920-9523-f8497f8c0ee9	Receive and Save client ID documents	Save client ID documents to client AML folder on OneDrive	t	25	2	2025-10-21 18:00:34.026	\N	f	\N	a2adaa31-8f59-409a-b39b-72568022adb4	5	2025-10-19 18:00:34.744983	2025-10-19 18:00:34.744983
6db8aa19-05f7-4382-a367-40bde211642e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d7a488d0-5f4f-4920-9523-f8497f8c0ee9	Complete AML ID check	Verify identity documents and complete AML compliance check	t	30	4	2025-10-23 18:00:34.026	2025-10-16 03:49:14.126	t	Porro turba veritatis.	a2adaa31-8f59-409a-b39b-72568022adb4	6	2025-10-19 18:00:34.744983	2025-10-19 18:00:34.744983
771ada22-ff2f-4656-8845-2da020471cde	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d7a488d0-5f4f-4920-9523-f8497f8c0ee9	Perform client risk assessment and grading	Assess client risk factors and determine risk level (Low/Medium/High), also a assign client a grade based off current communication quality	t	40	4	2025-10-23 18:00:34.026	\N	f	\N	a2adaa31-8f59-409a-b39b-72568022adb4	6	2025-10-19 18:00:34.744983	2025-10-19 18:00:34.744983
2dca6954-554e-4576-abd2-b93a3d8973ef	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d7a488d0-5f4f-4920-9523-f8497f8c0ee9	Send Letter of Engagement	Send LoE detailing scope of work, from Bright Manager and ensure it is signed	t	50	4	2025-10-23 18:00:34.026	2025-10-18 20:08:35.342	t	Caveo defendo voluptas caelum.	a2adaa31-8f59-409a-b39b-72568022adb4	8	2025-10-19 18:00:34.744983	2025-10-19 18:00:34.744983
19735244-d953-491a-8ddc-34ce10d6b678	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d7a488d0-5f4f-4920-9523-f8497f8c0ee9	Assign Client Manager	Discuss internally to decide which person will take on the new client	t	51	4	2025-10-23 18:00:34.026	2025-10-16 18:23:33.477	t	Audentia tum volo cruciamentum ullam appello.	a2adaa31-8f59-409a-b39b-72568022adb4	5	2025-10-19 18:00:34.744983	2025-10-19 18:00:34.744983
5e701096-067d-4d71-85b1-d6f4631c6340	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d7a488d0-5f4f-4920-9523-f8497f8c0ee9	Confirm Signing of LoE	Confirm the signing of Letter of Engagement before proceeding	t	55	7	2025-10-26 18:00:34.026	\N	f	\N	a2adaa31-8f59-409a-b39b-72568022adb4	5	2025-10-19 18:00:34.744983	2025-10-19 18:00:34.744983
4afe61d2-11e5-4716-a93f-ee975dbdc057	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d7a488d0-5f4f-4920-9523-f8497f8c0ee9	Request previous accountant clearance	Contact previous accountant for professional clearance	f	60	7	2025-10-26 18:00:34.026	2025-10-17 11:40:14.466	t	Vinum villa crudelis accommodo totam desipio adversus tergiversatio depopulo.	a2adaa31-8f59-409a-b39b-72568022adb4	5	2025-10-19 18:00:34.744983	2025-10-19 18:00:34.744983
51d12729-6c7b-440b-ad01-da998d1346f5	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d7a488d0-5f4f-4920-9523-f8497f8c0ee9	Request and confirm relevant UTRs	Ask client for all applicable UTRs, or register if needed	t	70	7	2025-10-26 18:00:34.026	2025-10-13 13:15:32.075	t	Maxime nam summisse video corrigo tabgo.	a2adaa31-8f59-409a-b39b-72568022adb4	5	2025-10-19 18:00:34.744983	2025-10-19 18:00:34.744983
8d5453d9-be25-4bba-bd99-10d0a71e080c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d7a488d0-5f4f-4920-9523-f8497f8c0ee9	Request Agent Authorisation Codes	Obtain codes for HMRC agent services	t	80	7	2025-10-26 18:00:34.026	\N	f	\N	a2adaa31-8f59-409a-b39b-72568022adb4	5	2025-10-19 18:00:34.744983	2025-10-19 18:00:34.744983
319856ce-42ee-4cf4-8092-5a5467d3553d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d7a488d0-5f4f-4920-9523-f8497f8c0ee9	Setup GoCardless Direct Debit	Setup client on GoCardless and send DD mandate	t	90	7	2025-10-26 18:00:34.026	\N	f	\N	a2adaa31-8f59-409a-b39b-72568022adb4	10	2025-10-19 18:00:34.744983	2025-10-19 18:00:34.744983
0ecb0eab-187f-4c01-8f70-4a527deb2568	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d7a488d0-5f4f-4920-9523-f8497f8c0ee9	Confirm information received	Confirm all outstanding information received before proceeding (Professional Clearance, UTRs, Authorisation codes etc)	t	95	10	2025-10-29 18:00:34.026	2025-10-17 13:42:55.074	t	Crastinus commodo patior.	a2adaa31-8f59-409a-b39b-72568022adb4	5	2025-10-19 18:00:34.744983	2025-10-19 18:00:34.744983
2100f499-85c1-4b2c-9f1f-866a0601e58d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d7a488d0-5f4f-4920-9523-f8497f8c0ee9	Register for necessary taxes	Register for applicable taxes (VAT, PAYE, etc.) Check with client manager for which period the taxes should fall under	f	100	10	2025-10-29 18:00:34.026	\N	f	\N	a2adaa31-8f59-409a-b39b-72568022adb4	5	2025-10-19 18:00:34.744983	2025-10-19 18:00:34.744983
e23a807c-5e6a-40dc-a0ce-0aa47a421396	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d7a488d0-5f4f-4920-9523-f8497f8c0ee9	Register for additional HMRC services	Register for additional services such as Income Tax record, MTD for IT, CIS etc	t	110	10	2025-10-29 18:00:34.026	2025-10-13 02:10:22.989	t	Tabgo abeo curiositas necessitatibus utique asperiores nostrum.	a2adaa31-8f59-409a-b39b-72568022adb4	5	2025-10-19 18:00:34.744983	2025-10-19 18:00:34.744983
ed005c12-a5b2-4928-abb8-f8954e5f8697	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d7a488d0-5f4f-4920-9523-f8497f8c0ee9	Set up tasks for recurring services	Create recurring tasks for ongoing services	t	120	10	2025-10-29 18:00:34.026	2025-10-13 05:13:17.795	t	Solvo dapifer cuius degenero arbor crux.	a2adaa31-8f59-409a-b39b-72568022adb4	5	2025-10-19 18:00:34.744983	2025-10-19 18:00:34.744983
8202661e-efc5-4c20-bfa1-d2aa2d5a96b2	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d7a488d0-5f4f-4920-9523-f8497f8c0ee9	Change client status to Active	Update client status when onboarding is complete	t	130	10	2025-10-29 18:00:34.026	2025-10-12 13:35:27.943	t	Demum credo provident volva.	a2adaa31-8f59-409a-b39b-72568022adb4	10	2025-10-19 18:00:34.744983	2025-10-19 18:00:34.744983
6103ff39-bc2c-47ae-ac55-12522d52dc3c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d94454c7-6e27-4891-8a91-e92725e22838	Ensure Client is Setup in Bright Manager	Check client is in Bright Manager with appropriate client information, services and pricing filled in	t	10	0	2025-10-19 18:00:34.026	\N	f	\N	d6f36046-e274-4776-a3d7-58eadb9d96b0	5	2025-10-19 18:00:34.760147	2025-10-19 18:00:34.760147
d52ac62a-e8ab-4793-9c61-2694475bde4e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d94454c7-6e27-4891-8a91-e92725e22838	Request client ID documents	Request passport/driving license and proof of address	t	20	0	2025-10-19 18:00:34.026	\N	f	\N	d6f36046-e274-4776-a3d7-58eadb9d96b0	5	2025-10-19 18:00:34.760147	2025-10-19 18:00:34.760147
020da27f-9c2f-44b8-addd-c744360b2af0	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d94454c7-6e27-4891-8a91-e92725e22838	Receive and Save client ID documents	Save client ID documents to client AML folder on OneDrive	t	25	2	2025-10-21 18:00:34.026	\N	f	\N	d6f36046-e274-4776-a3d7-58eadb9d96b0	5	2025-10-19 18:00:34.760147	2025-10-19 18:00:34.760147
5175addf-2bdb-4c7e-853d-5c7d5f90ebfe	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d94454c7-6e27-4891-8a91-e92725e22838	Complete AML ID check	Verify identity documents and complete AML compliance check	t	30	4	2025-10-23 18:00:34.026	\N	f	\N	d6f36046-e274-4776-a3d7-58eadb9d96b0	6	2025-10-19 18:00:34.760147	2025-10-19 18:00:34.760147
5b913a55-d45f-49ab-9e03-14849260871c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d94454c7-6e27-4891-8a91-e92725e22838	Perform client risk assessment and grading	Assess client risk factors and determine risk level (Low/Medium/High), also a assign client a grade based off current communication quality	t	40	4	2025-10-23 18:00:34.026	2025-10-19 17:02:51.01	t	Crustulum tergeo cibo caritas vivo complectus laudantium villa volubilis.	d6f36046-e274-4776-a3d7-58eadb9d96b0	6	2025-10-19 18:00:34.760147	2025-10-19 18:00:34.760147
d028d40b-8ceb-400f-9e41-afc23341b2df	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d94454c7-6e27-4891-8a91-e92725e22838	Send Letter of Engagement	Send LoE detailing scope of work, from Bright Manager and ensure it is signed	t	50	4	2025-10-23 18:00:34.026	2025-10-19 07:59:12.011	t	Vestrum tepidus coma cicuta calcar corpus.	d6f36046-e274-4776-a3d7-58eadb9d96b0	8	2025-10-19 18:00:34.760147	2025-10-19 18:00:34.760147
adf68a0c-28f9-47d6-91b6-c66dd0a835cc	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d94454c7-6e27-4891-8a91-e92725e22838	Assign Client Manager	Discuss internally to decide which person will take on the new client	t	51	4	2025-10-23 18:00:34.026	\N	f	\N	d6f36046-e274-4776-a3d7-58eadb9d96b0	5	2025-10-19 18:00:34.760147	2025-10-19 18:00:34.760147
9918ec1b-229c-4b55-8a68-ba754ccd499b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d94454c7-6e27-4891-8a91-e92725e22838	Confirm Signing of LoE	Confirm the signing of Letter of Engagement before proceeding	t	55	7	2025-10-26 18:00:34.026	\N	f	\N	d6f36046-e274-4776-a3d7-58eadb9d96b0	5	2025-10-19 18:00:34.760147	2025-10-19 18:00:34.760147
6da1d308-133b-4207-91cb-cdcdc14eb6e7	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d94454c7-6e27-4891-8a91-e92725e22838	Request previous accountant clearance	Contact previous accountant for professional clearance	f	60	7	2025-10-26 18:00:34.026	\N	f	\N	d6f36046-e274-4776-a3d7-58eadb9d96b0	5	2025-10-19 18:00:34.760147	2025-10-19 18:00:34.760147
b0cc12c3-22ea-4a8e-9b06-0b3266224ceb	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d94454c7-6e27-4891-8a91-e92725e22838	Request and confirm relevant UTRs	Ask client for all applicable UTRs, or register if needed	t	70	7	2025-10-26 18:00:34.026	\N	f	\N	d6f36046-e274-4776-a3d7-58eadb9d96b0	5	2025-10-19 18:00:34.760147	2025-10-19 18:00:34.760147
1f769352-1011-4161-9b61-bc25c073b8ad	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d94454c7-6e27-4891-8a91-e92725e22838	Request Agent Authorisation Codes	Obtain codes for HMRC agent services	t	80	7	2025-10-26 18:00:34.026	\N	f	\N	d6f36046-e274-4776-a3d7-58eadb9d96b0	5	2025-10-19 18:00:34.760147	2025-10-19 18:00:34.760147
2ead3db3-df0b-43ee-9538-cb039da0f931	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d94454c7-6e27-4891-8a91-e92725e22838	Setup GoCardless Direct Debit	Setup client on GoCardless and send DD mandate	t	90	7	2025-10-26 18:00:34.026	\N	f	\N	d6f36046-e274-4776-a3d7-58eadb9d96b0	10	2025-10-19 18:00:34.760147	2025-10-19 18:00:34.760147
ed4dc93b-55e9-4fed-9bba-5f372a996933	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d94454c7-6e27-4891-8a91-e92725e22838	Confirm information received	Confirm all outstanding information received before proceeding (Professional Clearance, UTRs, Authorisation codes etc)	t	95	10	2025-10-29 18:00:34.026	\N	f	\N	d6f36046-e274-4776-a3d7-58eadb9d96b0	5	2025-10-19 18:00:34.760147	2025-10-19 18:00:34.760147
a414be0d-40d8-420a-88ca-842c1bcfd4a6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d94454c7-6e27-4891-8a91-e92725e22838	Register for necessary taxes	Register for applicable taxes (VAT, PAYE, etc.) Check with client manager for which period the taxes should fall under	f	100	10	2025-10-29 18:00:34.026	\N	f	\N	d6f36046-e274-4776-a3d7-58eadb9d96b0	5	2025-10-19 18:00:34.760147	2025-10-19 18:00:34.760147
4da9187d-83a9-43f9-9367-8f20432d577b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d94454c7-6e27-4891-8a91-e92725e22838	Register for additional HMRC services	Register for additional services such as Income Tax record, MTD for IT, CIS etc	t	110	10	2025-10-29 18:00:34.026	\N	f	\N	d6f36046-e274-4776-a3d7-58eadb9d96b0	5	2025-10-19 18:00:34.760147	2025-10-19 18:00:34.760147
d04b0202-52b2-4ef8-8354-02f24fde2f20	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d94454c7-6e27-4891-8a91-e92725e22838	Set up tasks for recurring services	Create recurring tasks for ongoing services	t	120	10	2025-10-29 18:00:34.026	\N	f	\N	d6f36046-e274-4776-a3d7-58eadb9d96b0	5	2025-10-19 18:00:34.760147	2025-10-19 18:00:34.760147
5610e2b7-de58-4c75-be97-6215f4368b1d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d94454c7-6e27-4891-8a91-e92725e22838	Change client status to Active	Update client status when onboarding is complete	t	130	10	2025-10-29 18:00:34.026	2025-10-10 08:09:38.253	t	Succurro avaritia concido comes stillicidium calculus amoveo.	d6f36046-e274-4776-a3d7-58eadb9d96b0	10	2025-10-19 18:00:34.760147	2025-10-19 18:00:34.760147
afc5d75e-27db-4892-a291-bc0a52a45493	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	1fa27e81-524c-45d8-932d-dd727a19d6af	Ensure Client is Setup in Bright Manager	Check client is in Bright Manager with appropriate client information, services and pricing filled in	t	10	0	2025-10-19 18:00:34.026	\N	f	\N	c4f75303-a973-43e1-8f69-dfc6500c302c	5	2025-10-19 18:00:34.774339	2025-10-19 18:00:34.774339
b006cc26-8dfd-4b63-9c28-b3a8b8906e10	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	1fa27e81-524c-45d8-932d-dd727a19d6af	Request client ID documents	Request passport/driving license and proof of address	t	20	0	2025-10-19 18:00:34.026	\N	f	\N	c4f75303-a973-43e1-8f69-dfc6500c302c	5	2025-10-19 18:00:34.774339	2025-10-19 18:00:34.774339
826c32fb-aa80-4b5d-b753-8b2515e1618b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	1fa27e81-524c-45d8-932d-dd727a19d6af	Receive and Save client ID documents	Save client ID documents to client AML folder on OneDrive	t	25	2	2025-10-21 18:00:34.026	\N	f	\N	c4f75303-a973-43e1-8f69-dfc6500c302c	5	2025-10-19 18:00:34.774339	2025-10-19 18:00:34.774339
5bbb8b8f-5fef-405f-a30e-3c36f7f238e7	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	1fa27e81-524c-45d8-932d-dd727a19d6af	Complete AML ID check	Verify identity documents and complete AML compliance check	t	30	4	2025-10-23 18:00:34.026	\N	f	\N	c4f75303-a973-43e1-8f69-dfc6500c302c	6	2025-10-19 18:00:34.774339	2025-10-19 18:00:34.774339
4d3e2e37-f215-4190-ac05-70a9701c1352	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	1fa27e81-524c-45d8-932d-dd727a19d6af	Perform client risk assessment and grading	Assess client risk factors and determine risk level (Low/Medium/High), also a assign client a grade based off current communication quality	t	40	4	2025-10-23 18:00:34.026	2025-10-18 10:41:22.195	t	Torrens carmen quibusdam cupio caecus barba titulus uter tibi una.	c4f75303-a973-43e1-8f69-dfc6500c302c	6	2025-10-19 18:00:34.774339	2025-10-19 18:00:34.774339
b2f00ff0-fe1c-4b0b-8877-d5e3b7670f63	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	1fa27e81-524c-45d8-932d-dd727a19d6af	Send Letter of Engagement	Send LoE detailing scope of work, from Bright Manager and ensure it is signed	t	50	4	2025-10-23 18:00:34.026	2025-10-16 05:42:14.625	t	Vehemens vociferor succedo abstergo animadverto avarus demitto dolore clibanus sufficio.	c4f75303-a973-43e1-8f69-dfc6500c302c	8	2025-10-19 18:00:34.774339	2025-10-19 18:00:34.774339
ddd91fcf-1420-45e0-9117-601e406c30c0	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	1fa27e81-524c-45d8-932d-dd727a19d6af	Assign Client Manager	Discuss internally to decide which person will take on the new client	t	51	4	2025-10-23 18:00:34.026	\N	f	\N	c4f75303-a973-43e1-8f69-dfc6500c302c	5	2025-10-19 18:00:34.774339	2025-10-19 18:00:34.774339
bd314f22-085d-4195-9c95-6a81c6d0684a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	1fa27e81-524c-45d8-932d-dd727a19d6af	Confirm Signing of LoE	Confirm the signing of Letter of Engagement before proceeding	t	55	7	2025-10-26 18:00:34.026	\N	f	\N	c4f75303-a973-43e1-8f69-dfc6500c302c	5	2025-10-19 18:00:34.774339	2025-10-19 18:00:34.774339
8ca89d12-0002-4d1c-a270-24160c3e833c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	1fa27e81-524c-45d8-932d-dd727a19d6af	Request previous accountant clearance	Contact previous accountant for professional clearance	f	60	7	2025-10-26 18:00:34.026	\N	f	\N	c4f75303-a973-43e1-8f69-dfc6500c302c	5	2025-10-19 18:00:34.774339	2025-10-19 18:00:34.774339
17476cf1-109c-4067-a871-4001777546ad	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	1fa27e81-524c-45d8-932d-dd727a19d6af	Request and confirm relevant UTRs	Ask client for all applicable UTRs, or register if needed	t	70	7	2025-10-26 18:00:34.026	2025-10-13 22:22:05.493	t	Facilis demo comedo curriculum tibi arcus quos coaegresco compono ademptio.	c4f75303-a973-43e1-8f69-dfc6500c302c	5	2025-10-19 18:00:34.774339	2025-10-19 18:00:34.774339
4f1988af-1189-415d-bc19-0ea36d054857	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	1fa27e81-524c-45d8-932d-dd727a19d6af	Request Agent Authorisation Codes	Obtain codes for HMRC agent services	t	80	7	2025-10-26 18:00:34.026	\N	f	\N	c4f75303-a973-43e1-8f69-dfc6500c302c	5	2025-10-19 18:00:34.774339	2025-10-19 18:00:34.774339
06f00fa4-add2-4f7f-8c01-f2cf6794fac2	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	1fa27e81-524c-45d8-932d-dd727a19d6af	Setup GoCardless Direct Debit	Setup client on GoCardless and send DD mandate	t	90	7	2025-10-26 18:00:34.026	2025-10-16 21:18:33.425	t	Tego cauda averto.	c4f75303-a973-43e1-8f69-dfc6500c302c	10	2025-10-19 18:00:34.774339	2025-10-19 18:00:34.774339
1db09455-c8f5-469c-a107-d620b00500db	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	1fa27e81-524c-45d8-932d-dd727a19d6af	Confirm information received	Confirm all outstanding information received before proceeding (Professional Clearance, UTRs, Authorisation codes etc)	t	95	10	2025-10-29 18:00:34.026	\N	f	\N	c4f75303-a973-43e1-8f69-dfc6500c302c	5	2025-10-19 18:00:34.774339	2025-10-19 18:00:34.774339
c76e6c4b-72ee-42bc-830a-fef9db35afe6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	1fa27e81-524c-45d8-932d-dd727a19d6af	Register for necessary taxes	Register for applicable taxes (VAT, PAYE, etc.) Check with client manager for which period the taxes should fall under	f	100	10	2025-10-29 18:00:34.026	\N	f	\N	c4f75303-a973-43e1-8f69-dfc6500c302c	5	2025-10-19 18:00:34.774339	2025-10-19 18:00:34.774339
c1e55dd0-d4ac-4cba-9585-0d89cd1e6798	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	1fa27e81-524c-45d8-932d-dd727a19d6af	Register for additional HMRC services	Register for additional services such as Income Tax record, MTD for IT, CIS etc	t	110	10	2025-10-29 18:00:34.026	2025-10-13 06:13:06.557	t	Apparatus tamquam crepusculum fugiat studio audentia antiquus vespillo thalassinus sordeo.	c4f75303-a973-43e1-8f69-dfc6500c302c	5	2025-10-19 18:00:34.774339	2025-10-19 18:00:34.774339
9195c937-cd21-4a04-9796-c5142ea4eb1f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	1fa27e81-524c-45d8-932d-dd727a19d6af	Set up tasks for recurring services	Create recurring tasks for ongoing services	t	120	10	2025-10-29 18:00:34.026	\N	f	\N	c4f75303-a973-43e1-8f69-dfc6500c302c	5	2025-10-19 18:00:34.774339	2025-10-19 18:00:34.774339
8e1a401d-93ff-44fb-8f4c-39ca219e1a05	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	1fa27e81-524c-45d8-932d-dd727a19d6af	Change client status to Active	Update client status when onboarding is complete	t	130	10	2025-10-29 18:00:34.026	2025-10-17 03:45:18.542	t	Commodo color comptus decet charisma viriliter urbs tabernus.	c4f75303-a973-43e1-8f69-dfc6500c302c	10	2025-10-19 18:00:34.774339	2025-10-19 18:00:34.774339
f58c1f5f-def8-4212-9357-9e31a1236f73	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	45e05096-9c95-4378-96f5-da8bac0468a5	Ensure Client is Setup in Bright Manager	Check client is in Bright Manager with appropriate client information, services and pricing filled in	t	10	0	2025-10-19 18:00:34.026	\N	f	\N	c4f75303-a973-43e1-8f69-dfc6500c302c	5	2025-10-19 18:00:34.788922	2025-10-19 18:00:34.788922
c5c0b496-a767-49c4-aa2d-95ece42dea7d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	45e05096-9c95-4378-96f5-da8bac0468a5	Request client ID documents	Request passport/driving license and proof of address	t	20	0	2025-10-19 18:00:34.026	\N	f	\N	c4f75303-a973-43e1-8f69-dfc6500c302c	5	2025-10-19 18:00:34.788922	2025-10-19 18:00:34.788922
fe34f94c-7177-4656-b6a7-284b7965c751	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	45e05096-9c95-4378-96f5-da8bac0468a5	Receive and Save client ID documents	Save client ID documents to client AML folder on OneDrive	t	25	2	2025-10-21 18:00:34.026	\N	f	\N	c4f75303-a973-43e1-8f69-dfc6500c302c	5	2025-10-19 18:00:34.788922	2025-10-19 18:00:34.788922
7909a038-a54d-4cb3-b04f-06c4f04977c4	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	45e05096-9c95-4378-96f5-da8bac0468a5	Complete AML ID check	Verify identity documents and complete AML compliance check	t	30	4	2025-10-23 18:00:34.026	\N	f	\N	c4f75303-a973-43e1-8f69-dfc6500c302c	6	2025-10-19 18:00:34.788922	2025-10-19 18:00:34.788922
45acc35a-befc-4181-aa15-a12a9555aec0	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	45e05096-9c95-4378-96f5-da8bac0468a5	Perform client risk assessment and grading	Assess client risk factors and determine risk level (Low/Medium/High), also a assign client a grade based off current communication quality	t	40	4	2025-10-23 18:00:34.026	2025-10-16 15:52:51.705	t	Acceptus alioqui beatus defleo.	c4f75303-a973-43e1-8f69-dfc6500c302c	6	2025-10-19 18:00:34.788922	2025-10-19 18:00:34.788922
6411ee0e-3908-4321-b088-8dd93a547437	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	45e05096-9c95-4378-96f5-da8bac0468a5	Send Letter of Engagement	Send LoE detailing scope of work, from Bright Manager and ensure it is signed	t	50	4	2025-10-23 18:00:34.026	\N	f	\N	c4f75303-a973-43e1-8f69-dfc6500c302c	8	2025-10-19 18:00:34.788922	2025-10-19 18:00:34.788922
87e24251-95dd-4963-9a44-126b324a94b0	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	45e05096-9c95-4378-96f5-da8bac0468a5	Assign Client Manager	Discuss internally to decide which person will take on the new client	t	51	4	2025-10-23 18:00:34.026	\N	f	\N	c4f75303-a973-43e1-8f69-dfc6500c302c	5	2025-10-19 18:00:34.788922	2025-10-19 18:00:34.788922
0547f1f0-2136-4596-88b5-b0d831f5bc20	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	45e05096-9c95-4378-96f5-da8bac0468a5	Confirm Signing of LoE	Confirm the signing of Letter of Engagement before proceeding	t	55	7	2025-10-26 18:00:34.026	\N	f	\N	c4f75303-a973-43e1-8f69-dfc6500c302c	5	2025-10-19 18:00:34.788922	2025-10-19 18:00:34.788922
d253ff09-0849-48e2-a19e-cf6ade82cde0	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	45e05096-9c95-4378-96f5-da8bac0468a5	Request previous accountant clearance	Contact previous accountant for professional clearance	f	60	7	2025-10-26 18:00:34.026	2025-10-14 15:13:04.018	t	Supellex vos concedo casus.	c4f75303-a973-43e1-8f69-dfc6500c302c	5	2025-10-19 18:00:34.788922	2025-10-19 18:00:34.788922
1b35ff22-df3d-4aed-b961-839f891eb463	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	45e05096-9c95-4378-96f5-da8bac0468a5	Request and confirm relevant UTRs	Ask client for all applicable UTRs, or register if needed	t	70	7	2025-10-26 18:00:34.026	\N	f	\N	c4f75303-a973-43e1-8f69-dfc6500c302c	5	2025-10-19 18:00:34.788922	2025-10-19 18:00:34.788922
70ccdc52-4d14-4d9d-baf0-326bdcc0600e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	45e05096-9c95-4378-96f5-da8bac0468a5	Request Agent Authorisation Codes	Obtain codes for HMRC agent services	t	80	7	2025-10-26 18:00:34.026	\N	f	\N	c4f75303-a973-43e1-8f69-dfc6500c302c	5	2025-10-19 18:00:34.788922	2025-10-19 18:00:34.788922
23903104-58e7-4397-9a27-638ebab5ae7b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	45e05096-9c95-4378-96f5-da8bac0468a5	Setup GoCardless Direct Debit	Setup client on GoCardless and send DD mandate	t	90	7	2025-10-26 18:00:34.026	\N	f	\N	c4f75303-a973-43e1-8f69-dfc6500c302c	10	2025-10-19 18:00:34.788922	2025-10-19 18:00:34.788922
0bfe9b0c-5d26-4c4d-a0e8-8b08a9b4a7b5	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	45e05096-9c95-4378-96f5-da8bac0468a5	Confirm information received	Confirm all outstanding information received before proceeding (Professional Clearance, UTRs, Authorisation codes etc)	t	95	10	2025-10-29 18:00:34.026	\N	f	\N	c4f75303-a973-43e1-8f69-dfc6500c302c	5	2025-10-19 18:00:34.788922	2025-10-19 18:00:34.788922
2f2b4a24-8dbc-4b93-a965-26911bea9602	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	45e05096-9c95-4378-96f5-da8bac0468a5	Register for necessary taxes	Register for applicable taxes (VAT, PAYE, etc.) Check with client manager for which period the taxes should fall under	f	100	10	2025-10-29 18:00:34.026	\N	f	\N	c4f75303-a973-43e1-8f69-dfc6500c302c	5	2025-10-19 18:00:34.788922	2025-10-19 18:00:34.788922
f6e18a6f-1c64-4462-b484-a15df16c968f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	45e05096-9c95-4378-96f5-da8bac0468a5	Register for additional HMRC services	Register for additional services such as Income Tax record, MTD for IT, CIS etc	t	110	10	2025-10-29 18:00:34.026	2025-10-14 01:32:58.682	t	Cilicium quo viduo pauci placeat possimus cupressus.	c4f75303-a973-43e1-8f69-dfc6500c302c	5	2025-10-19 18:00:34.788922	2025-10-19 18:00:34.788922
6ca02932-eee4-4533-a003-c5f33d65b48d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	45e05096-9c95-4378-96f5-da8bac0468a5	Set up tasks for recurring services	Create recurring tasks for ongoing services	t	120	10	2025-10-29 18:00:34.026	\N	f	\N	c4f75303-a973-43e1-8f69-dfc6500c302c	5	2025-10-19 18:00:34.788922	2025-10-19 18:00:34.788922
881f0018-489a-48b0-bfcd-7448c21b54bd	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	45e05096-9c95-4378-96f5-da8bac0468a5	Change client status to Active	Update client status when onboarding is complete	t	130	10	2025-10-29 18:00:34.026	2025-10-15 09:24:36.771	t	Adopto reprehenderit aetas aegrotatio cribro custodia pecus texo cubicularis universe.	c4f75303-a973-43e1-8f69-dfc6500c302c	10	2025-10-19 18:00:34.788922	2025-10-19 18:00:34.788922
\.


--
-- Data for Name: portal_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.portal_categories (id, tenant_id, name, description, icon_name, color_hex, sort_order, is_active, created_by_id, created_at, updated_at) FROM stdin;
4adf888d-3149-4674-8de6-bf1cb874a2f0	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Practice Hub	Internal practice management modules	LayoutGrid	#ff8609	1	t	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-19 18:00:33.903668	2025-10-19 18:00:33.903668
8a865071-62aa-4edf-8749-46b3793d011d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	External Tools	Government and regulatory services	ExternalLink	#3b82f6	2	t	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-19 18:00:33.908003	2025-10-19 18:00:33.908003
c9dbf024-1fde-4a58-a206-312fd198b48d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Practice Resources	Professional bodies and resources	BookOpen	#8b5cf6	3	t	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-19 18:00:33.912216	2025-10-19 18:00:33.912216
\.


--
-- Data for Name: portal_links; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.portal_links (id, tenant_id, category_id, title, description, url, is_internal, icon_name, sort_order, is_active, target_blank, requires_auth, allowed_roles, created_by_id, created_at, updated_at) FROM stdin;
bdf661b5-c11b-47a5-a822-7e46ce9e313e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	4adf888d-3149-4674-8de6-bf1cb874a2f0	Client Hub	Manage clients, contacts, and relationships	/client-hub	t	Users	1	t	t	f	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-19 18:00:33.917451	2025-10-19 18:00:33.917451
3b300d9f-6709-407a-b292-d79a16576ffc	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	4adf888d-3149-4674-8de6-bf1cb874a2f0	Proposal Hub	Create and manage client proposals	/proposal-hub	t	FileText	2	t	t	f	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-19 18:00:33.917451	2025-10-19 18:00:33.917451
b5f09eb1-b605-45ab-bc7a-5fe1ed9d7208	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	4adf888d-3149-4674-8de6-bf1cb874a2f0	Social Hub	Practice social features (coming soon)	/social-hub	t	Share2	3	t	t	f	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-19 18:00:33.917451	2025-10-19 18:00:33.917451
fde3e693-911b-4c33-b199-94725773941d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	4adf888d-3149-4674-8de6-bf1cb874a2f0	Bookkeeping Hub	Bookkeeping and reconciliation (coming soon)	/bookkeeping	t	Calculator	4	t	t	f	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-19 18:00:33.917451	2025-10-19 18:00:33.917451
fcc1f408-5024-46b2-bfe3-0fd7cdb5f828	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	4adf888d-3149-4674-8de6-bf1cb874a2f0	Accounts Hub	Annual accounts preparation (coming soon)	/accounts-hub	t	Building	5	t	t	f	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-19 18:00:33.917451	2025-10-19 18:00:33.917451
bfbb1a72-a990-47e3-8879-45ee6baf0e18	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	4adf888d-3149-4674-8de6-bf1cb874a2f0	Payroll Hub	Payroll processing and RTI (coming soon)	/payroll	t	DollarSign	6	t	t	f	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-19 18:00:33.917451	2025-10-19 18:00:33.917451
efe5cc0d-a9fe-4f6b-b0bf-8ce6ab264c75	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	4adf888d-3149-4674-8de6-bf1cb874a2f0	Employee Portal	Employee self-service portal (coming soon)	/employee-portal	t	Briefcase	7	t	t	f	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-19 18:00:33.917451	2025-10-19 18:00:33.917451
c3c66fa6-5fe6-4d16-889a-0bf831777779	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	4adf888d-3149-4674-8de6-bf1cb874a2f0	Client Admin	Manage external client portal users and access	/client-admin	t	Users	8	t	t	f	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-19 18:00:33.917451	2025-10-19 18:00:33.917451
00b9e579-bdf2-40b1-a564-4b125c08b6ce	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	4adf888d-3149-4674-8de6-bf1cb874a2f0	Documents	File storage and document management	/client-hub/documents	t	FolderOpen	9	t	t	f	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-19 18:00:33.917451	2025-10-19 18:00:33.917451
bd6b5b4c-25cf-4335-95cc-196648a39c45	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	4adf888d-3149-4674-8de6-bf1cb874a2f0	Messages	Team chat and client communication	/practice-hub/messages	t	MessageSquare	10	t	t	f	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-19 18:00:33.917451	2025-10-19 18:00:33.917451
350d9d89-69ee-4d9d-aafc-509ccbac9fc8	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	4adf888d-3149-4674-8de6-bf1cb874a2f0	Calendar	Events, meetings, and deadlines	/practice-hub/calendar	t	Calendar	11	t	t	f	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-19 18:00:33.917451	2025-10-19 18:00:33.917451
0b433767-6a28-4b24-8eb5-7aa4da50abd7	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	4adf888d-3149-4674-8de6-bf1cb874a2f0	Admin Panel	System administration and configuration	/admin	t	Settings	12	t	t	f	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-19 18:00:33.917451	2025-10-19 18:00:33.917451
b0022962-3c61-4b54-8b6f-f5ace640a004	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	8a865071-62aa-4edf-8749-46b3793d011d	HMRC Online Services	Access HMRC tax services and submissions	https://www.tax.service.gov.uk/account	f	ExternalLink	1	t	t	f	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-19 18:00:33.923605	2025-10-19 18:00:33.923605
f2235524-bc75-44e6-9395-686c4fa44c8b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	8a865071-62aa-4edf-8749-46b3793d011d	Companies House	Search company information and file documents	https://www.gov.uk/government/organisations/companies-house	f	Building2	2	t	t	f	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-19 18:00:33.923605	2025-10-19 18:00:33.923605
8f7a7903-1795-4a83-a147-e89930b6dcba	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	8a865071-62aa-4edf-8749-46b3793d011d	WebFiling Service	Companies House online filing service	https://ewf.companieshouse.gov.uk/	f	Upload	3	t	t	f	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-19 18:00:33.923605	2025-10-19 18:00:33.923605
2e6f1ea8-9954-4f25-91f7-790ffc37db2d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	8a865071-62aa-4edf-8749-46b3793d011d	VAT Online	Submit VAT returns and view account	https://www.tax.service.gov.uk/vat-through-software/overview	f	FileCheck	4	t	t	f	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-19 18:00:33.923605	2025-10-19 18:00:33.923605
db5ab8b1-b4f5-4af0-8db9-2f5b2040ceb0	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	8a865071-62aa-4edf-8749-46b3793d011d	PAYE for Employers	PAYE online services and RTI submissions	https://www.gov.uk/paye-online	f	Users2	5	t	t	f	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-19 18:00:33.923605	2025-10-19 18:00:33.923605
1d6beb10-f001-4750-a2aa-863795bb48e1	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	8a865071-62aa-4edf-8749-46b3793d011d	Self Assessment	Self Assessment online services	https://www.gov.uk/log-in-file-self-assessment-tax-return	f	Receipt	6	t	t	f	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-19 18:00:33.923605	2025-10-19 18:00:33.923605
12090508-0e5a-49c7-bfac-71f958825752	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	8a865071-62aa-4edf-8749-46b3793d011d	Making Tax Digital	MTD for Income Tax and VAT	https://www.gov.uk/guidance/use-software-to-send-income-tax-updates	f	CloudUpload	7	t	t	f	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-19 18:00:33.923605	2025-10-19 18:00:33.923605
946f7f12-9f5d-4926-af15-e932547e1f06	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c9dbf024-1fde-4a58-a206-312fd198b48d	ICAEW	Institute of Chartered Accountants in England and Wales	https://www.icaew.com/	f	GraduationCap	1	t	t	f	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-19 18:00:33.931232	2025-10-19 18:00:33.931232
ae6a3259-2f33-4f43-a076-615ea0de503c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c9dbf024-1fde-4a58-a206-312fd198b48d	ACCA	Association of Chartered Certified Accountants	https://www.accaglobal.com/	f	Award	2	t	t	f	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-19 18:00:33.931232	2025-10-19 18:00:33.931232
4c36baa5-35f9-4577-96ad-3e7b9aa33106	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c9dbf024-1fde-4a58-a206-312fd198b48d	AAT	Association of Accounting Technicians	https://www.aat.org.uk/	f	BookmarkCheck	3	t	t	f	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-19 18:00:33.931232	2025-10-19 18:00:33.931232
ad817b09-1a0d-4a14-b82e-0f6e6c4684ec	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c9dbf024-1fde-4a58-a206-312fd198b48d	GOV.UK	Official UK government website	https://www.gov.uk/	f	Home	4	t	t	f	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-19 18:00:33.931232	2025-10-19 18:00:33.931232
\.


--
-- Data for Name: pricing_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pricing_rules (id, tenant_id, component_id, rule_type, min_value, max_value, price, complexity_level, metadata, is_active, created_at, updated_at) FROM stdin;
43ddafdd-770e-4bc9-8562-d8cca28bdd59	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	e2cd4da6-f171-436c-9c7e-a9c1c5436b98	turnover_band	0.00	89999.00	49.00	\N	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
3cf49080-4df7-4b86-88dc-e8723ce73f4b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	e2cd4da6-f171-436c-9c7e-a9c1c5436b98	turnover_band	90000.00	149999.00	59.00	\N	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
4b59acde-1dee-4d6d-92d1-6671ff1fecaa	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	e2cd4da6-f171-436c-9c7e-a9c1c5436b98	turnover_band	150000.00	249999.00	79.00	\N	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
b52bbbb3-8c2c-4eea-8b10-045a1b0ea1c1	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	e2cd4da6-f171-436c-9c7e-a9c1c5436b98	turnover_band	250000.00	499999.00	99.00	\N	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
b3035ef0-90bd-46ca-9693-131cc0463ad4	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	e2cd4da6-f171-436c-9c7e-a9c1c5436b98	turnover_band	500000.00	749999.00	119.00	\N	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
6ce13e27-b42c-4fd7-af6a-a7e728cd6bb4	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	e2cd4da6-f171-436c-9c7e-a9c1c5436b98	turnover_band	750000.00	999999.00	139.00	\N	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
f55da7d4-6871-4d53-939b-0636e9e4dba3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	e2cd4da6-f171-436c-9c7e-a9c1c5436b98	turnover_band	1000000.00	999999999.00	159.00	\N	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
84b370d3-6aea-4640-a05b-944cfabd680f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	e2cd4da6-f171-436c-9c7e-a9c1c5436b98	per_unit	\N	\N	0.15	\N	{"basePrice": 30, "description": "Per transaction"}	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
fce206ae-5805-4909-8256-bdccb9411d7c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	1ede1cc0-3627-404e-bb8a-487e028f4732	turnover_band	85000.00	149999.00	25.00	\N	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
95abd676-b41b-4cd6-80ab-b4ffb485774e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	1ede1cc0-3627-404e-bb8a-487e028f4732	turnover_band	150000.00	249999.00	35.00	\N	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
04541574-4cbe-441a-96b4-c26feb9bd0c1	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	1ede1cc0-3627-404e-bb8a-487e028f4732	turnover_band	250000.00	499999.00	45.00	\N	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
8f608392-0a7d-4380-8471-755ee505c987	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	1ede1cc0-3627-404e-bb8a-487e028f4732	turnover_band	500000.00	999999999.00	55.00	\N	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
7747ebdf-51d8-4ecc-a465-9284f66cb3dc	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	1ede1cc0-3627-404e-bb8a-487e028f4732	per_unit	\N	\N	0.10	\N	{"description": "Per transaction", "minimumPrice": 20}	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
98089a06-fad9-4896-b031-a31ed19926e3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	391f7d87-df5d-4538-9b3e-31e07ac9347e	turnover_band	0.00	89999.00	80.00	\N	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
4bdcf233-a8b1-4788-9e05-848871e09f4c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	391f7d87-df5d-4538-9b3e-31e07ac9347e	turnover_band	90000.00	149999.00	100.00	\N	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
feb67f72-e77e-4019-9759-0e3730072059	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	391f7d87-df5d-4538-9b3e-31e07ac9347e	turnover_band	150000.00	249999.00	130.00	\N	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
83719b73-b3af-46d5-9b32-6808006ba19d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	391f7d87-df5d-4538-9b3e-31e07ac9347e	turnover_band	250000.00	499999.00	160.00	\N	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
b334a443-c658-4f55-99c7-dbaade72b53b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	391f7d87-df5d-4538-9b3e-31e07ac9347e	turnover_band	500000.00	999999999.00	200.00	\N	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
3006b654-da69-4ac7-b3ad-0772065c1a2a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	391f7d87-df5d-4538-9b3e-31e07ac9347e	transaction_band	0.00	25.00	40.00	\N	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
f873daee-4d9d-4b34-ab21-6883766c9120	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	391f7d87-df5d-4538-9b3e-31e07ac9347e	transaction_band	26.00	50.00	60.00	\N	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
985f7778-202b-4158-b3db-8148a6460058	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	391f7d87-df5d-4538-9b3e-31e07ac9347e	transaction_band	51.00	75.00	80.00	\N	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
ee3766e1-b3a5-4d1e-806d-7f14f868c438	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	391f7d87-df5d-4538-9b3e-31e07ac9347e	transaction_band	76.00	100.00	100.00	\N	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
2aa07a2e-c604-4ebf-b9b4-3ac1484a066a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	391f7d87-df5d-4538-9b3e-31e07ac9347e	transaction_band	101.00	150.00	130.00	\N	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
d21758ba-30a3-4e96-b8ae-d0fac5249963	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	391f7d87-df5d-4538-9b3e-31e07ac9347e	transaction_band	151.00	200.00	160.00	\N	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
18c974d7-0d6d-4325-be47-318dbbc0a5a5	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	391f7d87-df5d-4538-9b3e-31e07ac9347e	transaction_band	201.00	300.00	200.00	\N	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
68399a69-1d8a-462d-8b0b-f2c3b556b293	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	391f7d87-df5d-4538-9b3e-31e07ac9347e	transaction_band	301.00	400.00	250.00	\N	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
d8e6e3b0-1d8c-43e9-8827-4a6fdf31c650	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	391f7d87-df5d-4538-9b3e-31e07ac9347e	transaction_band	401.00	500.00	300.00	\N	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
035cf684-9159-4e60-b550-42643bac409f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	391f7d87-df5d-4538-9b3e-31e07ac9347e	per_unit	501.00	\N	0.60	\N	{"description": "Per transaction over 500"}	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
75d8bb28-430a-460a-af2b-e18db6071f8e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	turnover_band	0.00	89999.00	150.00	clean	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
afa2412c-03dd-4a19-9cc8-04155910f5c6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	turnover_band	90000.00	149999.00	200.00	clean	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
6e9501f9-23cf-4ac0-b06c-4b3e386e2d00	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	turnover_band	150000.00	249999.00	250.00	clean	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
949dbe15-d125-43c8-bd60-08f96df1fa06	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	turnover_band	250000.00	499999.00	320.00	clean	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
12bb6e65-61d8-403f-8547-5469b038e065	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	turnover_band	500000.00	749999.00	400.00	clean	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
e771347b-641e-4079-aab2-9f4d153b8028	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	turnover_band	750000.00	999999.00	480.00	clean	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
192ab808-fb59-4920-9605-f075da5372cb	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	turnover_band	1000000.00	999999999.00	560.00	clean	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
d1617836-1c0e-44a5-b064-1ec3ca354c87	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	turnover_band	0.00	89999.00	180.00	average	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
9cf678e4-7c5f-48e5-93bf-f05a8919ea7f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	turnover_band	90000.00	149999.00	240.00	average	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
955d1e24-2af7-4e30-9f46-bd4a80a73799	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	turnover_band	150000.00	249999.00	300.00	average	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
d39b4358-6ae2-40a9-a954-6c849f67ef92	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	turnover_band	250000.00	499999.00	380.00	average	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
a6a79018-edae-4bfb-8591-4e3555245583	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	turnover_band	500000.00	749999.00	480.00	average	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
c7b442cd-ceb4-4582-bbac-1c576d66b1ea	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	turnover_band	750000.00	999999.00	580.00	average	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
ef79ca4f-342c-42af-88c8-c4007ffd345f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	turnover_band	1000000.00	999999999.00	680.00	average	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
7fd4da7a-52b7-4520-8ca1-3665f2821a9b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	turnover_band	0.00	89999.00	220.00	complex	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
62bd60fa-08b1-4abe-a737-0a9802c10430	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	turnover_band	90000.00	149999.00	290.00	complex	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
b78e92c9-1f54-4c72-98f0-9c513e503e5d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	turnover_band	150000.00	249999.00	360.00	complex	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
be8b0e04-fbe8-4db6-977f-392787a5f1d4	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	turnover_band	250000.00	499999.00	460.00	complex	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
9daee92b-ea65-40b1-934f-88820c2c599e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	turnover_band	500000.00	749999.00	580.00	complex	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
5c0998e0-473a-41c1-b7f1-a63e6c876ebb	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	turnover_band	750000.00	999999.00	700.00	complex	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
3e447bca-a1a2-455d-b8a3-922488c0c715	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	turnover_band	1000000.00	999999999.00	820.00	complex	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
9849dc4f-31c3-4adf-ad67-3ba120960662	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	turnover_band	0.00	89999.00	280.00	disaster	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
ab444d07-1a25-43a9-a4e8-837a6e221bd4	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	turnover_band	90000.00	149999.00	370.00	disaster	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
307cdbb5-2fcb-477e-a179-831b4e86eee8	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	turnover_band	150000.00	249999.00	460.00	disaster	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
e095153f-bc9f-41b7-b6a4-b3a09ade8127	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	turnover_band	250000.00	499999.00	590.00	disaster	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
7a76fb3d-5174-4d34-a212-46ae8fac15b9	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	turnover_band	500000.00	749999.00	740.00	disaster	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
de000452-b696-4a97-8f3b-ee031f24ef89	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	turnover_band	750000.00	999999.00	900.00	disaster	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
5aa836c3-821d-4f2f-9d4a-9a48fac08cb0	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	turnover_band	1000000.00	999999999.00	1050.00	disaster	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
c048a02d-c44a-47c8-b9eb-405570ac0913	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	transaction_band	0.00	25.00	120.00	clean	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
fc87b1d5-740f-4e64-b1f5-afce01fca290	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	transaction_band	26.00	50.00	180.00	clean	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
5b7cd2e5-9257-4412-8da2-2d6b369906c2	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	transaction_band	51.00	75.00	240.00	clean	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
adc3376c-db1c-41e5-9886-5cbbc2031c29	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	transaction_band	76.00	100.00	300.00	clean	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
f5622b7f-dcbe-4077-b5b8-4de817fa8042	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	transaction_band	101.00	150.00	380.00	clean	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
cf86be0b-8b91-44c2-864a-f4a659856a20	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	transaction_band	151.00	200.00	460.00	clean	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
64fab996-9cfa-4e49-994e-7b2f1ffdc1e8	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	transaction_band	201.00	300.00	580.00	clean	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
43d925ea-175c-4708-8292-c08cce5ef6ba	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	transaction_band	301.00	400.00	700.00	clean	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
0af5c69b-abe8-468a-ae7f-b7318cdcdf1b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	transaction_band	401.00	500.00	820.00	clean	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
193031ef-ad5a-43af-985c-fb391c3db2be	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	transaction_band	0.00	25.00	140.00	average	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
0fc07b36-9233-4f63-91dd-31f945e812a3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	transaction_band	26.00	50.00	210.00	average	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
79fd0097-22ca-4775-adde-b6e8972a8019	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	transaction_band	51.00	75.00	280.00	average	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
f43a561b-cba3-4b6a-9274-5615cff24380	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	transaction_band	76.00	100.00	350.00	average	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
5b615ad9-b368-422a-86be-5feb2a4007b0	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	transaction_band	101.00	150.00	440.00	average	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
7ad58278-fcd6-4508-9cdc-e52808f5ca72	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	transaction_band	151.00	200.00	530.00	average	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
8dd0b2cc-ace8-4b8a-9299-2c8f1c414160	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	transaction_band	201.00	300.00	670.00	average	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
92c2cc18-1a10-47d3-b9ce-6f07677b7d94	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	transaction_band	301.00	400.00	810.00	average	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
25b63419-9238-4245-8e39-5a4537141257	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	transaction_band	401.00	500.00	950.00	average	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
f52e937a-18fe-44bb-8623-32f252d634ec	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	transaction_band	0.00	25.00	170.00	complex	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
1f9292b6-df77-4759-bfac-928983f65a5a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	transaction_band	26.00	50.00	250.00	complex	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
6ad2fba1-b3f2-484e-a949-67012139a428	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	transaction_band	51.00	75.00	340.00	complex	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
1cbb1e29-156c-4c74-9f3c-4664a7eb048c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	transaction_band	76.00	100.00	420.00	complex	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
8451388e-90bf-49cc-a7b1-325f881a4a50	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	transaction_band	101.00	150.00	530.00	complex	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
7134d443-2276-4af5-9b13-7bce6c60fb56	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	transaction_band	151.00	200.00	640.00	complex	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
9b48c398-4cf6-48d7-811b-809bf818679b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	transaction_band	201.00	300.00	810.00	complex	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
4fabe9fd-17d6-421c-9b7e-20fcbe315216	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	transaction_band	301.00	400.00	980.00	complex	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
230b8fce-d932-43d1-a5f7-fd5d4d648d16	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	transaction_band	401.00	500.00	1150.00	complex	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
78ec2306-f331-4001-b90e-46789294288b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	transaction_band	0.00	25.00	210.00	disaster	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
28eb88ea-adea-4cd5-a7fb-88af471aabf3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	transaction_band	26.00	50.00	310.00	disaster	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
1c4ff34a-c4b7-446e-bf73-3c355a236d16	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	transaction_band	51.00	75.00	420.00	disaster	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
98890aad-9e2f-482b-a0f4-b137228a0193	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	transaction_band	76.00	100.00	520.00	disaster	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
86dc27fd-e1e6-489e-b66b-87b1a4c86eeb	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	transaction_band	101.00	150.00	660.00	disaster	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
63be46d1-ff68-4974-96ba-062c8ef5984d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	transaction_band	151.00	200.00	800.00	disaster	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
f3d52bd6-bdeb-4407-a358-95de93dc160d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	transaction_band	201.00	300.00	1010.00	disaster	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
40ef6f23-0310-4167-aa43-e9a9c4a5e471	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	transaction_band	301.00	400.00	1220.00	disaster	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
f5b45b63-0fe2-4885-8215-73f03e32912b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	transaction_band	401.00	500.00	1430.00	disaster	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
36b0a388-ccf1-46d0-aca6-b12ac36a0379	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	per_unit	501.00	\N	1.50	clean	{"description": "Per transaction over 500 (clean)"}	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
b60b42ef-69a6-41ea-a8ff-394c7ffb08b0	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	per_unit	501.00	\N	1.75	average	{"description": "Per transaction over 500 (average)"}	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
7f36718b-7427-4bb3-9483-68079c8d6981	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	per_unit	501.00	\N	2.10	complex	{"description": "Per transaction over 500 (complex)"}	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
218ce130-2ff0-4f38-a477-714b6869a33e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	per_unit	501.00	\N	2.60	disaster	{"description": "Per transaction over 500 (disaster)"}	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
ae944fa3-ca08-450e-b0ce-c1e8fe1011f5	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a49c064a-0890-4c02-8734-07a3185e6c03	turnover_band	0.00	249999.00	150.00	\N	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
6a282e6b-b6bf-4c6c-b4a5-d698516f1e59	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a49c064a-0890-4c02-8734-07a3185e6c03	turnover_band	250000.00	499999.00	200.00	\N	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
7de19d60-284b-4897-85ad-47ad76648693	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a49c064a-0890-4c02-8734-07a3185e6c03	turnover_band	500000.00	999999.00	250.00	\N	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
b0f21e52-3edf-4d37-8153-3aeedee857e0	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a49c064a-0890-4c02-8734-07a3185e6c03	turnover_band	1000000.00	1999999.00	350.00	\N	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
7067af1d-3cee-4a13-87e1-72e53ea40d33	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a49c064a-0890-4c02-8734-07a3185e6c03	turnover_band	2000000.00	999999999.00	450.00	\N	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
5e447766-d1a5-40fa-a883-5c69b446fdfa	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	cbf9b499-276b-4a28-999c-27388562c4f4	turnover_band	0.00	249999.00	75.00	\N	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
7a30313b-05de-4a37-ba73-1e2470da3fc3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	cbf9b499-276b-4a28-999c-27388562c4f4	turnover_band	250000.00	499999.00	100.00	\N	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
7ab91af6-1c46-4c3c-a477-2bf69856fb75	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	cbf9b499-276b-4a28-999c-27388562c4f4	turnover_band	500000.00	999999.00	125.00	\N	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
96f9c7cd-10a4-4b92-b425-e0d6055485c7	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	cbf9b499-276b-4a28-999c-27388562c4f4	turnover_band	1000000.00	1999999.00	175.00	\N	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
5e2e7226-559f-4a4d-837b-04ee58474c40	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	cbf9b499-276b-4a28-999c-27388562c4f4	turnover_band	2000000.00	999999999.00	225.00	\N	\N	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
0a7b9393-6578-481a-847e-ac853b847571	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ff4a2600-29fe-4448-bec3-ea868988a9ed	employee_band	1.00	1.00	18.00	\N	{"frequency": "monthly", "description": "Director only"}	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
e5523701-9ec9-4a9d-9524-fac760d53c42	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ff4a2600-29fe-4448-bec3-ea868988a9ed	employee_band	1.00	1.00	54.00	\N	{"frequency": "weekly", "description": "Director only"}	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
a6ddea3b-3e9c-43a8-a536-fe3a1b505cfc	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ff4a2600-29fe-4448-bec3-ea868988a9ed	employee_band	1.00	1.00	36.00	\N	{"frequency": "fortnightly", "description": "Director only"}	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
83dfeaee-adea-4e8f-a31d-53999b4ccf83	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ff4a2600-29fe-4448-bec3-ea868988a9ed	employee_band	1.00	1.00	36.00	\N	{"frequency": "4weekly", "description": "Director only"}	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
c0304d86-119f-40de-82f5-06e6f4410d75	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ff4a2600-29fe-4448-bec3-ea868988a9ed	employee_band	2.00	2.00	35.00	\N	{"frequency": "monthly", "description": "2 employees"}	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
698d70e1-4291-4e0c-bd14-bf44369cabd6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ff4a2600-29fe-4448-bec3-ea868988a9ed	employee_band	2.00	2.00	105.00	\N	{"frequency": "weekly", "description": "2 employees"}	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
0464102c-1ed4-4986-9765-e3b8716286d8	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ff4a2600-29fe-4448-bec3-ea868988a9ed	employee_band	2.00	2.00	70.00	\N	{"frequency": "fortnightly", "description": "2 employees"}	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
5095b62e-5486-4a2f-86b4-91458b161fa4	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ff4a2600-29fe-4448-bec3-ea868988a9ed	employee_band	2.00	2.00	70.00	\N	{"frequency": "4weekly", "description": "2 employees"}	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
b2fa0a01-5bbb-4d0b-9018-4ea7cf80d60f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ff4a2600-29fe-4448-bec3-ea868988a9ed	employee_band	3.00	3.00	50.00	\N	{"frequency": "monthly", "description": "3 employees"}	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
c7ee8718-5b13-4163-854d-2e65c3dac55c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ff4a2600-29fe-4448-bec3-ea868988a9ed	employee_band	3.00	3.00	150.00	\N	{"frequency": "weekly", "description": "3 employees"}	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
5f341e71-8c2e-4542-abd8-b426d2cfc4c0	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ff4a2600-29fe-4448-bec3-ea868988a9ed	employee_band	3.00	3.00	100.00	\N	{"frequency": "fortnightly", "description": "3 employees"}	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
3b9194f6-ac64-4d97-946b-30d440984139	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ff4a2600-29fe-4448-bec3-ea868988a9ed	employee_band	3.00	3.00	100.00	\N	{"frequency": "4weekly", "description": "3 employees"}	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
2ed55724-ef46-4fe8-8b65-5c70b8717fee	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ff4a2600-29fe-4448-bec3-ea868988a9ed	employee_band	4.00	5.00	65.00	\N	{"frequency": "monthly", "description": "4-5 employees"}	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
6ea3ca96-7000-4292-a21e-96c94c83826a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ff4a2600-29fe-4448-bec3-ea868988a9ed	employee_band	4.00	5.00	195.00	\N	{"frequency": "weekly", "description": "4-5 employees"}	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
6f3be875-e928-4606-a60f-712856235528	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ff4a2600-29fe-4448-bec3-ea868988a9ed	employee_band	4.00	5.00	130.00	\N	{"frequency": "fortnightly", "description": "4-5 employees"}	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
d60dd1f2-e4f3-404d-8ebf-d6f53c312cc2	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ff4a2600-29fe-4448-bec3-ea868988a9ed	employee_band	4.00	5.00	130.00	\N	{"frequency": "4weekly", "description": "4-5 employees"}	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
66d89a9c-ed7d-4ebb-91da-bd5db84661a6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ff4a2600-29fe-4448-bec3-ea868988a9ed	employee_band	6.00	10.00	90.00	\N	{"frequency": "monthly", "description": "6-10 employees"}	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
adec8294-8757-49c2-93c2-862bb44539d5	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ff4a2600-29fe-4448-bec3-ea868988a9ed	employee_band	6.00	10.00	270.00	\N	{"frequency": "weekly", "description": "6-10 employees"}	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
3c329d49-dbae-42b8-b9aa-9220631819f2	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ff4a2600-29fe-4448-bec3-ea868988a9ed	employee_band	6.00	10.00	180.00	\N	{"frequency": "fortnightly", "description": "6-10 employees"}	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
111c2fb8-5c1b-4fed-abe6-ab6f2c5b9806	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ff4a2600-29fe-4448-bec3-ea868988a9ed	employee_band	6.00	10.00	180.00	\N	{"frequency": "4weekly", "description": "6-10 employees"}	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
a14fdf08-2081-4569-86af-9366d30e23e2	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ff4a2600-29fe-4448-bec3-ea868988a9ed	employee_band	11.00	15.00	130.00	\N	{"frequency": "monthly", "description": "11-15 employees"}	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
a3b35e29-3623-43f6-bad1-02dace64b9c4	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ff4a2600-29fe-4448-bec3-ea868988a9ed	employee_band	11.00	15.00	390.00	\N	{"frequency": "weekly", "description": "11-15 employees"}	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
666525ae-d397-4546-8eea-c8e9098b0a9e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ff4a2600-29fe-4448-bec3-ea868988a9ed	employee_band	11.00	15.00	260.00	\N	{"frequency": "fortnightly", "description": "11-15 employees"}	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
7c36bb28-666e-4cf8-b390-3cd1d1f4a4c3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ff4a2600-29fe-4448-bec3-ea868988a9ed	employee_band	11.00	15.00	260.00	\N	{"frequency": "4weekly", "description": "11-15 employees"}	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
2ac5fc36-127a-495b-a240-9c36ceadc4a3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ff4a2600-29fe-4448-bec3-ea868988a9ed	employee_band	16.00	20.00	170.00	\N	{"frequency": "monthly", "description": "16-20 employees"}	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
8963265e-3f27-43d7-95f5-82999157ab67	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ff4a2600-29fe-4448-bec3-ea868988a9ed	employee_band	16.00	20.00	510.00	\N	{"frequency": "weekly", "description": "16-20 employees"}	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
69826d97-2668-4504-8ea5-4369f2779274	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ff4a2600-29fe-4448-bec3-ea868988a9ed	employee_band	16.00	20.00	340.00	\N	{"frequency": "fortnightly", "description": "16-20 employees"}	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
a8a13900-830a-41c6-b9c5-a6f37be2867e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ff4a2600-29fe-4448-bec3-ea868988a9ed	employee_band	16.00	20.00	340.00	\N	{"frequency": "4weekly", "description": "16-20 employees"}	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
5eac3b83-164c-438e-a246-9987d9353458	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ff4a2600-29fe-4448-bec3-ea868988a9ed	per_unit	21.00	\N	5.00	\N	{"basePrice": 170, "frequency": "monthly", "description": "Per employee over 20 (monthly)"}	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
67eb0d60-915a-49dc-bf38-5cb50929378b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ff4a2600-29fe-4448-bec3-ea868988a9ed	per_unit	21.00	\N	15.00	\N	{"basePrice": 510, "frequency": "weekly", "description": "Per employee over 20 (weekly)"}	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
8da5dcfa-05f2-4152-84b1-7feab5dabea5	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ff4a2600-29fe-4448-bec3-ea868988a9ed	per_unit	21.00	\N	10.00	\N	{"basePrice": 340, "frequency": "fortnightly", "description": "Per employee over 20 (fortnightly)"}	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
b09dc63e-8ad6-4db7-954b-7424324aa8b7	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ff4a2600-29fe-4448-bec3-ea868988a9ed	per_unit	21.00	\N	10.00	\N	{"basePrice": 340, "frequency": "4weekly", "description": "Per employee over 20 (4weekly)"}	t	2025-10-19 18:00:33.986433	2025-10-19 18:00:33.986433
\.


--
-- Data for Name: proposal_services; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.proposal_services (id, tenant_id, proposal_id, component_code, component_name, calculation, price, config, sort_order, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: proposal_signatures; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.proposal_signatures (id, tenant_id, proposal_id, docuseal_submission_id, signature_type, signature_method, signer_email, signer_name, signing_capacity, company_info, audit_trail, document_hash, signature_data, signed_at, viewed_at, ip_address, user_agent, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: proposals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.proposals (id, tenant_id, lead_id, quote_id, client_id, proposal_number, title, status, turnover, industry, monthly_transactions, pricing_model_used, monthly_total, annual_total, pdf_url, signed_pdf_url, docuseal_template_id, docuseal_submission_id, docuseal_signed_pdf_url, document_hash, template_id, custom_terms, terms_and_conditions, notes, valid_until, version, metadata, created_at, sent_at, viewed_at, signed_at, expires_at, updated_at, created_by_id) FROM stdin;
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_permissions (id, tenant_id, role, module, can_view, can_create, can_edit, can_delete, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: service_components; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_components (id, tenant_id, code, name, category, description, pricing_model, base_price, price, price_type, default_rate, duration, supports_complexity, tags, is_active, metadata, created_at, updated_at) FROM stdin;
e2cd4da6-f171-436c-9c7e-a9c1c5436b98	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	COMP_ACCOUNTS	Annual Accounts & Corporation Tax	compliance	Year-end accounts preparation and Corporation Tax return filing	both	30.00	49.00	fixed	\N	\N	f	["compliance", "accounts", "corporation-tax"]	t	\N	2025-10-19 18:00:33.949872	2025-10-19 18:00:33.949872
a0801828-5c53-41ef-9b3e-06db89d72e90	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	COMP_CONFIRMATION	Confirmation Statement	compliance	Annual Companies House confirmation statement filing	fixed	5.00	5.00	fixed	\N	\N	f	["compliance", "companies-house"]	t	\N	2025-10-19 18:00:33.949872	2025-10-19 18:00:33.949872
3f2e9a8e-bdfe-4d09-aced-e88cdc710462	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	COMP_SATR	Self-Assessment Tax Returns	compliance	Personal tax return for directors/shareholders	fixed	16.67	16.67	fixed	\N	\N	f	["compliance", "self-assessment", "personal-tax"]	t	\N	2025-10-19 18:00:33.949872	2025-10-19 18:00:33.949872
1ede1cc0-3627-404e-bb8a-487e028f4732	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	VAT_STANDARD	Quarterly VAT Returns	vat	Preparation and filing of quarterly VAT returns to HMRC	both	20.00	25.00	fixed	\N	\N	f	["vat", "returns", "mtd"]	t	\N	2025-10-19 18:00:33.949872	2025-10-19 18:00:33.949872
391f7d87-df5d-4538-9b3e-31e07ac9347e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	BOOK_BASIC	Basic Bookkeeping (Cash Coding)	bookkeeping	Transaction categorization and basic reconciliation in Xero	both	40.00	80.00	fixed	\N	\N	f	["bookkeeping", "basic", "xero"]	t	\N	2025-10-19 18:00:33.949872	2025-10-19 18:00:33.949872
b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	BOOK_FULL	Full Bookkeeping (Comprehensive)	bookkeeping	Complete bookkeeping service with proactive financial management	both	120.00	180.00	fixed	\N	\N	t	["bookkeeping", "full-service", "xero"]	t	\N	2025-10-19 18:00:33.949872	2025-10-19 18:00:33.949872
ff4a2600-29fe-4448-bec3-ea868988a9ed	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	PAYROLL_STANDARD	Standard Payroll Processing	payroll	Full payroll processing including RTI submissions to HMRC	fixed	18.00	18.00	fixed	\N	\N	f	["payroll", "rti", "paye"]	t	\N	2025-10-19 18:00:33.949872	2025-10-19 18:00:33.949872
a8a65b80-dc4c-49f9-9c8d-0dc4a336cf55	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	PAYROLL_PENSION	Auto-Enrolment Pension Administration	payroll	Pension scheme administration and compliance	fixed	2.00	2.00	fixed	\N	\N	f	["payroll", "pension", "auto-enrolment"]	t	\N	2025-10-19 18:00:33.949872	2025-10-19 18:00:33.949872
a49c064a-0890-4c02-8734-07a3185e6c03	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	MGMT_MONTHLY	Monthly Management Accounts	management	Comprehensive management reporting package	turnover	150.00	150.00	fixed	\N	\N	f	["management-accounts", "reporting", "kpi"]	t	\N	2025-10-19 18:00:33.949872	2025-10-19 18:00:33.949872
cbf9b499-276b-4a28-999c-27388562c4f4	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	MGMT_QUARTERLY	Quarterly Management Accounts	management	Quarterly management reporting package	turnover	75.00	75.00	fixed	\N	\N	f	["management-accounts", "reporting"]	t	\N	2025-10-19 18:00:33.949872	2025-10-19 18:00:33.949872
109283c7-55ef-4e05-bf53-c6efd1be486f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	SEC_BASIC	Basic Company Secretarial	secretarial	Annual return, share changes, basic filings	fixed	15.00	15.00	fixed	\N	\N	f	["secretarial", "companies-house"]	t	\N	2025-10-19 18:00:33.949872	2025-10-19 18:00:33.949872
78882562-2120-44d2-9286-03e696abbf02	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	SEC_FULL	Full Company Secretarial	secretarial	Minutes, resolutions, register maintenance, all filings	fixed	35.00	35.00	fixed	\N	\N	f	["secretarial", "minutes", "resolutions"]	t	\N	2025-10-19 18:00:33.949872	2025-10-19 18:00:33.949872
cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	SEC_COMPLEX	Complex Company Secretarial	secretarial	Group structures, multiple entities, complex changes	fixed	60.00	60.00	fixed	\N	\N	f	["secretarial", "complex", "group-structures"]	t	\N	2025-10-19 18:00:33.949872	2025-10-19 18:00:33.949872
235b548d-f0a0-4899-9a7e-d6e9bec6db40	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	TAX_ANNUAL	Annual Tax Planning Review	tax_planning	Annual tax planning review and optimization	fixed	50.00	50.00	fixed	\N	\N	f	["tax-planning", "advisory"]	t	\N	2025-10-19 18:00:33.949872	2025-10-19 18:00:33.949872
18c91d63-8f9d-4974-ba97-a4079c7457d5	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	TAX_QUARTERLY	Quarterly Tax Planning	tax_planning	Quarterly tax planning and optimization	fixed	100.00	100.00	fixed	\N	\N	f	["tax-planning", "advisory", "quarterly"]	t	\N	2025-10-19 18:00:33.949872	2025-10-19 18:00:33.949872
a96c9f4d-dc33-4af3-818d-8d729f0f8c1f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	TAX_RD	R&D Tax Claims	tax_planning	Research & Development tax claim preparation	fixed	1500.00	1500.00	percentage	\N	\N	f	["tax-planning", "rd-claims"]	t	{"percentage": 18}	2025-10-19 18:00:33.949872	2025-10-19 18:00:33.949872
e4487405-7859-40e9-8008-056d32fe6f10	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ADDON_CIS	CIS Returns	addon	Construction Industry Scheme returns	fixed	40.00	40.00	fixed	\N	\N	f	["addon", "cis", "construction"]	t	\N	2025-10-19 18:00:33.949872	2025-10-19 18:00:33.949872
b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ADDON_RENTAL	Additional Rental Properties	addon	Per additional rental property on SATR (beyond 2)	fixed	4.00	4.00	fixed	\N	\N	f	["addon", "rental", "property"]	t	\N	2025-10-19 18:00:33.949872	2025-10-19 18:00:33.949872
ef53422c-1305-4831-bf41-d85b2a76b0d5	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ADDON_VAT_REG	VAT Registration	addon	VAT registration service	fixed	5.00	5.00	fixed	\N	\N	f	["addon", "vat", "registration"]	t	{"oneOffSetupFee": 75}	2025-10-19 18:00:33.949872	2025-10-19 18:00:33.949872
79d01aa5-b680-4830-ab3a-5e3cb66edcfa	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ADDON_PAYE_REG	PAYE Registration	addon	PAYE registration service	fixed	5.00	5.00	fixed	\N	\N	f	["addon", "paye", "registration"]	t	{"oneOffSetupFee": 75}	2025-10-19 18:00:33.949872	2025-10-19 18:00:33.949872
9362cf11-827c-459a-8ffc-6634bd023508	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ADDON_MTD_SETUP	Making Tax Digital Setup	addon	MTD setup and training	fixed	200.00	200.00	fixed	\N	\N	f	["addon", "mtd", "setup"]	t	\N	2025-10-19 18:00:33.949872	2025-10-19 18:00:33.949872
d6d7e47b-cd48-48d8-a45a-fa75af1f9a52	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ADDON_XERO_SETUP	Xero Setup & Training	addon	Xero setup and training (3 hours)	fixed	300.00	300.00	fixed	\N	\N	f	["addon", "xero", "setup", "training"]	t	\N	2025-10-19 18:00:33.949872	2025-10-19 18:00:33.949872
ca413110-b7e3-4734-a185-d21ea0960708	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ADDON_MODULR_WEEKLY	Modulr - Weekly	addon	Modulr payment processing - weekly	fixed	60.00	60.00	fixed	\N	\N	f	["addon", "modulr", "payments"]	t	\N	2025-10-19 18:00:33.949872	2025-10-19 18:00:33.949872
08ee5378-067c-4708-886c-34df4c200b23	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ADDON_MODULR_BIWEEKLY	Modulr - Bi-Weekly	addon	Modulr payment processing - bi-weekly	fixed	30.00	30.00	fixed	\N	\N	f	["addon", "modulr", "payments"]	t	\N	2025-10-19 18:00:33.949872	2025-10-19 18:00:33.949872
ecfd2c2c-905b-4ef4-99a4-8949632b9ae9	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ADDON_MODULR_MONTHLY	Modulr - Monthly	addon	Modulr payment processing - monthly	fixed	10.00	10.00	fixed	\N	\N	f	["addon", "modulr", "payments"]	t	\N	2025-10-19 18:00:33.949872	2025-10-19 18:00:33.949872
996aa78c-cfd1-477f-8c30-d9489225b29e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ADDON_VAT_REVIEW	VAT Return Review	addon	VAT return review service	fixed	60.00	60.00	fixed	\N	\N	f	["addon", "vat", "review"]	t	\N	2025-10-19 18:00:33.949872	2025-10-19 18:00:33.949872
29a61f52-d957-4207-b54b-7fc565a57541	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ADDON_VAT_1614_REG	VAT 1614 Registration	addon	VAT 1614 (flat rate scheme) registration	fixed	5.00	5.00	fixed	\N	\N	f	["addon", "vat", "registration", "flat-rate"]	t	\N	2025-10-19 18:00:33.949872	2025-10-19 18:00:33.949872
d04961e2-5af7-4b9c-bb44-c37031dd6bfa	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	ADDON_SATR_REG	SATR Registration	addon	Self-assessment tax return registration	fixed	5.00	5.00	fixed	\N	\N	f	["addon", "satr", "registration"]	t	\N	2025-10-19 18:00:33.949872	2025-10-19 18:00:33.949872
\.


--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.services (id, tenant_id, code, name, description, category, default_rate, price, price_type, duration, tags, is_active, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.session (id, expires_at, token, created_at, updated_at, ip_address, user_agent, user_id, active_organization_id) FROM stdin;
\.


--
-- Data for Name: task_workflow_instances; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.task_workflow_instances (id, task_id, workflow_id, current_stage_id, status, stage_progress, started_at, completed_at, paused_at, metadata, created_at, updated_at) FROM stdin;
9446c651-0acd-4703-b00e-827ff715069b	8c04c9d5-2992-4108-bc71-d0210b7972e2	965823ac-8815-43cb-b52d-be3d11bee333	aec923f2-d4a6-4060-8e49-1a5a1482d2df	active	{}	2025-10-19 18:00:38.377363	\N	\N	\N	2025-10-19 18:00:38.377363	2025-10-19 18:00:38.377363
bdea101f-92c0-4dd9-be08-6f03ea652034	40ca5c4e-33d7-432f-a55c-b59c3010d7ef	6784d58d-be43-45ac-88e5-3232d67c5172	efae45d3-adc3-4b7e-b790-cdf771e92d4f	active	{}	2025-10-19 18:00:38.391021	\N	\N	\N	2025-10-19 18:00:38.391021	2025-10-19 18:00:38.391021
39906c1c-a40e-478a-9442-a36593ddf5a4	d2f831e1-38ca-429c-9942-06db88f8dfc5	965823ac-8815-43cb-b52d-be3d11bee333	aec923f2-d4a6-4060-8e49-1a5a1482d2df	active	{}	2025-10-19 18:00:38.401099	\N	\N	\N	2025-10-19 18:00:38.401099	2025-10-19 18:00:38.401099
923b7ef5-cec2-4f4c-a244-87e772e569d2	196a1b4b-9367-4b9f-baf6-717d312881a3	6784d58d-be43-45ac-88e5-3232d67c5172	efae45d3-adc3-4b7e-b790-cdf771e92d4f	active	{}	2025-10-19 18:00:38.411704	\N	\N	\N	2025-10-19 18:00:38.411704	2025-10-19 18:00:38.411704
06c8b6ce-28a3-4fb6-a8d1-123015222916	ed074125-f8db-4b46-af39-96ce8eb67c4b	965823ac-8815-43cb-b52d-be3d11bee333	aec923f2-d4a6-4060-8e49-1a5a1482d2df	active	{}	2025-10-19 18:00:38.421224	\N	\N	\N	2025-10-19 18:00:38.421224	2025-10-19 18:00:38.421224
58563673-be38-45b1-a61f-7e36255fad57	92700c16-c146-4a6e-9610-46ac28f4b4c3	6784d58d-be43-45ac-88e5-3232d67c5172	efae45d3-adc3-4b7e-b790-cdf771e92d4f	active	{}	2025-10-19 18:00:38.430622	\N	\N	\N	2025-10-19 18:00:38.430622	2025-10-19 18:00:38.430622
3b849ac3-9a9f-46a4-a23b-f6b1e3c3dcad	116f1e4b-b201-4dec-8d77-5e3b3695422f	6784d58d-be43-45ac-88e5-3232d67c5172	efae45d3-adc3-4b7e-b790-cdf771e92d4f	active	{}	2025-10-19 18:00:38.440968	\N	\N	\N	2025-10-19 18:00:38.440968	2025-10-19 18:00:38.440968
70de97c9-1e3d-43df-8bdf-37f2ae4d2610	7a582f98-6d3d-44d5-9796-ba1d12c49f62	4a29c5cf-69ba-4639-b91a-08f3851b5397	8e7dc108-3181-4886-8e69-1193c426e1f7	active	{}	2025-10-19 18:00:38.450914	\N	\N	\N	2025-10-19 18:00:38.450914	2025-10-19 18:00:38.450914
6097e140-508c-4fc4-9d0c-f80a3599f157	0b689153-0b45-4725-866b-5eac75a40ad8	965823ac-8815-43cb-b52d-be3d11bee333	aec923f2-d4a6-4060-8e49-1a5a1482d2df	active	{}	2025-10-19 18:00:38.459457	\N	\N	\N	2025-10-19 18:00:38.459457	2025-10-19 18:00:38.459457
095b8b4f-06a1-41b9-9e33-5118fc289ee6	ae73110f-e045-44ac-85ff-51aa2eb8ce69	51c831a7-42a0-4a9e-8e8a-69e873269a4f	b1ca67dc-a72a-45a5-8f3b-d5e50512cdd1	active	{}	2025-10-19 18:00:38.467293	\N	\N	\N	2025-10-19 18:00:38.467293	2025-10-19 18:00:38.467293
87ac746e-d08a-46fb-ad56-664c19cff4ea	0da2984a-30cb-4fdf-a4f6-b38ff97be406	acbad2fb-595b-462b-82fc-f2f04f43fc67	056061d3-463c-43ac-90cd-6e398c308ca1	active	{}	2025-10-19 18:00:38.475512	\N	\N	\N	2025-10-19 18:00:38.475512	2025-10-19 18:00:38.475512
6c5da831-c1ab-4a5a-abc1-df70b0e5bb1a	04600664-34f3-4ae0-9a01-2da04b5bc5fc	6624a9f6-9886-4b3d-a8fc-0bcc0ecfd112	5048a100-6ae3-46ef-96a4-a2c4c092eaa1	active	{}	2025-10-19 18:00:38.484714	\N	\N	\N	2025-10-19 18:00:38.484714	2025-10-19 18:00:38.484714
8531291c-4ae0-485a-8988-5075da490e0a	6c88f260-519e-41e9-9fac-18a28b9a7901	6624a9f6-9886-4b3d-a8fc-0bcc0ecfd112	5048a100-6ae3-46ef-96a4-a2c4c092eaa1	active	{}	2025-10-19 18:00:38.496236	\N	\N	\N	2025-10-19 18:00:38.496236	2025-10-19 18:00:38.496236
8ab2afd2-9eb7-4446-ad1e-93853e8da3a1	088446c4-4542-4007-9887-b512bd3db05d	f08a8f24-3be0-4086-bd5c-a4eb1cf19811	862129fa-26ed-4750-b835-a1209aaa6d08	active	{}	2025-10-19 18:00:38.505137	\N	\N	\N	2025-10-19 18:00:38.505137	2025-10-19 18:00:38.505137
df43614e-dd16-467c-ac37-60ace64968df	449f8e23-33a0-4bf0-915e-cc79d13bc3a9	c9013c22-350c-46aa-b8c4-8a71da338337	8fc49151-f9f3-4c30-8cd0-5d8c459062c4	active	{}	2025-10-19 18:00:38.511737	\N	\N	\N	2025-10-19 18:00:38.511737	2025-10-19 18:00:38.511737
f903d946-8b21-419d-8a87-832a85350b2a	b98cb032-3f5a-46db-ab39-de7d53570ae9	965823ac-8815-43cb-b52d-be3d11bee333	aec923f2-d4a6-4060-8e49-1a5a1482d2df	active	{}	2025-10-19 18:00:38.518595	\N	\N	\N	2025-10-19 18:00:38.518595	2025-10-19 18:00:38.518595
e4045a04-18ac-45ff-95a2-04c09014ee13	96a103f5-bc5b-43e1-b321-62fedda6eaa1	6624a9f6-9886-4b3d-a8fc-0bcc0ecfd112	5048a100-6ae3-46ef-96a4-a2c4c092eaa1	active	{}	2025-10-19 18:00:38.523832	\N	\N	\N	2025-10-19 18:00:38.523832	2025-10-19 18:00:38.523832
dff1be4d-5fcc-4655-a964-292d2f1bdb0d	e60c944c-85a6-45da-b007-56b5244e0257	acbad2fb-595b-462b-82fc-f2f04f43fc67	056061d3-463c-43ac-90cd-6e398c308ca1	active	{}	2025-10-19 18:00:38.528499	\N	\N	\N	2025-10-19 18:00:38.528499	2025-10-19 18:00:38.528499
c42d301f-ba94-4379-9416-f6b6500406c6	d8601cb6-589f-456f-a2b2-1b986973a4bc	51c831a7-42a0-4a9e-8e8a-69e873269a4f	b1ca67dc-a72a-45a5-8f3b-d5e50512cdd1	active	{}	2025-10-19 18:00:38.533876	\N	\N	\N	2025-10-19 18:00:38.533876	2025-10-19 18:00:38.533876
e64edddb-d1c2-4c86-bfae-523b4756bd35	2c1d5d5c-be1c-427c-b2ac-da3cc28b1680	f08a8f24-3be0-4086-bd5c-a4eb1cf19811	862129fa-26ed-4750-b835-a1209aaa6d08	active	{}	2025-10-19 18:00:38.539796	\N	\N	\N	2025-10-19 18:00:38.539796	2025-10-19 18:00:38.539796
cef865de-b816-406b-a9e4-efc1a3686eed	eb1af1df-ce0a-4763-aaef-49b6b390beab	6624a9f6-9886-4b3d-a8fc-0bcc0ecfd112	5048a100-6ae3-46ef-96a4-a2c4c092eaa1	active	{}	2025-10-19 18:00:38.546137	\N	\N	\N	2025-10-19 18:00:38.546137	2025-10-19 18:00:38.546137
3a977d02-7c9f-4220-86e1-944e20c06c4c	062f6587-cb37-4a01-aa03-004703abe1e2	6784d58d-be43-45ac-88e5-3232d67c5172	efae45d3-adc3-4b7e-b790-cdf771e92d4f	active	{}	2025-10-19 18:00:38.551592	\N	\N	\N	2025-10-19 18:00:38.551592	2025-10-19 18:00:38.551592
a2b48cdf-e910-4cd9-931c-27ba843a393e	5e2204cd-be52-42a7-aa41-14fcf0e4a272	6624a9f6-9886-4b3d-a8fc-0bcc0ecfd112	5048a100-6ae3-46ef-96a4-a2c4c092eaa1	active	{}	2025-10-19 18:00:38.556283	\N	\N	\N	2025-10-19 18:00:38.556283	2025-10-19 18:00:38.556283
0bd584f6-da58-4ebd-82bf-50bd52ffc8d1	a18510b4-73e3-40ff-84b1-89c4a2e0bdac	6624a9f6-9886-4b3d-a8fc-0bcc0ecfd112	5048a100-6ae3-46ef-96a4-a2c4c092eaa1	active	{}	2025-10-19 18:00:38.561826	\N	\N	\N	2025-10-19 18:00:38.561826	2025-10-19 18:00:38.561826
1e08ab21-b856-4923-8774-6f0696d7e567	fe24fe87-1db5-4f06-9a5c-46757a20518d	6784d58d-be43-45ac-88e5-3232d67c5172	efae45d3-adc3-4b7e-b790-cdf771e92d4f	active	{}	2025-10-19 18:00:38.567972	\N	\N	\N	2025-10-19 18:00:38.567972	2025-10-19 18:00:38.567972
dbcdcda3-01b6-4eb4-9e44-0c8bd79b22eb	98f9340d-eadb-45cd-bba2-115aa880f565	f08a8f24-3be0-4086-bd5c-a4eb1cf19811	862129fa-26ed-4750-b835-a1209aaa6d08	active	{}	2025-10-19 18:00:38.573748	\N	\N	\N	2025-10-19 18:00:38.573748	2025-10-19 18:00:38.573748
f7f555e6-e847-4735-add1-4841d4150cdd	c8eb351f-daa9-48cf-bc62-2cef6338a122	acbad2fb-595b-462b-82fc-f2f04f43fc67	056061d3-463c-43ac-90cd-6e398c308ca1	active	{}	2025-10-19 18:00:38.579352	\N	\N	\N	2025-10-19 18:00:38.579352	2025-10-19 18:00:38.579352
fd06bacf-d51b-41f8-aeb5-5a5dbc3d961d	7041a9f2-cd04-4f9c-ab2c-96bfdd45e5ff	51c831a7-42a0-4a9e-8e8a-69e873269a4f	b1ca67dc-a72a-45a5-8f3b-d5e50512cdd1	active	{}	2025-10-19 18:00:38.584457	\N	\N	\N	2025-10-19 18:00:38.584457	2025-10-19 18:00:38.584457
202781e6-7956-41f3-aa29-4babf542c9a5	07b65174-c767-4ace-ac22-e486eb422fa6	4a29c5cf-69ba-4639-b91a-08f3851b5397	8e7dc108-3181-4886-8e69-1193c426e1f7	active	{}	2025-10-19 18:00:38.589626	\N	\N	\N	2025-10-19 18:00:38.589626	2025-10-19 18:00:38.589626
bc826e0f-e160-4e86-b275-1c2c9ab19436	9485b00c-4fc8-454f-984a-6908039db9f9	965823ac-8815-43cb-b52d-be3d11bee333	aec923f2-d4a6-4060-8e49-1a5a1482d2df	active	{}	2025-10-19 18:00:38.59833	\N	\N	\N	2025-10-19 18:00:38.59833	2025-10-19 18:00:38.59833
5ccb7152-6c22-4570-bedf-46c41d9e1497	66d28217-b458-4ec3-9e88-eb34570556b7	4a29c5cf-69ba-4639-b91a-08f3851b5397	8e7dc108-3181-4886-8e69-1193c426e1f7	active	{}	2025-10-19 18:00:38.604767	\N	\N	\N	2025-10-19 18:00:38.604767	2025-10-19 18:00:38.604767
eea8d8f2-5c4b-4512-8185-1d5a18a9397f	9ec151a2-b6a4-433d-a21e-c94af23b785b	4a29c5cf-69ba-4639-b91a-08f3851b5397	8e7dc108-3181-4886-8e69-1193c426e1f7	active	{}	2025-10-19 18:00:38.610213	\N	\N	\N	2025-10-19 18:00:38.610213	2025-10-19 18:00:38.610213
94bc0598-6a63-4bb5-979c-1b87f22019d8	71b851af-8542-47e4-9ff8-304ed5983a0b	acbad2fb-595b-462b-82fc-f2f04f43fc67	056061d3-463c-43ac-90cd-6e398c308ca1	active	{}	2025-10-19 18:00:38.616472	\N	\N	\N	2025-10-19 18:00:38.616472	2025-10-19 18:00:38.616472
b31464bf-8cd1-4512-b6a9-61cef2bda10d	8c94ef1c-f972-45ba-9aaa-1fa78ab3fc92	f08a8f24-3be0-4086-bd5c-a4eb1cf19811	862129fa-26ed-4750-b835-a1209aaa6d08	active	{}	2025-10-19 18:00:38.622937	\N	\N	\N	2025-10-19 18:00:38.622937	2025-10-19 18:00:38.622937
b393ef9d-3b51-40b6-8ba2-8481fb3ba092	e171fa0b-3143-48ec-962f-0917bf1886bf	4a29c5cf-69ba-4639-b91a-08f3851b5397	8e7dc108-3181-4886-8e69-1193c426e1f7	active	{}	2025-10-19 18:00:38.633866	\N	\N	\N	2025-10-19 18:00:38.633866	2025-10-19 18:00:38.633866
25f38f9e-857e-4ebf-aafe-cf544228bbcd	1916b6af-0ab6-45d8-85ca-a9a6b331363c	51c831a7-42a0-4a9e-8e8a-69e873269a4f	b1ca67dc-a72a-45a5-8f3b-d5e50512cdd1	active	{}	2025-10-19 18:00:38.638528	\N	\N	\N	2025-10-19 18:00:38.638528	2025-10-19 18:00:38.638528
0961301c-1d4a-49bd-a3a5-5b36ec4b592a	e64d20a6-86e7-4dd1-ab40-aabaedbd6ebb	acbad2fb-595b-462b-82fc-f2f04f43fc67	056061d3-463c-43ac-90cd-6e398c308ca1	active	{}	2025-10-19 18:00:38.6424	\N	\N	\N	2025-10-19 18:00:38.6424	2025-10-19 18:00:38.6424
088bc56b-0b93-44b7-b581-399a15c1f512	ddc09723-5f7f-4f23-a202-0b6243ef63f9	6784d58d-be43-45ac-88e5-3232d67c5172	efae45d3-adc3-4b7e-b790-cdf771e92d4f	active	{}	2025-10-19 18:00:38.645998	\N	\N	\N	2025-10-19 18:00:38.645998	2025-10-19 18:00:38.645998
f50625a4-3035-41ae-9217-e1aff507ab6a	419cb8f8-8b70-44a5-883b-8fa92787aa46	4a29c5cf-69ba-4639-b91a-08f3851b5397	8e7dc108-3181-4886-8e69-1193c426e1f7	active	{}	2025-10-19 18:00:38.649195	\N	\N	\N	2025-10-19 18:00:38.649195	2025-10-19 18:00:38.649195
d90ace6e-2c85-4560-86dd-9533f2193c50	2db210d6-c799-49db-b61d-9aff5f87f1f0	51c831a7-42a0-4a9e-8e8a-69e873269a4f	b1ca67dc-a72a-45a5-8f3b-d5e50512cdd1	active	{}	2025-10-19 18:00:38.653407	\N	\N	\N	2025-10-19 18:00:38.653407	2025-10-19 18:00:38.653407
ccef7db9-d4b4-4fbe-a759-57b9efe9c6ee	6b008063-17c8-4c31-893b-ef9f17e74f13	acbad2fb-595b-462b-82fc-f2f04f43fc67	056061d3-463c-43ac-90cd-6e398c308ca1	active	{}	2025-10-19 18:00:38.657838	\N	\N	\N	2025-10-19 18:00:38.657838	2025-10-19 18:00:38.657838
447c0cef-b120-42fe-b77b-600e626db15e	b7a77905-edd5-451e-a92e-06976feeb638	51c831a7-42a0-4a9e-8e8a-69e873269a4f	b1ca67dc-a72a-45a5-8f3b-d5e50512cdd1	active	{}	2025-10-19 18:00:38.662764	\N	\N	\N	2025-10-19 18:00:38.662764	2025-10-19 18:00:38.662764
51c43463-2a27-4357-a311-4dc5ecc51124	9068b493-e301-4f68-9bcd-ad7c1f9cbe03	c9013c22-350c-46aa-b8c4-8a71da338337	8fc49151-f9f3-4c30-8cd0-5d8c459062c4	active	{}	2025-10-19 18:00:38.669318	\N	\N	\N	2025-10-19 18:00:38.669318	2025-10-19 18:00:38.669318
40d789c9-d124-44aa-bc51-ee75baf244fc	f37ad203-1495-4aec-be30-1b2d7fe4dd70	6624a9f6-9886-4b3d-a8fc-0bcc0ecfd112	5048a100-6ae3-46ef-96a4-a2c4c092eaa1	active	{}	2025-10-19 18:00:38.676694	\N	\N	\N	2025-10-19 18:00:38.676694	2025-10-19 18:00:38.676694
9d981ec2-d28c-40f9-a592-b351650c96f6	be3f2d80-2e55-4bec-bd5e-02e5a00444a9	6784d58d-be43-45ac-88e5-3232d67c5172	efae45d3-adc3-4b7e-b790-cdf771e92d4f	active	{}	2025-10-19 18:00:38.693886	\N	\N	\N	2025-10-19 18:00:38.693886	2025-10-19 18:00:38.693886
25da13cb-d026-477a-8436-4838fe058957	20222077-caa4-4444-b803-1f75d617ee85	4a29c5cf-69ba-4639-b91a-08f3851b5397	8e7dc108-3181-4886-8e69-1193c426e1f7	active	{}	2025-10-19 18:00:38.709512	\N	\N	\N	2025-10-19 18:00:38.709512	2025-10-19 18:00:38.709512
590d04fb-0ddc-4cf6-b3d5-893aeeb1d907	4f8e956e-3c05-4a0d-8695-2014ee9b2f8a	6624a9f6-9886-4b3d-a8fc-0bcc0ecfd112	5048a100-6ae3-46ef-96a4-a2c4c092eaa1	active	{}	2025-10-19 18:00:38.718049	\N	\N	\N	2025-10-19 18:00:38.718049	2025-10-19 18:00:38.718049
bf03ef17-8f61-4d55-95fb-afb1463f5e8c	ff7b1e48-6594-4997-9b76-46ab909220e2	c9013c22-350c-46aa-b8c4-8a71da338337	8fc49151-f9f3-4c30-8cd0-5d8c459062c4	active	{}	2025-10-19 18:00:38.730177	\N	\N	\N	2025-10-19 18:00:38.730177	2025-10-19 18:00:38.730177
6fa84687-4f18-43ce-a61e-019342ece10e	5515e216-ea3c-436b-95a5-6abf213c47ef	51c831a7-42a0-4a9e-8e8a-69e873269a4f	b1ca67dc-a72a-45a5-8f3b-d5e50512cdd1	active	{}	2025-10-19 18:00:38.736072	\N	\N	\N	2025-10-19 18:00:38.736072	2025-10-19 18:00:38.736072
14f581fd-74ea-4e33-9114-0b0ee6e11900	3d497ef7-35c9-4687-8476-96fbecc29f86	c9013c22-350c-46aa-b8c4-8a71da338337	8fc49151-f9f3-4c30-8cd0-5d8c459062c4	active	{}	2025-10-19 18:00:38.741148	\N	\N	\N	2025-10-19 18:00:38.741148	2025-10-19 18:00:38.741148
19ea0d03-f059-4a44-b1e9-9fd43f96f23f	269dca40-b352-4a09-9d7c-c735016a8c7d	6624a9f6-9886-4b3d-a8fc-0bcc0ecfd112	5048a100-6ae3-46ef-96a4-a2c4c092eaa1	active	{}	2025-10-19 18:00:38.745513	\N	\N	\N	2025-10-19 18:00:38.745513	2025-10-19 18:00:38.745513
a82b6001-57db-4700-9ebb-73d575617d9f	4d9083ba-923c-467a-8bdb-8b651cd6d7d7	965823ac-8815-43cb-b52d-be3d11bee333	aec923f2-d4a6-4060-8e49-1a5a1482d2df	active	{}	2025-10-19 18:00:38.749749	\N	\N	\N	2025-10-19 18:00:38.749749	2025-10-19 18:00:38.749749
7f488121-1380-4cc8-97c6-5a3f7c81f67c	b3d1095b-3d51-444b-be35-f485afdb174f	acbad2fb-595b-462b-82fc-f2f04f43fc67	056061d3-463c-43ac-90cd-6e398c308ca1	active	{}	2025-10-19 18:00:38.758645	\N	\N	\N	2025-10-19 18:00:38.758645	2025-10-19 18:00:38.758645
eca5da2a-3f29-4fd1-b12d-4d0b8371f934	6ebdfde2-aeab-4596-9744-cef10c12a313	6784d58d-be43-45ac-88e5-3232d67c5172	efae45d3-adc3-4b7e-b790-cdf771e92d4f	active	{}	2025-10-19 18:00:38.765117	\N	\N	\N	2025-10-19 18:00:38.765117	2025-10-19 18:00:38.765117
17d7438f-efdb-4b0a-9beb-4811595a129a	b09b8a10-2b29-4fa3-b57f-c69d46364489	965823ac-8815-43cb-b52d-be3d11bee333	aec923f2-d4a6-4060-8e49-1a5a1482d2df	active	{}	2025-10-19 18:00:38.77293	\N	\N	\N	2025-10-19 18:00:38.77293	2025-10-19 18:00:38.77293
236ab5e9-1182-47a2-a4f0-b92dce1c49f1	5cf17315-4658-4a7f-9c23-b4f8268d8f84	f08a8f24-3be0-4086-bd5c-a4eb1cf19811	862129fa-26ed-4750-b835-a1209aaa6d08	active	{}	2025-10-19 18:00:38.780386	\N	\N	\N	2025-10-19 18:00:38.780386	2025-10-19 18:00:38.780386
fb529cc4-74c5-4ca4-8511-ade38a1751a5	49ae64ac-de52-4d18-a5d6-d73c5d5605c5	51c831a7-42a0-4a9e-8e8a-69e873269a4f	b1ca67dc-a72a-45a5-8f3b-d5e50512cdd1	active	{}	2025-10-19 18:00:38.786429	\N	\N	\N	2025-10-19 18:00:38.786429	2025-10-19 18:00:38.786429
7af56421-c758-4191-aa9f-f01697e7042f	c7111387-5606-4d4b-88de-270766225b61	6784d58d-be43-45ac-88e5-3232d67c5172	efae45d3-adc3-4b7e-b790-cdf771e92d4f	active	{}	2025-10-19 18:00:38.79379	\N	\N	\N	2025-10-19 18:00:38.79379	2025-10-19 18:00:38.79379
8574440c-c0c9-480c-a952-963eb590c0c0	598a25cc-7c96-4dd9-af0e-1e27762bf53a	4a29c5cf-69ba-4639-b91a-08f3851b5397	8e7dc108-3181-4886-8e69-1193c426e1f7	active	{}	2025-10-19 18:00:38.802824	\N	\N	\N	2025-10-19 18:00:38.802824	2025-10-19 18:00:38.802824
6cc47be1-d3b0-4250-838b-b285b090cb81	dc9252b7-2022-4822-a8b2-7ec227fe0ea4	c9013c22-350c-46aa-b8c4-8a71da338337	8fc49151-f9f3-4c30-8cd0-5d8c459062c4	active	{}	2025-10-19 18:00:38.811383	\N	\N	\N	2025-10-19 18:00:38.811383	2025-10-19 18:00:38.811383
4490ecf0-5d02-41c1-afb6-5b842a3467e3	d486be12-5ed8-48b4-af34-79d9269f4c0b	51c831a7-42a0-4a9e-8e8a-69e873269a4f	b1ca67dc-a72a-45a5-8f3b-d5e50512cdd1	active	{}	2025-10-19 18:00:38.818153	\N	\N	\N	2025-10-19 18:00:38.818153	2025-10-19 18:00:38.818153
a4fda88d-95ac-43a4-a04f-ec74a67e63a2	4fb9cb0a-ca36-4af7-9203-ac1970ce555b	6624a9f6-9886-4b3d-a8fc-0bcc0ecfd112	5048a100-6ae3-46ef-96a4-a2c4c092eaa1	active	{}	2025-10-19 18:00:38.826619	\N	\N	\N	2025-10-19 18:00:38.826619	2025-10-19 18:00:38.826619
db8a83b0-a814-4c3a-98a5-999777e033a6	219aa257-710f-4ef2-892d-39086a9690ed	4a29c5cf-69ba-4639-b91a-08f3851b5397	8e7dc108-3181-4886-8e69-1193c426e1f7	active	{}	2025-10-19 18:00:38.832653	\N	\N	\N	2025-10-19 18:00:38.832653	2025-10-19 18:00:38.832653
60769a16-26d1-44e9-8c38-e0c396a9a97c	e4ce7abb-fb0c-42e1-a7c1-6419b4aa63ef	51c831a7-42a0-4a9e-8e8a-69e873269a4f	b1ca67dc-a72a-45a5-8f3b-d5e50512cdd1	active	{}	2025-10-19 18:00:38.846485	\N	\N	\N	2025-10-19 18:00:38.846485	2025-10-19 18:00:38.846485
16061bd9-397e-46ad-9017-b065d308cfad	a08b1624-6e7a-4a25-8f08-3b9b00adb6a0	6784d58d-be43-45ac-88e5-3232d67c5172	efae45d3-adc3-4b7e-b790-cdf771e92d4f	active	{}	2025-10-19 18:00:38.857341	\N	\N	\N	2025-10-19 18:00:38.857341	2025-10-19 18:00:38.857341
4ecc22c3-b19e-4968-96dd-a9daf96d8e5f	43f46d13-e4e7-4e0f-a62d-25d47b569d15	6624a9f6-9886-4b3d-a8fc-0bcc0ecfd112	5048a100-6ae3-46ef-96a4-a2c4c092eaa1	active	{}	2025-10-19 18:00:38.865867	\N	\N	\N	2025-10-19 18:00:38.865867	2025-10-19 18:00:38.865867
c6b3efe1-af72-43dc-b021-7340fd85fcbc	2105be2b-df4f-494a-bb20-548a7dbda952	c9013c22-350c-46aa-b8c4-8a71da338337	8fc49151-f9f3-4c30-8cd0-5d8c459062c4	active	{}	2025-10-19 18:00:38.876151	\N	\N	\N	2025-10-19 18:00:38.876151	2025-10-19 18:00:38.876151
6d8a9072-3639-4515-b076-b3f95e671544	af41070b-ce93-4cf4-88f6-19ed28a1f1fe	965823ac-8815-43cb-b52d-be3d11bee333	aec923f2-d4a6-4060-8e49-1a5a1482d2df	active	{}	2025-10-19 18:00:38.885759	\N	\N	\N	2025-10-19 18:00:38.885759	2025-10-19 18:00:38.885759
a6549996-7e43-41a0-b293-ad292a24894b	f9444b08-3c00-4407-98d8-3d654600142c	51c831a7-42a0-4a9e-8e8a-69e873269a4f	b1ca67dc-a72a-45a5-8f3b-d5e50512cdd1	active	{}	2025-10-19 18:00:38.895834	\N	\N	\N	2025-10-19 18:00:38.895834	2025-10-19 18:00:38.895834
b30bec78-81db-4ed4-8f87-73353487f550	80260d18-0de6-4cf6-af1d-5b4a1d17a6de	4a29c5cf-69ba-4639-b91a-08f3851b5397	8e7dc108-3181-4886-8e69-1193c426e1f7	active	{}	2025-10-19 18:00:38.904199	\N	\N	\N	2025-10-19 18:00:38.904199	2025-10-19 18:00:38.904199
4bccfed8-258a-4ea4-94a6-891d69c11971	f6f91297-d9d7-461b-bf97-34473b55f893	acbad2fb-595b-462b-82fc-f2f04f43fc67	056061d3-463c-43ac-90cd-6e398c308ca1	active	{}	2025-10-19 18:00:38.911989	\N	\N	\N	2025-10-19 18:00:38.911989	2025-10-19 18:00:38.911989
de2c7d3b-9d5d-4e76-8777-f997bfed91e3	674b7e91-de7b-4a7d-a519-8e8315afb5eb	6624a9f6-9886-4b3d-a8fc-0bcc0ecfd112	5048a100-6ae3-46ef-96a4-a2c4c092eaa1	active	{}	2025-10-19 18:00:38.923349	\N	\N	\N	2025-10-19 18:00:38.923349	2025-10-19 18:00:38.923349
2c6cade8-30c2-4b02-948a-7223da8e050a	2849d1a9-72a4-4287-8114-b604140c71aa	c9013c22-350c-46aa-b8c4-8a71da338337	8fc49151-f9f3-4c30-8cd0-5d8c459062c4	active	{}	2025-10-19 18:00:38.93392	\N	\N	\N	2025-10-19 18:00:38.93392	2025-10-19 18:00:38.93392
6e82c5cb-4108-4861-90a8-e886510958d2	1c9d17d2-a153-4f42-9604-129a162a1f0f	acbad2fb-595b-462b-82fc-f2f04f43fc67	056061d3-463c-43ac-90cd-6e398c308ca1	active	{}	2025-10-19 18:00:38.942516	\N	\N	\N	2025-10-19 18:00:38.942516	2025-10-19 18:00:38.942516
6e9a3842-ea9e-49e3-b524-0da2e5f148f7	7add02b8-5d73-4a39-8607-6f9d17b36fda	51c831a7-42a0-4a9e-8e8a-69e873269a4f	b1ca67dc-a72a-45a5-8f3b-d5e50512cdd1	active	{}	2025-10-19 18:00:38.950567	\N	\N	\N	2025-10-19 18:00:38.950567	2025-10-19 18:00:38.950567
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tasks (id, tenant_id, title, description, status, priority, client_id, assigned_to_id, reviewer_id, created_by_id, due_date, target_date, completed_at, estimated_hours, actual_hours, progress, task_type, category, tags, parent_task_id, workflow_id, is_recurring, recurring_pattern, metadata, created_at, updated_at) FROM stdin;
40ca5c4e-33d7-432f-a55c-b59c3010d7ef	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Document Review - Faye Gleichner	Adopto contigo caute cena contra sint aliqua testimonium. Ambitus voluptates bellicus surculus comptus cometes desparatus inventore unde. Ultio curtus sordeo delicate adfectus suggero cinis.	in_progress	urgent	0d0329f4-4b80-4899-8807-5854e9db312b	0409f8de-7e1d-4245-96c2-02a3b1c90a81	\N	0409f8de-7e1d-4245-96c2-02a3b1c90a81	2025-10-01 10:20:21.817	2025-10-03 20:21:28.384	\N	14.00	\N	2	Client Meeting	Support	["urgent", "monthly"]	\N	6784d58d-be43-45ac-88e5-3232d67c5172	f	\N	\N	2025-10-19 18:00:34.800676	2025-10-19 18:00:34.800676
d2f831e1-38ca-429c-9942-06db88f8dfc5	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	VAT Return - Dana Dickens	Barba amiculum armarium. Illo vulgaris succurro. Quos odit soleo acidus animadverto cariosus alienus comburo.	in_progress	urgent	b7295600-5c20-4de2-8782-af87987c2bee	d6f36046-e274-4776-a3d7-58eadb9d96b0	\N	c4f75303-a973-43e1-8f69-dfc6500c302c	2025-11-26 09:02:16.833	2025-11-27 09:22:40.421	\N	15.00	\N	42	Tax Return	Client Work	["annual", "quarterly"]	\N	965823ac-8815-43cb-b52d-be3d11bee333	f	\N	\N	2025-10-19 18:00:34.808335	2025-10-19 18:00:34.808335
196a1b4b-9367-4b9f-baf6-717d312881a3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Compliance Check - Dana Dickens	Desparatus solium vulticulus viridis tremo succurro claudeo collum. Supra adsuesco aliquam strenuus conforto tempore. Verus deprecator iusto utor stips nisi depraedor depromo vomito.	completed	high	b7295600-5c20-4de2-8782-af87987c2bee	d6f36046-e274-4776-a3d7-58eadb9d96b0	c4f75303-a973-43e1-8f69-dfc6500c302c	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-21 20:38:28.59	2025-10-24 19:53:35.609	2025-10-19 15:01:49.703	7.00	17.00	100	Client Meeting	Admin	["urgent"]	\N	6784d58d-be43-45ac-88e5-3232d67c5172	f	\N	\N	2025-10-19 18:00:34.814524	2025-10-19 18:00:34.814524
ed074125-f8db-4b46-af39-96ce8eb67c4b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Annual Accounts - Stiedemann, Reichel and Brown	Contego creber sordeo demitto ratione vilitas attollo suggero. Tunc verbera abstergo solitudo advenio officia tondeo adulescens. Officia vestigium patrocinor cribro adfectus maxime ascisco vulgus.	in_progress	low	67f62599-7f9f-44e8-bc18-d2ce08ea9919	d6f36046-e274-4776-a3d7-58eadb9d96b0	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-14 02:47:22.299	2025-10-15 23:15:42.979	\N	9.00	\N	73	Tax Return	Support	["monthly", "quarterly", "annual"]	\N	965823ac-8815-43cb-b52d-be3d11bee333	f	\N	\N	2025-10-19 18:00:34.819939	2025-10-19 18:00:34.819939
92700c16-c146-4a6e-9610-46ac28f4b4c3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Bookkeeping - Ruecker - Jerde	Subito deinde veniam suadeo ad vomica voveo ciminatio viridis crinis. Esse bestia strenuus tracto. Voluptatem talio tondeo pauper avaritia amiculum curo caelum abundans.	in_progress	high	45b3d726-e151-4770-9b64-4653914bdaa5	a2adaa31-8f59-409a-b39b-72568022adb4	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-13 13:20:44.868	2025-10-15 05:56:59.541	\N	1.00	\N	72	Client Meeting	Development	["monthly", "annual"]	\N	6784d58d-be43-45ac-88e5-3232d67c5172	f	\N	\N	2025-10-19 18:00:34.825963	2025-10-19 18:00:34.825963
116f1e4b-b201-4dec-8d77-5e3b3695422f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Document Review - Skiles - Bernier	Defleo audeo omnis. Quibusdam crepusculum spectaculum calculus crebro deporto voluptatum desparatus aequitas. Capio brevis culpa.	pending	urgent	d69d0436-37d7-42a4-b907-3d9c3a091ea6	d6f36046-e274-4776-a3d7-58eadb9d96b0	0409f8de-7e1d-4245-96c2-02a3b1c90a81	0409f8de-7e1d-4245-96c2-02a3b1c90a81	2025-10-03 09:03:12.901	2025-10-04 16:51:54.825	\N	10.00	\N	15	Client Meeting	Admin	["annual", "urgent", "monthly"]	\N	6784d58d-be43-45ac-88e5-3232d67c5172	f	\N	\N	2025-10-19 18:00:34.831462	2025-10-19 18:00:34.831462
7a582f98-6d3d-44d5-9796-ba1d12c49f62	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Compliance Check - Latoya Crooks	Vitae artificiose dens. Amplexus sit voveo succedo abutor. Copia cupio tepidus sponte delicate terga cum alius adsidue aestas.	pending	urgent	584bab37-ccf2-484c-9a7f-7394e4b30ec6	a2adaa31-8f59-409a-b39b-72568022adb4	\N	c4f75303-a973-43e1-8f69-dfc6500c302c	2025-09-30 23:47:08.679	2025-10-01 21:00:48.64	\N	1.00	\N	37	Compliance Check	Development	["quarterly", "annual", "urgent"]	\N	4a29c5cf-69ba-4639-b91a-08f3851b5397	f	\N	\N	2025-10-19 18:00:34.837202	2025-10-19 18:00:34.837202
0b689153-0b45-4725-866b-5eac75a40ad8	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Payroll - Skiles - Bernier	Adinventitias valetudo quam. Perspiciatis delego pauci vesper arbustum. Molestiae bos apud vallum combibo curis toties vapulus deprecator.	cancelled	urgent	d69d0436-37d7-42a4-b907-3d9c3a091ea6	a2adaa31-8f59-409a-b39b-72568022adb4	\N	c4f75303-a973-43e1-8f69-dfc6500c302c	2025-12-14 11:55:07.391	2025-12-14 22:34:49.548	\N	16.00	\N	7	Tax Return	Client Work	["annual", "client-request"]	\N	965823ac-8815-43cb-b52d-be3d11bee333	f	\N	\N	2025-10-19 18:00:34.844174	2025-10-19 18:00:34.844174
ae73110f-e045-44ac-85ff-51aa2eb8ce69	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Payroll - Abel Shanahan	Corrupti sufficio ventosus vivo quae arcus eum uter apud tabula. Suadeo constans quia credo creta totam. Rerum patria audentia addo.	cancelled	medium	4554e09d-4391-42a8-a2cd-9702bce80511	a2adaa31-8f59-409a-b39b-72568022adb4	c4f75303-a973-43e1-8f69-dfc6500c302c	d6f36046-e274-4776-a3d7-58eadb9d96b0	2025-11-03 09:04:30.417	2025-11-05 10:30:17.821	\N	6.00	\N	34	Bookkeeping	Development	["urgent", "monthly"]	\N	51c831a7-42a0-4a9e-8e8a-69e873269a4f	f	\N	\N	2025-10-19 18:00:34.85067	2025-10-19 18:00:34.85067
04600664-34f3-4ae0-9a01-2da04b5bc5fc	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Payroll - Anderson - Kohler	Saepe cimentarius vigilo voluntarius conforto sollicito audentia subiungo consuasor texo. Commemoro sono sum venia debilito. Animi anser arceo coniuratio blanditiis ventus vinco taedium.	cancelled	urgent	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	c4f75303-a973-43e1-8f69-dfc6500c302c	\N	c4f75303-a973-43e1-8f69-dfc6500c302c	2025-10-02 14:55:16.785	2025-10-05 07:59:09.811	\N	5.00	\N	43	VAT Return	Development	["urgent", "monthly"]	\N	6624a9f6-9886-4b3d-a8fc-0bcc0ecfd112	f	\N	\N	2025-10-19 18:00:34.863081	2025-10-19 18:00:34.863081
6c88f260-519e-41e9-9fac-18a28b9a7901	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	VAT Return - Boyer - Dibbert	Laborum voveo verbum maiores solum crapula toties defluo cultura virga. Sonitus alo est. Derideo aurum aer subnecto umbra arguo sunt porro coniecto bis.	pending	high	6ecda653-6094-4502-9d1d-6e90d9ea99ed	d6f36046-e274-4776-a3d7-58eadb9d96b0	\N	0409f8de-7e1d-4245-96c2-02a3b1c90a81	2025-11-06 13:02:30.072	2025-11-08 14:52:21.45	\N	19.00	\N	49	VAT Return	Client Work	["client-request"]	\N	6624a9f6-9886-4b3d-a8fc-0bcc0ecfd112	f	\N	\N	2025-10-19 18:00:34.869755	2025-10-19 18:00:34.869755
088446c4-4542-4007-9887-b512bd3db05d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Tax Return - Pacocha - Ziemann	Ab caterva cupiditas somnus cena caecus. Tribuo video surgo temeritas ab abundans rerum volo. Tactus vicinus delicate causa decerno appositus ademptio accedo.	pending	low	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	0409f8de-7e1d-4245-96c2-02a3b1c90a81	\N	d6f36046-e274-4776-a3d7-58eadb9d96b0	2025-11-16 04:51:10.154	2025-11-17 12:49:51.262	\N	18.00	\N	15	Payroll	Client Work	["annual", "client-request", "urgent"]	\N	f08a8f24-3be0-4086-bd5c-a4eb1cf19811	f	\N	\N	2025-10-19 18:00:34.875883	2025-10-19 18:00:34.875883
449f8e23-33a0-4bf0-915e-cc79d13bc3a9	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Tax Return - Ruecker - Jerde	Subnecto denuncio ocer velut viriliter vos totus sulum angustus terra. Qui aut amissio reprehenderit tersus acceptus capio adhuc vulnus cruciamentum. Deprimo aveho vito verto cornu perspiciatis incidunt tamquam aufero sui.	completed	urgent	45b3d726-e151-4770-9b64-4653914bdaa5	d6f36046-e274-4776-a3d7-58eadb9d96b0	\N	0409f8de-7e1d-4245-96c2-02a3b1c90a81	2025-10-19 13:32:00.623	2025-10-19 18:32:16.452	2025-10-16 04:29:34.779	9.00	1.00	100	Document Review	Admin	["annual", "client-request", "quarterly"]	\N	c9013c22-350c-46aa-b8c4-8a71da338337	f	\N	\N	2025-10-19 18:00:34.884317	2025-10-19 18:00:34.884317
b98cb032-3f5a-46db-ab39-de7d53570ae9	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Bookkeeping - Evelyn Lubowitz	Uredo calco suscipio amplexus tricesimus considero. Trucido aureus speculum cohibeo. Sto coerceo sordeo tamen.	pending	low	65a6152e-a261-4a70-99fb-82f044e87d05	c4f75303-a973-43e1-8f69-dfc6500c302c	d6f36046-e274-4776-a3d7-58eadb9d96b0	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-17 08:47:10.874	2025-10-19 12:00:57.51	\N	6.00	\N	49	Tax Return	Support	[]	\N	965823ac-8815-43cb-b52d-be3d11bee333	f	\N	\N	2025-10-19 18:00:34.888512	2025-10-19 18:00:34.888512
e60c944c-85a6-45da-b007-56b5244e0257	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Tax Return - Faye Gleichner	Viduo defleo caritas comminor statua video voluptas. Defungo credo iusto administratio infit vester adduco. Ara adipiscor carmen adulatio.	in_progress	medium	0d0329f4-4b80-4899-8807-5854e9db312b	c4f75303-a973-43e1-8f69-dfc6500c302c	d6f36046-e274-4776-a3d7-58eadb9d96b0	d6f36046-e274-4776-a3d7-58eadb9d96b0	2025-11-18 00:45:05.734	2025-11-19 02:42:53.905	\N	4.00	\N	15	Annual Accounts	Admin	["quarterly", "monthly"]	\N	acbad2fb-595b-462b-82fc-f2f04f43fc67	f	\N	\N	2025-10-19 18:00:34.896652	2025-10-19 18:00:34.896652
d8601cb6-589f-456f-a2b2-1b986973a4bc	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Client Meeting - Anderson - Kohler	Comis adsum arma stultus autus tenuis. Ultio suspendo thymbra crapula. Aestivus trado vigilo tergiversatio.	pending	high	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	c4f75303-a973-43e1-8f69-dfc6500c302c	\N	d6f36046-e274-4776-a3d7-58eadb9d96b0	2025-09-20 01:41:56.715	2025-09-21 02:47:17.165	\N	9.00	\N	10	Bookkeeping	Support	["annual"]	\N	51c831a7-42a0-4a9e-8e8a-69e873269a4f	f	\N	\N	2025-10-19 18:00:34.900641	2025-10-19 18:00:34.900641
2c1d5d5c-be1c-427c-b2ac-da3cc28b1680	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Payroll - Ruecker - Jerde	Vilicus viridis creator nesciunt comes textilis. Pax conforto debeo conventus. Vomito adsuesco aequus demo harum quis repellendus.	in_progress	high	45b3d726-e151-4770-9b64-4653914bdaa5	a2adaa31-8f59-409a-b39b-72568022adb4	\N	d6f36046-e274-4776-a3d7-58eadb9d96b0	2025-10-04 13:37:12.309	2025-10-05 04:40:52.293	\N	7.00	\N	73	Payroll	Development	[]	\N	f08a8f24-3be0-4086-bd5c-a4eb1cf19811	f	\N	\N	2025-10-19 18:00:34.904332	2025-10-19 18:00:34.904332
eb1af1df-ce0a-4763-aaef-49b6b390beab	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Annual Accounts - Grimes, Predovic and Goodwin	Tener crepusculum venia convoco somnus toties vestigium. Tametsi adiuvo comprehendo decumbo vacuus catena accusator vulpes. Absens conculco valetudo video aurum terga.	completed	low	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	c4f75303-a973-43e1-8f69-dfc6500c302c	\N	c4f75303-a973-43e1-8f69-dfc6500c302c	2025-11-03 08:56:07.606	2025-11-04 01:16:26.069	2025-10-18 15:22:19.879	4.00	9.00	100	VAT Return	Support	[]	\N	6624a9f6-9886-4b3d-a8fc-0bcc0ecfd112	f	\N	\N	2025-10-19 18:00:34.90961	2025-10-19 18:00:34.90961
062f6587-cb37-4a01-aa03-004703abe1e2	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Bookkeeping - Ernser and Sons	Tres cernuus demens cuppedia vero cursus laudantium adicio demonstro aureus. Suscipio confero adipisci reprehenderit accendo curatio cruentus. Attero baiulus deleniti vilis torqueo usitas stillicidium deludo.	pending	low	6a032ece-4f9e-405a-b48a-b28516d15fe1	a2adaa31-8f59-409a-b39b-72568022adb4	\N	0409f8de-7e1d-4245-96c2-02a3b1c90a81	2025-12-03 20:29:59.135	2025-12-06 08:28:09.449	\N	13.00	\N	74	Client Meeting	Support	["quarterly", "urgent", "client-request"]	\N	6784d58d-be43-45ac-88e5-3232d67c5172	f	\N	\N	2025-10-19 18:00:34.916523	2025-10-19 18:00:34.916523
5e2204cd-be52-42a7-aa41-14fcf0e4a272	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Document Review - Champlin, Trantow and Dare	Decet caecus venio repellat advenio est super crur adamo ipsam. Arto inventore adstringo curtus ultio patruus vigor aptus. Solum suscipio contigo.	pending	high	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	a2adaa31-8f59-409a-b39b-72568022adb4	0409f8de-7e1d-4245-96c2-02a3b1c90a81	a2adaa31-8f59-409a-b39b-72568022adb4	2025-11-18 21:04:25.929	2025-11-20 21:26:54.317	\N	4.00	\N	75	VAT Return	Support	[]	\N	6624a9f6-9886-4b3d-a8fc-0bcc0ecfd112	f	\N	\N	2025-10-19 18:00:34.92177	2025-10-19 18:00:34.92177
a18510b4-73e3-40ff-84b1-89c4a2e0bdac	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Client Meeting - Jerde LLC	Tenetur absens administratio spoliatio tersus comburo vito caterva. Conduco vigilo alo voluptates texo neque. Neque territo comptus una universe solio vicinus molestias campana.	pending	low	17f141c2-e297-4c93-9178-0fd819259c50	c4f75303-a973-43e1-8f69-dfc6500c302c	d6f36046-e274-4776-a3d7-58eadb9d96b0	0409f8de-7e1d-4245-96c2-02a3b1c90a81	2025-12-04 12:19:28.106	2025-12-06 18:35:47.964	\N	17.00	\N	19	VAT Return	Development	["annual", "quarterly"]	\N	6624a9f6-9886-4b3d-a8fc-0bcc0ecfd112	f	\N	\N	2025-10-19 18:00:34.926632	2025-10-19 18:00:34.926632
fe24fe87-1db5-4f06-9a5c-46757a20518d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Bookkeeping - Skiles - Bernier	Uredo coniecto usque cubo agnosco theatrum. Amoveo desidero vomica. Confero et templum varius vesper defendo.	cancelled	urgent	d69d0436-37d7-42a4-b907-3d9c3a091ea6	c4f75303-a973-43e1-8f69-dfc6500c302c	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-12-17 02:22:30.89	2025-12-18 10:16:04.647	\N	9.00	\N	70	Client Meeting	Development	["monthly"]	\N	6784d58d-be43-45ac-88e5-3232d67c5172	f	\N	\N	2025-10-19 18:00:34.93071	2025-10-19 18:00:34.93071
c8eb351f-daa9-48cf-bc62-2cef6338a122	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Document Review - Anderson - Kohler	Appositus fuga officiis aduro teneo cohibeo laudantium calcar currus. Voluptatem amiculum ab ulciscor sollers debeo dolorum culpo porro aeger. Vesper peccatus cupiditate sumo usque apud viridis bellum.	pending	low	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	a2adaa31-8f59-409a-b39b-72568022adb4	a2adaa31-8f59-409a-b39b-72568022adb4	c4f75303-a973-43e1-8f69-dfc6500c302c	2025-11-11 13:27:54.306	2025-11-13 23:39:25.565	\N	10.00	\N	9	Annual Accounts	Support	[]	\N	acbad2fb-595b-462b-82fc-f2f04f43fc67	f	\N	\N	2025-10-19 18:00:34.936897	2025-10-19 18:00:34.936897
7041a9f2-cd04-4f9c-ab2c-96bfdd45e5ff	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Compliance Check - Strosin - Runte	Maiores eligendi balbus commodi nisi collum totam cultellus. Autus triduana pauci desolo nemo tricesimus argentum expedita. Basium aequitas toties virtus suscipit aduro perspiciatis argumentum.	pending	urgent	a4464f5a-2125-46d9-9f58-7252c9adc16b	0409f8de-7e1d-4245-96c2-02a3b1c90a81	a2adaa31-8f59-409a-b39b-72568022adb4	0409f8de-7e1d-4245-96c2-02a3b1c90a81	2025-09-21 06:15:01.852	2025-09-23 20:29:15.678	\N	18.00	\N	23	Bookkeeping	Client Work	["monthly", "annual"]	\N	51c831a7-42a0-4a9e-8e8a-69e873269a4f	f	\N	\N	2025-10-19 18:00:34.939834	2025-10-19 18:00:34.939834
07b65174-c767-4ace-ac22-e486eb422fa6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Client Meeting - Anderson - Kohler	Vulgo vobis vergo adeo nobis utor creptio viridis pauci una. Verus crux vehemens. Vorax praesentium venustas adnuo.	completed	urgent	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	0409f8de-7e1d-4245-96c2-02a3b1c90a81	\N	d6f36046-e274-4776-a3d7-58eadb9d96b0	2025-10-30 18:35:25.657	2025-11-01 04:22:12.31	2025-10-19 06:11:53.608	19.00	5.00	100	Compliance Check	Development	["urgent"]	\N	4a29c5cf-69ba-4639-b91a-08f3851b5397	f	\N	\N	2025-10-19 18:00:34.942357	2025-10-19 18:00:34.942357
9485b00c-4fc8-454f-984a-6908039db9f9	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Tax Return - Hand - Stamm	Communis verecundia statim error laboriosam cariosus inflammatio valde auctus optio. Adsuesco solum bellum vestrum. Sustineo desolo voluptas ipsa desidero facere appono sui templum.	cancelled	low	405d4d05-841b-437d-af7d-70b66dda4cbc	d6f36046-e274-4776-a3d7-58eadb9d96b0	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-12-08 09:51:45.765	2025-12-10 01:14:49.509	\N	12.00	\N	79	Tax Return	Support	[]	\N	965823ac-8815-43cb-b52d-be3d11bee333	f	\N	\N	2025-10-19 18:00:34.944584	2025-10-19 18:00:34.944584
66d28217-b458-4ec3-9e88-eb34570556b7	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Payroll - Terry, Carter and Kshlerin	Arto corrumpo amissio thesaurus peior. Demo vigor adipisci ut. Thesis cultellus corona tremo arceo supra tergum comburo tardus atque.	in_progress	high	702b5a48-f7a9-464c-8833-1ff6577e50e6	d6f36046-e274-4776-a3d7-58eadb9d96b0	\N	d6f36046-e274-4776-a3d7-58eadb9d96b0	2025-10-30 09:48:56.425	2025-10-30 13:21:45.514	\N	9.00	\N	71	Compliance Check	Development	["quarterly"]	\N	4a29c5cf-69ba-4639-b91a-08f3851b5397	f	\N	\N	2025-10-19 18:00:34.946891	2025-10-19 18:00:34.946891
9ec151a2-b6a4-433d-a21e-c94af23b785b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Payroll - Stiedemann, Reichel and Brown	Ventito cattus labore statim infit vir tutis spoliatio velut. Aliqua adfero tametsi cetera omnis toties altus tabula. Aegrotatio talus amita.	pending	low	67f62599-7f9f-44e8-bc18-d2ce08ea9919	a2adaa31-8f59-409a-b39b-72568022adb4	\N	0409f8de-7e1d-4245-96c2-02a3b1c90a81	2025-10-06 12:08:45.199	2025-10-09 10:03:03.472	\N	17.00	\N	67	Compliance Check	Development	["annual", "quarterly"]	\N	4a29c5cf-69ba-4639-b91a-08f3851b5397	f	\N	\N	2025-10-19 18:00:34.949088	2025-10-19 18:00:34.949088
8c94ef1c-f972-45ba-9aaa-1fa78ab3fc92	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Client Meeting - Silvia Will	Conservo saepe eligendi ustilo enim possimus virgo alioqui. Denego aiunt aveho cupiditate speculum ait arbustum. Thema vinitor vulgaris eum.	pending	medium	b0a95e11-90ac-4ab3-b099-c4de69f498b8	a2adaa31-8f59-409a-b39b-72568022adb4	\N	d6f36046-e274-4776-a3d7-58eadb9d96b0	2025-12-16 00:56:18.097	2025-12-16 23:31:50.797	\N	3.00	\N	40	Payroll	Admin	[]	\N	f08a8f24-3be0-4086-bd5c-a4eb1cf19811	f	\N	\N	2025-10-19 18:00:34.955395	2025-10-19 18:00:34.955395
1916b6af-0ab6-45d8-85ca-a9a6b331363c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Document Review - Ernser and Sons	Agnitio vestrum thesis audeo paulatim decumbo asper reprehenderit beatus curriculum. Voluptates adimpleo tepidus atrocitas candidus astrum tepesco. Adimpleo valens civitas.	in_progress	urgent	6a032ece-4f9e-405a-b48a-b28516d15fe1	0409f8de-7e1d-4245-96c2-02a3b1c90a81	0409f8de-7e1d-4245-96c2-02a3b1c90a81	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-24 14:16:30.139	2025-10-27 07:07:33.733	\N	20.00	\N	7	Bookkeeping	Support	["monthly", "quarterly"]	\N	51c831a7-42a0-4a9e-8e8a-69e873269a4f	f	\N	\N	2025-10-19 18:00:34.962215	2025-10-19 18:00:34.962215
e64d20a6-86e7-4dd1-ab40-aabaedbd6ebb	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	VAT Return - Latoya Crooks	Vel officiis adulatio valde astrum aliquid territo aegrus summa cattus. Catena sapiente crur demergo solio canto consectetur. Cognomen claro capitulus ver inventore.	pending	medium	584bab37-ccf2-484c-9a7f-7394e4b30ec6	0409f8de-7e1d-4245-96c2-02a3b1c90a81	\N	0409f8de-7e1d-4245-96c2-02a3b1c90a81	2025-10-07 04:02:27.329	2025-10-09 16:53:41.157	\N	12.00	\N	78	Annual Accounts	Admin	["quarterly", "urgent"]	\N	acbad2fb-595b-462b-82fc-f2f04f43fc67	f	\N	\N	2025-10-19 18:00:34.968397	2025-10-19 18:00:34.968397
ddc09723-5f7f-4f23-a202-0b6243ef63f9	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Compliance Check - Latoya Crooks	Tempus possimus aranea arca. Adaugeo temptatio strues delicate nihil. Vapulus tero creator ea.	completed	low	584bab37-ccf2-484c-9a7f-7394e4b30ec6	c4f75303-a973-43e1-8f69-dfc6500c302c	a2adaa31-8f59-409a-b39b-72568022adb4	d6f36046-e274-4776-a3d7-58eadb9d96b0	2025-10-05 21:28:11.448	2025-10-07 04:58:14.665	2025-10-14 03:17:49.564	2.00	24.00	100	Client Meeting	Development	["client-request"]	\N	6784d58d-be43-45ac-88e5-3232d67c5172	f	\N	\N	2025-10-19 18:00:34.974193	2025-10-19 18:00:34.974193
419cb8f8-8b70-44a5-883b-8fa92787aa46	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Bookkeeping - Stiedemann, Reichel and Brown	Denique uterque vitiosus nesciunt placeat pauci atque comis. Amplitudo ver agnitio crur aufero vilis speculum adulatio. Adfectus turbo summa suspendo defleo.	completed	medium	67f62599-7f9f-44e8-bc18-d2ce08ea9919	d6f36046-e274-4776-a3d7-58eadb9d96b0	\N	d6f36046-e274-4776-a3d7-58eadb9d96b0	2025-10-23 21:36:31.695	2025-10-26 14:45:02.585	2025-10-13 18:17:40.276	10.00	10.00	100	Compliance Check	Client Work	["urgent", "client-request", "monthly"]	\N	4a29c5cf-69ba-4639-b91a-08f3851b5397	f	\N	\N	2025-10-19 18:00:34.979395	2025-10-19 18:00:34.979395
2db210d6-c799-49db-b61d-9aff5f87f1f0	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Bookkeeping - Constance Mante	Cupressus valeo cado corrigo incidunt summisse valde. Compono conor titulus stella tam bonus. Velum arbitro somniculosus pauci.	in_progress	low	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	d6f36046-e274-4776-a3d7-58eadb9d96b0	\N	0409f8de-7e1d-4245-96c2-02a3b1c90a81	2025-11-01 01:07:04.362	2025-11-03 16:59:55.327	\N	18.00	\N	25	Bookkeeping	Admin	["monthly"]	\N	51c831a7-42a0-4a9e-8e8a-69e873269a4f	f	\N	\N	2025-10-19 18:00:34.982998	2025-10-19 18:00:34.982998
6b008063-17c8-4c31-893b-ef9f17e74f13	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Bookkeeping - Anderson - Kohler	Adamo cetera audeo coniecto. Aliqua synagoga in. Vulnus desidero vito derideo tabernus amiculum tergeo.	in_progress	medium	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	c4f75303-a973-43e1-8f69-dfc6500c302c	a2adaa31-8f59-409a-b39b-72568022adb4	0409f8de-7e1d-4245-96c2-02a3b1c90a81	2025-11-27 00:41:54.369	2025-11-29 15:49:38.548	\N	1.00	\N	72	Annual Accounts	Admin	["annual"]	\N	acbad2fb-595b-462b-82fc-f2f04f43fc67	f	\N	\N	2025-10-19 18:00:34.98689	2025-10-19 18:00:34.98689
b7a77905-edd5-451e-a92e-06976feeb638	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Compliance Check - Evelyn Lubowitz	Quaerat compono ambulo acer spectaculum cohaero desolo depopulo. Quasi degero patria comes fugit vivo iure tersus. Amitto coadunatio cruentus.	pending	medium	65a6152e-a261-4a70-99fb-82f044e87d05	d6f36046-e274-4776-a3d7-58eadb9d96b0	\N	d6f36046-e274-4776-a3d7-58eadb9d96b0	2025-09-21 01:24:27.613	2025-09-21 19:28:20.884	\N	6.00	\N	52	Bookkeeping	Admin	["urgent"]	\N	51c831a7-42a0-4a9e-8e8a-69e873269a4f	f	\N	\N	2025-10-19 18:00:34.990228	2025-10-19 18:00:34.990228
9068b493-e301-4f68-9bcd-ad7c1f9cbe03	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Compliance Check - Strosin - Runte	Fuga summisse coniuratio. Venustas est molestias demum auxilium causa. Atqui magnam vitium absens conduco tripudio decet tracto audacia.	cancelled	urgent	a4464f5a-2125-46d9-9f58-7252c9adc16b	c4f75303-a973-43e1-8f69-dfc6500c302c	d6f36046-e274-4776-a3d7-58eadb9d96b0	0409f8de-7e1d-4245-96c2-02a3b1c90a81	2025-10-02 08:40:35.26	2025-10-03 15:07:58.539	\N	3.00	\N	55	Document Review	Support	["client-request", "urgent"]	\N	c9013c22-350c-46aa-b8c4-8a71da338337	f	\N	\N	2025-10-19 18:00:34.993182	2025-10-19 18:00:34.993182
f37ad203-1495-4aec-be30-1b2d7fe4dd70	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Compliance Check - Schamberger LLC	Bestia corroboro sol talio cultura. Tabella audacia inventore cognomen spiculum deprimo. Vinco conicio clibanus rerum.	cancelled	medium	12edb785-268b-4219-840d-15b8f0df1198	a2adaa31-8f59-409a-b39b-72568022adb4	\N	d6f36046-e274-4776-a3d7-58eadb9d96b0	2025-10-30 09:57:35.262	2025-10-30 17:11:30.915	\N	19.00	\N	1	VAT Return	Support	["client-request", "annual"]	\N	6624a9f6-9886-4b3d-a8fc-0bcc0ecfd112	f	\N	\N	2025-10-19 18:00:34.99617	2025-10-19 18:00:34.99617
be3f2d80-2e55-4bec-bd5e-02e5a00444a9	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Annual Accounts - Ruecker - Jerde	Vulgus tabgo tunc acidus adopto cilicium. Viridis stillicidium tantum calcar aliquid tabgo sustineo praesentium. Cervus adstringo cultura.	completed	high	45b3d726-e151-4770-9b64-4653914bdaa5	c4f75303-a973-43e1-8f69-dfc6500c302c	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-27 06:47:38.375	2025-10-29 17:03:10.001	2025-10-14 10:35:00.135	8.00	13.00	100	Client Meeting	Admin	[]	\N	6784d58d-be43-45ac-88e5-3232d67c5172	f	\N	\N	2025-10-19 18:00:34.999069	2025-10-19 18:00:34.999069
20222077-caa4-4444-b803-1f75d617ee85	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Annual Accounts - Skiles - Bernier	Tubineus demoror virga ipsum vindico tutis consuasor nulla. Causa tum coniuratio absorbeo vorago venio arcesso itaque. Contigo acquiro vesica vindico aequus capitulus.	in_progress	medium	d69d0436-37d7-42a4-b907-3d9c3a091ea6	0409f8de-7e1d-4245-96c2-02a3b1c90a81	a2adaa31-8f59-409a-b39b-72568022adb4	a2adaa31-8f59-409a-b39b-72568022adb4	2025-11-30 19:55:44.265	2025-12-03 09:10:24.985	\N	18.00	\N	75	Compliance Check	Development	[]	\N	4a29c5cf-69ba-4639-b91a-08f3851b5397	f	\N	\N	2025-10-19 18:00:35.004479	2025-10-19 18:00:35.004479
4f8e956e-3c05-4a0d-8695-2014ee9b2f8a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Tax Return - Hand - Stamm	Defungo conqueror spiculum utique voluptas saepe sequi depopulo thesaurus tribuo. Theologus repudiandae timor blanditiis defaeco vehemens verto. Calco at aut.	completed	low	405d4d05-841b-437d-af7d-70b66dda4cbc	a2adaa31-8f59-409a-b39b-72568022adb4	\N	c4f75303-a973-43e1-8f69-dfc6500c302c	2025-10-04 00:16:49.829	2025-10-06 12:44:16.504	2025-10-13 15:39:13.422	4.00	12.00	100	VAT Return	Client Work	["monthly"]	\N	6624a9f6-9886-4b3d-a8fc-0bcc0ecfd112	f	\N	\N	2025-10-19 18:00:35.010881	2025-10-19 18:00:35.010881
ff7b1e48-6594-4997-9b76-46ab909220e2	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Annual Accounts - Latoya Crooks	Deduco acidus tabula tristis chirographum. Carus cognatus apostolus caritas stips vero delibero cruciamentum. Paens adopto conscendo caritas universe thesaurus.	pending	urgent	584bab37-ccf2-484c-9a7f-7394e4b30ec6	d6f36046-e274-4776-a3d7-58eadb9d96b0	0409f8de-7e1d-4245-96c2-02a3b1c90a81	c4f75303-a973-43e1-8f69-dfc6500c302c	2025-10-23 11:27:24.308	2025-10-23 12:39:28.563	\N	14.00	\N	1	Document Review	Admin	[]	\N	c9013c22-350c-46aa-b8c4-8a71da338337	f	\N	\N	2025-10-19 18:00:35.015231	2025-10-19 18:00:35.015231
5515e216-ea3c-436b-95a5-6abf213c47ef	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Payroll - Grimes, Predovic and Goodwin	Thorax umquam est. Deporto volva tardus. Cum tyrannus thesaurus valetudo auctor acceptus convoco videlicet vulnero.	completed	high	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	c4f75303-a973-43e1-8f69-dfc6500c302c	a2adaa31-8f59-409a-b39b-72568022adb4	c4f75303-a973-43e1-8f69-dfc6500c302c	2025-10-17 13:42:55.753	2025-10-19 06:30:40.716	2025-10-13 09:07:26.144	20.00	18.00	100	Bookkeeping	Support	["monthly"]	\N	51c831a7-42a0-4a9e-8e8a-69e873269a4f	f	\N	\N	2025-10-19 18:00:35.019224	2025-10-19 18:00:35.019224
269dca40-b352-4a09-9d7c-c735016a8c7d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Compliance Check - Silvia Will	Civis acceptus supplanto cultellus volubilis talus appono placeat dens. Ter pectus cerno vulnero architecto bardus pel ipsum. Ater optio viriliter clementia velum.	completed	urgent	b0a95e11-90ac-4ab3-b099-c4de69f498b8	c4f75303-a973-43e1-8f69-dfc6500c302c	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-12-12 12:21:04.427	2025-12-14 11:21:50.494	2025-10-19 05:54:28.345	7.00	24.00	100	VAT Return	Development	["urgent"]	\N	6624a9f6-9886-4b3d-a8fc-0bcc0ecfd112	f	\N	\N	2025-10-19 18:00:35.027647	2025-10-19 18:00:35.027647
4d9083ba-923c-467a-8bdb-8b651cd6d7d7	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Compliance Check - Ernser and Sons	Coadunatio acidus decet vicinus sit. Terra traho ciminatio. Aspernatur cubo curso vel.	in_progress	urgent	6a032ece-4f9e-405a-b48a-b28516d15fe1	a2adaa31-8f59-409a-b39b-72568022adb4	\N	0409f8de-7e1d-4245-96c2-02a3b1c90a81	2025-11-02 05:02:56.608	2025-11-03 19:22:03.027	\N	5.00	\N	78	Tax Return	Client Work	["urgent"]	\N	965823ac-8815-43cb-b52d-be3d11bee333	f	\N	\N	2025-10-19 18:00:35.031714	2025-10-19 18:00:35.031714
b3d1095b-3d51-444b-be35-f485afdb174f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Bookkeeping - Gilberto Mante	Admoveo concido utroque terebro. Sunt adfectus tabula creo cauda viduo tempore. Crinis via xiphias ea coma.	in_progress	low	8538cc30-f9e7-4b63-a885-56b23e16ecef	c4f75303-a973-43e1-8f69-dfc6500c302c	d6f36046-e274-4776-a3d7-58eadb9d96b0	a2adaa31-8f59-409a-b39b-72568022adb4	2025-12-03 19:50:40.303	2025-12-04 03:53:37.39	\N	3.00	\N	41	Annual Accounts	Development	["quarterly"]	\N	acbad2fb-595b-462b-82fc-f2f04f43fc67	f	\N	\N	2025-10-19 18:00:35.035526	2025-10-19 18:00:35.035526
6ebdfde2-aeab-4596-9744-cef10c12a313	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Document Review - Terry, Carter and Kshlerin	Curtus curatio cogo temeritas id ullus. Cui ceno barba. Aestivus quo demulceo celo comptus spero valens.	cancelled	high	702b5a48-f7a9-464c-8833-1ff6577e50e6	0409f8de-7e1d-4245-96c2-02a3b1c90a81	\N	0409f8de-7e1d-4245-96c2-02a3b1c90a81	2025-10-18 02:40:39.808	2025-10-20 16:55:29.554	\N	6.00	\N	71	Client Meeting	Support	[]	\N	6784d58d-be43-45ac-88e5-3232d67c5172	f	\N	\N	2025-10-19 18:00:35.038701	2025-10-19 18:00:35.038701
b09b8a10-2b29-4fa3-b57f-c69d46364489	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	VAT Return - Strosin - Runte	Solus quia allatus tenuis animi cinis deprimo subseco. Decimus admiratio adipisci stillicidium tubineus vulariter cimentarius creator temperantia eum. Labore curso verecundia demens tergiversatio terreo.	completed	high	a4464f5a-2125-46d9-9f58-7252c9adc16b	0409f8de-7e1d-4245-96c2-02a3b1c90a81	\N	c4f75303-a973-43e1-8f69-dfc6500c302c	2025-10-23 15:45:07.541	2025-10-25 07:02:09.815	2025-10-14 11:12:44.513	18.00	5.00	100	Tax Return	Client Work	["client-request", "quarterly"]	\N	965823ac-8815-43cb-b52d-be3d11bee333	f	\N	\N	2025-10-19 18:00:35.042979	2025-10-19 18:00:35.042979
5cf17315-4658-4a7f-9c23-b4f8268d8f84	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Tax Return - Jeremy Larson	Adstringo stultus vesper sapiente aeternus. Optio synagoga repudiandae accusantium caveo temporibus qui ait. Iusto thymbra tremo ara.	completed	medium	7ef8af5a-1080-42a2-988f-ddfa799c8070	c4f75303-a973-43e1-8f69-dfc6500c302c	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-11-06 04:44:14.537	2025-11-07 01:55:50.502	2025-10-13 18:23:56.078	9.00	6.00	100	Payroll	Client Work	["annual", "monthly"]	\N	f08a8f24-3be0-4086-bd5c-a4eb1cf19811	f	\N	\N	2025-10-19 18:00:35.047907	2025-10-19 18:00:35.047907
49ae64ac-de52-4d18-a5d6-d73c5d5605c5	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Tax Return - Strosin - Runte	Libero theologus aliqua celer stultus. Vinculum combibo labore claustrum. Cursus adduco vindico utrum.	completed	high	a4464f5a-2125-46d9-9f58-7252c9adc16b	c4f75303-a973-43e1-8f69-dfc6500c302c	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-13 23:59:14.063	2025-10-14 04:07:31.342	2025-10-16 02:52:21.768	13.00	5.00	100	Bookkeeping	Client Work	["monthly", "quarterly"]	\N	51c831a7-42a0-4a9e-8e8a-69e873269a4f	f	\N	\N	2025-10-19 18:00:35.050585	2025-10-19 18:00:35.050585
c7111387-5606-4d4b-88de-270766225b61	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Annual Accounts - Jerde LLC	Urbs dignissimos aetas versus caelestis vinculum totam vilis abduco. Tego spes occaecati vilis vesica provident. Ancilla vesco confugo cultura vitiosus.	completed	medium	17f141c2-e297-4c93-9178-0fd819259c50	d6f36046-e274-4776-a3d7-58eadb9d96b0	d6f36046-e274-4776-a3d7-58eadb9d96b0	c4f75303-a973-43e1-8f69-dfc6500c302c	2025-10-19 04:40:16.13	2025-10-19 23:09:23.643	2025-10-14 16:34:46.846	6.00	12.00	100	Client Meeting	Client Work	[]	\N	6784d58d-be43-45ac-88e5-3232d67c5172	f	\N	\N	2025-10-19 18:00:35.053574	2025-10-19 18:00:35.053574
598a25cc-7c96-4dd9-af0e-1e27762bf53a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Document Review - Latoya Crooks	Solio thesis paulatim ulterius itaque confero verto solutio. Calco corpus dapifer cervus admitto assumenda crustulum consequuntur tertius. Crustulum umerus aveho tracto pecco altus.	completed	high	584bab37-ccf2-484c-9a7f-7394e4b30ec6	a2adaa31-8f59-409a-b39b-72568022adb4	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-12-12 22:36:19.993	2025-12-12 23:02:33.303	2025-10-18 12:27:09.368	7.00	14.00	100	Compliance Check	Client Work	["urgent", "annual"]	\N	4a29c5cf-69ba-4639-b91a-08f3851b5397	f	\N	\N	2025-10-19 18:00:35.056405	2025-10-19 18:00:35.056405
dc9252b7-2022-4822-a8b2-7ec227fe0ea4	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Document Review - Grimes, Predovic and Goodwin	Alveus adinventitias cur corona xiphias cogito usus aer ara facere. Decipio admoneo validus. Adduco autem vesco complectus aequus deficio sordeo creber tredecim.	cancelled	high	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	a2adaa31-8f59-409a-b39b-72568022adb4	a2adaa31-8f59-409a-b39b-72568022adb4	d6f36046-e274-4776-a3d7-58eadb9d96b0	2025-11-03 07:11:27.872	2025-11-03 10:26:55.487	\N	4.00	\N	33	Document Review	Support	["monthly", "quarterly", "client-request"]	\N	c9013c22-350c-46aa-b8c4-8a71da338337	f	\N	\N	2025-10-19 18:00:35.059289	2025-10-19 18:00:35.059289
d486be12-5ed8-48b4-af34-79d9269f4c0b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Annual Accounts - Noah Walsh V	Trepide aut pectus unus. Exercitationem deprimo vivo magnam tempora cito pariatur velut. Tyrannus voco debitis maiores thorax adeo vesco accommodo venio totam.	in_progress	medium	46859340-c8cf-4144-aa6c-28fbaf53fa0e	c4f75303-a973-43e1-8f69-dfc6500c302c	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-14 06:04:39.285	2025-10-15 14:30:34.855	\N	16.00	\N	36	Bookkeeping	Client Work	["urgent", "annual", "client-request"]	\N	51c831a7-42a0-4a9e-8e8a-69e873269a4f	f	\N	\N	2025-10-19 18:00:35.062271	2025-10-19 18:00:35.062271
4fb9cb0a-ca36-4af7-9203-ac1970ce555b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Annual Accounts - Boyer - Dibbert	Cenaculum vinum reprehenderit aperte iure commodo subnecto talio sapiente. Aeger quisquam tonsor vix talis vitium derelinquo laboriosam unus. Thema abeo quisquam custodia curatio.	cancelled	urgent	6ecda653-6094-4502-9d1d-6e90d9ea99ed	0409f8de-7e1d-4245-96c2-02a3b1c90a81	0409f8de-7e1d-4245-96c2-02a3b1c90a81	a2adaa31-8f59-409a-b39b-72568022adb4	2025-11-28 15:04:47.403	2025-11-29 11:23:51.21	\N	14.00	\N	10	VAT Return	Admin	[]	\N	6624a9f6-9886-4b3d-a8fc-0bcc0ecfd112	f	\N	\N	2025-10-19 18:00:35.06471	2025-10-19 18:00:35.06471
219aa257-710f-4ef2-892d-39086a9690ed	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	VAT Return - Hand - Stamm	Conturbo umerus conculco surgo cuppedia earum demergo velit. Vetus caste repudiandae. Volutabrum caries color currus turba conicio censura urbanus.	completed	urgent	405d4d05-841b-437d-af7d-70b66dda4cbc	a2adaa31-8f59-409a-b39b-72568022adb4	\N	c4f75303-a973-43e1-8f69-dfc6500c302c	2025-10-20 01:02:01.486	2025-10-21 00:27:51.031	2025-10-14 01:53:13.492	5.00	12.00	100	Compliance Check	Client Work	["client-request"]	\N	4a29c5cf-69ba-4639-b91a-08f3851b5397	f	\N	\N	2025-10-19 18:00:35.067217	2025-10-19 18:00:35.067217
e4ce7abb-fb0c-42e1-a7c1-6419b4aa63ef	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Compliance Check - Legros - Turcotte	Adopto demum officiis urbs via peccatus adipiscor atqui. Agnitio depono defessus victoria solutio totidem speculum sordeo acsi alveus. Cedo circumvenio auditor studio audeo conventus.	in_progress	high	04465623-29cb-4298-8828-d1839e9cc00d	0409f8de-7e1d-4245-96c2-02a3b1c90a81	d6f36046-e274-4776-a3d7-58eadb9d96b0	c4f75303-a973-43e1-8f69-dfc6500c302c	2025-11-16 22:19:08.576	2025-11-18 01:39:46.638	\N	13.00	\N	59	Bookkeeping	Support	[]	\N	51c831a7-42a0-4a9e-8e8a-69e873269a4f	f	\N	\N	2025-10-19 18:00:35.072197	2025-10-19 18:00:35.072197
a08b1624-6e7a-4a25-8f08-3b9b00adb6a0	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Annual Accounts - Strosin - Runte	Curriculum ustilo usque aperiam conicio eaque infit velut. Trans aranea brevis utor ager ars vulnero. Curriculum adduco apud deprecator conor stipes.	cancelled	urgent	a4464f5a-2125-46d9-9f58-7252c9adc16b	a2adaa31-8f59-409a-b39b-72568022adb4	d6f36046-e274-4776-a3d7-58eadb9d96b0	c4f75303-a973-43e1-8f69-dfc6500c302c	2025-10-27 00:43:04.685	2025-10-29 14:36:35.062	\N	17.00	\N	58	Client Meeting	Admin	["client-request"]	\N	6784d58d-be43-45ac-88e5-3232d67c5172	f	\N	\N	2025-10-19 18:00:35.07565	2025-10-19 18:00:35.07565
8c04c9d5-2992-4108-bc71-d0210b7972e2	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Compliance Check - Stiedemann, Reichel and Brown	Crepusculum animus depulso abbas ara nisi unus aperiam. Vilicus dolore ipsa decumbo bene trucido attonbitus repudiandae. Certus solitudo deinde quia.	cancelled	high	67f62599-7f9f-44e8-bc18-d2ce08ea9919	c4f75303-a973-43e1-8f69-dfc6500c302c	\N	d6f36046-e274-4776-a3d7-58eadb9d96b0	2025-10-19 16:00:39.512	2025-10-21 20:07:35.168	\N	1.00	\N	78	Tax Return	Client Work	["monthly", "client-request", "urgent"]	\N	965823ac-8815-43cb-b52d-be3d11bee333	f	\N	\N	2025-10-19 18:00:34.794557	2025-10-19 18:00:34.794557
0da2984a-30cb-4fdf-a4f6-b38ff97be406	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Tax Return - Terry, Carter and Kshlerin	Soluta ambulo amplitudo amicitia urbanus tripudio campana cohibeo. Damnatio arcesso amoveo volva. Placeat terror voluptatum cursim contabesco.	in_progress	urgent	702b5a48-f7a9-464c-8833-1ff6577e50e6	c4f75303-a973-43e1-8f69-dfc6500c302c	a2adaa31-8f59-409a-b39b-72568022adb4	c4f75303-a973-43e1-8f69-dfc6500c302c	2025-10-24 22:00:57.935	2025-10-25 01:06:52.029	\N	16.00	\N	5	Annual Accounts	Client Work	["annual"]	\N	acbad2fb-595b-462b-82fc-f2f04f43fc67	f	\N	\N	2025-10-19 18:00:34.85664	2025-10-19 18:00:34.85664
96a103f5-bc5b-43e1-b321-62fedda6eaa1	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Compliance Check - Constance Mante	Trepide asper cito pax architecto tepesco tui adulescens. Aranea terga vesica. Substantia beneficium ustulo neque ustulo tempora verecundia aequus cado accusator.	pending	urgent	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	0409f8de-7e1d-4245-96c2-02a3b1c90a81	a2adaa31-8f59-409a-b39b-72568022adb4	0409f8de-7e1d-4245-96c2-02a3b1c90a81	2025-11-06 00:20:53.048	2025-11-07 07:35:49.382	\N	11.00	\N	6	VAT Return	Development	["annual", "client-request"]	\N	6624a9f6-9886-4b3d-a8fc-0bcc0ecfd112	f	\N	\N	2025-10-19 18:00:34.892758	2025-10-19 18:00:34.892758
98f9340d-eadb-45cd-bba2-115aa880f565	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Compliance Check - Constance Mante	Subseco reprehenderit reiciendis angelus celo trado terror amplitudo pax desparatus. Amor deludo vulgus reprehenderit atqui unde. Videlicet allatus sol vado laborum labore apostolus nobis summisse ustulo.	cancelled	medium	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	d6f36046-e274-4776-a3d7-58eadb9d96b0	d6f36046-e274-4776-a3d7-58eadb9d96b0	c4f75303-a973-43e1-8f69-dfc6500c302c	2025-10-24 10:04:33.199	2025-10-24 22:11:51.471	\N	12.00	\N	42	Payroll	Admin	["client-request", "quarterly", "annual"]	\N	f08a8f24-3be0-4086-bd5c-a4eb1cf19811	f	\N	\N	2025-10-19 18:00:34.934015	2025-10-19 18:00:34.934015
71b851af-8542-47e4-9ff8-304ed5983a0b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Tax Return - Latoya Crooks	Distinctio corrigo decerno tergiversatio. Suggero acceptus ciminatio ait paulatim voluptatum attollo solutio. Sublime tener capto hic ea illo aliquam alius cubitum convoco.	pending	medium	584bab37-ccf2-484c-9a7f-7394e4b30ec6	0409f8de-7e1d-4245-96c2-02a3b1c90a81	\N	c4f75303-a973-43e1-8f69-dfc6500c302c	2025-10-24 14:54:24.151	2025-10-25 18:15:50.577	\N	16.00	\N	18	Annual Accounts	Admin	[]	\N	acbad2fb-595b-462b-82fc-f2f04f43fc67	f	\N	\N	2025-10-19 18:00:34.951426	2025-10-19 18:00:34.951426
e171fa0b-3143-48ec-962f-0917bf1886bf	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Compliance Check - Schamberger LLC	Tenetur ver suffragium derelinquo molestiae volaticus peccatus solium undique benevolentia. Tergo confero ipsum combibo. Traho suadeo voluptatum curia.	pending	medium	12edb785-268b-4219-840d-15b8f0df1198	a2adaa31-8f59-409a-b39b-72568022adb4	\N	c4f75303-a973-43e1-8f69-dfc6500c302c	2025-09-25 22:38:00.709	2025-09-26 09:21:52.862	\N	8.00	\N	0	Compliance Check	Support	["urgent", "client-request"]	\N	4a29c5cf-69ba-4639-b91a-08f3851b5397	f	\N	\N	2025-10-19 18:00:34.959404	2025-10-19 18:00:34.959404
2105be2b-df4f-494a-bb20-548a7dbda952	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Bookkeeping - Evelyn Lubowitz	Deleniti vesper clementia laboriosam. Decens commodi sustineo abduco. Ascisco ceno circumvenio attonbitus arcus desolo spectaculum.	in_progress	urgent	65a6152e-a261-4a70-99fb-82f044e87d05	0409f8de-7e1d-4245-96c2-02a3b1c90a81	\N	0409f8de-7e1d-4245-96c2-02a3b1c90a81	2025-11-13 08:13:49.107	2025-11-13 08:42:42.339	\N	18.00	\N	30	Document Review	Development	[]	\N	c9013c22-350c-46aa-b8c4-8a71da338337	f	\N	\N	2025-10-19 18:00:35.084495	2025-10-19 18:00:35.084495
af41070b-ce93-4cf4-88f6-19ed28a1f1fe	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Client Meeting - Jerde LLC	Depereo cogo aegrotatio caveo sopor crudelis exercitationem. Amaritudo clibanus auxilium absque sursum. Aegrus degero a accusator vis tibi demitto atqui.	in_progress	medium	17f141c2-e297-4c93-9178-0fd819259c50	0409f8de-7e1d-4245-96c2-02a3b1c90a81	0409f8de-7e1d-4245-96c2-02a3b1c90a81	d6f36046-e274-4776-a3d7-58eadb9d96b0	2025-11-09 21:03:26.545	2025-11-10 21:39:38.732	\N	8.00	\N	55	Tax Return	Client Work	[]	\N	965823ac-8815-43cb-b52d-be3d11bee333	f	\N	\N	2025-10-19 18:00:35.089748	2025-10-19 18:00:35.089748
f9444b08-3c00-4407-98d8-3d654600142c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Client Meeting - Noah Walsh V	Summa unus amitto antiquus pecco paulatim creo natus. Sustineo attollo eaque. Decipio virga ultio.	completed	high	46859340-c8cf-4144-aa6c-28fbaf53fa0e	c4f75303-a973-43e1-8f69-dfc6500c302c	a2adaa31-8f59-409a-b39b-72568022adb4	0409f8de-7e1d-4245-96c2-02a3b1c90a81	2025-10-31 02:05:52.906	2025-11-02 16:44:42.091	2025-10-14 03:31:29.754	4.00	18.00	100	Bookkeeping	Support	["annual"]	\N	51c831a7-42a0-4a9e-8e8a-69e873269a4f	f	\N	\N	2025-10-19 18:00:35.09408	2025-10-19 18:00:35.09408
80260d18-0de6-4cf6-af1d-5b4a1d17a6de	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Compliance Check - Jerde LLC	Artificiose comis valeo addo. Cinis quae surculus. Attollo calco itaque suus demo.	cancelled	low	17f141c2-e297-4c93-9178-0fd819259c50	0409f8de-7e1d-4245-96c2-02a3b1c90a81	\N	d6f36046-e274-4776-a3d7-58eadb9d96b0	2025-12-13 12:45:57.737	2025-12-14 15:28:51.907	\N	13.00	\N	4	Compliance Check	Development	["quarterly", "monthly", "client-request"]	\N	4a29c5cf-69ba-4639-b91a-08f3851b5397	f	\N	\N	2025-10-19 18:00:35.09771	2025-10-19 18:00:35.09771
f6f91297-d9d7-461b-bf97-34473b55f893	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Annual Accounts - Latoya Crooks	Cursus soleo campana acidus assumenda cupiditate pauper conservo creptio. Tamquam comburo voluntarius titulus cotidie dignissimos inflammatio. Deprimo conitor hic crustulum tenax nostrum vetus alioqui deporto.	completed	urgent	584bab37-ccf2-484c-9a7f-7394e4b30ec6	0409f8de-7e1d-4245-96c2-02a3b1c90a81	a2adaa31-8f59-409a-b39b-72568022adb4	0409f8de-7e1d-4245-96c2-02a3b1c90a81	2025-11-25 20:44:55.37	2025-11-26 17:37:59.067	2025-10-18 13:43:12.586	9.00	1.00	100	Annual Accounts	Admin	[]	\N	acbad2fb-595b-462b-82fc-f2f04f43fc67	f	\N	\N	2025-10-19 18:00:35.101004	2025-10-19 18:00:35.101004
674b7e91-de7b-4a7d-a519-8e8315afb5eb	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	VAT Return - Latoya Crooks	Cohaero nemo incidunt arto vinculum vehemens caecus substantia contigo totidem. Thesaurus delibero usque. Quis admitto aperiam.	completed	medium	584bab37-ccf2-484c-9a7f-7394e4b30ec6	c4f75303-a973-43e1-8f69-dfc6500c302c	\N	d6f36046-e274-4776-a3d7-58eadb9d96b0	2025-11-21 17:25:48.098	2025-11-22 18:17:28.923	2025-10-19 14:45:28.139	3.00	24.00	100	VAT Return	Admin	["quarterly"]	\N	6624a9f6-9886-4b3d-a8fc-0bcc0ecfd112	f	\N	\N	2025-10-19 18:00:35.103615	2025-10-19 18:00:35.103615
2849d1a9-72a4-4287-8114-b604140c71aa	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Document Review - Dana Dickens	Arbustum voluptates denique. Maiores torqueo amitto uxor thalassinus quibusdam. Conduco delinquo amplexus arto aptus calco depopulo.	cancelled	urgent	b7295600-5c20-4de2-8782-af87987c2bee	d6f36046-e274-4776-a3d7-58eadb9d96b0	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-17 14:07:03.975	2025-10-20 08:26:18.22	\N	6.00	\N	36	Document Review	Client Work	[]	\N	c9013c22-350c-46aa-b8c4-8a71da338337	f	\N	\N	2025-10-19 18:00:35.106279	2025-10-19 18:00:35.106279
7add02b8-5d73-4a39-8607-6f9d17b36fda	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Annual Accounts - Ernser and Sons	Advenio beatae articulus caelestis demulceo sponte volutabrum terreo. Spiritus thesaurus vitiosus voluptates voluptatum. Conforto capillus tum aedificium tubineus.	in_progress	medium	6a032ece-4f9e-405a-b48a-b28516d15fe1	c4f75303-a973-43e1-8f69-dfc6500c302c	\N	0409f8de-7e1d-4245-96c2-02a3b1c90a81	2025-11-09 07:02:51.963	2025-11-10 02:13:10.258	\N	7.00	\N	22	Bookkeeping	Development	["quarterly", "annual"]	\N	51c831a7-42a0-4a9e-8e8a-69e873269a4f	f	\N	\N	2025-10-19 18:00:35.117106	2025-10-19 18:00:35.117106
3d497ef7-35c9-4687-8476-96fbecc29f86	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Compliance Check - Ernser and Sons	Currus deprecator sumptus tergiversatio dignissimos. Depopulo ver vado decimus culpo. Commemoro testimonium uterque acerbitas cibus versus.	in_progress	high	6a032ece-4f9e-405a-b48a-b28516d15fe1	0409f8de-7e1d-4245-96c2-02a3b1c90a81	\N	0409f8de-7e1d-4245-96c2-02a3b1c90a81	2025-12-12 00:22:30.491	2025-12-12 23:36:50.093	\N	12.00	\N	48	Document Review	Support	[]	\N	c9013c22-350c-46aa-b8c4-8a71da338337	f	\N	\N	2025-10-19 18:00:35.023442	2025-10-19 18:00:35.023442
43f46d13-e4e7-4e0f-a62d-25d47b569d15	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Compliance Check - Ernser and Sons	Civis tristis aestus vomica conturbo usus surgo ubi. Uxor textus sumptus tollo aperio video crepusculum atque concedo voluptate. Tepesco vere animadverto arbustum.	pending	high	6a032ece-4f9e-405a-b48a-b28516d15fe1	c4f75303-a973-43e1-8f69-dfc6500c302c	\N	0409f8de-7e1d-4245-96c2-02a3b1c90a81	2025-11-10 20:43:00.455	2025-11-11 01:50:45.255	\N	5.00	\N	26	VAT Return	Development	["monthly"]	\N	6624a9f6-9886-4b3d-a8fc-0bcc0ecfd112	f	\N	\N	2025-10-19 18:00:35.079085	2025-10-19 18:00:35.079085
1c9d17d2-a153-4f42-9604-129a162a1f0f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Annual Accounts - Jeremy Larson	Bestia solum cena solus saepe umquam alo infit socius comminor. Vicinus consectetur utroque delectus vester utilis desparatus harum demens assentator. Auxilium quia atrox curvo tristis.	cancelled	urgent	7ef8af5a-1080-42a2-988f-ddfa799c8070	0409f8de-7e1d-4245-96c2-02a3b1c90a81	c4f75303-a973-43e1-8f69-dfc6500c302c	c4f75303-a973-43e1-8f69-dfc6500c302c	2025-11-05 22:26:24.036	2025-11-07 17:47:49.979	\N	19.00	\N	10	Annual Accounts	Admin	["quarterly"]	\N	acbad2fb-595b-462b-82fc-f2f04f43fc67	f	\N	\N	2025-10-19 18:00:35.109386	2025-10-19 18:00:35.109386
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tenants (id, name, slug, metadata, created_at, updated_at) FROM stdin;
e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Demo Accounting Firm	demo-firm	\N	2025-10-19 18:00:33.871959	2025-10-19 18:00:33.871959
\.


--
-- Data for Name: time_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.time_entries (id, tenant_id, user_id, client_id, task_id, service_component_id, date, start_time, end_time, hours, work_type, billable, billed, rate, amount, invoice_id, description, notes, status, submitted_at, approved_by_id, approved_at, metadata, created_at, updated_at) FROM stdin;
0dc5e7ab-4663-45bd-9473-29cb66cbdda5	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	8538cc30-f9e7-4b63-a885-56b23e16ecef	b3d1095b-3d51-444b-be35-f485afdb174f	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-07-21	\N	\N	2.00	training	f	f	150.00	300.00	\N	Vulticulus adicio coadunatio conculco tempore contego validus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-21 18:00:35.119	\N	2025-10-19 18:00:35.121306	2025-10-19 18:00:35.121306
3355f7d1-8c05-4b06-9f74-a4034e6996af	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	088446c4-4542-4007-9887-b512bd3db05d	d6d7e47b-cd48-48d8-a45a-fa75af1f9a52	2025-07-21	\N	\N	0.75	training	t	f	150.00	112.50	\N	Carpo tribuo damno adeptio corona nostrum termes doloremque.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-21 18:00:35.119	\N	2025-10-19 18:00:35.128065	2025-10-19 18:00:35.128065
8229b662-b344-4174-95b4-a08e2333b9dd	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	65a6152e-a261-4a70-99fb-82f044e87d05	2105be2b-df4f-494a-bb20-548a7dbda952	d04961e2-5af7-4b9c-bb44-c37031dd6bfa	2025-07-21	\N	\N	3.00	research	t	f	150.00	450.00	\N	Voco agnosco amplitudo vesper deporto comminor quo textor speciosus consectetur.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-21 18:00:35.119	\N	2025-10-19 18:00:35.131287	2025-10-19 18:00:35.131287
744d5efc-7353-439b-bdc7-d3908d77b5b6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	46859340-c8cf-4144-aa6c-28fbaf53fa0e	f9444b08-3c00-4407-98d8-3d654600142c	1ede1cc0-3627-404e-bb8a-487e028f4732	2025-07-21	\N	\N	2.00	work	t	f	120.00	240.00	\N	Temporibus talio temptatio comes convoco audio terebro.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-21 18:00:35.119	\N	2025-10-19 18:00:35.134703	2025-10-19 18:00:35.134703
60a96e77-f967-453f-b870-d32fcd64f13e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	4554e09d-4391-42a8-a2cd-9702bce80511	ae73110f-e045-44ac-85ff-51aa2eb8ce69	a8a65b80-dc4c-49f9-9c8d-0dc4a336cf55	2025-07-21	\N	\N	2.00	admin	t	f	120.00	240.00	\N	Amplexus theca deleo tot.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-21 18:00:35.119	\N	2025-10-19 18:00:35.139297	2025-10-19 18:00:35.139297
0067445b-4a17-4296-99f2-1c90835eb340	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	6a032ece-4f9e-405a-b48a-b28516d15fe1	43f46d13-e4e7-4e0f-a62d-25d47b569d15	d6d7e47b-cd48-48d8-a45a-fa75af1f9a52	2025-07-21	\N	\N	2.50	work	t	t	120.00	300.00	\N	Cunabula aro argentum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-21 18:00:35.119	\N	2025-10-19 18:00:35.142879	2025-10-19 18:00:35.142879
6ae9bfe8-dcd2-40e3-9ad3-cff07ff371cb	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	088446c4-4542-4007-9887-b512bd3db05d	e2cd4da6-f171-436c-9c7e-a9c1c5436b98	2025-07-21	\N	\N	1.00	research	t	t	120.00	120.00	\N	Atrocitas eos cunae sumptus aro cupiditas vesco.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-21 18:00:35.119	\N	2025-10-19 18:00:35.146284	2025-10-19 18:00:35.146284
76425f52-60ba-4b87-8997-b27c6d77f862	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	088446c4-4542-4007-9887-b512bd3db05d	391f7d87-df5d-4538-9b3e-31e07ac9347e	2025-07-21	\N	\N	2.00	training	t	t	120.00	240.00	\N	Animus quae theca delectatio illo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-21 18:00:35.119	\N	2025-10-19 18:00:35.149983	2025-10-19 18:00:35.149983
20d97c06-019b-473e-a6bd-580d1908d30f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	a4464f5a-2125-46d9-9f58-7252c9adc16b	9068b493-e301-4f68-9bcd-ad7c1f9cbe03	e2cd4da6-f171-436c-9c7e-a9c1c5436b98	2025-07-21	\N	\N	3.25	training	t	f	110.00	357.50	\N	Decerno aperio calco conventus absconditus solio.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-21 18:00:35.119	\N	2025-10-19 18:00:35.154613	2025-10-19 18:00:35.154613
5a2cd856-cc09-4026-9895-bc8940150abf	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	088446c4-4542-4007-9887-b512bd3db05d	a49c064a-0890-4c02-8734-07a3185e6c03	2025-07-21	\N	\N	3.25	work	t	f	110.00	357.50	\N	Tempore tolero culpo vilicus charisma cuppedia conicio arguo minima.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-21 18:00:35.119	\N	2025-10-19 18:00:35.158338	2025-10-19 18:00:35.158338
73750554-7d46-4014-97c1-c6b7451eb899	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	7ef8af5a-1080-42a2-988f-ddfa799c8070	1c9d17d2-a153-4f42-9604-129a162a1f0f	08ee5378-067c-4708-886c-34df4c200b23	2025-07-21	\N	\N	2.75	research	t	f	110.00	302.50	\N	Adaugeo acceptus id facilis vesica porro calco.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-21 18:00:35.119	\N	2025-10-19 18:00:35.162722	2025-10-19 18:00:35.162722
592c0d77-760c-4335-8d38-ee637b33c325	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	d69d0436-37d7-42a4-b907-3d9c3a091ea6	0b689153-0b45-4725-866b-5eac75a40ad8	a8a65b80-dc4c-49f9-9c8d-0dc4a336cf55	2025-07-21	\N	\N	2.25	admin	t	f	110.00	247.50	\N	Depromo triumphus claustrum sponte abstergo vester appello cohors.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-21 18:00:35.119	\N	2025-10-19 18:00:35.166227	2025-10-19 18:00:35.166227
1ba45ec7-ce47-40c8-ae9f-1640b6f3714d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	4554e09d-4391-42a8-a2cd-9702bce80511	ae73110f-e045-44ac-85ff-51aa2eb8ce69	a8a65b80-dc4c-49f9-9c8d-0dc4a336cf55	2025-07-21	\N	\N	0.50	training	f	f	110.00	55.00	\N	Approbo commemoro iusto odit conduco decerno.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-21 18:00:35.119	\N	2025-10-19 18:00:35.169351	2025-10-19 18:00:35.169351
6569b715-3592-42a3-8d41-47114a939da8	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	088446c4-4542-4007-9887-b512bd3db05d	ef53422c-1305-4831-bf41-d85b2a76b0d5	2025-07-21	\N	\N	3.50	training	t	f	85.00	297.50	\N	Quisquam caelestis amitto.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-21 18:00:35.119	\N	2025-10-19 18:00:35.172969	2025-10-19 18:00:35.172969
0e11873c-fe41-4c61-afba-cd936349de1d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	584bab37-ccf2-484c-9a7f-7394e4b30ec6	598a25cc-7c96-4dd9-af0e-1e27762bf53a	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	2025-07-21	\N	\N	2.75	admin	t	f	85.00	233.75	\N	Coepi crebro vix libero expedita.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-21 18:00:35.119	\N	2025-10-19 18:00:35.176193	2025-10-19 18:00:35.176193
8a0418eb-875d-41c3-8c00-3abbb3796371	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	46859340-c8cf-4144-aa6c-28fbaf53fa0e	d486be12-5ed8-48b4-af34-79d9269f4c0b	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-07-22	\N	\N	2.25	work	t	f	150.00	337.50	\N	Vir voluptatum ager ciminatio cras spectaculum aperiam.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-22 18:00:35.178	\N	2025-10-19 18:00:35.179519	2025-10-19 18:00:35.179519
8ff7e8cb-4be9-46f8-9b1b-48baa7fc6606	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	45b3d726-e151-4770-9b64-4653914bdaa5	2c1d5d5c-be1c-427c-b2ac-da3cc28b1680	a96c9f4d-dc33-4af3-818d-8d729f0f8c1f	2025-07-22	\N	\N	3.25	meeting	t	t	150.00	487.50	\N	Causa capillus commemoro artificiose voluptatibus urbs.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-22 18:00:35.178	\N	2025-10-19 18:00:35.182674	2025-10-19 18:00:35.182674
f5aeb2e2-a6f0-4225-898b-736b35700ac2	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	702b5a48-f7a9-464c-8833-1ff6577e50e6	0da2984a-30cb-4fdf-a4f6-b38ff97be406	cbf9b499-276b-4a28-999c-27388562c4f4	2025-07-22	\N	\N	1.25	admin	t	f	150.00	187.50	\N	Suffragium desipio absconditus delibero coerceo sol crepusculum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-22 18:00:35.178	\N	2025-10-19 18:00:35.18589	2025-10-19 18:00:35.18589
6747684e-b46d-4aba-93c8-7bde9166782b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	17f141c2-e297-4c93-9178-0fd819259c50	80260d18-0de6-4cf6-af1d-5b4a1d17a6de	ef53422c-1305-4831-bf41-d85b2a76b0d5	2025-07-22	\N	\N	0.50	admin	f	f	150.00	75.00	\N	Caste ultra vix admoveo degusto.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-22 18:00:35.178	\N	2025-10-19 18:00:35.189126	2025-10-19 18:00:35.189126
43cbd8e7-114a-4c8b-b0bd-f2a0565232f0	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	46859340-c8cf-4144-aa6c-28fbaf53fa0e	f9444b08-3c00-4407-98d8-3d654600142c	e4487405-7859-40e9-8008-056d32fe6f10	2025-07-22	\N	\N	1.25	meeting	t	f	150.00	187.50	\N	Somnus magnam confido dolores delectatio est.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-22 18:00:35.178	\N	2025-10-19 18:00:35.192007	2025-10-19 18:00:35.192007
a5388953-28bd-458a-8f3f-b29373e4f3dc	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	584bab37-ccf2-484c-9a7f-7394e4b30ec6	7a582f98-6d3d-44d5-9796-ba1d12c49f62	996aa78c-cfd1-477f-8c30-d9489225b29e	2025-07-22	\N	\N	3.75	work	f	f	120.00	450.00	\N	Commemoro odio acidus coruscus accusamus vigilo tametsi.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-22 18:00:35.178	\N	2025-10-19 18:00:35.195436	2025-10-19 18:00:35.195436
b458416e-e7b3-4d50-b31c-78e322298d89	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	6ecda653-6094-4502-9d1d-6e90d9ea99ed	4fb9cb0a-ca36-4af7-9203-ac1970ce555b	109283c7-55ef-4e05-bf53-c6efd1be486f	2025-07-22	\N	\N	2.75	training	t	f	120.00	330.00	\N	Calamitas crux tabula.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-22 18:00:35.178	\N	2025-10-19 18:00:35.198924	2025-10-19 18:00:35.198924
78d46265-fde8-4389-882c-c699671c46b1	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	98f9340d-eadb-45cd-bba2-115aa880f565	a0801828-5c53-41ef-9b3e-06db89d72e90	2025-07-22	\N	\N	2.75	work	f	f	120.00	330.00	\N	Conor acies tonsor celer cohaero acer.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-22 18:00:35.178	\N	2025-10-19 18:00:35.202724	2025-10-19 18:00:35.202724
bc6d4d46-ed07-4acf-bb38-ddb510bdb9f5	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	65a6152e-a261-4a70-99fb-82f044e87d05	b7a77905-edd5-451e-a92e-06976feeb638	996aa78c-cfd1-477f-8c30-d9489225b29e	2025-07-22	\N	\N	2.25	admin	t	t	110.00	247.50	\N	Verumtamen deinde crudelis alter asper tersus dolor calcar voluptatum cibus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-22 18:00:35.178	\N	2025-10-19 18:00:35.207313	2025-10-19 18:00:35.207313
fa98dcd6-0951-4e6c-95e9-f33b46bdceaa	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	4554e09d-4391-42a8-a2cd-9702bce80511	ae73110f-e045-44ac-85ff-51aa2eb8ce69	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	2025-07-22	\N	\N	3.25	meeting	t	f	110.00	357.50	\N	Minima creo adulatio vivo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-22 18:00:35.178	\N	2025-10-19 18:00:35.211825	2025-10-19 18:00:35.211825
ffb9a55e-e529-4b7b-9df4-48ab5d299a66	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	8538cc30-f9e7-4b63-a885-56b23e16ecef	b3d1095b-3d51-444b-be35-f485afdb174f	08ee5378-067c-4708-886c-34df4c200b23	2025-07-22	\N	\N	1.25	work	t	t	85.00	106.25	\N	Eos degusto tempus acquiro pecco ulterius coepi vito congregatio.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-22 18:00:35.178	\N	2025-10-19 18:00:35.216996	2025-10-19 18:00:35.216996
e3a3916f-da37-4bb5-9b04-bad2baf92239	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	8538cc30-f9e7-4b63-a885-56b23e16ecef	b3d1095b-3d51-444b-be35-f485afdb174f	a8a65b80-dc4c-49f9-9c8d-0dc4a336cf55	2025-07-22	\N	\N	3.00	research	t	f	85.00	255.00	\N	Timidus odio accedo curiositas architecto adsidue apud demoror tamquam hic.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-22 18:00:35.178	\N	2025-10-19 18:00:35.222842	2025-10-19 18:00:35.222842
583981cb-8c24-45e8-b315-d1c019e4d5e5	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	67f62599-7f9f-44e8-bc18-d2ce08ea9919	9ec151a2-b6a4-433d-a21e-c94af23b785b	a49c064a-0890-4c02-8734-07a3185e6c03	2025-07-22	\N	\N	2.00	research	t	t	85.00	170.00	\N	Praesentium harum inflammatio libero utrimque utroque assumenda.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-22 18:00:35.178	\N	2025-10-19 18:00:35.226318	2025-10-19 18:00:35.226318
4c2e3970-465c-4079-b40d-a3a0e6c8cf52	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	65a6152e-a261-4a70-99fb-82f044e87d05	2105be2b-df4f-494a-bb20-548a7dbda952	109283c7-55ef-4e05-bf53-c6efd1be486f	2025-07-22	\N	\N	1.25	training	f	t	85.00	106.25	\N	Censura umerus pecco tertius arx tutis vinculum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-22 18:00:35.178	\N	2025-10-19 18:00:35.229914	2025-10-19 18:00:35.229914
4028020d-6044-41ae-a081-6252ec76ab21	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	8538cc30-f9e7-4b63-a885-56b23e16ecef	b3d1095b-3d51-444b-be35-f485afdb174f	ecfd2c2c-905b-4ef4-99a4-8949632b9ae9	2025-07-22	\N	\N	2.50	work	t	f	85.00	212.50	\N	Cibo depulso atrocitas.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-22 18:00:35.178	\N	2025-10-19 18:00:35.232903	2025-10-19 18:00:35.232903
02434bab-3c3c-447f-bd00-bc7b4922bfdb	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	65a6152e-a261-4a70-99fb-82f044e87d05	b7a77905-edd5-451e-a92e-06976feeb638	235b548d-f0a0-4899-9a7e-d6e9bec6db40	2025-07-23	\N	\N	3.00	admin	t	f	150.00	450.00	\N	Verto nemo dedecor.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-23 18:00:35.234	\N	2025-10-19 18:00:35.236393	2025-10-19 18:00:35.236393
28c1088a-8958-4de0-bac0-1ca70b48ecba	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	d69d0436-37d7-42a4-b907-3d9c3a091ea6	0b689153-0b45-4725-866b-5eac75a40ad8	996aa78c-cfd1-477f-8c30-d9489225b29e	2025-07-23	\N	\N	1.75	training	t	f	150.00	262.50	\N	Beneficium sollers depraedor.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-23 18:00:35.234	\N	2025-10-19 18:00:35.240294	2025-10-19 18:00:35.240294
81a91474-035d-4907-beb3-063aea109a4e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	0d0329f4-4b80-4899-8807-5854e9db312b	40ca5c4e-33d7-432f-a55c-b59c3010d7ef	ef53422c-1305-4831-bf41-d85b2a76b0d5	2025-07-23	\N	\N	1.50	training	f	f	120.00	180.00	\N	Coniecto arx colligo benigne aptus cicuta denuncio deludo volutabrum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-23 18:00:35.234	\N	2025-10-19 18:00:35.24438	2025-10-19 18:00:35.24438
360cf3bf-dec1-4e8c-a5df-451870617634	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	65a6152e-a261-4a70-99fb-82f044e87d05	b98cb032-3f5a-46db-ab39-de7d53570ae9	a96c9f4d-dc33-4af3-818d-8d729f0f8c1f	2025-07-23	\N	\N	2.25	meeting	t	f	120.00	270.00	\N	Sodalitas adduco magnam bonus damnatio velut.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-23 18:00:35.234	\N	2025-10-19 18:00:35.247517	2025-10-19 18:00:35.247517
246edd1b-2a91-40d4-9726-6708622ae37b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	dc9252b7-2022-4822-a8b2-7ec227fe0ea4	18c91d63-8f9d-4974-ba97-a4079c7457d5	2025-07-23	\N	\N	1.75	work	f	f	120.00	210.00	\N	Aperio ara vox color quod defluo capto.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-23 18:00:35.234	\N	2025-10-19 18:00:35.250728	2025-10-19 18:00:35.250728
365bd09f-14c7-4799-9b2b-6f4ba077a0cf	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	17f141c2-e297-4c93-9178-0fd819259c50	80260d18-0de6-4cf6-af1d-5b4a1d17a6de	3f2e9a8e-bdfe-4d09-aced-e88cdc710462	2025-07-23	\N	\N	0.75	meeting	t	f	110.00	82.50	\N	Vesper toties colligo tersus a denego appello attero acer.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-23 18:00:35.234	\N	2025-10-19 18:00:35.254001	2025-10-19 18:00:35.254001
199b5cbd-1f70-482c-a5b3-bd8d963d8377	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	d69d0436-37d7-42a4-b907-3d9c3a091ea6	20222077-caa4-4444-b803-1f75d617ee85	78882562-2120-44d2-9286-03e696abbf02	2025-07-23	\N	\N	1.75	training	t	t	110.00	192.50	\N	Tribuo assumenda arbitro desipio crepusculum autus aliqua.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-23 18:00:35.234	\N	2025-10-19 18:00:35.256846	2025-10-19 18:00:35.256846
8f264915-35c6-4dad-a367-dae52a96d30b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	65a6152e-a261-4a70-99fb-82f044e87d05	b7a77905-edd5-451e-a92e-06976feeb638	996aa78c-cfd1-477f-8c30-d9489225b29e	2025-07-23	\N	\N	2.75	work	t	f	110.00	302.50	\N	Torrens aeger ultra cognomen.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-23 18:00:35.234	\N	2025-10-19 18:00:35.259702	2025-10-19 18:00:35.259702
9d9a99d4-3eb0-4e01-bdf7-2d5999de80fe	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	d69d0436-37d7-42a4-b907-3d9c3a091ea6	0b689153-0b45-4725-866b-5eac75a40ad8	ca413110-b7e3-4734-a185-d21ea0960708	2025-07-23	\N	\N	1.75	research	t	f	110.00	192.50	\N	Repudiandae cattus quia amicitia crux qui comparo barba quas abeo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-23 18:00:35.234	\N	2025-10-19 18:00:35.262433	2025-10-19 18:00:35.262433
ffc2e4dc-df0d-4d22-beed-2854c9e7e077	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	04465623-29cb-4298-8828-d1839e9cc00d	e4ce7abb-fb0c-42e1-a7c1-6419b4aa63ef	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-07-23	\N	\N	4.00	training	t	f	85.00	340.00	\N	Correptius compello vulgaris.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-23 18:00:35.234	\N	2025-10-19 18:00:35.265755	2025-10-19 18:00:35.265755
6d6397ec-584c-4eab-8397-a7a211497f82	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	45b3d726-e151-4770-9b64-4653914bdaa5	449f8e23-33a0-4bf0-915e-cc79d13bc3a9	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	2025-07-23	\N	\N	1.00	meeting	t	f	85.00	85.00	\N	Coaegresco angulus stabilis cursus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-23 18:00:35.234	\N	2025-10-19 18:00:35.269232	2025-10-19 18:00:35.269232
00ffa2e8-75f5-48df-baec-35de8a121d67	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	46859340-c8cf-4144-aa6c-28fbaf53fa0e	f9444b08-3c00-4407-98d8-3d654600142c	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-07-24	\N	\N	2.00	meeting	t	f	150.00	300.00	\N	Creber crur fugit audax contabesco.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-24 18:00:35.271	\N	2025-10-19 18:00:35.272482	2025-10-19 18:00:35.272482
88693780-375e-4f16-ab48-0b36538104b3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	b0a95e11-90ac-4ab3-b099-c4de69f498b8	8c94ef1c-f972-45ba-9aaa-1fa78ab3fc92	235b548d-f0a0-4899-9a7e-d6e9bec6db40	2025-07-24	\N	\N	3.75	admin	t	f	150.00	562.50	\N	Usque inflammatio certus tabesco turpis bibo antiquus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-24 18:00:35.271	\N	2025-10-19 18:00:35.275423	2025-10-19 18:00:35.275423
60084558-4353-4a9c-8370-d5b5e16a871e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	b0a95e11-90ac-4ab3-b099-c4de69f498b8	8c94ef1c-f972-45ba-9aaa-1fa78ab3fc92	d04961e2-5af7-4b9c-bb44-c37031dd6bfa	2025-07-24	\N	\N	3.25	meeting	f	f	150.00	487.50	\N	Arca creptio angustus traho demoror.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-24 18:00:35.271	\N	2025-10-19 18:00:35.278445	2025-10-19 18:00:35.278445
f1cbfa14-9e1f-4679-8025-a189c9d2e93e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	b0a95e11-90ac-4ab3-b099-c4de69f498b8	269dca40-b352-4a09-9d7c-c735016a8c7d	d04961e2-5af7-4b9c-bb44-c37031dd6bfa	2025-07-24	\N	\N	2.25	meeting	t	t	150.00	337.50	\N	Annus collum bellum fugiat explicabo spiculum aro.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-24 18:00:35.271	\N	2025-10-19 18:00:35.281157	2025-10-19 18:00:35.281157
14632677-c3f9-4ef9-b33e-5e54845b3c46	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	12edb785-268b-4219-840d-15b8f0df1198	f37ad203-1495-4aec-be30-1b2d7fe4dd70	29a61f52-d957-4207-b54b-7fc565a57541	2025-07-24	\N	\N	1.00	admin	t	t	150.00	150.00	\N	Stultus tabesco nisi consequatur approbo commemoro depulso virgo textilis.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-24 18:00:35.271	\N	2025-10-19 18:00:35.284156	2025-10-19 18:00:35.284156
c4a37c8d-c701-4ab7-bb20-892d4ee7a2a3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	4554e09d-4391-42a8-a2cd-9702bce80511	ae73110f-e045-44ac-85ff-51aa2eb8ce69	9362cf11-827c-459a-8ffc-6634bd023508	2025-07-24	\N	\N	2.25	admin	f	t	120.00	270.00	\N	Harum terminatio charisma alias armarium.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-24 18:00:35.271	\N	2025-10-19 18:00:35.288657	2025-10-19 18:00:35.288657
67a0bc5d-c1f0-4670-967c-2543c16974b9	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	04465623-29cb-4298-8828-d1839e9cc00d	e4ce7abb-fb0c-42e1-a7c1-6419b4aa63ef	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	2025-07-24	\N	\N	1.75	work	t	f	120.00	210.00	\N	Eaque coepi eos aut abutor crur sumptus spoliatio vulnero perferendis.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-24 18:00:35.271	\N	2025-10-19 18:00:35.292638	2025-10-19 18:00:35.292638
e68e5810-c591-4184-ba96-6ac248c7d2be	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	b0a95e11-90ac-4ab3-b099-c4de69f498b8	8c94ef1c-f972-45ba-9aaa-1fa78ab3fc92	235b548d-f0a0-4899-9a7e-d6e9bec6db40	2025-07-24	\N	\N	3.25	admin	t	t	120.00	390.00	\N	Creator usque argumentum tonsor sequi chirographum accendo perferendis auxilium.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-24 18:00:35.271	\N	2025-10-19 18:00:35.296325	2025-10-19 18:00:35.296325
d40165f8-a1a8-4408-b2b4-b78582967ae3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	17f141c2-e297-4c93-9178-0fd819259c50	a18510b4-73e3-40ff-84b1-89c4a2e0bdac	d6d7e47b-cd48-48d8-a45a-fa75af1f9a52	2025-07-24	\N	\N	0.50	work	t	f	120.00	60.00	\N	Spes adeo tenetur delicate nisi.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-24 18:00:35.271	\N	2025-10-19 18:00:35.300056	2025-10-19 18:00:35.300056
82fe5101-9b1f-47d5-a6d7-dd683604d85c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	96a103f5-bc5b-43e1-b321-62fedda6eaa1	cbf9b499-276b-4a28-999c-27388562c4f4	2025-07-24	\N	\N	4.00	research	t	f	110.00	440.00	\N	Absens viridis vitiosus atavus accedo ager doloremque depopulo ipsam.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-24 18:00:35.271	\N	2025-10-19 18:00:35.303575	2025-10-19 18:00:35.303575
f73f3f05-690d-43dc-8f6d-be3a8c944257	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	584bab37-ccf2-484c-9a7f-7394e4b30ec6	e64d20a6-86e7-4dd1-ab40-aabaedbd6ebb	a0801828-5c53-41ef-9b3e-06db89d72e90	2025-07-24	\N	\N	1.75	admin	t	t	110.00	192.50	\N	Ager statim corpus avaritia tamdiu.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-24 18:00:35.271	\N	2025-10-19 18:00:35.307066	2025-10-19 18:00:35.307066
9df36bf1-c1a5-4a56-8c6a-f3cf5e3fe163	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	6ecda653-6094-4502-9d1d-6e90d9ea99ed	4fb9cb0a-ca36-4af7-9203-ac1970ce555b	d04961e2-5af7-4b9c-bb44-c37031dd6bfa	2025-07-24	\N	\N	1.25	work	t	f	110.00	137.50	\N	Cura territo umbra altus tabernus cultura sollers.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-24 18:00:35.271	\N	2025-10-19 18:00:35.31002	2025-10-19 18:00:35.31002
e20cbd08-c007-4277-8d02-dee697e6447c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	a4464f5a-2125-46d9-9f58-7252c9adc16b	9068b493-e301-4f68-9bcd-ad7c1f9cbe03	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	2025-07-24	\N	\N	2.75	research	f	f	110.00	302.50	\N	Terreo sui debitis tremo textus crastinus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-24 18:00:35.271	\N	2025-10-19 18:00:35.313682	2025-10-19 18:00:35.313682
99578360-ae56-4eee-bc89-71a5a1a9ba63	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	d8601cb6-589f-456f-a2b2-1b986973a4bc	235b548d-f0a0-4899-9a7e-d6e9bec6db40	2025-07-24	\N	\N	2.75	work	t	f	110.00	302.50	\N	Praesentium candidus tantillus astrum architecto candidus terebro.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-24 18:00:35.271	\N	2025-10-19 18:00:35.317008	2025-10-19 18:00:35.317008
d9d33bb9-bee9-47bd-acab-3bc5a934d87c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	dc9252b7-2022-4822-a8b2-7ec227fe0ea4	109283c7-55ef-4e05-bf53-c6efd1be486f	2025-07-24	\N	\N	1.75	admin	t	t	85.00	148.75	\N	Tempora vilicus quis ager triumphus arcus saepe capio.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-24 18:00:35.271	\N	2025-10-19 18:00:35.320779	2025-10-19 18:00:35.320779
88fc29bb-cdc9-48d5-bbff-5087dd275ab8	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	b0a95e11-90ac-4ab3-b099-c4de69f498b8	8c94ef1c-f972-45ba-9aaa-1fa78ab3fc92	a0801828-5c53-41ef-9b3e-06db89d72e90	2025-07-24	\N	\N	0.50	admin	t	f	85.00	42.50	\N	Tibi facere voluptatem dolorem.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-24 18:00:35.271	\N	2025-10-19 18:00:35.325292	2025-10-19 18:00:35.325292
5f53b28f-fcab-4535-ba91-482805da1012	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	584bab37-ccf2-484c-9a7f-7394e4b30ec6	71b851af-8542-47e4-9ff8-304ed5983a0b	3f2e9a8e-bdfe-4d09-aced-e88cdc710462	2025-07-25	\N	\N	3.00	admin	t	f	150.00	450.00	\N	Terra subito varietas cubitum aliquid.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-25 18:00:35.327	\N	2025-10-19 18:00:35.328907	2025-10-19 18:00:35.328907
3d3d283d-cb1e-4f32-8395-6107c553693d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	0d0329f4-4b80-4899-8807-5854e9db312b	e60c944c-85a6-45da-b007-56b5244e0257	a8a65b80-dc4c-49f9-9c8d-0dc4a336cf55	2025-07-25	\N	\N	1.50	research	t	f	150.00	225.00	\N	Textus comes dolores adimpleo aeger suffoco deduco volaticus apostolus teneo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-25 18:00:35.327	\N	2025-10-19 18:00:35.332108	2025-10-19 18:00:35.332108
25fcee6d-c2ac-42d0-be8f-879c1310ebae	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	c8eb351f-daa9-48cf-bc62-2cef6338a122	3f2e9a8e-bdfe-4d09-aced-e88cdc710462	2025-07-25	\N	\N	1.00	admin	t	t	150.00	150.00	\N	Adhuc temperantia adipiscor tricesimus cariosus abutor copiose coma vociferor crinis.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-25 18:00:35.327	\N	2025-10-19 18:00:35.334611	2025-10-19 18:00:35.334611
e8b2d0cd-4a57-4d35-9575-4a33222eb75f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	6ecda653-6094-4502-9d1d-6e90d9ea99ed	4fb9cb0a-ca36-4af7-9203-ac1970ce555b	a49c064a-0890-4c02-8734-07a3185e6c03	2025-07-25	\N	\N	1.25	work	t	f	150.00	187.50	\N	Abbas tubineus in vicinus amo tremo laborum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-25 18:00:35.327	\N	2025-10-19 18:00:35.33701	2025-10-19 18:00:35.33701
a99975c5-13cc-49cf-9840-6141815a9251	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	088446c4-4542-4007-9887-b512bd3db05d	cbf9b499-276b-4a28-999c-27388562c4f4	2025-07-25	\N	\N	1.00	research	t	f	150.00	150.00	\N	Antea tenus tenuis asperiores quo acsi.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-25 18:00:35.327	\N	2025-10-19 18:00:35.339656	2025-10-19 18:00:35.339656
66caca69-a292-4d58-beea-8ad864a2a5fc	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	67f62599-7f9f-44e8-bc18-d2ce08ea9919	419cb8f8-8b70-44a5-883b-8fa92787aa46	d6d7e47b-cd48-48d8-a45a-fa75af1f9a52	2025-07-25	\N	\N	4.00	training	t	f	120.00	480.00	\N	Pecco ambulo casus dolorem termes thesis sustineo vulnus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-25 18:00:35.327	\N	2025-10-19 18:00:35.342221	2025-10-19 18:00:35.342221
deb4013c-3dd0-4702-950c-f037a6f4b4dd	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	b7295600-5c20-4de2-8782-af87987c2bee	d2f831e1-38ca-429c-9942-06db88f8dfc5	391f7d87-df5d-4538-9b3e-31e07ac9347e	2025-07-25	\N	\N	4.00	meeting	t	f	120.00	480.00	\N	Adsidue triduana torrens velociter capio neque accusator animi.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-25 18:00:35.327	\N	2025-10-19 18:00:35.344758	2025-10-19 18:00:35.344758
128646be-8432-42cf-bf23-e15c2403bae7	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	6ecda653-6094-4502-9d1d-6e90d9ea99ed	6c88f260-519e-41e9-9fac-18a28b9a7901	a49c064a-0890-4c02-8734-07a3185e6c03	2025-07-25	\N	\N	2.25	training	t	f	120.00	270.00	\N	Animi tandem tubineus veniam acervus quasi cruciamentum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-25 18:00:35.327	\N	2025-10-19 18:00:35.3472	2025-10-19 18:00:35.3472
a3e8e0b7-1143-469f-94e1-9c14743547d2	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	d69d0436-37d7-42a4-b907-3d9c3a091ea6	0b689153-0b45-4725-866b-5eac75a40ad8	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-07-25	\N	\N	4.00	meeting	t	f	110.00	440.00	\N	Sonitus vacuus decet vesco articulus capio asper cruentus valeo iure.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-25 18:00:35.327	\N	2025-10-19 18:00:35.34971	2025-10-19 18:00:35.34971
91cbcc9e-fbbb-45af-8870-ef6a2be7ff79	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	12edb785-268b-4219-840d-15b8f0df1198	f37ad203-1495-4aec-be30-1b2d7fe4dd70	9362cf11-827c-459a-8ffc-6634bd023508	2025-07-25	\N	\N	4.00	training	t	f	110.00	440.00	\N	Denuo iusto amet.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-25 18:00:35.327	\N	2025-10-19 18:00:35.352061	2025-10-19 18:00:35.352061
f05d0aba-b251-4597-b0c5-271d936d041d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	584bab37-ccf2-484c-9a7f-7394e4b30ec6	ff7b1e48-6594-4997-9b76-46ab909220e2	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	2025-07-25	\N	\N	2.00	training	f	f	110.00	220.00	\N	Patrocinor thesis aetas nostrum acsi tabella.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-25 18:00:35.327	\N	2025-10-19 18:00:35.354395	2025-10-19 18:00:35.354395
ed4cdd7e-f56b-4c65-a512-2b8fd43ccc0c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	04600664-34f3-4ae0-9a01-2da04b5bc5fc	391f7d87-df5d-4538-9b3e-31e07ac9347e	2025-07-25	\N	\N	1.00	training	t	t	110.00	110.00	\N	Stella tremo tum terga quod caste.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-25 18:00:35.327	\N	2025-10-19 18:00:35.356693	2025-10-19 18:00:35.356693
68816156-117e-42b3-9bc6-04f0dd40bd50	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	b0a95e11-90ac-4ab3-b099-c4de69f498b8	269dca40-b352-4a09-9d7c-c735016a8c7d	ff4a2600-29fe-4448-bec3-ea868988a9ed	2025-07-25	\N	\N	1.75	research	f	f	85.00	148.75	\N	Tricesimus cicuta ustilo ciminatio occaecati turbo virtus distinctio amita.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-25 18:00:35.327	\N	2025-10-19 18:00:35.359171	2025-10-19 18:00:35.359171
a77afc1e-f5fd-4932-a4e7-734d692fa859	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	0d0329f4-4b80-4899-8807-5854e9db312b	e60c944c-85a6-45da-b007-56b5244e0257	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	2025-07-25	\N	\N	4.00	admin	t	f	85.00	340.00	\N	Optio tubineus adeo deputo usitas comitatus facere repudiandae.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-25 18:00:35.327	\N	2025-10-19 18:00:35.362019	2025-10-19 18:00:35.362019
ac1d53e7-6a5c-4071-a352-185da94e0ee1	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	0d0329f4-4b80-4899-8807-5854e9db312b	e60c944c-85a6-45da-b007-56b5244e0257	08ee5378-067c-4708-886c-34df4c200b23	2025-07-25	\N	\N	0.50	work	f	f	85.00	42.50	\N	Sufficio aeneus sunt sonitus terror videlicet concedo centum termes.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-25 18:00:35.327	\N	2025-10-19 18:00:35.364978	2025-10-19 18:00:35.364978
fe376fb2-1367-409c-aa5e-2548ceee7ce3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	67f62599-7f9f-44e8-bc18-d2ce08ea9919	8c04c9d5-2992-4108-bc71-d0210b7972e2	d6d7e47b-cd48-48d8-a45a-fa75af1f9a52	2025-07-25	\N	\N	2.25	meeting	t	f	85.00	191.25	\N	Soleo antiquus thorax tego tenus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-25 18:00:35.327	\N	2025-10-19 18:00:35.368661	2025-10-19 18:00:35.368661
f12c11df-5e2d-4287-9e0b-8dc55f8534a8	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	584bab37-ccf2-484c-9a7f-7394e4b30ec6	71b851af-8542-47e4-9ff8-304ed5983a0b	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-07-28	\N	\N	3.50	work	t	f	150.00	525.00	\N	Vulticulus derideo chirographum aequitas cubitum ad expedita.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-28 18:00:35.371	\N	2025-10-19 18:00:35.372652	2025-10-19 18:00:35.372652
df17c1cd-e7f4-4927-9299-999e9113f7ba	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	702b5a48-f7a9-464c-8833-1ff6577e50e6	66d28217-b458-4ec3-9e88-eb34570556b7	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-07-28	\N	\N	3.75	research	t	f	150.00	562.50	\N	Vulgo neque agnosco amplus adopto voluptates balbus depulso utique taceo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-28 18:00:35.371	\N	2025-10-19 18:00:35.375617	2025-10-19 18:00:35.375617
5b2975a9-c9a6-4a41-baf7-d2f9ed223df1	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	2db210d6-c799-49db-b61d-9aff5f87f1f0	391f7d87-df5d-4538-9b3e-31e07ac9347e	2025-07-28	\N	\N	3.50	training	t	f	120.00	420.00	\N	Illo absens sint totam delibero spectaculum alias ceno possimus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-28 18:00:35.371	\N	2025-10-19 18:00:35.378418	2025-10-19 18:00:35.378418
c3acb216-972c-4b7b-84a9-845ad2be16c6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	b7295600-5c20-4de2-8782-af87987c2bee	196a1b4b-9367-4b9f-baf6-717d312881a3	3f2e9a8e-bdfe-4d09-aced-e88cdc710462	2025-07-28	\N	\N	2.75	work	t	f	120.00	330.00	\N	Degusto uter centum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-28 18:00:35.371	\N	2025-10-19 18:00:35.380975	2025-10-19 18:00:35.380975
d1491727-264f-44f9-b55c-c98848cc6081	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	0d0329f4-4b80-4899-8807-5854e9db312b	40ca5c4e-33d7-432f-a55c-b59c3010d7ef	78882562-2120-44d2-9286-03e696abbf02	2025-07-28	\N	\N	0.50	training	t	t	110.00	55.00	\N	Curtus demens tui.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-28 18:00:35.371	\N	2025-10-19 18:00:35.383579	2025-10-19 18:00:35.383579
3804f4e5-3230-4cdd-a9fa-ae340b23e348	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	d8601cb6-589f-456f-a2b2-1b986973a4bc	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	2025-07-28	\N	\N	0.75	work	t	f	110.00	82.50	\N	Tametsi dolores tres vero.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-28 18:00:35.371	\N	2025-10-19 18:00:35.386056	2025-10-19 18:00:35.386056
6bb68ec8-0b64-4ac7-b8bb-3448311e7667	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	7ef8af5a-1080-42a2-988f-ddfa799c8070	1c9d17d2-a153-4f42-9604-129a162a1f0f	08ee5378-067c-4708-886c-34df4c200b23	2025-07-28	\N	\N	3.75	training	t	t	110.00	412.50	\N	Statua cicuta utpote canto conatus degero vigilo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-28 18:00:35.371	\N	2025-10-19 18:00:35.388566	2025-10-19 18:00:35.388566
dc112e51-1da2-47a9-adcf-1acd0a0c46c9	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	a4464f5a-2125-46d9-9f58-7252c9adc16b	a08b1624-6e7a-4a25-8f08-3b9b00adb6a0	1ede1cc0-3627-404e-bb8a-487e028f4732	2025-07-28	\N	\N	3.50	meeting	f	f	85.00	297.50	\N	Dicta convoco eaque utrimque infit appello aetas tertius.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-28 18:00:35.371	\N	2025-10-19 18:00:35.391217	2025-10-19 18:00:35.391217
2c69cff0-20f4-40ca-8430-008bff0487c4	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	6a032ece-4f9e-405a-b48a-b28516d15fe1	062f6587-cb37-4a01-aa03-004703abe1e2	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	2025-07-28	\N	\N	2.25	research	t	f	85.00	191.25	\N	Totus aestas synagoga.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-28 18:00:35.371	\N	2025-10-19 18:00:35.393626	2025-10-19 18:00:35.393626
8aec4bfc-6637-4997-ba8d-e90d77a94bfc	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	6a032ece-4f9e-405a-b48a-b28516d15fe1	3d497ef7-35c9-4687-8476-96fbecc29f86	a0801828-5c53-41ef-9b3e-06db89d72e90	2025-07-28	\N	\N	1.00	work	t	f	85.00	85.00	\N	Vilitas pecus impedit demum vilicus aggero.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-28 18:00:35.371	\N	2025-10-19 18:00:35.397228	2025-10-19 18:00:35.397228
375aee9d-bcbb-4eba-ac62-e032afef861f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	b0a95e11-90ac-4ab3-b099-c4de69f498b8	8c94ef1c-f972-45ba-9aaa-1fa78ab3fc92	ca413110-b7e3-4734-a185-d21ea0960708	2025-07-28	\N	\N	0.75	admin	t	t	85.00	63.75	\N	Tribuo thema cattus sono defleo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-28 18:00:35.371	\N	2025-10-19 18:00:35.401544	2025-10-19 18:00:35.401544
96637c9b-3822-463a-987d-313b04f69706	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	4554e09d-4391-42a8-a2cd-9702bce80511	ae73110f-e045-44ac-85ff-51aa2eb8ce69	18c91d63-8f9d-4974-ba97-a4079c7457d5	2025-07-29	\N	\N	0.50	meeting	f	t	150.00	75.00	\N	Beneficium thesaurus tres recusandae creber usitas animadverto unde sufficio curso.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-29 18:00:35.404	\N	2025-10-19 18:00:35.406019	2025-10-19 18:00:35.406019
7c3805ae-4401-4cb1-a276-d7c302385afe	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	8538cc30-f9e7-4b63-a885-56b23e16ecef	b3d1095b-3d51-444b-be35-f485afdb174f	ecfd2c2c-905b-4ef4-99a4-8949632b9ae9	2025-07-29	\N	\N	3.00	work	t	f	150.00	450.00	\N	Subseco volubilis perspiciatis.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-29 18:00:35.404	\N	2025-10-19 18:00:35.409186	2025-10-19 18:00:35.409186
64488dfb-aecd-4f07-aab9-f29c25ef40e5	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	17f141c2-e297-4c93-9178-0fd819259c50	af41070b-ce93-4cf4-88f6-19ed28a1f1fe	ef53422c-1305-4831-bf41-d85b2a76b0d5	2025-07-29	\N	\N	3.00	work	f	f	150.00	450.00	\N	Cursim vesica administratio carcer tribuo totidem combibo corpus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-29 18:00:35.404	\N	2025-10-19 18:00:35.412842	2025-10-19 18:00:35.412842
68c3b5bf-0ac2-4f37-8632-f005a232ffe3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	67f62599-7f9f-44e8-bc18-d2ce08ea9919	9ec151a2-b6a4-433d-a21e-c94af23b785b	ecfd2c2c-905b-4ef4-99a4-8949632b9ae9	2025-07-29	\N	\N	4.00	work	t	f	120.00	480.00	\N	Delinquo sint ars assumenda sonitus amo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-29 18:00:35.404	\N	2025-10-19 18:00:35.416504	2025-10-19 18:00:35.416504
8884117b-bac6-472f-a6fc-2640014ecced	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	5515e216-ea3c-436b-95a5-6abf213c47ef	18c91d63-8f9d-4974-ba97-a4079c7457d5	2025-07-29	\N	\N	2.00	admin	t	f	120.00	240.00	\N	Angulus varius cado candidus ante tamisium uxor.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-29 18:00:35.404	\N	2025-10-19 18:00:35.420165	2025-10-19 18:00:35.420165
62960621-34fd-4e80-a3ae-97249f87a69e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	5515e216-ea3c-436b-95a5-6abf213c47ef	78882562-2120-44d2-9286-03e696abbf02	2025-07-29	\N	\N	2.75	training	t	f	120.00	330.00	\N	Maxime adamo tener vulariter conicio timor valetudo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-29 18:00:35.404	\N	2025-10-19 18:00:35.424245	2025-10-19 18:00:35.424245
8ec177d2-a4fb-4c20-bf9c-c00ed2c4e58e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	584bab37-ccf2-484c-9a7f-7394e4b30ec6	e64d20a6-86e7-4dd1-ab40-aabaedbd6ebb	cbf9b499-276b-4a28-999c-27388562c4f4	2025-07-29	\N	\N	3.50	meeting	t	f	110.00	385.00	\N	Civitas vulgaris cunabula caecus turbo calamitas.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-29 18:00:35.404	\N	2025-10-19 18:00:35.428756	2025-10-19 18:00:35.428756
5dda13e4-d367-4dee-b305-4d6c816b6ded	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	12edb785-268b-4219-840d-15b8f0df1198	f37ad203-1495-4aec-be30-1b2d7fe4dd70	a0801828-5c53-41ef-9b3e-06db89d72e90	2025-07-29	\N	\N	3.00	admin	f	t	110.00	330.00	\N	Vulgivagus capillus vergo delectatio.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-29 18:00:35.404	\N	2025-10-19 18:00:35.434225	2025-10-19 18:00:35.434225
6447cc07-c5f9-4ec9-91f3-26151b66c28a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	17f141c2-e297-4c93-9178-0fd819259c50	af41070b-ce93-4cf4-88f6-19ed28a1f1fe	a8a65b80-dc4c-49f9-9c8d-0dc4a336cf55	2025-07-29	\N	\N	2.75	research	f	f	85.00	233.75	\N	Degenero cogo rerum error thorax delectus adfero ager adsuesco suscipio.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-29 18:00:35.404	\N	2025-10-19 18:00:35.438358	2025-10-19 18:00:35.438358
419b935f-dab4-49be-b904-6267fd1c494b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	6b008063-17c8-4c31-893b-ef9f17e74f13	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	2025-07-29	\N	\N	0.75	work	t	f	85.00	63.75	\N	Triduana viridis provident conor ultio tutis crinis vilitas.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-29 18:00:35.404	\N	2025-10-19 18:00:35.443335	2025-10-19 18:00:35.443335
d1f2769b-9117-4965-995e-c387c8fc403e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	a4464f5a-2125-46d9-9f58-7252c9adc16b	7041a9f2-cd04-4f9c-ab2c-96bfdd45e5ff	996aa78c-cfd1-477f-8c30-d9489225b29e	2025-07-29	\N	\N	2.00	work	t	f	85.00	170.00	\N	Cubitum officiis patria nisi rem vesica cervus colligo volo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-29 18:00:35.404	\N	2025-10-19 18:00:35.44789	2025-10-19 18:00:35.44789
7da521b8-3a32-4d0a-a246-ad004fd2cb6f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	17f141c2-e297-4c93-9178-0fd819259c50	80260d18-0de6-4cf6-af1d-5b4a1d17a6de	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	2025-07-30	\N	\N	3.00	admin	t	f	150.00	450.00	\N	Verbum triduana asporto amicitia.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-30 18:00:35.45	\N	2025-10-19 18:00:35.451335	2025-10-19 18:00:35.451335
4c55e1ae-b723-4a7a-aaed-8b5735aec829	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	12edb785-268b-4219-840d-15b8f0df1198	e171fa0b-3143-48ec-962f-0917bf1886bf	ca413110-b7e3-4734-a185-d21ea0960708	2025-07-30	\N	\N	1.00	admin	t	t	150.00	150.00	\N	Tergiversatio crustulum quod arbitro porro optio thalassinus incidunt stultus sponte.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-30 18:00:35.45	\N	2025-10-19 18:00:35.454461	2025-10-19 18:00:35.454461
81731ba3-2252-4c3e-9d83-11bcf866c053	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	17f141c2-e297-4c93-9178-0fd819259c50	a18510b4-73e3-40ff-84b1-89c4a2e0bdac	a49c064a-0890-4c02-8734-07a3185e6c03	2025-07-30	\N	\N	3.00	research	f	t	150.00	450.00	\N	Cenaculum vero acer.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-30 18:00:35.45	\N	2025-10-19 18:00:35.458533	2025-10-19 18:00:35.458533
2e3c08c0-f26c-4a73-abb3-a39beadb7d9f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	405d4d05-841b-437d-af7d-70b66dda4cbc	4f8e956e-3c05-4a0d-8695-2014ee9b2f8a	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	2025-07-30	\N	\N	4.00	admin	t	f	120.00	480.00	\N	Crepusculum copiose traho.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-30 18:00:35.45	\N	2025-10-19 18:00:35.461911	2025-10-19 18:00:35.461911
9cb70356-675d-4f37-a460-3916bb5d9c2f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	04465623-29cb-4298-8828-d1839e9cc00d	e4ce7abb-fb0c-42e1-a7c1-6419b4aa63ef	08ee5378-067c-4708-886c-34df4c200b23	2025-07-30	\N	\N	2.75	research	t	f	120.00	330.00	\N	Casus cupiditas capillus confido arbitro ex adficio bis creta.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-30 18:00:35.45	\N	2025-10-19 18:00:35.465836	2025-10-19 18:00:35.465836
81c2c604-5e67-4d75-88ed-59734a7c5fa9	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	7ef8af5a-1080-42a2-988f-ddfa799c8070	5cf17315-4658-4a7f-9c23-b4f8268d8f84	e4487405-7859-40e9-8008-056d32fe6f10	2025-07-30	\N	\N	3.75	research	t	f	120.00	450.00	\N	Laboriosam suffoco culpo mollitia antiquus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-30 18:00:35.45	\N	2025-10-19 18:00:35.469411	2025-10-19 18:00:35.469411
5c5761c6-75f2-4e2c-a08c-9fb906ab3257	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	8538cc30-f9e7-4b63-a885-56b23e16ecef	b3d1095b-3d51-444b-be35-f485afdb174f	18c91d63-8f9d-4974-ba97-a4079c7457d5	2025-07-30	\N	\N	3.25	admin	t	t	120.00	390.00	\N	Omnis aptus conor excepturi varius.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-30 18:00:35.45	\N	2025-10-19 18:00:35.471693	2025-10-19 18:00:35.471693
e1b8094e-809d-4cc6-a00a-41e8abd2f696	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	b0a95e11-90ac-4ab3-b099-c4de69f498b8	8c94ef1c-f972-45ba-9aaa-1fa78ab3fc92	d6d7e47b-cd48-48d8-a45a-fa75af1f9a52	2025-07-30	\N	\N	3.25	work	t	t	110.00	357.50	\N	Celebrer ex veniam suasoria arcus suus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-30 18:00:35.45	\N	2025-10-19 18:00:35.474844	2025-10-19 18:00:35.474844
88a931e1-7cad-44b7-8737-d9e1d993d1de	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	12edb785-268b-4219-840d-15b8f0df1198	f37ad203-1495-4aec-be30-1b2d7fe4dd70	e4487405-7859-40e9-8008-056d32fe6f10	2025-07-30	\N	\N	2.75	research	t	f	110.00	302.50	\N	Arx thermae aliqua vere compello cattus curvo cuius tamisium.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-30 18:00:35.45	\N	2025-10-19 18:00:35.477473	2025-10-19 18:00:35.477473
39348d87-a114-4684-a0a6-5699a69cf1e0	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	6b008063-17c8-4c31-893b-ef9f17e74f13	cbf9b499-276b-4a28-999c-27388562c4f4	2025-07-30	\N	\N	3.50	work	f	f	110.00	385.00	\N	Ademptio numquam incidunt optio.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-30 18:00:35.45	\N	2025-10-19 18:00:35.479629	2025-10-19 18:00:35.479629
b414d3f7-3a2d-4d04-a5ed-7ead5af52c21	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	7ef8af5a-1080-42a2-988f-ddfa799c8070	1c9d17d2-a153-4f42-9604-129a162a1f0f	a0801828-5c53-41ef-9b3e-06db89d72e90	2025-07-30	\N	\N	3.75	admin	f	f	110.00	412.50	\N	Dapifer cerno ducimus tener vos laboriosam asporto corrupti subvenio tantum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-30 18:00:35.45	\N	2025-10-19 18:00:35.481765	2025-10-19 18:00:35.481765
3513424f-d145-433b-8488-45064a3584bd	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	04600664-34f3-4ae0-9a01-2da04b5bc5fc	ef53422c-1305-4831-bf41-d85b2a76b0d5	2025-07-30	\N	\N	0.75	admin	f	f	85.00	63.75	\N	Alveus alo acies confugo doloribus celer aranea.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-30 18:00:35.45	\N	2025-10-19 18:00:35.484127	2025-10-19 18:00:35.484127
85d5a319-08c3-493f-b49b-3ee730faee37	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	46859340-c8cf-4144-aa6c-28fbaf53fa0e	d486be12-5ed8-48b4-af34-79d9269f4c0b	79d01aa5-b680-4830-ab3a-5e3cb66edcfa	2025-07-30	\N	\N	1.25	work	t	f	85.00	106.25	\N	Adduco correptius adulescens vado.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-30 18:00:35.45	\N	2025-10-19 18:00:35.486417	2025-10-19 18:00:35.486417
c3a57af6-2fad-4411-9541-70059b969386	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	46859340-c8cf-4144-aa6c-28fbaf53fa0e	f9444b08-3c00-4407-98d8-3d654600142c	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-07-30	\N	\N	3.25	training	t	t	85.00	276.25	\N	Vulticulus cruentus provident.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-30 18:00:35.45	\N	2025-10-19 18:00:35.488477	2025-10-19 18:00:35.488477
c53cdd7a-70aa-4d4c-adc6-04b89f4fb679	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	6a032ece-4f9e-405a-b48a-b28516d15fe1	062f6587-cb37-4a01-aa03-004703abe1e2	a96c9f4d-dc33-4af3-818d-8d729f0f8c1f	2025-07-31	\N	\N	4.00	meeting	t	f	150.00	600.00	\N	Dolorum aedificium comburo ultio triduana eum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-31 18:00:35.489	\N	2025-10-19 18:00:35.490739	2025-10-19 18:00:35.490739
5d82183e-ab69-489d-a602-2755e1f77f29	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	c8eb351f-daa9-48cf-bc62-2cef6338a122	235b548d-f0a0-4899-9a7e-d6e9bec6db40	2025-07-31	\N	\N	3.25	research	t	f	150.00	487.50	\N	Alo astrum collum inflammatio tabesco compello cras tot.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-31 18:00:35.489	\N	2025-10-19 18:00:35.492935	2025-10-19 18:00:35.492935
1e8221d6-af14-41dc-af17-a0aecf32f1f2	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	7ef8af5a-1080-42a2-988f-ddfa799c8070	1c9d17d2-a153-4f42-9604-129a162a1f0f	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-07-31	\N	\N	3.50	training	t	f	120.00	420.00	\N	Sub corporis voco celebrer adinventitias spiculum alioqui animus conculco.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-31 18:00:35.489	\N	2025-10-19 18:00:35.495078	2025-10-19 18:00:35.495078
b546e643-c8e7-4dfb-acad-1242e2a63e83	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	0d0329f4-4b80-4899-8807-5854e9db312b	e60c944c-85a6-45da-b007-56b5244e0257	e4487405-7859-40e9-8008-056d32fe6f10	2025-07-31	\N	\N	0.75	training	t	t	120.00	90.00	\N	Desidero coruscus cresco.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-31 18:00:35.489	\N	2025-10-19 18:00:35.49874	2025-10-19 18:00:35.49874
57718233-59d1-4289-9001-1376d959ac08	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	46859340-c8cf-4144-aa6c-28fbaf53fa0e	d486be12-5ed8-48b4-af34-79d9269f4c0b	d6d7e47b-cd48-48d8-a45a-fa75af1f9a52	2025-07-31	\N	\N	2.50	research	t	f	120.00	300.00	\N	Vinco agnitio verbera viridis vulgivagus crebro.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-31 18:00:35.489	\N	2025-10-19 18:00:35.503432	2025-10-19 18:00:35.503432
282ae184-5bab-4ac1-abba-e1b530045a90	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	5e2204cd-be52-42a7-aa41-14fcf0e4a272	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-07-31	\N	\N	2.50	meeting	f	t	120.00	300.00	\N	Exercitationem ulciscor desino quod voluptas aequus capitulus tametsi antiquus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-31 18:00:35.489	\N	2025-10-19 18:00:35.507861	2025-10-19 18:00:35.507861
c8e59301-4add-4dd3-b2be-e68a2a99e751	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	d69d0436-37d7-42a4-b907-3d9c3a091ea6	fe24fe87-1db5-4f06-9a5c-46757a20518d	78882562-2120-44d2-9286-03e696abbf02	2025-07-31	\N	\N	0.50	admin	t	t	110.00	55.00	\N	Cavus temperantia cometes contabesco coaegresco audio defetiscor ipsum subseco confugo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-31 18:00:35.489	\N	2025-10-19 18:00:35.511864	2025-10-19 18:00:35.511864
8cb8581b-8896-44d4-83be-71c6fa79b8ab	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	405d4d05-841b-437d-af7d-70b66dda4cbc	219aa257-710f-4ef2-892d-39086a9690ed	e2cd4da6-f171-436c-9c7e-a9c1c5436b98	2025-07-31	\N	\N	3.75	admin	t	t	110.00	412.50	\N	Tener summopere blandior cogito.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-31 18:00:35.489	\N	2025-10-19 18:00:35.516162	2025-10-19 18:00:35.516162
3788d378-ade8-4cde-a2a2-9e18710da244	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	d69d0436-37d7-42a4-b907-3d9c3a091ea6	20222077-caa4-4444-b803-1f75d617ee85	9362cf11-827c-459a-8ffc-6634bd023508	2025-07-31	\N	\N	2.75	meeting	t	f	110.00	302.50	\N	Suadeo communis velum aestus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-31 18:00:35.489	\N	2025-10-19 18:00:35.519654	2025-10-19 18:00:35.519654
bc090d38-65a3-4f40-8d59-4d4ac6aad146	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	b7295600-5c20-4de2-8782-af87987c2bee	d2f831e1-38ca-429c-9942-06db88f8dfc5	18c91d63-8f9d-4974-ba97-a4079c7457d5	2025-07-31	\N	\N	1.50	work	f	f	85.00	127.50	\N	Tamisium vir vos cupiditate benigne.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-31 18:00:35.489	\N	2025-10-19 18:00:35.523383	2025-10-19 18:00:35.523383
ed32393c-a2c7-41f6-8f9d-da54c449dffb	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	4554e09d-4391-42a8-a2cd-9702bce80511	ae73110f-e045-44ac-85ff-51aa2eb8ce69	109283c7-55ef-4e05-bf53-c6efd1be486f	2025-07-31	\N	\N	1.50	meeting	f	t	85.00	127.50	\N	Appello cetera veniam accendo depraedor placeat assumenda utroque terminatio acsi.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-31 18:00:35.489	\N	2025-10-19 18:00:35.526699	2025-10-19 18:00:35.526699
121c62b5-595b-4dd5-a2b6-e3d1c49a85da	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	2db210d6-c799-49db-b61d-9aff5f87f1f0	996aa78c-cfd1-477f-8c30-d9489225b29e	2025-07-31	\N	\N	1.75	research	f	f	85.00	148.75	\N	Sequi vinitor stillicidium creptio vallum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-31 18:00:35.489	\N	2025-10-19 18:00:35.530159	2025-10-19 18:00:35.530159
75c1d99d-a9be-4151-adab-96a297e11e71	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	b7295600-5c20-4de2-8782-af87987c2bee	2849d1a9-72a4-4287-8114-b604140c71aa	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-07-31	\N	\N	1.00	admin	t	f	85.00	85.00	\N	Doloremque careo brevis tergum cerno.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-07-31 18:00:35.489	\N	2025-10-19 18:00:35.534209	2025-10-19 18:00:35.534209
fa17f9a5-1449-4b8c-81be-a34ad919596d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	584bab37-ccf2-484c-9a7f-7394e4b30ec6	71b851af-8542-47e4-9ff8-304ed5983a0b	e4487405-7859-40e9-8008-056d32fe6f10	2025-08-01	\N	\N	0.50	research	t	t	150.00	75.00	\N	Complectus eius ventito sodalitas templum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-01 18:00:35.536	\N	2025-10-19 18:00:35.538976	2025-10-19 18:00:35.538976
98633f54-9951-4e8b-bcf1-b816b5b35057	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	7ef8af5a-1080-42a2-988f-ddfa799c8070	5cf17315-4658-4a7f-9c23-b4f8268d8f84	391f7d87-df5d-4538-9b3e-31e07ac9347e	2025-08-05	\N	\N	2.00	research	f	f	150.00	300.00	\N	Adflicto decimus ullus compono alo iste.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-05 18:00:35.647	\N	2025-10-19 18:00:35.649159	2025-10-19 18:00:35.649159
6865cb9c-c7cc-4bb1-bd02-f296ce31cbec	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	8538cc30-f9e7-4b63-a885-56b23e16ecef	b3d1095b-3d51-444b-be35-f485afdb174f	109283c7-55ef-4e05-bf53-c6efd1be486f	2025-08-01	\N	\N	2.00	research	f	f	150.00	300.00	\N	Voluptatem adicio defessus adimpleo textus ante cerno ultra bos.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-01 18:00:35.536	\N	2025-10-19 18:00:35.543067	2025-10-19 18:00:35.543067
490ccaf9-272f-4377-80c2-d13f298b2608	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	4554e09d-4391-42a8-a2cd-9702bce80511	ae73110f-e045-44ac-85ff-51aa2eb8ce69	08ee5378-067c-4708-886c-34df4c200b23	2025-08-01	\N	\N	3.00	training	t	f	150.00	450.00	\N	Adsuesco ater suppellex cumque.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-01 18:00:35.536	\N	2025-10-19 18:00:35.546905	2025-10-19 18:00:35.546905
19f9bcd9-1243-42ab-848b-20a88eb185ab	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	702b5a48-f7a9-464c-8833-1ff6577e50e6	0da2984a-30cb-4fdf-a4f6-b38ff97be406	996aa78c-cfd1-477f-8c30-d9489225b29e	2025-08-01	\N	\N	1.75	training	t	t	120.00	210.00	\N	Ventito audax taedium arbor coepi coruscus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-01 18:00:35.536	\N	2025-10-19 18:00:35.552106	2025-10-19 18:00:35.552106
f976d197-8686-4a1b-93fc-2cb0d16b07ce	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	6ecda653-6094-4502-9d1d-6e90d9ea99ed	4fb9cb0a-ca36-4af7-9203-ac1970ce555b	78882562-2120-44d2-9286-03e696abbf02	2025-08-01	\N	\N	2.00	training	t	f	120.00	240.00	\N	Subseco cattus totus volubilis civitas dens centum audacia tactus synagoga.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-01 18:00:35.536	\N	2025-10-19 18:00:35.557319	2025-10-19 18:00:35.557319
9f402fd7-100a-4433-a62a-91404997a5cd	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	67f62599-7f9f-44e8-bc18-d2ce08ea9919	419cb8f8-8b70-44a5-883b-8fa92787aa46	cbf9b499-276b-4a28-999c-27388562c4f4	2025-08-01	\N	\N	3.25	work	t	f	120.00	390.00	\N	Volutabrum velit aliquam virtus cumque sursum amoveo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-01 18:00:35.536	\N	2025-10-19 18:00:35.562329	2025-10-19 18:00:35.562329
e0b08f78-f9cf-434c-9557-f68198ddf446	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	d69d0436-37d7-42a4-b907-3d9c3a091ea6	20222077-caa4-4444-b803-1f75d617ee85	29a61f52-d957-4207-b54b-7fc565a57541	2025-08-01	\N	\N	1.50	training	t	f	110.00	165.00	\N	Coniecto alii demonstro.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-01 18:00:35.536	\N	2025-10-19 18:00:35.566559	2025-10-19 18:00:35.566559
8990d10c-60be-43d1-9b95-e1da15876c1c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	98f9340d-eadb-45cd-bba2-115aa880f565	1ede1cc0-3627-404e-bb8a-487e028f4732	2025-08-01	\N	\N	2.00	work	f	f	110.00	220.00	\N	Traho vilitas advoco tamdiu explicabo cattus urbs mollitia tui ultra.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-01 18:00:35.536	\N	2025-10-19 18:00:35.57078	2025-10-19 18:00:35.57078
f3433483-a5ed-4f60-b7e0-fd42972462fa	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	65a6152e-a261-4a70-99fb-82f044e87d05	b7a77905-edd5-451e-a92e-06976feeb638	cbf9b499-276b-4a28-999c-27388562c4f4	2025-08-01	\N	\N	0.50	admin	t	f	110.00	55.00	\N	Cinis trepide sponte inventore uberrime carmen cum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-01 18:00:35.536	\N	2025-10-19 18:00:35.574911	2025-10-19 18:00:35.574911
7bdaaf1c-d86a-40bf-8569-b0ee0148641d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	584bab37-ccf2-484c-9a7f-7394e4b30ec6	7a582f98-6d3d-44d5-9796-ba1d12c49f62	a0801828-5c53-41ef-9b3e-06db89d72e90	2025-08-01	\N	\N	2.25	meeting	f	f	85.00	191.25	\N	Videlicet votum defungo iure.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-01 18:00:35.536	\N	2025-10-19 18:00:35.58014	2025-10-19 18:00:35.58014
ed8c06df-af2f-4854-93a9-7efa770e39c3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	04465623-29cb-4298-8828-d1839e9cc00d	e4ce7abb-fb0c-42e1-a7c1-6419b4aa63ef	79d01aa5-b680-4830-ab3a-5e3cb66edcfa	2025-08-01	\N	\N	4.00	admin	t	t	85.00	340.00	\N	Cognatus vulariter confero derideo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-01 18:00:35.536	\N	2025-10-19 18:00:35.584911	2025-10-19 18:00:35.584911
60c5bb81-788f-4124-8049-97da50f15870	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	45b3d726-e151-4770-9b64-4653914bdaa5	449f8e23-33a0-4bf0-915e-cc79d13bc3a9	109283c7-55ef-4e05-bf53-c6efd1be486f	2025-08-04	\N	\N	1.25	work	t	f	150.00	187.50	\N	Claro et voluptas vesco voluptates.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-04 18:00:35.586	\N	2025-10-19 18:00:35.588179	2025-10-19 18:00:35.588179
e25c5b9a-67d2-4661-883d-3dc86594d95a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	d69d0436-37d7-42a4-b907-3d9c3a091ea6	fe24fe87-1db5-4f06-9a5c-46757a20518d	ef53422c-1305-4831-bf41-d85b2a76b0d5	2025-08-04	\N	\N	2.50	training	t	t	150.00	375.00	\N	Desino cetera vestigium cursim vilicus depopulo tutis teres cohibeo audax.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-04 18:00:35.586	\N	2025-10-19 18:00:35.592207	2025-10-19 18:00:35.592207
1687cd75-d171-4626-ace4-89789fb590e7	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	67f62599-7f9f-44e8-bc18-d2ce08ea9919	9ec151a2-b6a4-433d-a21e-c94af23b785b	79d01aa5-b680-4830-ab3a-5e3cb66edcfa	2025-08-04	\N	\N	3.00	meeting	t	f	150.00	450.00	\N	Vae thorax statim.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-04 18:00:35.586	\N	2025-10-19 18:00:35.595756	2025-10-19 18:00:35.595756
53974488-1062-41b0-a5d2-27aabfea5379	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	405d4d05-841b-437d-af7d-70b66dda4cbc	4f8e956e-3c05-4a0d-8695-2014ee9b2f8a	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	2025-08-04	\N	\N	1.75	admin	t	f	120.00	210.00	\N	Calamitas clam accusantium curso quas tripudio atrocitas textus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-04 18:00:35.586	\N	2025-10-19 18:00:35.599951	2025-10-19 18:00:35.599951
d9e40398-a7f9-49e0-9236-65145bca189b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	6ecda653-6094-4502-9d1d-6e90d9ea99ed	6c88f260-519e-41e9-9fac-18a28b9a7901	a0801828-5c53-41ef-9b3e-06db89d72e90	2025-08-04	\N	\N	1.50	meeting	t	f	120.00	180.00	\N	Desidero absconditus suscipit cupiditas umbra tergeo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-04 18:00:35.586	\N	2025-10-19 18:00:35.604182	2025-10-19 18:00:35.604182
c5f668f5-0ca7-436d-884a-ff6838aec742	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	c8eb351f-daa9-48cf-bc62-2cef6338a122	a49c064a-0890-4c02-8734-07a3185e6c03	2025-08-04	\N	\N	0.50	research	t	f	120.00	60.00	\N	Vomer confugo sit.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-04 18:00:35.586	\N	2025-10-19 18:00:35.608232	2025-10-19 18:00:35.608232
03c79cdb-fe34-41c4-a74f-c10e4b6ee8e2	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	6ecda653-6094-4502-9d1d-6e90d9ea99ed	4fb9cb0a-ca36-4af7-9203-ac1970ce555b	e4487405-7859-40e9-8008-056d32fe6f10	2025-08-04	\N	\N	3.25	meeting	t	f	120.00	390.00	\N	Eligendi arcus vacuus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-04 18:00:35.586	\N	2025-10-19 18:00:35.612318	2025-10-19 18:00:35.612318
d02d5ea5-c211-4657-bc12-84c703d6e8f6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	2db210d6-c799-49db-b61d-9aff5f87f1f0	79d01aa5-b680-4830-ab3a-5e3cb66edcfa	2025-08-04	\N	\N	4.00	training	t	f	110.00	440.00	\N	Tutis reiciendis arma agnosco condico.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-04 18:00:35.586	\N	2025-10-19 18:00:35.616434	2025-10-19 18:00:35.616434
54b7d28e-cd6c-4012-bd87-c690d77ea807	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	6a032ece-4f9e-405a-b48a-b28516d15fe1	7add02b8-5d73-4a39-8607-6f9d17b36fda	ff4a2600-29fe-4448-bec3-ea868988a9ed	2025-08-04	\N	\N	2.75	research	t	t	110.00	302.50	\N	Animus stips terror adinventitias.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-04 18:00:35.586	\N	2025-10-19 18:00:35.619717	2025-10-19 18:00:35.619717
09b63117-7b01-4fb8-814b-5db5936bc534	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	088446c4-4542-4007-9887-b512bd3db05d	109283c7-55ef-4e05-bf53-c6efd1be486f	2025-08-04	\N	\N	1.00	meeting	t	t	110.00	110.00	\N	Vinitor nisi tres.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-04 18:00:35.586	\N	2025-10-19 18:00:35.623241	2025-10-19 18:00:35.623241
ed5283ef-6988-4742-b89f-7cebc073e405	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	6ecda653-6094-4502-9d1d-6e90d9ea99ed	4fb9cb0a-ca36-4af7-9203-ac1970ce555b	cbf9b499-276b-4a28-999c-27388562c4f4	2025-08-04	\N	\N	2.00	admin	t	f	110.00	220.00	\N	Communis amoveo quisquam arbitro curto bis terreo valens.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-04 18:00:35.586	\N	2025-10-19 18:00:35.627062	2025-10-19 18:00:35.627062
d6d0bf50-5391-45e6-b512-6fd935274d0a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	12edb785-268b-4219-840d-15b8f0df1198	f37ad203-1495-4aec-be30-1b2d7fe4dd70	391f7d87-df5d-4538-9b3e-31e07ac9347e	2025-08-04	\N	\N	0.50	work	t	f	110.00	55.00	\N	Circumvenio atrox doloremque asper conservo commemoro.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-04 18:00:35.586	\N	2025-10-19 18:00:35.631419	2025-10-19 18:00:35.631419
a989bb2a-f61c-4a10-a767-889e41411115	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	b7295600-5c20-4de2-8782-af87987c2bee	d2f831e1-38ca-429c-9942-06db88f8dfc5	ef53422c-1305-4831-bf41-d85b2a76b0d5	2025-08-04	\N	\N	0.50	research	f	f	85.00	42.50	\N	Molestias utique quia vado cumque calamitas sumo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-04 18:00:35.586	\N	2025-10-19 18:00:35.636005	2025-10-19 18:00:35.636005
301010d3-e0b2-4711-9aed-10155eda6e4e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	45b3d726-e151-4770-9b64-4653914bdaa5	92700c16-c146-4a6e-9610-46ac28f4b4c3	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-08-04	\N	\N	1.00	meeting	t	t	85.00	85.00	\N	Abstergo una vociferor absque quaerat solio curatio vel alienus usus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-04 18:00:35.586	\N	2025-10-19 18:00:35.640002	2025-10-19 18:00:35.640002
69dfa962-2dca-4716-a314-bc015bdc78aa	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	5e2204cd-be52-42a7-aa41-14fcf0e4a272	3f2e9a8e-bdfe-4d09-aced-e88cdc710462	2025-08-04	\N	\N	2.50	work	f	t	85.00	212.50	\N	Usus comburo deinde aurum amita ait nam vitiosus abbas bos.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-04 18:00:35.586	\N	2025-10-19 18:00:35.643999	2025-10-19 18:00:35.643999
6b1b7547-9a1d-48da-9859-b85dbde150cd	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	7ef8af5a-1080-42a2-988f-ddfa799c8070	5cf17315-4658-4a7f-9c23-b4f8268d8f84	a49c064a-0890-4c02-8734-07a3185e6c03	2025-08-05	\N	\N	2.25	meeting	t	f	150.00	337.50	\N	Compono ciminatio nobis aurum velociter deorsum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-05 18:00:35.647	\N	2025-10-19 18:00:35.653106	2025-10-19 18:00:35.653106
6bd17c52-e3cf-404a-85b9-361f4ef4e341	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	405d4d05-841b-437d-af7d-70b66dda4cbc	9485b00c-4fc8-454f-984a-6908039db9f9	9362cf11-827c-459a-8ffc-6634bd023508	2025-08-05	\N	\N	2.00	research	t	f	150.00	300.00	\N	Ara derelinquo audio vivo curso angulus laborum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-05 18:00:35.647	\N	2025-10-19 18:00:35.655729	2025-10-19 18:00:35.655729
1bc660b2-5657-4ff5-9cda-115878198fd2	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	b0a95e11-90ac-4ab3-b099-c4de69f498b8	269dca40-b352-4a09-9d7c-c735016a8c7d	1ede1cc0-3627-404e-bb8a-487e028f4732	2025-08-05	\N	\N	0.75	training	t	f	150.00	112.50	\N	Defungo commodi surgo vis confugo defluo audeo advoco cicuta caveo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-05 18:00:35.647	\N	2025-10-19 18:00:35.658346	2025-10-19 18:00:35.658346
c6040638-e2dd-4c90-9431-419cadd594ec	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	0d0329f4-4b80-4899-8807-5854e9db312b	40ca5c4e-33d7-432f-a55c-b59c3010d7ef	78882562-2120-44d2-9286-03e696abbf02	2025-08-05	\N	\N	1.50	training	t	f	120.00	180.00	\N	Perspiciatis ulciscor tutis illo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-05 18:00:35.647	\N	2025-10-19 18:00:35.661305	2025-10-19 18:00:35.661305
ef242cda-451d-4512-8ead-bdf34d45623c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	7ef8af5a-1080-42a2-988f-ddfa799c8070	1c9d17d2-a153-4f42-9604-129a162a1f0f	3f2e9a8e-bdfe-4d09-aced-e88cdc710462	2025-08-05	\N	\N	1.50	research	t	t	120.00	180.00	\N	Circumvenio quisquam alius adopto astrum voluptas claro tui.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-05 18:00:35.647	\N	2025-10-19 18:00:35.664802	2025-10-19 18:00:35.664802
b005fc3d-8263-4d92-95a2-cc02637b884a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	4554e09d-4391-42a8-a2cd-9702bce80511	ae73110f-e045-44ac-85ff-51aa2eb8ce69	1ede1cc0-3627-404e-bb8a-487e028f4732	2025-08-05	\N	\N	2.50	meeting	t	t	120.00	300.00	\N	Auditor confido mollitia turpis vulgus coepi theologus aspicio annus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-05 18:00:35.647	\N	2025-10-19 18:00:35.668821	2025-10-19 18:00:35.668821
3545a194-8181-4f5e-810f-48f6c2cd37b0	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	088446c4-4542-4007-9887-b512bd3db05d	a96c9f4d-dc33-4af3-818d-8d729f0f8c1f	2025-08-05	\N	\N	1.25	research	f	f	110.00	137.50	\N	Bonus demo umerus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-05 18:00:35.647	\N	2025-10-19 18:00:35.671934	2025-10-19 18:00:35.671934
15027617-dacf-4733-b199-72119d18c24c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	5e2204cd-be52-42a7-aa41-14fcf0e4a272	996aa78c-cfd1-477f-8c30-d9489225b29e	2025-08-05	\N	\N	3.25	research	f	f	110.00	357.50	\N	Asporto candidus cena derelinquo talis calamitas.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-05 18:00:35.647	\N	2025-10-19 18:00:35.67497	2025-10-19 18:00:35.67497
0c7cbda5-caaa-476a-af9b-df169cbe8b60	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	584bab37-ccf2-484c-9a7f-7394e4b30ec6	ff7b1e48-6594-4997-9b76-46ab909220e2	cbf9b499-276b-4a28-999c-27388562c4f4	2025-08-05	\N	\N	3.00	meeting	f	f	110.00	330.00	\N	Tam titulus certe volup alioqui charisma sed caelum corpus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-05 18:00:35.647	\N	2025-10-19 18:00:35.679755	2025-10-19 18:00:35.679755
bb142940-5926-48e8-8bb2-e06191a45575	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	12edb785-268b-4219-840d-15b8f0df1198	f37ad203-1495-4aec-be30-1b2d7fe4dd70	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	2025-08-05	\N	\N	3.00	admin	f	f	110.00	330.00	\N	Asperiores vigilo reiciendis dolorem fuga cruentus sollers contra.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-05 18:00:35.647	\N	2025-10-19 18:00:35.684907	2025-10-19 18:00:35.684907
7da673d7-ba52-437b-8f6f-93230f635817	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	12edb785-268b-4219-840d-15b8f0df1198	f37ad203-1495-4aec-be30-1b2d7fe4dd70	ecfd2c2c-905b-4ef4-99a4-8949632b9ae9	2025-08-05	\N	\N	1.75	research	t	f	85.00	148.75	\N	Quis statim tersus centum reiciendis angulus cupressus stella.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-05 18:00:35.647	\N	2025-10-19 18:00:35.688648	2025-10-19 18:00:35.688648
1432e52c-81c1-49d8-b77f-638adebd12c7	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	7ef8af5a-1080-42a2-988f-ddfa799c8070	5cf17315-4658-4a7f-9c23-b4f8268d8f84	e4487405-7859-40e9-8008-056d32fe6f10	2025-08-05	\N	\N	3.50	training	f	f	85.00	297.50	\N	Consequuntur ter caput deorsum dolores possimus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-05 18:00:35.647	\N	2025-10-19 18:00:35.691692	2025-10-19 18:00:35.691692
377c9955-e0ca-451e-938c-6c14b6772865	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	45b3d726-e151-4770-9b64-4653914bdaa5	be3f2d80-2e55-4bec-bd5e-02e5a00444a9	78882562-2120-44d2-9286-03e696abbf02	2025-08-05	\N	\N	0.75	work	t	f	85.00	63.75	\N	Comitatus voluptas in cito crudelis amoveo urbs.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-05 18:00:35.647	\N	2025-10-19 18:00:35.694526	2025-10-19 18:00:35.694526
b814843f-3908-494f-8383-4e8a7a1f2242	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	b0a95e11-90ac-4ab3-b099-c4de69f498b8	8c94ef1c-f972-45ba-9aaa-1fa78ab3fc92	d6d7e47b-cd48-48d8-a45a-fa75af1f9a52	2025-08-06	\N	\N	3.50	research	t	t	150.00	525.00	\N	Cerno crapula animus nobis ab.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-06 18:00:35.695	\N	2025-10-19 18:00:35.697412	2025-10-19 18:00:35.697412
b609235f-1d27-49ef-865a-5abdfce2502f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	45b3d726-e151-4770-9b64-4653914bdaa5	449f8e23-33a0-4bf0-915e-cc79d13bc3a9	a8a65b80-dc4c-49f9-9c8d-0dc4a336cf55	2025-08-06	\N	\N	0.75	meeting	t	f	150.00	112.50	\N	Rem abbas valetudo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-06 18:00:35.695	\N	2025-10-19 18:00:35.699732	2025-10-19 18:00:35.699732
3af29862-fe16-46fe-acdb-e43402b3a46d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	b0a95e11-90ac-4ab3-b099-c4de69f498b8	8c94ef1c-f972-45ba-9aaa-1fa78ab3fc92	d6d7e47b-cd48-48d8-a45a-fa75af1f9a52	2025-08-06	\N	\N	1.25	meeting	f	f	150.00	187.50	\N	Ambitus armarium commodo deleo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-06 18:00:35.695	\N	2025-10-19 18:00:35.702486	2025-10-19 18:00:35.702486
fb3deff5-6b62-4023-8c31-5364536ad494	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	8538cc30-f9e7-4b63-a885-56b23e16ecef	b3d1095b-3d51-444b-be35-f485afdb174f	3f2e9a8e-bdfe-4d09-aced-e88cdc710462	2025-08-06	\N	\N	0.50	research	t	f	120.00	60.00	\N	Decor approbo statim vulnero artificiose defendo uterque utroque termes ater.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-06 18:00:35.695	\N	2025-10-19 18:00:35.705627	2025-10-19 18:00:35.705627
bad87b72-bb85-4426-b9b2-b10f3d039415	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	07b65174-c767-4ace-ac22-e486eb422fa6	1ede1cc0-3627-404e-bb8a-487e028f4732	2025-08-06	\N	\N	1.00	admin	t	t	120.00	120.00	\N	Caute aspicio maiores textus repellat vilis.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-06 18:00:35.695	\N	2025-10-19 18:00:35.710173	2025-10-19 18:00:35.710173
5d33c62e-2602-4815-9662-b8bbb6569187	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	405d4d05-841b-437d-af7d-70b66dda4cbc	219aa257-710f-4ef2-892d-39086a9690ed	a49c064a-0890-4c02-8734-07a3185e6c03	2025-08-06	\N	\N	2.75	admin	t	f	110.00	302.50	\N	Ter cariosus anser vomito arbitro sint cruciamentum ulterius dicta viriliter.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-06 18:00:35.695	\N	2025-10-19 18:00:35.713814	2025-10-19 18:00:35.713814
218f54da-7817-4a43-8da3-414fc670463e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	45b3d726-e151-4770-9b64-4653914bdaa5	92700c16-c146-4a6e-9610-46ac28f4b4c3	9362cf11-827c-459a-8ffc-6634bd023508	2025-08-06	\N	\N	2.50	research	t	f	110.00	275.00	\N	Ars deleo suasoria aggredior ambulo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-06 18:00:35.695	\N	2025-10-19 18:00:35.717578	2025-10-19 18:00:35.717578
55993468-1259-45e4-adce-cfa4d8d4f722	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	6ecda653-6094-4502-9d1d-6e90d9ea99ed	6c88f260-519e-41e9-9fac-18a28b9a7901	d04961e2-5af7-4b9c-bb44-c37031dd6bfa	2025-08-06	\N	\N	3.00	admin	t	f	110.00	330.00	\N	Ullam astrum decimus contigo curia debeo comminor depromo adopto.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-06 18:00:35.695	\N	2025-10-19 18:00:35.720665	2025-10-19 18:00:35.720665
cf39cdb0-79de-47a5-a792-9cc0e06c5ad4	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	4554e09d-4391-42a8-a2cd-9702bce80511	ae73110f-e045-44ac-85ff-51aa2eb8ce69	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	2025-08-06	\N	\N	3.00	training	f	f	110.00	330.00	\N	Laboriosam illo succedo vigilo optio clamo absorbeo vesper.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-06 18:00:35.695	\N	2025-10-19 18:00:35.723678	2025-10-19 18:00:35.723678
2c885a02-6a97-4d03-a947-9665ad032f67	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	04465623-29cb-4298-8828-d1839e9cc00d	e4ce7abb-fb0c-42e1-a7c1-6419b4aa63ef	ef53422c-1305-4831-bf41-d85b2a76b0d5	2025-08-06	\N	\N	1.50	admin	t	f	85.00	127.50	\N	Qui cerno corona.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-06 18:00:35.695	\N	2025-10-19 18:00:35.726771	2025-10-19 18:00:35.726771
cf01e6d6-d7d4-439e-a8dc-5d4d79e36db7	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	12edb785-268b-4219-840d-15b8f0df1198	e171fa0b-3143-48ec-962f-0917bf1886bf	08ee5378-067c-4708-886c-34df4c200b23	2025-08-06	\N	\N	1.25	meeting	t	f	85.00	106.25	\N	Arguo collum defero currus celer voco.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-06 18:00:35.695	\N	2025-10-19 18:00:35.729762	2025-10-19 18:00:35.729762
794896fa-652b-46ed-b74d-eb09aed1ac96	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	67f62599-7f9f-44e8-bc18-d2ce08ea9919	9ec151a2-b6a4-433d-a21e-c94af23b785b	e4487405-7859-40e9-8008-056d32fe6f10	2025-08-07	\N	\N	3.75	work	t	t	150.00	562.50	\N	Ullus celo vobis addo voluptates deprimo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-07 18:00:35.731	\N	2025-10-19 18:00:35.732483	2025-10-19 18:00:35.732483
0e087020-bceb-4d67-b8be-ea4e4405d24c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	702b5a48-f7a9-464c-8833-1ff6577e50e6	66d28217-b458-4ec3-9e88-eb34570556b7	9362cf11-827c-459a-8ffc-6634bd023508	2025-08-07	\N	\N	3.50	research	f	f	150.00	525.00	\N	Non adsum votum tabella carus terebro viridis adflicto audio.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-07 18:00:35.731	\N	2025-10-19 18:00:35.734964	2025-10-19 18:00:35.734964
c8c137ab-f613-427e-8d2e-5840c989cef9	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	5515e216-ea3c-436b-95a5-6abf213c47ef	a8a65b80-dc4c-49f9-9c8d-0dc4a336cf55	2025-08-07	\N	\N	1.50	research	t	t	150.00	225.00	\N	Decimus tolero suppellex cotidie.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-07 18:00:35.731	\N	2025-10-19 18:00:35.737296	2025-10-19 18:00:35.737296
14797554-39f5-49da-8184-516667446bd2	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	5e2204cd-be52-42a7-aa41-14fcf0e4a272	391f7d87-df5d-4538-9b3e-31e07ac9347e	2025-08-07	\N	\N	3.50	training	t	t	150.00	525.00	\N	Angustus curto una adeo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-07 18:00:35.731	\N	2025-10-19 18:00:35.739545	2025-10-19 18:00:35.739545
e36c6848-c790-4a6a-951e-01e8b3bd2e17	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	405d4d05-841b-437d-af7d-70b66dda4cbc	9485b00c-4fc8-454f-984a-6908039db9f9	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-08-07	\N	\N	2.75	work	t	f	120.00	330.00	\N	Aeternus delego decet circumvenio adicio apto ademptio theca.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-07 18:00:35.731	\N	2025-10-19 18:00:35.741672	2025-10-19 18:00:35.741672
97f6634b-f9d1-4c52-bad7-1bdb1ccd25e0	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	67f62599-7f9f-44e8-bc18-d2ce08ea9919	ed074125-f8db-4b46-af39-96ce8eb67c4b	d6d7e47b-cd48-48d8-a45a-fa75af1f9a52	2025-08-07	\N	\N	3.25	work	t	f	120.00	390.00	\N	Antea canis vero summa porro astrum vulticulus conitor.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-07 18:00:35.731	\N	2025-10-19 18:00:35.743832	2025-10-19 18:00:35.743832
39550161-940d-4064-9797-e9d93320a61f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	b0a95e11-90ac-4ab3-b099-c4de69f498b8	8c94ef1c-f972-45ba-9aaa-1fa78ab3fc92	996aa78c-cfd1-477f-8c30-d9489225b29e	2025-08-07	\N	\N	3.75	admin	t	f	110.00	412.50	\N	Facere consequuntur crinis paulatim vomica super vallum umquam vinco cervus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-07 18:00:35.731	\N	2025-10-19 18:00:35.74595	2025-10-19 18:00:35.74595
7dfb272b-8b33-465c-ae84-ff4a03dbe005	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	8538cc30-f9e7-4b63-a885-56b23e16ecef	b3d1095b-3d51-444b-be35-f485afdb174f	9362cf11-827c-459a-8ffc-6634bd023508	2025-08-07	\N	\N	0.50	work	t	f	110.00	55.00	\N	Copia coniecto venio occaecati derelinquo tutamen vaco.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-07 18:00:35.731	\N	2025-10-19 18:00:35.747897	2025-10-19 18:00:35.747897
fef5f268-f275-48b6-9312-1a693f02e809	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	702b5a48-f7a9-464c-8833-1ff6577e50e6	6ebdfde2-aeab-4596-9744-cef10c12a313	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-08-07	\N	\N	1.50	training	t	t	110.00	165.00	\N	Demoror defluo voluptatum despecto tripudio dolores.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-07 18:00:35.731	\N	2025-10-19 18:00:35.749833	2025-10-19 18:00:35.749833
dbbb1d4d-0865-484f-a6fe-e0bf37615fa9	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	702b5a48-f7a9-464c-8833-1ff6577e50e6	66d28217-b458-4ec3-9e88-eb34570556b7	e2cd4da6-f171-436c-9c7e-a9c1c5436b98	2025-08-07	\N	\N	2.25	research	t	f	110.00	247.50	\N	Dolorum adulatio voveo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-07 18:00:35.731	\N	2025-10-19 18:00:35.751481	2025-10-19 18:00:35.751481
c2bbd200-69ab-4148-9d5a-07338bce5993	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	088446c4-4542-4007-9887-b512bd3db05d	79d01aa5-b680-4830-ab3a-5e3cb66edcfa	2025-08-07	\N	\N	1.50	training	t	f	110.00	165.00	\N	Surgo vicinus depopulo laborum aeternus illo cernuus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-07 18:00:35.731	\N	2025-10-19 18:00:35.752977	2025-10-19 18:00:35.752977
5958a6a4-1833-4b64-81ae-b57f839a14aa	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	4554e09d-4391-42a8-a2cd-9702bce80511	ae73110f-e045-44ac-85ff-51aa2eb8ce69	391f7d87-df5d-4538-9b3e-31e07ac9347e	2025-08-07	\N	\N	1.75	work	t	t	85.00	148.75	\N	Terebro quidem suscipio delectus vicissitudo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-07 18:00:35.731	\N	2025-10-19 18:00:35.754754	2025-10-19 18:00:35.754754
6ff9ec05-83f1-42e4-97d2-3f447022dbe7	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	6b008063-17c8-4c31-893b-ef9f17e74f13	a0801828-5c53-41ef-9b3e-06db89d72e90	2025-08-07	\N	\N	2.75	research	f	f	85.00	233.75	\N	Ut aptus verto adhaero.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-07 18:00:35.731	\N	2025-10-19 18:00:35.756448	2025-10-19 18:00:35.756448
925c1a38-42f6-41f5-9513-1c1c547c9941	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	96a103f5-bc5b-43e1-b321-62fedda6eaa1	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	2025-08-07	\N	\N	3.00	admin	t	f	85.00	255.00	\N	Utique urbs amoveo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-07 18:00:35.731	\N	2025-10-19 18:00:35.758005	2025-10-19 18:00:35.758005
2041eda9-e20f-4dbb-8eb9-859c8231be7f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	98f9340d-eadb-45cd-bba2-115aa880f565	ef53422c-1305-4831-bf41-d85b2a76b0d5	2025-08-08	\N	\N	3.25	training	t	f	150.00	487.50	\N	Repellendus alveus deprecator qui vorago confugo labore summisse vulgivagus tracto.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-08 18:00:35.759	\N	2025-10-19 18:00:35.759695	2025-10-19 18:00:35.759695
58f55a53-3527-4d6b-8fc3-fbf34c2e5b12	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	d69d0436-37d7-42a4-b907-3d9c3a091ea6	0b689153-0b45-4725-866b-5eac75a40ad8	d6d7e47b-cd48-48d8-a45a-fa75af1f9a52	2025-08-08	\N	\N	3.00	work	f	t	150.00	450.00	\N	Temptatio varius thorax avaritia vulnus adstringo bos vomer.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-08 18:00:35.759	\N	2025-10-19 18:00:35.761468	2025-10-19 18:00:35.761468
8c4c1261-8b90-4a58-9c4b-9d35ba526da9	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	65a6152e-a261-4a70-99fb-82f044e87d05	2105be2b-df4f-494a-bb20-548a7dbda952	79d01aa5-b680-4830-ab3a-5e3cb66edcfa	2025-08-08	\N	\N	3.50	research	t	f	150.00	525.00	\N	Cubitum arma calculus ventosus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-08 18:00:35.759	\N	2025-10-19 18:00:35.763351	2025-10-19 18:00:35.763351
8a0a43f9-34e3-4142-a810-a02c992bbae7	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	5e2204cd-be52-42a7-aa41-14fcf0e4a272	ff4a2600-29fe-4448-bec3-ea868988a9ed	2025-08-08	\N	\N	3.00	admin	t	t	120.00	360.00	\N	Assumenda surculus peior contigo pauper absorbeo agnosco vado validus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-08 18:00:35.759	\N	2025-10-19 18:00:35.765191	2025-10-19 18:00:35.765191
e480c227-d3d7-4d9d-8a3c-0d2e9c8ad629	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	5e2204cd-be52-42a7-aa41-14fcf0e4a272	d6d7e47b-cd48-48d8-a45a-fa75af1f9a52	2025-08-08	\N	\N	0.75	admin	f	f	120.00	90.00	\N	Valde cohibeo adopto clarus desparatus cubo thesaurus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-08 18:00:35.759	\N	2025-10-19 18:00:35.767629	2025-10-19 18:00:35.767629
3b4845ef-7f8c-474b-94fa-d2f1d0207a62	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	45b3d726-e151-4770-9b64-4653914bdaa5	be3f2d80-2e55-4bec-bd5e-02e5a00444a9	cbf9b499-276b-4a28-999c-27388562c4f4	2025-08-08	\N	\N	1.50	meeting	t	t	110.00	165.00	\N	Accommodo coadunatio vesper tantillus civitas provident tres.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-08 18:00:35.759	\N	2025-10-19 18:00:35.769789	2025-10-19 18:00:35.769789
df7dceee-4d88-467f-9d04-4176db9c7e2b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	17f141c2-e297-4c93-9178-0fd819259c50	80260d18-0de6-4cf6-af1d-5b4a1d17a6de	29a61f52-d957-4207-b54b-7fc565a57541	2025-08-08	\N	\N	2.75	work	t	f	110.00	302.50	\N	Somniculosus suspendo vivo tricesimus valetudo vester solitudo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-08 18:00:35.759	\N	2025-10-19 18:00:35.771506	2025-10-19 18:00:35.771506
f5cb048e-6c81-4694-9ce2-fd19bf8c36ca	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	eb1af1df-ce0a-4763-aaef-49b6b390beab	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-08-08	\N	\N	4.00	work	t	f	85.00	340.00	\N	Curo peccatus catena carcer.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-08 18:00:35.759	\N	2025-10-19 18:00:35.773558	2025-10-19 18:00:35.773558
fce6cad1-4f05-47c2-b4bc-1942057f3ee6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	6a032ece-4f9e-405a-b48a-b28516d15fe1	4d9083ba-923c-467a-8bdb-8b651cd6d7d7	9362cf11-827c-459a-8ffc-6634bd023508	2025-08-08	\N	\N	1.25	work	t	f	85.00	106.25	\N	Strues denuncio vulgaris bellicus audentia et aggero apud.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-08 18:00:35.759	\N	2025-10-19 18:00:35.775484	2025-10-19 18:00:35.775484
95f064a5-89e8-44ae-a1a7-6c36d25a928f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	7ef8af5a-1080-42a2-988f-ddfa799c8070	5cf17315-4658-4a7f-9c23-b4f8268d8f84	3f2e9a8e-bdfe-4d09-aced-e88cdc710462	2025-08-11	\N	\N	2.00	meeting	t	f	150.00	300.00	\N	Tenuis speculum peior.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-11 18:00:35.776	\N	2025-10-19 18:00:35.777514	2025-10-19 18:00:35.777514
142140e7-b27b-4792-8c7e-590d5d88b073	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	405d4d05-841b-437d-af7d-70b66dda4cbc	219aa257-710f-4ef2-892d-39086a9690ed	3f2e9a8e-bdfe-4d09-aced-e88cdc710462	2025-08-11	\N	\N	3.25	research	t	t	150.00	487.50	\N	Urbanus ducimus subseco.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-11 18:00:35.776	\N	2025-10-19 18:00:35.779532	2025-10-19 18:00:35.779532
badc7d77-7476-4c77-ac81-c965f0ea44f5	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	4554e09d-4391-42a8-a2cd-9702bce80511	ae73110f-e045-44ac-85ff-51aa2eb8ce69	ecfd2c2c-905b-4ef4-99a4-8949632b9ae9	2025-08-11	\N	\N	0.75	meeting	t	t	150.00	112.50	\N	Odio brevis adipisci tabernus adnuo traho aperiam.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-11 18:00:35.776	\N	2025-10-19 18:00:35.782483	2025-10-19 18:00:35.782483
3b565de0-a10d-482f-abe8-3ef33fd5ea0f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	405d4d05-841b-437d-af7d-70b66dda4cbc	219aa257-710f-4ef2-892d-39086a9690ed	e2cd4da6-f171-436c-9c7e-a9c1c5436b98	2025-08-11	\N	\N	3.00	training	t	f	120.00	360.00	\N	Bellicus varius textor agnosco tametsi tubineus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-11 18:00:35.776	\N	2025-10-19 18:00:35.78661	2025-10-19 18:00:35.78661
5ea3a27c-2204-478a-b10f-8ae71d2596ee	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	67f62599-7f9f-44e8-bc18-d2ce08ea9919	8c04c9d5-2992-4108-bc71-d0210b7972e2	e2cd4da6-f171-436c-9c7e-a9c1c5436b98	2025-08-11	\N	\N	2.75	work	t	f	120.00	330.00	\N	Clibanus dolorem decerno similique avaritia.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-11 18:00:35.776	\N	2025-10-19 18:00:35.789913	2025-10-19 18:00:35.789913
5bcc292f-6f39-4ee5-9912-1a6f25446599	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	65a6152e-a261-4a70-99fb-82f044e87d05	2105be2b-df4f-494a-bb20-548a7dbda952	ef53422c-1305-4831-bf41-d85b2a76b0d5	2025-08-11	\N	\N	3.75	admin	t	f	120.00	450.00	\N	Vetus atqui stultus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-11 18:00:35.776	\N	2025-10-19 18:00:35.792696	2025-10-19 18:00:35.792696
2da19894-5817-4fa3-ba4e-c835822330a0	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	67f62599-7f9f-44e8-bc18-d2ce08ea9919	419cb8f8-8b70-44a5-883b-8fa92787aa46	78882562-2120-44d2-9286-03e696abbf02	2025-08-11	\N	\N	0.50	admin	t	f	120.00	60.00	\N	Speculum casso usus vulgus subnecto certe velit aeger depromo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-11 18:00:35.776	\N	2025-10-19 18:00:35.795655	2025-10-19 18:00:35.795655
3dc43ce1-93f0-40ab-9e82-d44179a6f6b5	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	67f62599-7f9f-44e8-bc18-d2ce08ea9919	419cb8f8-8b70-44a5-883b-8fa92787aa46	a8a65b80-dc4c-49f9-9c8d-0dc4a336cf55	2025-08-11	\N	\N	0.50	training	f	f	110.00	55.00	\N	Vomer clementia stips adfectus nostrum vulticulus tardus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-11 18:00:35.776	\N	2025-10-19 18:00:35.798714	2025-10-19 18:00:35.798714
e36021fe-c6e2-407e-88bb-f1b42a778e92	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	17f141c2-e297-4c93-9178-0fd819259c50	af41070b-ce93-4cf4-88f6-19ed28a1f1fe	a96c9f4d-dc33-4af3-818d-8d729f0f8c1f	2025-08-11	\N	\N	1.50	work	t	f	110.00	165.00	\N	Statua vado antepono urbs crudelis placeat timor argentum turpis abstergo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-11 18:00:35.776	\N	2025-10-19 18:00:35.801279	2025-10-19 18:00:35.801279
e88485d2-7c91-4a04-8ef8-5616d1b9ac23	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	2db210d6-c799-49db-b61d-9aff5f87f1f0	d6d7e47b-cd48-48d8-a45a-fa75af1f9a52	2025-08-11	\N	\N	3.25	research	t	f	85.00	276.25	\N	Ipsa aspicio tergiversatio tempus cilicium.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-11 18:00:35.776	\N	2025-10-19 18:00:35.803429	2025-10-19 18:00:35.803429
4dd5a330-3208-4f03-8a08-673e3961aeb0	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	b0a95e11-90ac-4ab3-b099-c4de69f498b8	269dca40-b352-4a09-9d7c-c735016a8c7d	78882562-2120-44d2-9286-03e696abbf02	2025-08-11	\N	\N	2.50	admin	t	f	85.00	212.50	\N	Acervus solus adfectus cubicularis sublime.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-11 18:00:35.776	\N	2025-10-19 18:00:35.8057	2025-10-19 18:00:35.8057
4610cecb-35b9-4b33-bf5c-aa7762271333	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	b0a95e11-90ac-4ab3-b099-c4de69f498b8	269dca40-b352-4a09-9d7c-c735016a8c7d	235b548d-f0a0-4899-9a7e-d6e9bec6db40	2025-08-12	\N	\N	2.50	research	t	f	150.00	375.00	\N	Decor acerbitas cometes.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-12 18:00:35.808	\N	2025-10-19 18:00:35.809915	2025-10-19 18:00:35.809915
3c86ea6e-043b-4926-a837-f6c29dfd3d93	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	eb1af1df-ce0a-4763-aaef-49b6b390beab	ff4a2600-29fe-4448-bec3-ea868988a9ed	2025-08-12	\N	\N	0.50	work	t	f	150.00	75.00	\N	Valetudo quos verbum talio statua arma capio validus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-12 18:00:35.808	\N	2025-10-19 18:00:35.814138	2025-10-19 18:00:35.814138
a4dec476-085c-4a85-9d62-338b9531afdf	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	8538cc30-f9e7-4b63-a885-56b23e16ecef	b3d1095b-3d51-444b-be35-f485afdb174f	78882562-2120-44d2-9286-03e696abbf02	2025-08-12	\N	\N	2.75	training	t	t	120.00	330.00	\N	Harum cruciamentum uredo confero vapulus aeneus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-12 18:00:35.808	\N	2025-10-19 18:00:35.81892	2025-10-19 18:00:35.81892
3e1ec169-fe79-498b-9f47-cbde39fc187f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	0d0329f4-4b80-4899-8807-5854e9db312b	40ca5c4e-33d7-432f-a55c-b59c3010d7ef	cbf9b499-276b-4a28-999c-27388562c4f4	2025-08-12	\N	\N	2.25	work	t	t	120.00	270.00	\N	Depromo speciosus compello canonicus acsi calcar officiis quam curso.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-12 18:00:35.808	\N	2025-10-19 18:00:35.822439	2025-10-19 18:00:35.822439
1a2cd9e0-3083-442c-b853-097cf8399f65	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	b0a95e11-90ac-4ab3-b099-c4de69f498b8	269dca40-b352-4a09-9d7c-c735016a8c7d	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	2025-08-12	\N	\N	1.00	training	t	f	110.00	110.00	\N	Bis acidus comes theologus ulciscor curvo vos tergiversatio cui cultura.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-12 18:00:35.808	\N	2025-10-19 18:00:35.826219	2025-10-19 18:00:35.826219
07261b91-33b5-49fc-a7e5-2acce5a225f5	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	4554e09d-4391-42a8-a2cd-9702bce80511	ae73110f-e045-44ac-85ff-51aa2eb8ce69	08ee5378-067c-4708-886c-34df4c200b23	2025-08-12	\N	\N	1.75	research	f	f	110.00	192.50	\N	Thorax conforto thorax tricesimus volva.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-12 18:00:35.808	\N	2025-10-19 18:00:35.832848	2025-10-19 18:00:35.832848
2868f89a-ef6f-4033-a4a2-d440fbdce7c0	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	65a6152e-a261-4a70-99fb-82f044e87d05	b98cb032-3f5a-46db-ab39-de7d53570ae9	1ede1cc0-3627-404e-bb8a-487e028f4732	2025-08-12	\N	\N	4.00	admin	t	f	110.00	440.00	\N	Armarium confugo aspicio cornu.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-12 18:00:35.808	\N	2025-10-19 18:00:35.837443	2025-10-19 18:00:35.837443
dacb01dd-607d-4f5a-a5f2-9faca83c9698	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	4554e09d-4391-42a8-a2cd-9702bce80511	ae73110f-e045-44ac-85ff-51aa2eb8ce69	d6d7e47b-cd48-48d8-a45a-fa75af1f9a52	2025-08-12	\N	\N	2.75	work	t	f	110.00	302.50	\N	Cribro paens asporto tersus cariosus commodi via vaco nesciunt.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-12 18:00:35.808	\N	2025-10-19 18:00:35.845115	2025-10-19 18:00:35.845115
427d1197-ec81-49b4-bbe1-1f13a9195cbe	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	702b5a48-f7a9-464c-8833-1ff6577e50e6	66d28217-b458-4ec3-9e88-eb34570556b7	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-08-12	\N	\N	3.75	work	t	f	85.00	318.75	\N	Vox error tui tripudio textus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-12 18:00:35.808	\N	2025-10-19 18:00:35.851306	2025-10-19 18:00:35.851306
1ec1f714-b6ef-4441-bbf7-1fc73a0c71b4	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	702b5a48-f7a9-464c-8833-1ff6577e50e6	6ebdfde2-aeab-4596-9744-cef10c12a313	a8a65b80-dc4c-49f9-9c8d-0dc4a336cf55	2025-08-12	\N	\N	3.50	work	t	f	85.00	297.50	\N	Desino tollo aperte perferendis ago surgo succurro crastinus verus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-12 18:00:35.808	\N	2025-10-19 18:00:35.855093	2025-10-19 18:00:35.855093
4158e2d4-5b87-4a1b-a36e-b869eade24c4	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	b7295600-5c20-4de2-8782-af87987c2bee	2849d1a9-72a4-4287-8114-b604140c71aa	996aa78c-cfd1-477f-8c30-d9489225b29e	2025-08-13	\N	\N	4.00	work	t	f	150.00	600.00	\N	Recusandae aranea tamdiu adaugeo turbo thymum theatrum tremo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-13 18:00:35.857	\N	2025-10-19 18:00:35.85883	2025-10-19 18:00:35.85883
64064b6f-e8e7-4706-9cf5-ba5b676cdf09	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	65a6152e-a261-4a70-99fb-82f044e87d05	b7a77905-edd5-451e-a92e-06976feeb638	08ee5378-067c-4708-886c-34df4c200b23	2025-08-13	\N	\N	2.50	research	f	t	150.00	375.00	\N	Crustulum tenetur aqua.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-13 18:00:35.857	\N	2025-10-19 18:00:35.861968	2025-10-19 18:00:35.861968
17fbd538-3ee7-4697-85a0-beb24ce372ab	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	17f141c2-e297-4c93-9178-0fd819259c50	af41070b-ce93-4cf4-88f6-19ed28a1f1fe	cbf9b499-276b-4a28-999c-27388562c4f4	2025-08-13	\N	\N	1.25	meeting	t	f	150.00	187.50	\N	Appositus velit sortitus vinco defetiscor terebro.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-13 18:00:35.857	\N	2025-10-19 18:00:35.865086	2025-10-19 18:00:35.865086
7ac6c2f0-df06-4637-81ad-5b426d4e9554	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	5e2204cd-be52-42a7-aa41-14fcf0e4a272	a96c9f4d-dc33-4af3-818d-8d729f0f8c1f	2025-08-13	\N	\N	1.75	meeting	t	t	150.00	262.50	\N	Ultra vita adnuo error pauci centum ulterius tabella.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-13 18:00:35.857	\N	2025-10-19 18:00:35.867599	2025-10-19 18:00:35.867599
c3347111-dcd3-463a-9747-9819d110eb9a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	8538cc30-f9e7-4b63-a885-56b23e16ecef	b3d1095b-3d51-444b-be35-f485afdb174f	a8a65b80-dc4c-49f9-9c8d-0dc4a336cf55	2025-08-13	\N	\N	2.75	work	t	f	120.00	330.00	\N	Pauper vel traho ratione tabgo adeptio attollo chirographum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-13 18:00:35.857	\N	2025-10-19 18:00:35.870865	2025-10-19 18:00:35.870865
abf50ce5-eb4c-4bc7-84ba-dc3556266886	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	2db210d6-c799-49db-b61d-9aff5f87f1f0	29a61f52-d957-4207-b54b-7fc565a57541	2025-08-13	\N	\N	3.50	work	t	t	120.00	420.00	\N	Cultura comitatus vomer ciminatio expedita approbo cuppedia.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-13 18:00:35.857	\N	2025-10-19 18:00:35.873732	2025-10-19 18:00:35.873732
ef18699f-5728-4087-b39a-d4d75ca1f17c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	dc9252b7-2022-4822-a8b2-7ec227fe0ea4	235b548d-f0a0-4899-9a7e-d6e9bec6db40	2025-10-15	\N	\N	4.00	admin	t	f	110.00	440.00	\N	Statim crudelis adeo acceptus.	\N	submitted	\N	\N	\N	\N	2025-10-19 18:00:37.799283	2025-10-19 18:00:37.799283
8261b404-bf9f-4c65-a5a9-2fbc01061d35	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	67f62599-7f9f-44e8-bc18-d2ce08ea9919	419cb8f8-8b70-44a5-883b-8fa92787aa46	a96c9f4d-dc33-4af3-818d-8d729f0f8c1f	2025-08-13	\N	\N	3.50	work	t	t	120.00	420.00	\N	Ater aedificium corrumpo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-13 18:00:35.857	\N	2025-10-19 18:00:35.875894	2025-10-19 18:00:35.875894
69a0875a-0163-4db0-a410-8fca459be48d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	65a6152e-a261-4a70-99fb-82f044e87d05	2105be2b-df4f-494a-bb20-548a7dbda952	a0801828-5c53-41ef-9b3e-06db89d72e90	2025-08-13	\N	\N	2.25	research	t	f	120.00	270.00	\N	Absorbeo crur animus creber alveus magnam clam color.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-13 18:00:35.857	\N	2025-10-19 18:00:35.877942	2025-10-19 18:00:35.877942
6437ae62-fd5f-4a63-a69f-55aa95ff84aa	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	46859340-c8cf-4144-aa6c-28fbaf53fa0e	f9444b08-3c00-4407-98d8-3d654600142c	cbf9b499-276b-4a28-999c-27388562c4f4	2025-08-13	\N	\N	3.00	training	t	f	110.00	330.00	\N	Aranea curia ter coepi depopulo uter deprimo pel curso custodia.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-13 18:00:35.857	\N	2025-10-19 18:00:35.8799	2025-10-19 18:00:35.8799
6659aad6-f426-40d7-9665-c2eaa5d8b4e1	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	07b65174-c767-4ace-ac22-e486eb422fa6	109283c7-55ef-4e05-bf53-c6efd1be486f	2025-08-13	\N	\N	0.50	research	t	f	110.00	55.00	\N	Voluptates cohaero compello valeo chirographum tondeo curtus arca campana tempus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-13 18:00:35.857	\N	2025-10-19 18:00:35.882067	2025-10-19 18:00:35.882067
3c631089-fc1e-496a-9c14-5baeb43934c7	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	a4464f5a-2125-46d9-9f58-7252c9adc16b	7041a9f2-cd04-4f9c-ab2c-96bfdd45e5ff	996aa78c-cfd1-477f-8c30-d9489225b29e	2025-08-13	\N	\N	2.00	admin	t	t	110.00	220.00	\N	Caries usque reprehenderit porro comedo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-13 18:00:35.857	\N	2025-10-19 18:00:35.884072	2025-10-19 18:00:35.884072
4155c42c-cc76-45f4-b724-d052d83da312	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	b7295600-5c20-4de2-8782-af87987c2bee	196a1b4b-9367-4b9f-baf6-717d312881a3	e4487405-7859-40e9-8008-056d32fe6f10	2025-08-13	\N	\N	3.75	work	t	t	110.00	412.50	\N	Cilicium desino vereor tibi suffragium vespillo velit stips summa cribro.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-13 18:00:35.857	\N	2025-10-19 18:00:35.886179	2025-10-19 18:00:35.886179
2c48dd3e-5e06-4390-ba41-542699fe4062	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	98f9340d-eadb-45cd-bba2-115aa880f565	78882562-2120-44d2-9286-03e696abbf02	2025-08-13	\N	\N	1.00	research	t	f	85.00	85.00	\N	Vomica aperte magnam calco sollicito atrocitas.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-13 18:00:35.857	\N	2025-10-19 18:00:35.888442	2025-10-19 18:00:35.888442
bf355bc9-e14c-4a67-9b88-18aa40e99b2a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	5515e216-ea3c-436b-95a5-6abf213c47ef	d6d7e47b-cd48-48d8-a45a-fa75af1f9a52	2025-08-13	\N	\N	2.25	training	t	f	85.00	191.25	\N	Arcesso talio amicitia adamo solutio delectatio dedico quisquam cauda.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-13 18:00:35.857	\N	2025-10-19 18:00:35.890954	2025-10-19 18:00:35.890954
7c05cb8d-9d44-4776-91fa-b843b17d62fa	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	6ecda653-6094-4502-9d1d-6e90d9ea99ed	4fb9cb0a-ca36-4af7-9203-ac1970ce555b	a0801828-5c53-41ef-9b3e-06db89d72e90	2025-08-13	\N	\N	0.75	work	t	f	85.00	63.75	\N	Aliqua atqui usus cognomen tepidus sum vulgus valetudo amplitudo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-13 18:00:35.857	\N	2025-10-19 18:00:35.893582	2025-10-19 18:00:35.893582
909307f1-3304-4d83-8d1e-1a7c21041c67	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	65a6152e-a261-4a70-99fb-82f044e87d05	b98cb032-3f5a-46db-ab39-de7d53570ae9	ff4a2600-29fe-4448-bec3-ea868988a9ed	2025-08-13	\N	\N	0.50	work	t	f	85.00	42.50	\N	Ducimus conitor officiis optio theatrum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-13 18:00:35.857	\N	2025-10-19 18:00:35.896157	2025-10-19 18:00:35.896157
129e699e-865d-4ab3-a6b2-d6b2c99cf46f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	b0a95e11-90ac-4ab3-b099-c4de69f498b8	269dca40-b352-4a09-9d7c-c735016a8c7d	79d01aa5-b680-4830-ab3a-5e3cb66edcfa	2025-08-13	\N	\N	3.50	training	t	t	85.00	297.50	\N	Ago sit vester.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-13 18:00:35.857	\N	2025-10-19 18:00:35.898496	2025-10-19 18:00:35.898496
3b67fa44-b990-40d5-a41a-0be4caf7858a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	702b5a48-f7a9-464c-8833-1ff6577e50e6	6ebdfde2-aeab-4596-9744-cef10c12a313	ca413110-b7e3-4734-a185-d21ea0960708	2025-08-14	\N	\N	0.75	research	t	f	150.00	112.50	\N	Vespillo tero vir.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-14 18:00:35.9	\N	2025-10-19 18:00:35.901589	2025-10-19 18:00:35.901589
ada0b9fc-11b8-4096-99b5-08e03fd8a5f5	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	7ef8af5a-1080-42a2-988f-ddfa799c8070	1c9d17d2-a153-4f42-9604-129a162a1f0f	18c91d63-8f9d-4974-ba97-a4079c7457d5	2025-08-14	\N	\N	4.00	admin	t	f	150.00	600.00	\N	Civitas facere spargo vulpes tametsi.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-14 18:00:35.9	\N	2025-10-19 18:00:35.904802	2025-10-19 18:00:35.904802
700ca95c-5383-440f-8eff-b45edbcb7f76	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	405d4d05-841b-437d-af7d-70b66dda4cbc	219aa257-710f-4ef2-892d-39086a9690ed	78882562-2120-44d2-9286-03e696abbf02	2025-08-14	\N	\N	3.75	meeting	f	f	150.00	562.50	\N	Tactus attonbitus pectus clamo argumentum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-14 18:00:35.9	\N	2025-10-19 18:00:35.908082	2025-10-19 18:00:35.908082
c8dba3b6-3971-4965-bffa-afb51083167f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	46859340-c8cf-4144-aa6c-28fbaf53fa0e	d486be12-5ed8-48b4-af34-79d9269f4c0b	18c91d63-8f9d-4974-ba97-a4079c7457d5	2025-08-14	\N	\N	0.75	research	t	f	150.00	112.50	\N	Amitto contigo uberrime valetudo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-14 18:00:35.9	\N	2025-10-19 18:00:35.911629	2025-10-19 18:00:35.911629
6615e510-3051-48bf-aa12-f4f254b6527e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	07b65174-c767-4ace-ac22-e486eb422fa6	e4487405-7859-40e9-8008-056d32fe6f10	2025-08-14	\N	\N	1.50	meeting	t	f	120.00	180.00	\N	Vita atque caritas tempora.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-14 18:00:35.9	\N	2025-10-19 18:00:35.914885	2025-10-19 18:00:35.914885
57caf543-6b25-480d-be0a-8c36615b7c92	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	7ef8af5a-1080-42a2-988f-ddfa799c8070	5cf17315-4658-4a7f-9c23-b4f8268d8f84	996aa78c-cfd1-477f-8c30-d9489225b29e	2025-08-14	\N	\N	0.75	research	t	f	120.00	90.00	\N	Eveniet vorax commemoro sodalitas.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-14 18:00:35.9	\N	2025-10-19 18:00:35.919915	2025-10-19 18:00:35.919915
a62e731c-d998-45ca-81e2-e3ec42eee46c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	67f62599-7f9f-44e8-bc18-d2ce08ea9919	9ec151a2-b6a4-433d-a21e-c94af23b785b	78882562-2120-44d2-9286-03e696abbf02	2025-08-14	\N	\N	2.75	training	t	t	120.00	330.00	\N	Cupiditas caecus catena tenax fugiat dignissimos.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-14 18:00:35.9	\N	2025-10-19 18:00:35.924446	2025-10-19 18:00:35.924446
70c7b38c-1692-48ea-8cba-75552f9a5c06	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	d69d0436-37d7-42a4-b907-3d9c3a091ea6	20222077-caa4-4444-b803-1f75d617ee85	ecfd2c2c-905b-4ef4-99a4-8949632b9ae9	2025-08-14	\N	\N	4.00	training	f	t	110.00	440.00	\N	Capillus brevis vester animus dolorum tempora teres.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-14 18:00:35.9	\N	2025-10-19 18:00:35.92856	2025-10-19 18:00:35.92856
1c69f741-a1dc-48c4-ad52-7c473113bff9	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	96a103f5-bc5b-43e1-b321-62fedda6eaa1	ef53422c-1305-4831-bf41-d85b2a76b0d5	2025-08-14	\N	\N	3.75	work	t	t	110.00	412.50	\N	Abbas tibi timidus aqua appello demum totam incidunt.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-14 18:00:35.9	\N	2025-10-19 18:00:35.932282	2025-10-19 18:00:35.932282
83caa3a8-18ad-4e13-b136-b093470aba00	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	b0a95e11-90ac-4ab3-b099-c4de69f498b8	269dca40-b352-4a09-9d7c-c735016a8c7d	1ede1cc0-3627-404e-bb8a-487e028f4732	2025-08-14	\N	\N	4.00	work	t	f	85.00	340.00	\N	Clarus consectetur censura spoliatio aut cimentarius nihil statim defluo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-14 18:00:35.9	\N	2025-10-19 18:00:35.936308	2025-10-19 18:00:35.936308
f6913204-8c40-4391-95fc-7cf398048c3d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	12edb785-268b-4219-840d-15b8f0df1198	e171fa0b-3143-48ec-962f-0917bf1886bf	235b548d-f0a0-4899-9a7e-d6e9bec6db40	2025-08-14	\N	\N	2.00	training	f	f	85.00	170.00	\N	Calculus thymbra spes demo copia cultellus degenero sodalitas.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-14 18:00:35.9	\N	2025-10-19 18:00:35.94051	2025-10-19 18:00:35.94051
cc6ce250-9667-4ff8-9d42-81fed4ba7fd5	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	c8eb351f-daa9-48cf-bc62-2cef6338a122	1ede1cc0-3627-404e-bb8a-487e028f4732	2025-08-14	\N	\N	3.00	work	t	f	85.00	255.00	\N	Beatae verto beneficium stips adhaero civitas uredo commodo ait.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-14 18:00:35.9	\N	2025-10-19 18:00:35.94368	2025-10-19 18:00:35.94368
1a8c77e9-687b-4d8f-99c5-7e6d53e00d6d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	dc9252b7-2022-4822-a8b2-7ec227fe0ea4	ff4a2600-29fe-4448-bec3-ea868988a9ed	2025-08-14	\N	\N	1.00	work	t	f	85.00	85.00	\N	Pariatur civis consectetur audax pecto arcesso tardus ademptio xiphias.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-14 18:00:35.9	\N	2025-10-19 18:00:35.945929	2025-10-19 18:00:35.945929
4a8b0c8f-5496-4774-85b0-64717691563b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	b0a95e11-90ac-4ab3-b099-c4de69f498b8	269dca40-b352-4a09-9d7c-c735016a8c7d	1ede1cc0-3627-404e-bb8a-487e028f4732	2025-08-15	\N	\N	1.00	training	t	t	150.00	150.00	\N	Laudantium cognomen beatus convoco.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-15 18:00:35.947	\N	2025-10-19 18:00:35.948276	2025-10-19 18:00:35.948276
71a301e4-5e23-40fd-bc43-7328037fba91	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	98f9340d-eadb-45cd-bba2-115aa880f565	a96c9f4d-dc33-4af3-818d-8d729f0f8c1f	2025-08-15	\N	\N	3.75	training	t	f	150.00	562.50	\N	Abduco surgo volo patruus adipisci sit sit attollo celo earum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-15 18:00:35.947	\N	2025-10-19 18:00:35.951307	2025-10-19 18:00:35.951307
d5f137ab-5799-493c-b9af-027608f8f19e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	12edb785-268b-4219-840d-15b8f0df1198	e171fa0b-3143-48ec-962f-0917bf1886bf	18c91d63-8f9d-4974-ba97-a4079c7457d5	2025-08-15	\N	\N	2.75	training	t	f	150.00	412.50	\N	Tibi enim amo decet curis ter eos.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-15 18:00:35.947	\N	2025-10-19 18:00:35.956923	2025-10-19 18:00:35.956923
e51f75a4-f60e-4852-a1ea-d7b0376803ca	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	702b5a48-f7a9-464c-8833-1ff6577e50e6	66d28217-b458-4ec3-9e88-eb34570556b7	78882562-2120-44d2-9286-03e696abbf02	2025-08-15	\N	\N	3.50	work	t	t	120.00	420.00	\N	Appositus despecto acidus defendo spectaculum vita tolero spargo ventito correptius.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-15 18:00:35.947	\N	2025-10-19 18:00:35.961396	2025-10-19 18:00:35.961396
5721ba8e-4592-4333-9de2-70bc5323db62	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	4554e09d-4391-42a8-a2cd-9702bce80511	ae73110f-e045-44ac-85ff-51aa2eb8ce69	e4487405-7859-40e9-8008-056d32fe6f10	2025-08-15	\N	\N	0.75	admin	t	f	120.00	90.00	\N	Calco cunabula supellex quod.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-15 18:00:35.947	\N	2025-10-19 18:00:35.964611	2025-10-19 18:00:35.964611
3418317d-30b6-4275-b75f-025b4498a666	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	46859340-c8cf-4144-aa6c-28fbaf53fa0e	f9444b08-3c00-4407-98d8-3d654600142c	18c91d63-8f9d-4974-ba97-a4079c7457d5	2025-08-15	\N	\N	3.00	research	t	f	120.00	360.00	\N	Adinventitias dens ulciscor virga.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-15 18:00:35.947	\N	2025-10-19 18:00:35.968175	2025-10-19 18:00:35.968175
b86186f8-edd4-49ba-9666-029907310cf7	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	d8601cb6-589f-456f-a2b2-1b986973a4bc	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-08-15	\N	\N	3.25	meeting	f	f	120.00	390.00	\N	Totam cohibeo acies beneficium solutio.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-15 18:00:35.947	\N	2025-10-19 18:00:35.972606	2025-10-19 18:00:35.972606
b709fca6-acb0-478e-b3dc-ecf60a23202a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	7ef8af5a-1080-42a2-988f-ddfa799c8070	1c9d17d2-a153-4f42-9604-129a162a1f0f	a0801828-5c53-41ef-9b3e-06db89d72e90	2025-08-15	\N	\N	1.75	admin	t	f	120.00	210.00	\N	Acceptus universe maiores.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-15 18:00:35.947	\N	2025-10-19 18:00:35.977445	2025-10-19 18:00:35.977445
6c734929-abad-42fe-8e5e-d43fd3a1e9d8	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	088446c4-4542-4007-9887-b512bd3db05d	ff4a2600-29fe-4448-bec3-ea868988a9ed	2025-08-15	\N	\N	2.75	admin	t	t	110.00	302.50	\N	Civitas basium suffragium utilis maiores textor tepesco fugiat.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-15 18:00:35.947	\N	2025-10-19 18:00:35.980946	2025-10-19 18:00:35.980946
3a136a99-7650-4fc5-88f1-eae79a75fddf	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	0d0329f4-4b80-4899-8807-5854e9db312b	e60c944c-85a6-45da-b007-56b5244e0257	29a61f52-d957-4207-b54b-7fc565a57541	2025-08-15	\N	\N	2.50	admin	t	f	110.00	275.00	\N	Abscido nam porro aliquid totus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-15 18:00:35.947	\N	2025-10-19 18:00:35.984729	2025-10-19 18:00:35.984729
10759503-dab0-4a66-9758-b5d6f5c9aa3c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	6ecda653-6094-4502-9d1d-6e90d9ea99ed	6c88f260-519e-41e9-9fac-18a28b9a7901	3f2e9a8e-bdfe-4d09-aced-e88cdc710462	2025-08-15	\N	\N	2.50	admin	t	f	110.00	275.00	\N	Id alii aperiam.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-15 18:00:35.947	\N	2025-10-19 18:00:35.988418	2025-10-19 18:00:35.988418
3775c940-39e9-449d-ab89-916fd068d4f9	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	a4464f5a-2125-46d9-9f58-7252c9adc16b	9068b493-e301-4f68-9bcd-ad7c1f9cbe03	d04961e2-5af7-4b9c-bb44-c37031dd6bfa	2025-08-15	\N	\N	3.50	research	t	f	85.00	297.50	\N	Titulus adinventitias vitiosus temeritas.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-15 18:00:35.947	\N	2025-10-19 18:00:35.992281	2025-10-19 18:00:35.992281
ef2cd513-7a9f-4d30-857c-d22aa1e852c5	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	65a6152e-a261-4a70-99fb-82f044e87d05	b98cb032-3f5a-46db-ab39-de7d53570ae9	a8a65b80-dc4c-49f9-9c8d-0dc4a336cf55	2025-08-15	\N	\N	3.00	admin	t	f	85.00	255.00	\N	Sursum vigilo thalassinus cumque.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-15 18:00:35.947	\N	2025-10-19 18:00:35.997014	2025-10-19 18:00:35.997014
91a82e97-907a-4ae4-9e05-1cd2e66956e8	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	d69d0436-37d7-42a4-b907-3d9c3a091ea6	fe24fe87-1db5-4f06-9a5c-46757a20518d	ecfd2c2c-905b-4ef4-99a4-8949632b9ae9	2025-08-15	\N	\N	2.50	admin	f	f	85.00	212.50	\N	Curo tempus varius impedit ascisco vos cornu peior defluo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-15 18:00:35.947	\N	2025-10-19 18:00:36.00199	2025-10-19 18:00:36.00199
da68dd3d-2bee-466b-a17c-4bee25de5bc2	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	5e2204cd-be52-42a7-aa41-14fcf0e4a272	9362cf11-827c-459a-8ffc-6634bd023508	2025-08-15	\N	\N	3.00	meeting	t	f	85.00	255.00	\N	Subvenio autus vita cerno quasi audeo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-15 18:00:35.947	\N	2025-10-19 18:00:36.006913	2025-10-19 18:00:36.006913
892406a0-f1fb-4379-be62-f42982308c1f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	8538cc30-f9e7-4b63-a885-56b23e16ecef	b3d1095b-3d51-444b-be35-f485afdb174f	d04961e2-5af7-4b9c-bb44-c37031dd6bfa	2025-08-15	\N	\N	2.25	training	f	f	85.00	191.25	\N	Provident bardus vesica creo vorago depulso circumvenio.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-15 18:00:35.947	\N	2025-10-19 18:00:36.01137	2025-10-19 18:00:36.01137
d44ebdb3-dc7e-42ee-97c4-462076f146ea	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	5515e216-ea3c-436b-95a5-6abf213c47ef	18c91d63-8f9d-4974-ba97-a4079c7457d5	2025-08-18	\N	\N	0.50	admin	t	f	150.00	75.00	\N	Timor abbas velut bardus corroboro cito testimonium utilis adopto.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-18 18:00:36.013	\N	2025-10-19 18:00:36.014293	2025-10-19 18:00:36.014293
f83b53eb-58e2-4931-9198-b00dee196aa9	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	67f62599-7f9f-44e8-bc18-d2ce08ea9919	ed074125-f8db-4b46-af39-96ce8eb67c4b	cbf9b499-276b-4a28-999c-27388562c4f4	2025-08-18	\N	\N	1.75	training	t	f	150.00	262.50	\N	Colo urbs atrocitas.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-18 18:00:36.013	\N	2025-10-19 18:00:36.017392	2025-10-19 18:00:36.017392
be6cc834-e9f4-440a-a190-6431de7ec91c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	7ef8af5a-1080-42a2-988f-ddfa799c8070	5cf17315-4658-4a7f-9c23-b4f8268d8f84	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	2025-08-18	\N	\N	1.25	work	t	t	150.00	187.50	\N	Est defendo dolores tego dolorem cogo odio desidero.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-18 18:00:36.013	\N	2025-10-19 18:00:36.020194	2025-10-19 18:00:36.020194
7bf8eab3-f39d-4e1c-beef-c974259d5db6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	45b3d726-e151-4770-9b64-4653914bdaa5	449f8e23-33a0-4bf0-915e-cc79d13bc3a9	a8a65b80-dc4c-49f9-9c8d-0dc4a336cf55	2025-08-18	\N	\N	1.25	work	t	f	150.00	187.50	\N	Tubineus vulgus dolorum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-18 18:00:36.013	\N	2025-10-19 18:00:36.022685	2025-10-19 18:00:36.022685
c2b85148-f168-4a0f-b7a3-ca59ba1936ac	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	6a032ece-4f9e-405a-b48a-b28516d15fe1	43f46d13-e4e7-4e0f-a62d-25d47b569d15	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-08-18	\N	\N	3.00	admin	f	t	150.00	450.00	\N	Depraedor vero asper celebrer degero.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-18 18:00:36.013	\N	2025-10-19 18:00:36.025958	2025-10-19 18:00:36.025958
728530d3-4b96-4a87-81a1-67e955966300	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	6ecda653-6094-4502-9d1d-6e90d9ea99ed	6c88f260-519e-41e9-9fac-18a28b9a7901	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	2025-08-18	\N	\N	3.50	admin	t	f	120.00	420.00	\N	Tepesco defleo dolorum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-18 18:00:36.013	\N	2025-10-19 18:00:36.029549	2025-10-19 18:00:36.029549
7f4e5f6c-37f6-4399-b865-ee72bbc0f9e4	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	b0a95e11-90ac-4ab3-b099-c4de69f498b8	8c94ef1c-f972-45ba-9aaa-1fa78ab3fc92	29a61f52-d957-4207-b54b-7fc565a57541	2025-08-18	\N	\N	0.75	research	f	t	120.00	90.00	\N	Triumphus bene tamdiu vivo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-18 18:00:36.013	\N	2025-10-19 18:00:36.033226	2025-10-19 18:00:36.033226
04a1346f-7ff3-4b1b-a2cf-c16af419a447	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	c8eb351f-daa9-48cf-bc62-2cef6338a122	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-08-18	\N	\N	3.25	meeting	t	t	120.00	390.00	\N	Advoco aliquid sui amiculum abeo amo appositus atrocitas.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-18 18:00:36.013	\N	2025-10-19 18:00:36.036754	2025-10-19 18:00:36.036754
30754be9-06e7-4e2c-9190-51718b3ab7fa	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	7ef8af5a-1080-42a2-988f-ddfa799c8070	5cf17315-4658-4a7f-9c23-b4f8268d8f84	29a61f52-d957-4207-b54b-7fc565a57541	2025-08-18	\N	\N	2.00	research	t	f	120.00	240.00	\N	Caelum adulatio chirographum adhuc articulus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-18 18:00:36.013	\N	2025-10-19 18:00:36.039485	2025-10-19 18:00:36.039485
3c6131ec-3b92-4c8e-adcc-109cd65726ae	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	6ecda653-6094-4502-9d1d-6e90d9ea99ed	4fb9cb0a-ca36-4af7-9203-ac1970ce555b	a8a65b80-dc4c-49f9-9c8d-0dc4a336cf55	2025-08-18	\N	\N	0.75	research	t	f	110.00	82.50	\N	Territo tergo adamo bardus magnam demitto texo anser.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-18 18:00:36.013	\N	2025-10-19 18:00:36.042358	2025-10-19 18:00:36.042358
68938089-4178-4354-90fe-9e8c42ee7e08	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	702b5a48-f7a9-464c-8833-1ff6577e50e6	0da2984a-30cb-4fdf-a4f6-b38ff97be406	d6d7e47b-cd48-48d8-a45a-fa75af1f9a52	2025-08-18	\N	\N	2.75	research	t	f	110.00	302.50	\N	Cruentus virtus basium crustulum corrumpo audeo considero calcar amicitia temporibus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-18 18:00:36.013	\N	2025-10-19 18:00:36.044603	2025-10-19 18:00:36.044603
ed1fceb4-85de-482c-a881-223793a7e2fa	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	8538cc30-f9e7-4b63-a885-56b23e16ecef	b3d1095b-3d51-444b-be35-f485afdb174f	996aa78c-cfd1-477f-8c30-d9489225b29e	2025-08-18	\N	\N	4.00	admin	f	f	85.00	340.00	\N	Ademptio aeneus veniam patria suadeo alter atrox.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-18 18:00:36.013	\N	2025-10-19 18:00:36.047764	2025-10-19 18:00:36.047764
d55a58d5-f66c-4815-a1f8-6e858014ea2f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	5e2204cd-be52-42a7-aa41-14fcf0e4a272	996aa78c-cfd1-477f-8c30-d9489225b29e	2025-08-18	\N	\N	0.75	admin	t	f	85.00	63.75	\N	Abundans coniuratio alter.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-18 18:00:36.013	\N	2025-10-19 18:00:36.051503	2025-10-19 18:00:36.051503
3a088530-d32e-417b-95bd-fb2f5047690f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	46859340-c8cf-4144-aa6c-28fbaf53fa0e	d486be12-5ed8-48b4-af34-79d9269f4c0b	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	2025-08-18	\N	\N	2.50	training	f	t	85.00	212.50	\N	Baiulus spiculum defaeco patior argentum cilicium.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-18 18:00:36.013	\N	2025-10-19 18:00:36.054701	2025-10-19 18:00:36.054701
953b9fc7-310b-4c56-8c2a-4ae1327ad922	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	04465623-29cb-4298-8828-d1839e9cc00d	e4ce7abb-fb0c-42e1-a7c1-6419b4aa63ef	ecfd2c2c-905b-4ef4-99a4-8949632b9ae9	2025-08-18	\N	\N	0.50	training	t	f	85.00	42.50	\N	Enim subito ustulo dignissimos atavus ullam deporto.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-18 18:00:36.013	\N	2025-10-19 18:00:36.058436	2025-10-19 18:00:36.058436
0adc4840-1b2d-4aec-8c7f-42c1e2072e32	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	17f141c2-e297-4c93-9178-0fd819259c50	c7111387-5606-4d4b-88de-270766225b61	e2cd4da6-f171-436c-9c7e-a9c1c5436b98	2025-08-19	\N	\N	1.00	admin	f	t	150.00	150.00	\N	Atrox beatae crudelis surgo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-19 18:00:36.06	\N	2025-10-19 18:00:36.061005	2025-10-19 18:00:36.061005
bd3d960e-4f80-4f2e-9c78-69710ab23d44	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	12edb785-268b-4219-840d-15b8f0df1198	e171fa0b-3143-48ec-962f-0917bf1886bf	391f7d87-df5d-4538-9b3e-31e07ac9347e	2025-08-19	\N	\N	1.25	meeting	t	f	150.00	187.50	\N	Spes amita aranea ustilo utrum et denuo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-19 18:00:36.06	\N	2025-10-19 18:00:36.063852	2025-10-19 18:00:36.063852
e7466ccc-77bc-40fc-a512-dd86174e61fd	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	702b5a48-f7a9-464c-8833-1ff6577e50e6	6ebdfde2-aeab-4596-9744-cef10c12a313	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	2025-08-19	\N	\N	0.50	admin	t	t	150.00	75.00	\N	Culpa conduco odio suppellex velit creo vehemens apostolus impedit.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-19 18:00:36.06	\N	2025-10-19 18:00:36.06781	2025-10-19 18:00:36.06781
2ec9fe18-4c84-49b5-a93e-70734cb8d016	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	7ef8af5a-1080-42a2-988f-ddfa799c8070	1c9d17d2-a153-4f42-9604-129a162a1f0f	a0801828-5c53-41ef-9b3e-06db89d72e90	2025-08-19	\N	\N	1.50	admin	t	t	150.00	225.00	\N	Arguo libero candidus debitis avaritia.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-19 18:00:36.06	\N	2025-10-19 18:00:36.070598	2025-10-19 18:00:36.070598
9e01b5aa-e899-45bb-ac30-f7797ab96a17	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	6ecda653-6094-4502-9d1d-6e90d9ea99ed	4fb9cb0a-ca36-4af7-9203-ac1970ce555b	996aa78c-cfd1-477f-8c30-d9489225b29e	2025-08-19	\N	\N	2.00	work	t	f	120.00	240.00	\N	Infit decumbo avaritia dedecor amor cena iure clarus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-19 18:00:36.06	\N	2025-10-19 18:00:36.073341	2025-10-19 18:00:36.073341
e7e992ff-012e-484a-ac34-312924ee5d49	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	584bab37-ccf2-484c-9a7f-7394e4b30ec6	f6f91297-d9d7-461b-bf97-34473b55f893	d04961e2-5af7-4b9c-bb44-c37031dd6bfa	2025-08-19	\N	\N	3.00	meeting	t	f	120.00	360.00	\N	Textus conduco abbas laboriosam tantillus vitae cariosus desparatus avarus appositus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-19 18:00:36.06	\N	2025-10-19 18:00:36.076076	2025-10-19 18:00:36.076076
8e5dfdc8-3057-4b03-8599-45de274db65b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	6a032ece-4f9e-405a-b48a-b28516d15fe1	7add02b8-5d73-4a39-8607-6f9d17b36fda	18c91d63-8f9d-4974-ba97-a4079c7457d5	2025-08-19	\N	\N	1.75	work	t	f	120.00	210.00	\N	Crapula substantia dolore civitas volubilis stipes crinis amita suffragium explicabo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-19 18:00:36.06	\N	2025-10-19 18:00:36.078431	2025-10-19 18:00:36.078431
8a51bc58-4d3a-4352-b8bd-15a4225f5234	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	6ecda653-6094-4502-9d1d-6e90d9ea99ed	4fb9cb0a-ca36-4af7-9203-ac1970ce555b	ca413110-b7e3-4734-a185-d21ea0960708	2025-08-19	\N	\N	1.50	training	t	f	110.00	165.00	\N	Ante thesaurus temeritas possimus amo debeo trans despecto coniuratio cur.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-19 18:00:36.06	\N	2025-10-19 18:00:36.080656	2025-10-19 18:00:36.080656
c51b13aa-77bf-4b84-82cd-e095d26d2d56	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	b7295600-5c20-4de2-8782-af87987c2bee	d2f831e1-38ca-429c-9942-06db88f8dfc5	08ee5378-067c-4708-886c-34df4c200b23	2025-08-19	\N	\N	2.75	work	t	f	110.00	302.50	\N	Attollo vulticulus aspernatur verus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-19 18:00:36.06	\N	2025-10-19 18:00:36.082903	2025-10-19 18:00:36.082903
f01a584c-3c67-435a-af8f-0eb8f9322649	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	4554e09d-4391-42a8-a2cd-9702bce80511	ae73110f-e045-44ac-85ff-51aa2eb8ce69	9362cf11-827c-459a-8ffc-6634bd023508	2025-08-19	\N	\N	3.25	research	t	f	85.00	276.25	\N	Teneo tunc iure cetera abscido sono quasi.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-19 18:00:36.06	\N	2025-10-19 18:00:36.087543	2025-10-19 18:00:36.087543
0c5ea3d3-6e4d-4c97-87ae-87d84ad374bb	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	b7295600-5c20-4de2-8782-af87987c2bee	d2f831e1-38ca-429c-9942-06db88f8dfc5	a96c9f4d-dc33-4af3-818d-8d729f0f8c1f	2025-08-19	\N	\N	1.00	admin	f	f	85.00	85.00	\N	Denique perspiciatis stabilis talis absconditus tamquam cibus cultura appello timor.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-19 18:00:36.06	\N	2025-10-19 18:00:36.091603	2025-10-19 18:00:36.091603
2a325e75-bde1-4257-b740-d4a08c24205a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	04465623-29cb-4298-8828-d1839e9cc00d	e4ce7abb-fb0c-42e1-a7c1-6419b4aa63ef	d6d7e47b-cd48-48d8-a45a-fa75af1f9a52	2025-08-19	\N	\N	0.50	training	f	f	85.00	42.50	\N	Deputo solitudo delectatio animi sapiente viridis utor damno clam.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-19 18:00:36.06	\N	2025-10-19 18:00:36.096314	2025-10-19 18:00:36.096314
22d5c4da-c05b-421b-87e8-9befa847fe17	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	46859340-c8cf-4144-aa6c-28fbaf53fa0e	d486be12-5ed8-48b4-af34-79d9269f4c0b	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	2025-08-19	\N	\N	2.50	work	t	f	85.00	212.50	\N	Necessitatibus aedificium bellum recusandae ea.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-19 18:00:36.06	\N	2025-10-19 18:00:36.102163	2025-10-19 18:00:36.102163
f867c632-f1ca-41d8-b7d0-9c84ff403215	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	17f141c2-e297-4c93-9178-0fd819259c50	a18510b4-73e3-40ff-84b1-89c4a2e0bdac	a8a65b80-dc4c-49f9-9c8d-0dc4a336cf55	2025-08-20	\N	\N	1.00	admin	t	f	150.00	150.00	\N	Numquam cedo cauda audio curiositas strues tenuis ars.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-20 18:00:36.104	\N	2025-10-19 18:00:36.106957	2025-10-19 18:00:36.106957
b9373cf5-2972-45eb-a7f3-6bdd38efd52e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	45b3d726-e151-4770-9b64-4653914bdaa5	2c1d5d5c-be1c-427c-b2ac-da3cc28b1680	79d01aa5-b680-4830-ab3a-5e3cb66edcfa	2025-08-20	\N	\N	0.50	work	f	f	150.00	75.00	\N	Caveo attonbitus veritatis vereor decipio neque possimus sollers sunt.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-20 18:00:36.104	\N	2025-10-19 18:00:36.112103	2025-10-19 18:00:36.112103
8ea9977d-edc6-4154-a590-b53538bfd5e7	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	584bab37-ccf2-484c-9a7f-7394e4b30ec6	ff7b1e48-6594-4997-9b76-46ab909220e2	18c91d63-8f9d-4974-ba97-a4079c7457d5	2025-08-20	\N	\N	0.50	training	t	f	120.00	60.00	\N	Dicta clementia candidus ventito chirographum apparatus cuppedia.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-20 18:00:36.104	\N	2025-10-19 18:00:36.115204	2025-10-19 18:00:36.115204
b2128b49-75a7-4a88-b8c0-e593434fc49b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	6a032ece-4f9e-405a-b48a-b28516d15fe1	4d9083ba-923c-467a-8bdb-8b651cd6d7d7	cbf9b499-276b-4a28-999c-27388562c4f4	2025-08-20	\N	\N	4.00	training	t	f	120.00	480.00	\N	Claro aeternus cedo desipio arceo deleniti aedificium.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-20 18:00:36.104	\N	2025-10-19 18:00:36.118205	2025-10-19 18:00:36.118205
f9f531f1-168f-4f73-9509-a3c4a3ea1eab	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	6ecda653-6094-4502-9d1d-6e90d9ea99ed	4fb9cb0a-ca36-4af7-9203-ac1970ce555b	ff4a2600-29fe-4448-bec3-ea868988a9ed	2025-08-20	\N	\N	3.00	work	f	t	120.00	360.00	\N	Sulum magnam natus vapulus thalassinus fugiat deripio vereor.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-20 18:00:36.104	\N	2025-10-19 18:00:36.121671	2025-10-19 18:00:36.121671
f99aae75-a374-4558-80e4-90589ef8b276	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	4554e09d-4391-42a8-a2cd-9702bce80511	ae73110f-e045-44ac-85ff-51aa2eb8ce69	a49c064a-0890-4c02-8734-07a3185e6c03	2025-08-20	\N	\N	0.75	admin	f	f	120.00	90.00	\N	Certe auctor agnitio delectus coniuratio decumbo crux.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-20 18:00:36.104	\N	2025-10-19 18:00:36.124732	2025-10-19 18:00:36.124732
85cf5a8d-27eb-4703-9b5b-5b4bf2fe9ea7	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	12edb785-268b-4219-840d-15b8f0df1198	e171fa0b-3143-48ec-962f-0917bf1886bf	a0801828-5c53-41ef-9b3e-06db89d72e90	2025-08-20	\N	\N	3.75	meeting	t	t	110.00	412.50	\N	Viriliter vesper vigor benevolentia capto.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-20 18:00:36.104	\N	2025-10-19 18:00:36.128064	2025-10-19 18:00:36.128064
87e02e52-f07f-46e4-a985-5d0e94b2d4df	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	702b5a48-f7a9-464c-8833-1ff6577e50e6	66d28217-b458-4ec3-9e88-eb34570556b7	e2cd4da6-f171-436c-9c7e-a9c1c5436b98	2025-08-20	\N	\N	1.50	research	t	f	110.00	165.00	\N	Minus caecus suscipio abscido quaerat modi caelestis.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-20 18:00:36.104	\N	2025-10-19 18:00:36.131232	2025-10-19 18:00:36.131232
47c07d34-058a-4b24-9a0a-abb7bc8e0d3f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	0d0329f4-4b80-4899-8807-5854e9db312b	40ca5c4e-33d7-432f-a55c-b59c3010d7ef	08ee5378-067c-4708-886c-34df4c200b23	2025-08-20	\N	\N	3.25	training	t	f	110.00	357.50	\N	Una condico crastinus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-20 18:00:36.104	\N	2025-10-19 18:00:36.13378	2025-10-19 18:00:36.13378
9f14f641-5e02-41b8-9210-3a83b05f394f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	67f62599-7f9f-44e8-bc18-d2ce08ea9919	8c04c9d5-2992-4108-bc71-d0210b7972e2	996aa78c-cfd1-477f-8c30-d9489225b29e	2025-08-20	\N	\N	4.00	admin	t	f	110.00	440.00	\N	Adinventitias stella suppellex vinum a adipisci vulnus caelum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-20 18:00:36.104	\N	2025-10-19 18:00:36.136802	2025-10-19 18:00:36.136802
9d301e52-1b15-444d-88a1-b5ab7d6a91a1	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	b0a95e11-90ac-4ab3-b099-c4de69f498b8	269dca40-b352-4a09-9d7c-c735016a8c7d	e2cd4da6-f171-436c-9c7e-a9c1c5436b98	2025-08-20	\N	\N	2.00	work	f	f	110.00	220.00	\N	Succurro laborum creo tabernus tabesco thesaurus tunc crustulum quas provident.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-20 18:00:36.104	\N	2025-10-19 18:00:36.139319	2025-10-19 18:00:36.139319
0cc3af45-75cd-4721-b74c-cb3dd6cba94c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	04465623-29cb-4298-8828-d1839e9cc00d	e4ce7abb-fb0c-42e1-a7c1-6419b4aa63ef	235b548d-f0a0-4899-9a7e-d6e9bec6db40	2025-08-20	\N	\N	4.00	meeting	t	f	85.00	340.00	\N	Laborum calcar corona.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-20 18:00:36.104	\N	2025-10-19 18:00:36.141565	2025-10-19 18:00:36.141565
3de4d9e9-68c7-46f7-9abc-2ce9b4d1b142	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	17f141c2-e297-4c93-9178-0fd819259c50	a18510b4-73e3-40ff-84b1-89c4a2e0bdac	a8a65b80-dc4c-49f9-9c8d-0dc4a336cf55	2025-08-20	\N	\N	0.50	meeting	t	f	85.00	42.50	\N	Synagoga adiuvo solio aptus absconditus laudantium id cohibeo vae.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-20 18:00:36.104	\N	2025-10-19 18:00:36.143945	2025-10-19 18:00:36.143945
b560d72a-a8c5-4e1f-a61e-6f05abcb5612	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	5e2204cd-be52-42a7-aa41-14fcf0e4a272	29a61f52-d957-4207-b54b-7fc565a57541	2025-08-20	\N	\N	3.50	work	t	t	85.00	297.50	\N	Virtus tametsi delicate magni tabernus accedo creo argumentum decor victus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-20 18:00:36.104	\N	2025-10-19 18:00:36.146297	2025-10-19 18:00:36.146297
6f2a9090-2733-43d7-878c-c51dad01f075	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	a4464f5a-2125-46d9-9f58-7252c9adc16b	7041a9f2-cd04-4f9c-ab2c-96bfdd45e5ff	a0801828-5c53-41ef-9b3e-06db89d72e90	2025-08-20	\N	\N	3.00	training	f	f	85.00	255.00	\N	Sollicito ascisco deprecator teres censura ante coadunatio vulgaris.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-20 18:00:36.104	\N	2025-10-19 18:00:36.148421	2025-10-19 18:00:36.148421
c4139454-26f8-4e4c-bb14-c802c100ba4c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	5515e216-ea3c-436b-95a5-6abf213c47ef	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	2025-08-21	\N	\N	1.50	training	t	f	150.00	225.00	\N	Animadverto cinis delectus conitor civis colo viduo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-21 18:00:36.149	\N	2025-10-19 18:00:36.150454	2025-10-19 18:00:36.150454
ecd1ef23-98a1-49dd-bb0d-1b2e52c9672a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	b0a95e11-90ac-4ab3-b099-c4de69f498b8	269dca40-b352-4a09-9d7c-c735016a8c7d	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	2025-08-21	\N	\N	1.00	admin	t	f	150.00	150.00	\N	Tredecim cito earum truculenter conventus argentum viduo claustrum alveus video.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-21 18:00:36.149	\N	2025-10-19 18:00:36.152545	2025-10-19 18:00:36.152545
9c48d2b2-fe48-410c-86b6-92defbac62b3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	584bab37-ccf2-484c-9a7f-7394e4b30ec6	7a582f98-6d3d-44d5-9796-ba1d12c49f62	ef53422c-1305-4831-bf41-d85b2a76b0d5	2025-08-21	\N	\N	3.00	admin	t	f	150.00	450.00	\N	Amplexus enim corrigo ter conculco asporto ambulo curia aperte.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-21 18:00:36.149	\N	2025-10-19 18:00:36.154828	2025-10-19 18:00:36.154828
ce9867d6-ee1c-4170-8fbe-6c00a1a1b7e7	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	7ef8af5a-1080-42a2-988f-ddfa799c8070	1c9d17d2-a153-4f42-9604-129a162a1f0f	18c91d63-8f9d-4974-ba97-a4079c7457d5	2025-08-21	\N	\N	1.50	training	t	f	150.00	225.00	\N	Speciosus certe validus dolor denique civitas vapulus sonitus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-21 18:00:36.149	\N	2025-10-19 18:00:36.158443	2025-10-19 18:00:36.158443
c041ff5e-c089-4ad3-9c91-f6176d05244a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	b0a95e11-90ac-4ab3-b099-c4de69f498b8	269dca40-b352-4a09-9d7c-c735016a8c7d	78882562-2120-44d2-9286-03e696abbf02	2025-08-21	\N	\N	1.00	research	t	f	120.00	120.00	\N	Deprecator contego ipsa abscido curatio casso.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-21 18:00:36.149	\N	2025-10-19 18:00:36.162907	2025-10-19 18:00:36.162907
0ea48b79-f890-4abd-a652-ed5059630af5	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	584bab37-ccf2-484c-9a7f-7394e4b30ec6	ddc09723-5f7f-4f23-a202-0b6243ef63f9	d6d7e47b-cd48-48d8-a45a-fa75af1f9a52	2025-08-21	\N	\N	3.25	work	t	f	120.00	390.00	\N	Considero acerbitas denique viridis expedita cerno autus ocer.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-21 18:00:36.149	\N	2025-10-19 18:00:36.166302	2025-10-19 18:00:36.166302
4a6ca402-7354-4878-a9d5-85d837e5f36c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	6ecda653-6094-4502-9d1d-6e90d9ea99ed	4fb9cb0a-ca36-4af7-9203-ac1970ce555b	08ee5378-067c-4708-886c-34df4c200b23	2025-08-21	\N	\N	1.25	admin	t	f	120.00	150.00	\N	Comparo altus aperte theatrum demum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-21 18:00:36.149	\N	2025-10-19 18:00:36.168734	2025-10-19 18:00:36.168734
286e8e0c-f1a2-4176-b582-ceaa69d0a29b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	dc9252b7-2022-4822-a8b2-7ec227fe0ea4	cbf9b499-276b-4a28-999c-27388562c4f4	2025-08-21	\N	\N	2.50	meeting	t	f	120.00	300.00	\N	Centum est cito pecco occaecati tamen.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-21 18:00:36.149	\N	2025-10-19 18:00:36.170647	2025-10-19 18:00:36.170647
b8cb3252-b23a-4890-aaec-a318440d6546	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	67f62599-7f9f-44e8-bc18-d2ce08ea9919	9ec151a2-b6a4-433d-a21e-c94af23b785b	ff4a2600-29fe-4448-bec3-ea868988a9ed	2025-08-21	\N	\N	2.25	meeting	t	f	120.00	270.00	\N	Pecus tamen expedita venia cubo aeneus capillus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-21 18:00:36.149	\N	2025-10-19 18:00:36.172991	2025-10-19 18:00:36.172991
68550066-bc09-4713-b55f-3161bca5c796	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	a4464f5a-2125-46d9-9f58-7252c9adc16b	9068b493-e301-4f68-9bcd-ad7c1f9cbe03	18c91d63-8f9d-4974-ba97-a4079c7457d5	2025-08-21	\N	\N	2.50	training	t	t	110.00	275.00	\N	Porro vilis terra cuppedia.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-21 18:00:36.149	\N	2025-10-19 18:00:36.175316	2025-10-19 18:00:36.175316
a117f3c6-6451-40bf-96fd-ef4c6b9f6881	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	4554e09d-4391-42a8-a2cd-9702bce80511	ae73110f-e045-44ac-85ff-51aa2eb8ce69	996aa78c-cfd1-477f-8c30-d9489225b29e	2025-08-21	\N	\N	2.75	research	t	t	110.00	302.50	\N	Alter voluntarius voluptatem similique via confugo soleo ipsa.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-21 18:00:36.149	\N	2025-10-19 18:00:36.178043	2025-10-19 18:00:36.178043
12fa1be4-ef05-43d2-a228-3ebb7b3fbab9	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	b0a95e11-90ac-4ab3-b099-c4de69f498b8	269dca40-b352-4a09-9d7c-c735016a8c7d	18c91d63-8f9d-4974-ba97-a4079c7457d5	2025-08-21	\N	\N	4.00	work	t	f	110.00	440.00	\N	Tantillus alo tenus voluptatibus ullus acerbitas.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-21 18:00:36.149	\N	2025-10-19 18:00:36.180854	2025-10-19 18:00:36.180854
c718c1c9-a99b-4ac8-9e0e-5f96e0a1ca24	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	a4464f5a-2125-46d9-9f58-7252c9adc16b	b09b8a10-2b29-4fa3-b57f-c69d46364489	a8a65b80-dc4c-49f9-9c8d-0dc4a336cf55	2025-08-21	\N	\N	2.25	research	t	f	110.00	247.50	\N	Curtus appello callide denuo cenaculum vero infit tres statim.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-21 18:00:36.149	\N	2025-10-19 18:00:36.185893	2025-10-19 18:00:36.185893
e5d05b30-1155-4ded-b2ac-8bad4da1878a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	702b5a48-f7a9-464c-8833-1ff6577e50e6	0da2984a-30cb-4fdf-a4f6-b38ff97be406	18c91d63-8f9d-4974-ba97-a4079c7457d5	2025-08-21	\N	\N	3.75	research	t	t	110.00	412.50	\N	Omnis pax verus credo amoveo incidunt est solvo volup calculus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-21 18:00:36.149	\N	2025-10-19 18:00:36.190839	2025-10-19 18:00:36.190839
6b404b4d-212d-4004-8f30-aa7c0ff18ebc	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	04465623-29cb-4298-8828-d1839e9cc00d	e4ce7abb-fb0c-42e1-a7c1-6419b4aa63ef	e2cd4da6-f171-436c-9c7e-a9c1c5436b98	2025-08-21	\N	\N	1.25	work	t	f	85.00	106.25	\N	Convoco turbo valde damnatio.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-21 18:00:36.149	\N	2025-10-19 18:00:36.19344	2025-10-19 18:00:36.19344
63f7b2f0-ebe2-4ccd-8c78-a8c583f21563	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	07b65174-c767-4ace-ac22-e486eb422fa6	a96c9f4d-dc33-4af3-818d-8d729f0f8c1f	2025-08-21	\N	\N	1.75	research	t	f	85.00	148.75	\N	Argumentum damnatio auxilium cauda curtus totus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-21 18:00:36.149	\N	2025-10-19 18:00:36.195486	2025-10-19 18:00:36.195486
f129cfe5-b920-4667-a970-da1688c3157f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	405d4d05-841b-437d-af7d-70b66dda4cbc	9485b00c-4fc8-454f-984a-6908039db9f9	d04961e2-5af7-4b9c-bb44-c37031dd6bfa	2025-08-21	\N	\N	2.50	research	t	f	85.00	212.50	\N	Tepidus acsi annus adficio pectus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-21 18:00:36.149	\N	2025-10-19 18:00:36.197634	2025-10-19 18:00:36.197634
9680eeaf-db53-4759-94c6-08e698750b59	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	8538cc30-f9e7-4b63-a885-56b23e16ecef	b3d1095b-3d51-444b-be35-f485afdb174f	d04961e2-5af7-4b9c-bb44-c37031dd6bfa	2025-08-22	\N	\N	3.00	meeting	t	f	150.00	450.00	\N	Asperiores agnitio voluptatibus adimpleo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-22 18:00:36.199	\N	2025-10-19 18:00:36.20049	2025-10-19 18:00:36.20049
f3f3fcc7-ff18-4c0c-b728-ce56a94e7c86	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	b7295600-5c20-4de2-8782-af87987c2bee	2849d1a9-72a4-4287-8114-b604140c71aa	1ede1cc0-3627-404e-bb8a-487e028f4732	2025-08-22	\N	\N	1.00	training	f	f	150.00	150.00	\N	Tandem odit utique sub attonbitus cado.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-22 18:00:36.199	\N	2025-10-19 18:00:36.2056	2025-10-19 18:00:36.2056
0e402bfb-7a23-4bd2-9574-eb64e9752538	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	088446c4-4542-4007-9887-b512bd3db05d	d6d7e47b-cd48-48d8-a45a-fa75af1f9a52	2025-08-22	\N	\N	1.75	training	t	t	150.00	262.50	\N	Armarium cohors laudantium thymbra.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-22 18:00:36.199	\N	2025-10-19 18:00:36.212595	2025-10-19 18:00:36.212595
db669b71-9fc2-4b4f-bb6b-21a68cbc7eb3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	702b5a48-f7a9-464c-8833-1ff6577e50e6	66d28217-b458-4ec3-9e88-eb34570556b7	29a61f52-d957-4207-b54b-7fc565a57541	2025-08-22	\N	\N	1.75	admin	t	t	150.00	262.50	\N	Solitudo reprehenderit demergo repellat supplanto similique.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-22 18:00:36.199	\N	2025-10-19 18:00:36.21817	2025-10-19 18:00:36.21817
99ad0103-3bbd-4719-bc62-3ed8c38e1d1e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	b7295600-5c20-4de2-8782-af87987c2bee	2849d1a9-72a4-4287-8114-b604140c71aa	ff4a2600-29fe-4448-bec3-ea868988a9ed	2025-08-22	\N	\N	1.00	admin	t	t	120.00	120.00	\N	Vero altus illo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-22 18:00:36.199	\N	2025-10-19 18:00:36.22222	2025-10-19 18:00:36.22222
2779dd5d-d75f-47e2-a4f7-1d6ac32f6841	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	702b5a48-f7a9-464c-8833-1ff6577e50e6	0da2984a-30cb-4fdf-a4f6-b38ff97be406	1ede1cc0-3627-404e-bb8a-487e028f4732	2025-08-22	\N	\N	0.50	admin	t	f	120.00	60.00	\N	Acidus dedico vinculum armarium tergiversatio conicio dolorum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-22 18:00:36.199	\N	2025-10-19 18:00:36.224883	2025-10-19 18:00:36.224883
1e8ea9f1-49cf-4b04-a3da-a35af7bbb5fa	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	088446c4-4542-4007-9887-b512bd3db05d	ecfd2c2c-905b-4ef4-99a4-8949632b9ae9	2025-08-22	\N	\N	1.50	work	t	f	110.00	165.00	\N	Desparatus utique corrupti ventito repellendus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-22 18:00:36.199	\N	2025-10-19 18:00:36.228777	2025-10-19 18:00:36.228777
98ad328f-cbc8-43a1-b49d-f31c7a843130	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	a4464f5a-2125-46d9-9f58-7252c9adc16b	a08b1624-6e7a-4a25-8f08-3b9b00adb6a0	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	2025-08-22	\N	\N	2.50	meeting	f	t	110.00	275.00	\N	Voluptatum commemoro cuius delicate adamo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-22 18:00:36.199	\N	2025-10-19 18:00:36.234478	2025-10-19 18:00:36.234478
bed9cfc2-51d7-471c-ae72-dbf5032e5389	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	b7295600-5c20-4de2-8782-af87987c2bee	d2f831e1-38ca-429c-9942-06db88f8dfc5	a49c064a-0890-4c02-8734-07a3185e6c03	2025-08-22	\N	\N	3.00	meeting	t	t	110.00	330.00	\N	Chirographum sonitus adduco ea carcer tabula vacuus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-22 18:00:36.199	\N	2025-10-19 18:00:36.236832	2025-10-19 18:00:36.236832
82ad42fb-fb35-445d-ab67-f04a528cb3d8	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	405d4d05-841b-437d-af7d-70b66dda4cbc	9485b00c-4fc8-454f-984a-6908039db9f9	78882562-2120-44d2-9286-03e696abbf02	2025-08-22	\N	\N	1.00	meeting	t	t	110.00	110.00	\N	Labore audax cometes.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-22 18:00:36.199	\N	2025-10-19 18:00:36.24085	2025-10-19 18:00:36.24085
0e104fb7-5de9-451e-ba4f-004b61f091a0	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	45b3d726-e151-4770-9b64-4653914bdaa5	92700c16-c146-4a6e-9610-46ac28f4b4c3	18c91d63-8f9d-4974-ba97-a4079c7457d5	2025-08-22	\N	\N	2.50	meeting	t	f	110.00	275.00	\N	Valeo velum taceo concedo alii argumentum explicabo aperio qui.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-22 18:00:36.199	\N	2025-10-19 18:00:36.243146	2025-10-19 18:00:36.243146
c17f51ba-e8fe-41a4-acb2-89ce24177797	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	dc9252b7-2022-4822-a8b2-7ec227fe0ea4	08ee5378-067c-4708-886c-34df4c200b23	2025-08-22	\N	\N	1.75	research	t	f	85.00	148.75	\N	Adflicto tollo consuasor sperno stabilis tactus voluptatum votum suppono quis.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-22 18:00:36.199	\N	2025-10-19 18:00:36.245281	2025-10-19 18:00:36.245281
5c4e5f11-d50a-47c8-92af-2e8de9a5377a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	8538cc30-f9e7-4b63-a885-56b23e16ecef	b3d1095b-3d51-444b-be35-f485afdb174f	996aa78c-cfd1-477f-8c30-d9489225b29e	2025-08-22	\N	\N	2.50	work	f	f	85.00	212.50	\N	Tergeo voluptatum ventito volubilis.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-22 18:00:36.199	\N	2025-10-19 18:00:36.249067	2025-10-19 18:00:36.249067
c0419d39-1db7-479e-b891-696fb803ffec	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	eb1af1df-ce0a-4763-aaef-49b6b390beab	391f7d87-df5d-4538-9b3e-31e07ac9347e	2025-08-22	\N	\N	2.00	training	f	f	85.00	170.00	\N	Territo uredo solus soluta utpote tenus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-22 18:00:36.199	\N	2025-10-19 18:00:36.250987	2025-10-19 18:00:36.250987
f14245fc-ab7f-4d69-b74f-1f13683f1ec0	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	405d4d05-841b-437d-af7d-70b66dda4cbc	4f8e956e-3c05-4a0d-8695-2014ee9b2f8a	d6d7e47b-cd48-48d8-a45a-fa75af1f9a52	2025-08-22	\N	\N	4.00	work	f	f	85.00	340.00	\N	Cavus dolorem votum derideo subito solutio vinculum deficio cumque.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-22 18:00:36.199	\N	2025-10-19 18:00:36.255768	2025-10-19 18:00:36.255768
c79047cd-81d8-43f0-a9e3-83d4599144f8	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	d69d0436-37d7-42a4-b907-3d9c3a091ea6	0b689153-0b45-4725-866b-5eac75a40ad8	29a61f52-d957-4207-b54b-7fc565a57541	2025-08-25	\N	\N	2.50	research	f	f	150.00	375.00	\N	Depono ubi campana.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-25 18:00:36.257	\N	2025-10-19 18:00:36.259636	2025-10-19 18:00:36.259636
c559d3c6-336c-4efc-95bb-fb25992b6773	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	4554e09d-4391-42a8-a2cd-9702bce80511	ae73110f-e045-44ac-85ff-51aa2eb8ce69	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	2025-08-25	\N	\N	2.75	admin	t	f	150.00	412.50	\N	Textus arto coniuratio vulnero tricesimus villa cubitum ubi deduco dolorum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-25 18:00:36.257	\N	2025-10-19 18:00:36.264342	2025-10-19 18:00:36.264342
b62d6d19-72cc-40a1-8399-e103145b3952	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	67f62599-7f9f-44e8-bc18-d2ce08ea9919	9ec151a2-b6a4-433d-a21e-c94af23b785b	18c91d63-8f9d-4974-ba97-a4079c7457d5	2025-08-25	\N	\N	2.25	meeting	t	t	150.00	337.50	\N	Patruus amissio angustus commemoro uredo arca.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-25 18:00:36.257	\N	2025-10-19 18:00:36.266455	2025-10-19 18:00:36.266455
a1119089-7025-488d-a8b0-05bb0e05a70a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	dc9252b7-2022-4822-a8b2-7ec227fe0ea4	a49c064a-0890-4c02-8734-07a3185e6c03	2025-08-25	\N	\N	2.00	research	t	f	150.00	300.00	\N	Copia circumvenio terga texo usque.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-25 18:00:36.257	\N	2025-10-19 18:00:36.269393	2025-10-19 18:00:36.269393
7fc263df-8c02-4ba4-89a9-e860b9447f36	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	17f141c2-e297-4c93-9178-0fd819259c50	80260d18-0de6-4cf6-af1d-5b4a1d17a6de	a8a65b80-dc4c-49f9-9c8d-0dc4a336cf55	2025-08-25	\N	\N	1.50	work	t	f	150.00	225.00	\N	Celo tabella unde alii.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-25 18:00:36.257	\N	2025-10-19 18:00:36.272398	2025-10-19 18:00:36.272398
c051f811-7e4a-4f1f-bd37-e5ad754cac9d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	6b008063-17c8-4c31-893b-ef9f17e74f13	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	2025-08-25	\N	\N	0.50	research	t	f	120.00	60.00	\N	Aliquam trans aer pecus vacuus labore patrocinor cilicium.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-25 18:00:36.257	\N	2025-10-19 18:00:36.275516	2025-10-19 18:00:36.275516
097d7b0d-5f32-48bd-b2d7-52245c3f3aa3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	46859340-c8cf-4144-aa6c-28fbaf53fa0e	f9444b08-3c00-4407-98d8-3d654600142c	d6d7e47b-cd48-48d8-a45a-fa75af1f9a52	2025-08-25	\N	\N	0.75	research	f	f	120.00	90.00	\N	Exercitationem cedo consequatur vito defendo deorsum utrum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-25 18:00:36.257	\N	2025-10-19 18:00:36.278527	2025-10-19 18:00:36.278527
ed71865a-0a7e-4515-a7a5-4ef513b1a9b0	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	b7295600-5c20-4de2-8782-af87987c2bee	2849d1a9-72a4-4287-8114-b604140c71aa	a49c064a-0890-4c02-8734-07a3185e6c03	2025-08-25	\N	\N	2.00	training	t	f	110.00	220.00	\N	Aut tactus adversus recusandae perspiciatis veritatis causa vilis delibero.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-25 18:00:36.257	\N	2025-10-19 18:00:36.281894	2025-10-19 18:00:36.281894
b02b19ef-b27d-43d1-8088-cefcc48b5910	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	eb1af1df-ce0a-4763-aaef-49b6b390beab	a8a65b80-dc4c-49f9-9c8d-0dc4a336cf55	2025-08-25	\N	\N	3.75	training	t	f	110.00	412.50	\N	Sequi modi aestas.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-25 18:00:36.257	\N	2025-10-19 18:00:36.284116	2025-10-19 18:00:36.284116
1397e4e6-c0c7-4e56-9ca3-f050cfebd2fd	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	46859340-c8cf-4144-aa6c-28fbaf53fa0e	f9444b08-3c00-4407-98d8-3d654600142c	3f2e9a8e-bdfe-4d09-aced-e88cdc710462	2025-08-25	\N	\N	3.75	training	t	f	110.00	412.50	\N	Vero coadunatio verto quod vivo at.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-25 18:00:36.257	\N	2025-10-19 18:00:36.286396	2025-10-19 18:00:36.286396
743c053a-beff-43fd-ab3c-e662f37e6c66	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	4554e09d-4391-42a8-a2cd-9702bce80511	ae73110f-e045-44ac-85ff-51aa2eb8ce69	a49c064a-0890-4c02-8734-07a3185e6c03	2025-08-25	\N	\N	3.50	research	t	t	85.00	297.50	\N	Adduco adeo error suppono aestus aduro arcesso suggero eaque.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-25 18:00:36.257	\N	2025-10-19 18:00:36.288604	2025-10-19 18:00:36.288604
17762d90-a5f3-4fb2-b3c0-c46c661404aa	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	405d4d05-841b-437d-af7d-70b66dda4cbc	219aa257-710f-4ef2-892d-39086a9690ed	ca413110-b7e3-4734-a185-d21ea0960708	2025-08-25	\N	\N	2.75	admin	f	f	85.00	233.75	\N	Vitae quidem uredo coerceo dedecor asperiores vilitas placeat pectus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-25 18:00:36.257	\N	2025-10-19 18:00:36.290777	2025-10-19 18:00:36.290777
23334af8-2df1-43a9-9ef7-6524bb078106	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	45b3d726-e151-4770-9b64-4653914bdaa5	449f8e23-33a0-4bf0-915e-cc79d13bc3a9	ca413110-b7e3-4734-a185-d21ea0960708	2025-08-26	\N	\N	2.00	research	t	f	150.00	300.00	\N	Atrox animadverto quam tantum vita cupio derelinquo desino.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-26 18:00:36.292	\N	2025-10-19 18:00:36.292878	2025-10-19 18:00:36.292878
ffae7fa5-14c0-46a6-8768-0b2f63b04acc	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	702b5a48-f7a9-464c-8833-1ff6577e50e6	66d28217-b458-4ec3-9e88-eb34570556b7	235b548d-f0a0-4899-9a7e-d6e9bec6db40	2025-08-26	\N	\N	2.00	training	t	f	150.00	300.00	\N	Titulus commemoro aspernatur accusamus soleo aureus repellendus paens celebrer amitto.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-26 18:00:36.292	\N	2025-10-19 18:00:36.295675	2025-10-19 18:00:36.295675
163af5ed-521d-4ee9-8955-630bf6b5b3b8	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	405d4d05-841b-437d-af7d-70b66dda4cbc	4f8e956e-3c05-4a0d-8695-2014ee9b2f8a	d6d7e47b-cd48-48d8-a45a-fa75af1f9a52	2025-08-26	\N	\N	1.50	work	t	f	150.00	225.00	\N	Stultus tactus assentator verumtamen tego quisquam calamitas aperte accendo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-26 18:00:36.292	\N	2025-10-19 18:00:36.298202	2025-10-19 18:00:36.298202
01c4d139-3079-465d-9137-cb5a3e1a6673	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	65a6152e-a261-4a70-99fb-82f044e87d05	b7a77905-edd5-451e-a92e-06976feeb638	d04961e2-5af7-4b9c-bb44-c37031dd6bfa	2025-08-26	\N	\N	4.00	training	t	t	150.00	600.00	\N	Valde suppono creptio.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-26 18:00:36.292	\N	2025-10-19 18:00:36.300338	2025-10-19 18:00:36.300338
00f76910-0b18-4961-91d0-7becf62e162c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	6a032ece-4f9e-405a-b48a-b28516d15fe1	43f46d13-e4e7-4e0f-a62d-25d47b569d15	9362cf11-827c-459a-8ffc-6634bd023508	2025-08-26	\N	\N	3.50	meeting	t	f	120.00	420.00	\N	Tot turpis terebro arma officiis crepusculum subiungo sordeo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-26 18:00:36.292	\N	2025-10-19 18:00:36.302706	2025-10-19 18:00:36.302706
84ada4f9-a397-4fee-ba32-bf975337fedb	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	584bab37-ccf2-484c-9a7f-7394e4b30ec6	71b851af-8542-47e4-9ff8-304ed5983a0b	d04961e2-5af7-4b9c-bb44-c37031dd6bfa	2025-08-26	\N	\N	3.50	meeting	t	f	120.00	420.00	\N	Tenetur vulticulus bibo quos contego.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-26 18:00:36.292	\N	2025-10-19 18:00:36.305403	2025-10-19 18:00:36.305403
9b5a7080-086c-4612-b523-da885ccdf9a9	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	584bab37-ccf2-484c-9a7f-7394e4b30ec6	e64d20a6-86e7-4dd1-ab40-aabaedbd6ebb	391f7d87-df5d-4538-9b3e-31e07ac9347e	2025-08-26	\N	\N	1.75	research	f	f	120.00	210.00	\N	Degero amissio vociferor vinitor sunt qui tergum velociter curso.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-26 18:00:36.292	\N	2025-10-19 18:00:36.307412	2025-10-19 18:00:36.307412
e2745dc7-65a3-4969-b1d6-7ceda55dc399	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	6ecda653-6094-4502-9d1d-6e90d9ea99ed	4fb9cb0a-ca36-4af7-9203-ac1970ce555b	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	2025-08-26	\N	\N	3.00	training	t	t	110.00	330.00	\N	Umquam ait aspicio adiuvo acquiro vir comptus solvo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-26 18:00:36.292	\N	2025-10-19 18:00:36.309657	2025-10-19 18:00:36.309657
55a3315d-6f56-4345-bbc1-d5d307d016dc	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	7ef8af5a-1080-42a2-988f-ddfa799c8070	5cf17315-4658-4a7f-9c23-b4f8268d8f84	235b548d-f0a0-4899-9a7e-d6e9bec6db40	2025-08-26	\N	\N	3.75	work	t	f	110.00	412.50	\N	Suadeo corrupti approbo contra desino.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-26 18:00:36.292	\N	2025-10-19 18:00:36.312751	2025-10-19 18:00:36.312751
9a536476-8549-4500-91fd-2cc8e896d4f3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	5e2204cd-be52-42a7-aa41-14fcf0e4a272	109283c7-55ef-4e05-bf53-c6efd1be486f	2025-08-26	\N	\N	2.00	work	f	f	110.00	220.00	\N	Truculenter tamdiu tero.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-26 18:00:36.292	\N	2025-10-19 18:00:36.316707	2025-10-19 18:00:36.316707
b3cceced-35fa-4eea-9827-696f72506253	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	4554e09d-4391-42a8-a2cd-9702bce80511	ae73110f-e045-44ac-85ff-51aa2eb8ce69	08ee5378-067c-4708-886c-34df4c200b23	2025-08-26	\N	\N	1.50	work	t	f	110.00	165.00	\N	Concedo vinum fugiat vitiosus non despecto quis charisma sunt.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-26 18:00:36.292	\N	2025-10-19 18:00:36.320881	2025-10-19 18:00:36.320881
b2261768-50e7-4824-a793-b7681e8ae38d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	b0a95e11-90ac-4ab3-b099-c4de69f498b8	269dca40-b352-4a09-9d7c-c735016a8c7d	79d01aa5-b680-4830-ab3a-5e3cb66edcfa	2025-08-26	\N	\N	1.00	admin	t	t	110.00	110.00	\N	Acies necessitatibus vociferor curto.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-26 18:00:36.292	\N	2025-10-19 18:00:36.323083	2025-10-19 18:00:36.323083
c86ed724-99d2-423a-a452-62047c59f261	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	6a032ece-4f9e-405a-b48a-b28516d15fe1	7add02b8-5d73-4a39-8607-6f9d17b36fda	ef53422c-1305-4831-bf41-d85b2a76b0d5	2025-08-26	\N	\N	0.50	meeting	t	t	85.00	42.50	\N	Tollo averto comburo constans temperantia blandior volutabrum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-26 18:00:36.292	\N	2025-10-19 18:00:36.325444	2025-10-19 18:00:36.325444
b57759a8-0331-4547-8f70-c420fe878bb6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	8538cc30-f9e7-4b63-a885-56b23e16ecef	b3d1095b-3d51-444b-be35-f485afdb174f	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	2025-08-26	\N	\N	3.00	work	t	f	85.00	255.00	\N	Sopor curatio civitas stabilis.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-26 18:00:36.292	\N	2025-10-19 18:00:36.327725	2025-10-19 18:00:36.327725
a2d41a9a-c55b-463a-bdd9-f0e33c1b66de	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	04465623-29cb-4298-8828-d1839e9cc00d	e4ce7abb-fb0c-42e1-a7c1-6419b4aa63ef	e4487405-7859-40e9-8008-056d32fe6f10	2025-08-26	\N	\N	2.25	work	t	f	85.00	191.25	\N	Cito cetera stultus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-26 18:00:36.292	\N	2025-10-19 18:00:36.329705	2025-10-19 18:00:36.329705
21cd1d28-0f78-414a-a385-7c516fcdfbab	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	5515e216-ea3c-436b-95a5-6abf213c47ef	d04961e2-5af7-4b9c-bb44-c37031dd6bfa	2025-08-26	\N	\N	1.25	training	t	f	85.00	106.25	\N	Adversus vomito argumentum iste tunc suppono exercitationem.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-26 18:00:36.292	\N	2025-10-19 18:00:36.331628	2025-10-19 18:00:36.331628
533bd14d-57e5-48f3-b783-764661edc85b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	17f141c2-e297-4c93-9178-0fd819259c50	c7111387-5606-4d4b-88de-270766225b61	79d01aa5-b680-4830-ab3a-5e3cb66edcfa	2025-08-27	\N	\N	3.75	admin	t	f	150.00	562.50	\N	Autus autem suppellex textus quidem.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-27 18:00:36.332	\N	2025-10-19 18:00:36.333511	2025-10-19 18:00:36.333511
8a0aa714-c1af-466e-b0b2-5bf4365c71da	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	5515e216-ea3c-436b-95a5-6abf213c47ef	e2cd4da6-f171-436c-9c7e-a9c1c5436b98	2025-08-27	\N	\N	4.00	meeting	f	f	150.00	600.00	\N	Neque tonsor pecco triduana.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-27 18:00:36.332	\N	2025-10-19 18:00:36.335126	2025-10-19 18:00:36.335126
0578c0ae-f367-4efe-8940-a22195fca8ba	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	4554e09d-4391-42a8-a2cd-9702bce80511	ae73110f-e045-44ac-85ff-51aa2eb8ce69	9362cf11-827c-459a-8ffc-6634bd023508	2025-08-27	\N	\N	1.00	training	t	f	120.00	120.00	\N	Admoneo tabesco angelus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-27 18:00:36.332	\N	2025-10-19 18:00:36.336946	2025-10-19 18:00:36.336946
9c9c50ed-4d51-4aff-b808-6a122d685f57	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	702b5a48-f7a9-464c-8833-1ff6577e50e6	66d28217-b458-4ec3-9e88-eb34570556b7	ecfd2c2c-905b-4ef4-99a4-8949632b9ae9	2025-08-27	\N	\N	4.00	research	t	f	120.00	480.00	\N	Sollicito voluptatibus certe avarus despecto.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-27 18:00:36.332	\N	2025-10-19 18:00:36.338594	2025-10-19 18:00:36.338594
2c70173f-ab9f-4ade-afcd-0f1973f0a941	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	5515e216-ea3c-436b-95a5-6abf213c47ef	9362cf11-827c-459a-8ffc-6634bd023508	2025-08-27	\N	\N	1.50	meeting	t	t	120.00	180.00	\N	Cunctatio depono spiritus baiulus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-27 18:00:36.332	\N	2025-10-19 18:00:36.341148	2025-10-19 18:00:36.341148
70ccf9c2-a467-4c88-af65-d7e9d18c14fb	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	5e2204cd-be52-42a7-aa41-14fcf0e4a272	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-08-27	\N	\N	1.00	meeting	t	t	110.00	110.00	\N	Dolorum articulus terga civitas tum debilito defungo sollicito omnis.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-27 18:00:36.332	\N	2025-10-19 18:00:36.343824	2025-10-19 18:00:36.343824
ce283422-978b-414c-ab05-9ce49f900090	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	6ecda653-6094-4502-9d1d-6e90d9ea99ed	6c88f260-519e-41e9-9fac-18a28b9a7901	3f2e9a8e-bdfe-4d09-aced-e88cdc710462	2025-08-27	\N	\N	3.75	work	t	f	110.00	412.50	\N	Conitor suffragium fuga pax adhuc cuius facilis una cursim.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-27 18:00:36.332	\N	2025-10-19 18:00:36.346804	2025-10-19 18:00:36.346804
973593ec-4b8a-4020-97ee-52a55ee160b4	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	04465623-29cb-4298-8828-d1839e9cc00d	e4ce7abb-fb0c-42e1-a7c1-6419b4aa63ef	79d01aa5-b680-4830-ab3a-5e3cb66edcfa	2025-08-27	\N	\N	3.25	research	t	f	110.00	357.50	\N	Varius ventosus spiculum adversus facere cupio substantia.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-27 18:00:36.332	\N	2025-10-19 18:00:36.352845	2025-10-19 18:00:36.352845
b37f25a7-7de2-4130-ae1b-c248408236ca	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	b7295600-5c20-4de2-8782-af87987c2bee	196a1b4b-9367-4b9f-baf6-717d312881a3	a49c064a-0890-4c02-8734-07a3185e6c03	2025-08-27	\N	\N	2.25	admin	t	f	110.00	247.50	\N	Capio uberrime vulgo cognatus vinitor dicta talio despecto eum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-27 18:00:36.332	\N	2025-10-19 18:00:36.356084	2025-10-19 18:00:36.356084
c69de9ce-f243-49d2-b910-650cd4bcf876	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	6b008063-17c8-4c31-893b-ef9f17e74f13	ef53422c-1305-4831-bf41-d85b2a76b0d5	2025-08-27	\N	\N	3.25	admin	f	f	85.00	276.25	\N	Curvo aggredior color sit vomer succedo caste vesco.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-27 18:00:36.332	\N	2025-10-19 18:00:36.359358	2025-10-19 18:00:36.359358
b2f267b7-0199-4fc6-9392-cfeab691f69d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	5e2204cd-be52-42a7-aa41-14fcf0e4a272	1ede1cc0-3627-404e-bb8a-487e028f4732	2025-08-27	\N	\N	3.50	research	f	f	85.00	297.50	\N	Cariosus strenuus urbanus error cum agnosco utpote impedit ara volo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-27 18:00:36.332	\N	2025-10-19 18:00:36.362544	2025-10-19 18:00:36.362544
c66f2a35-ebd7-4d61-8416-5e82f2685e37	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	a4464f5a-2125-46d9-9f58-7252c9adc16b	9068b493-e301-4f68-9bcd-ad7c1f9cbe03	e2cd4da6-f171-436c-9c7e-a9c1c5436b98	2025-08-27	\N	\N	1.25	research	t	t	85.00	106.25	\N	Laudantium careo audacia architecto alo verumtamen bonus rem adfectus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-27 18:00:36.332	\N	2025-10-19 18:00:36.365504	2025-10-19 18:00:36.365504
bd549f66-c010-482a-ab7c-31652618a741	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	0d0329f4-4b80-4899-8807-5854e9db312b	40ca5c4e-33d7-432f-a55c-b59c3010d7ef	78882562-2120-44d2-9286-03e696abbf02	2025-08-27	\N	\N	1.25	meeting	t	t	85.00	106.25	\N	Aspernatur vitium voluptatibus corona benigne.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-27 18:00:36.332	\N	2025-10-19 18:00:36.368086	2025-10-19 18:00:36.368086
c1b117cb-7dfb-4070-b6aa-ca5375f2be2c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	04600664-34f3-4ae0-9a01-2da04b5bc5fc	78882562-2120-44d2-9286-03e696abbf02	2025-08-28	\N	\N	2.00	admin	t	f	150.00	300.00	\N	Traho varius subseco solvo subiungo spiritus vitae crastinus coaegresco apostolus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-28 18:00:36.369	\N	2025-10-19 18:00:36.371142	2025-10-19 18:00:36.371142
bdbebee0-2aad-4468-933b-013f99118845	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	8538cc30-f9e7-4b63-a885-56b23e16ecef	b3d1095b-3d51-444b-be35-f485afdb174f	391f7d87-df5d-4538-9b3e-31e07ac9347e	2025-08-28	\N	\N	1.50	research	t	f	150.00	225.00	\N	Laborum sufficio sum cui vulgo pauci.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-28 18:00:36.369	\N	2025-10-19 18:00:36.373301	2025-10-19 18:00:36.373301
6f53fb3a-3967-4719-a372-3ea368841ebb	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	8538cc30-f9e7-4b63-a885-56b23e16ecef	b3d1095b-3d51-444b-be35-f485afdb174f	29a61f52-d957-4207-b54b-7fc565a57541	2025-08-28	\N	\N	2.50	training	f	f	150.00	375.00	\N	Tenetur atqui cumque administratio decens consequatur urbanus umerus degusto.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-28 18:00:36.369	\N	2025-10-19 18:00:36.376148	2025-10-19 18:00:36.376148
b7e89969-0b42-4b32-b55c-80fdf2156a6e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	45b3d726-e151-4770-9b64-4653914bdaa5	2c1d5d5c-be1c-427c-b2ac-da3cc28b1680	9362cf11-827c-459a-8ffc-6634bd023508	2025-08-28	\N	\N	3.50	admin	t	f	150.00	525.00	\N	Tabella vesica vulgivagus super crustulum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-28 18:00:36.369	\N	2025-10-19 18:00:36.378448	2025-10-19 18:00:36.378448
cdb4b66b-93bb-453c-8ec7-f361a0c1a7ee	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	b0a95e11-90ac-4ab3-b099-c4de69f498b8	269dca40-b352-4a09-9d7c-c735016a8c7d	3f2e9a8e-bdfe-4d09-aced-e88cdc710462	2025-08-28	\N	\N	2.25	training	t	f	150.00	337.50	\N	Tredecim ab careo audax ducimus cohaero timidus animus iste.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-28 18:00:36.369	\N	2025-10-19 18:00:36.380732	2025-10-19 18:00:36.380732
3b0bbea0-3346-46fb-b316-45adadf7e30e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	4554e09d-4391-42a8-a2cd-9702bce80511	ae73110f-e045-44ac-85ff-51aa2eb8ce69	1ede1cc0-3627-404e-bb8a-487e028f4732	2025-08-28	\N	\N	1.25	work	f	t	120.00	150.00	\N	Dedico victus canis adfectus solus denuo clibanus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-28 18:00:36.369	\N	2025-10-19 18:00:36.383112	2025-10-19 18:00:36.383112
22e2ca02-699f-4b7e-b252-cb33a7174515	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	5e2204cd-be52-42a7-aa41-14fcf0e4a272	ca413110-b7e3-4734-a185-d21ea0960708	2025-08-28	\N	\N	1.00	research	t	f	120.00	120.00	\N	Bene videlicet cupiditate ademptio.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-28 18:00:36.369	\N	2025-10-19 18:00:36.385478	2025-10-19 18:00:36.385478
8906e345-daf7-4f34-95dc-94cfcac1b06c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	584bab37-ccf2-484c-9a7f-7394e4b30ec6	598a25cc-7c96-4dd9-af0e-1e27762bf53a	109283c7-55ef-4e05-bf53-c6efd1be486f	2025-08-28	\N	\N	2.50	admin	t	f	120.00	300.00	\N	Curo venia calcar sol sollers vehemens.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-28 18:00:36.369	\N	2025-10-19 18:00:36.387581	2025-10-19 18:00:36.387581
79d0862d-fd2e-4420-a4c6-84d0362c6ede	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	5e2204cd-be52-42a7-aa41-14fcf0e4a272	78882562-2120-44d2-9286-03e696abbf02	2025-08-28	\N	\N	2.25	work	t	t	110.00	247.50	\N	Cruentus speciosus quaerat corrumpo inventore corroboro votum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-28 18:00:36.369	\N	2025-10-19 18:00:36.390463	2025-10-19 18:00:36.390463
144aad44-fa5b-4517-be7b-d3c196bf04e5	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	b0a95e11-90ac-4ab3-b099-c4de69f498b8	8c94ef1c-f972-45ba-9aaa-1fa78ab3fc92	ca413110-b7e3-4734-a185-d21ea0960708	2025-08-28	\N	\N	3.00	admin	t	t	110.00	330.00	\N	Versus paens carcer desolo allatus demonstro.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-28 18:00:36.369	\N	2025-10-19 18:00:36.392524	2025-10-19 18:00:36.392524
97e3086e-e5a1-49ac-874f-da68f279982e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	12edb785-268b-4219-840d-15b8f0df1198	f37ad203-1495-4aec-be30-1b2d7fe4dd70	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	2025-08-28	\N	\N	3.75	meeting	t	f	110.00	412.50	\N	Degenero amo cursus agnitio torqueo accommodo volup facere.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-28 18:00:36.369	\N	2025-10-19 18:00:36.395002	2025-10-19 18:00:36.395002
ccc07891-f034-4988-98cc-d71e00119c2a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	67f62599-7f9f-44e8-bc18-d2ce08ea9919	ed074125-f8db-4b46-af39-96ce8eb67c4b	18c91d63-8f9d-4974-ba97-a4079c7457d5	2025-08-28	\N	\N	3.75	research	t	t	110.00	412.50	\N	Uredo soleo cur desino accendo nemo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-28 18:00:36.369	\N	2025-10-19 18:00:36.396946	2025-10-19 18:00:36.396946
43166107-c5e0-436d-b7ec-4d4d7f1ccdec	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	46859340-c8cf-4144-aa6c-28fbaf53fa0e	d486be12-5ed8-48b4-af34-79d9269f4c0b	1ede1cc0-3627-404e-bb8a-487e028f4732	2025-08-28	\N	\N	2.75	meeting	t	f	85.00	233.75	\N	Aptus canto cerno tero spiculum toties suppono.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-28 18:00:36.369	\N	2025-10-19 18:00:36.398812	2025-10-19 18:00:36.398812
bb9bb029-3351-472a-bce1-29fb138253fd	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	4554e09d-4391-42a8-a2cd-9702bce80511	ae73110f-e045-44ac-85ff-51aa2eb8ce69	e2cd4da6-f171-436c-9c7e-a9c1c5436b98	2025-08-28	\N	\N	4.00	research	t	f	85.00	340.00	\N	Cogo accusator verbum vesper stips cado deporto cras auctor.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-28 18:00:36.369	\N	2025-10-19 18:00:36.400677	2025-10-19 18:00:36.400677
8d1f7020-8248-4df8-947a-f1c96e27b3c1	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	04600664-34f3-4ae0-9a01-2da04b5bc5fc	79d01aa5-b680-4830-ab3a-5e3cb66edcfa	2025-08-28	\N	\N	0.75	meeting	f	f	85.00	63.75	\N	Dignissimos cilicium aegrus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-28 18:00:36.369	\N	2025-10-19 18:00:36.402601	2025-10-19 18:00:36.402601
30bdfb95-5c56-4fea-920e-27af0e04d029	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	b7295600-5c20-4de2-8782-af87987c2bee	196a1b4b-9367-4b9f-baf6-717d312881a3	08ee5378-067c-4708-886c-34df4c200b23	2025-08-29	\N	\N	0.50	admin	t	t	150.00	75.00	\N	A conforto summopere.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-29 18:00:36.404	\N	2025-10-19 18:00:36.405555	2025-10-19 18:00:36.405555
631d5d26-c765-4584-83fc-5e86a2f4d646	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	4554e09d-4391-42a8-a2cd-9702bce80511	ae73110f-e045-44ac-85ff-51aa2eb8ce69	18c91d63-8f9d-4974-ba97-a4079c7457d5	2025-08-29	\N	\N	0.75	admin	f	t	150.00	112.50	\N	Sint vinculum arx attonbitus depereo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-29 18:00:36.404	\N	2025-10-19 18:00:36.409049	2025-10-19 18:00:36.409049
6a555770-8080-4e7e-a46c-1553502a1726	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	04600664-34f3-4ae0-9a01-2da04b5bc5fc	235b548d-f0a0-4899-9a7e-d6e9bec6db40	2025-08-29	\N	\N	2.25	work	t	t	150.00	337.50	\N	Depulso ager addo turpis comitatus cervus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-29 18:00:36.404	\N	2025-10-19 18:00:36.413001	2025-10-19 18:00:36.413001
ad21ec56-e454-4093-bc66-1730a0c0910e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	702b5a48-f7a9-464c-8833-1ff6577e50e6	6ebdfde2-aeab-4596-9744-cef10c12a313	e4487405-7859-40e9-8008-056d32fe6f10	2025-08-29	\N	\N	1.50	training	t	f	150.00	225.00	\N	Tabgo conforto eos volutabrum talus comedo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-29 18:00:36.404	\N	2025-10-19 18:00:36.416405	2025-10-19 18:00:36.416405
db8250e7-1882-4e94-8aac-fd7d16534dd7	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	04465623-29cb-4298-8828-d1839e9cc00d	e4ce7abb-fb0c-42e1-a7c1-6419b4aa63ef	78882562-2120-44d2-9286-03e696abbf02	2025-08-29	\N	\N	4.00	research	t	t	120.00	480.00	\N	Trado stipes cometes spes pel.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-29 18:00:36.404	\N	2025-10-19 18:00:36.419777	2025-10-19 18:00:36.419777
c2854e4c-4fd3-4803-aa0c-366dc8d16c97	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	088446c4-4542-4007-9887-b512bd3db05d	d04961e2-5af7-4b9c-bb44-c37031dd6bfa	2025-08-29	\N	\N	4.00	work	f	f	120.00	480.00	\N	Summisse apto solio.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-29 18:00:36.404	\N	2025-10-19 18:00:36.423825	2025-10-19 18:00:36.423825
86a8d732-92ac-4cad-8c39-455dc0dccb87	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	96a103f5-bc5b-43e1-b321-62fedda6eaa1	ef53422c-1305-4831-bf41-d85b2a76b0d5	2025-08-29	\N	\N	3.25	meeting	t	t	120.00	390.00	\N	Aliquam sulum vinum tracto blanditiis appono undique callide iure.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-29 18:00:36.404	\N	2025-10-19 18:00:36.428001	2025-10-19 18:00:36.428001
d692e282-21e4-4cba-9de3-f26c8c9018e3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	46859340-c8cf-4144-aa6c-28fbaf53fa0e	f9444b08-3c00-4407-98d8-3d654600142c	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-08-29	\N	\N	1.00	admin	t	f	120.00	120.00	\N	Aureus aggredior caelestis arma angulus vinco decumbo allatus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-29 18:00:36.404	\N	2025-10-19 18:00:36.431862	2025-10-19 18:00:36.431862
1792ec30-18e5-43ed-81f9-3ba3f814691e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	a4464f5a-2125-46d9-9f58-7252c9adc16b	7041a9f2-cd04-4f9c-ab2c-96bfdd45e5ff	a8a65b80-dc4c-49f9-9c8d-0dc4a336cf55	2025-08-29	\N	\N	2.00	research	f	f	110.00	220.00	\N	Ambulo acceptus sui carcer.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-29 18:00:36.404	\N	2025-10-19 18:00:36.43532	2025-10-19 18:00:36.43532
2bbad5f1-0021-4c4e-836f-02afd274b54c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	c8eb351f-daa9-48cf-bc62-2cef6338a122	ff4a2600-29fe-4448-bec3-ea868988a9ed	2025-08-29	\N	\N	3.25	admin	t	f	110.00	357.50	\N	Caveo tardus curso suspendo ocer suasoria deripio accendo aperiam.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-29 18:00:36.404	\N	2025-10-19 18:00:36.43846	2025-10-19 18:00:36.43846
3d71b8c1-e5e9-4bda-9a45-2e8427542d8d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	4554e09d-4391-42a8-a2cd-9702bce80511	ae73110f-e045-44ac-85ff-51aa2eb8ce69	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	2025-08-29	\N	\N	1.00	admin	t	t	85.00	85.00	\N	Ocer deputo avaritia cito quis benigne apparatus adhuc bos.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-29 18:00:36.404	\N	2025-10-19 18:00:36.441853	2025-10-19 18:00:36.441853
ac930c9e-5447-493f-aa71-53a5d54cbe93	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	b0a95e11-90ac-4ab3-b099-c4de69f498b8	269dca40-b352-4a09-9d7c-c735016a8c7d	ca413110-b7e3-4734-a185-d21ea0960708	2025-08-29	\N	\N	1.00	research	t	t	85.00	85.00	\N	Voro accusator vitae.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-29 18:00:36.404	\N	2025-10-19 18:00:36.445638	2025-10-19 18:00:36.445638
b70269d0-79c0-47b9-b8c8-075f0d4e390e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	96a103f5-bc5b-43e1-b321-62fedda6eaa1	29a61f52-d957-4207-b54b-7fc565a57541	2025-08-29	\N	\N	2.75	meeting	t	f	85.00	233.75	\N	Aut cultura beatae qui depereo est abeo perspiciatis vesper.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-29 18:00:36.404	\N	2025-10-19 18:00:36.448802	2025-10-19 18:00:36.448802
c1c42fc2-f330-4b91-93e4-418020ca5f68	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	45b3d726-e151-4770-9b64-4653914bdaa5	be3f2d80-2e55-4bec-bd5e-02e5a00444a9	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-08-29	\N	\N	4.00	meeting	t	f	85.00	340.00	\N	Verecundia veniam vitae carmen thesaurus aperte callide.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-29 18:00:36.404	\N	2025-10-19 18:00:36.451715	2025-10-19 18:00:36.451715
d1edad61-114d-4867-9f06-31183d00d478	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	584bab37-ccf2-484c-9a7f-7394e4b30ec6	674b7e91-de7b-4a7d-a519-8e8315afb5eb	29a61f52-d957-4207-b54b-7fc565a57541	2025-08-29	\N	\N	3.00	meeting	t	f	85.00	255.00	\N	Valens curo unde volutabrum curis.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-08-29 18:00:36.404	\N	2025-10-19 18:00:36.455189	2025-10-19 18:00:36.455189
03cb469a-46a0-401f-9451-8ec9c5418a50	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	b7295600-5c20-4de2-8782-af87987c2bee	d2f831e1-38ca-429c-9942-06db88f8dfc5	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	2025-09-01	\N	\N	0.50	meeting	t	f	150.00	75.00	\N	Unus audacia fugiat soleo pecto adfectus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-01 18:00:36.457	\N	2025-10-19 18:00:36.458937	2025-10-19 18:00:36.458937
f219e66a-1966-4760-8997-7004daf2cec1	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	d69d0436-37d7-42a4-b907-3d9c3a091ea6	0b689153-0b45-4725-866b-5eac75a40ad8	08ee5378-067c-4708-886c-34df4c200b23	2025-09-01	\N	\N	3.00	training	t	t	150.00	450.00	\N	Adulescens suppono xiphias careo arceo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-01 18:00:36.457	\N	2025-10-19 18:00:36.461561	2025-10-19 18:00:36.461561
2a3565e4-6a0c-4ab7-ab21-794ad0ed646c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	584bab37-ccf2-484c-9a7f-7394e4b30ec6	7a582f98-6d3d-44d5-9796-ba1d12c49f62	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-09-01	\N	\N	0.50	meeting	t	f	150.00	75.00	\N	Autem aperte degero architecto aestus canis statim cubicularis dolorum vespillo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-01 18:00:36.457	\N	2025-10-19 18:00:36.465168	2025-10-19 18:00:36.465168
bcc7bfa8-7120-41d3-ae9a-b5562050ffaf	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	dc9252b7-2022-4822-a8b2-7ec227fe0ea4	a8a65b80-dc4c-49f9-9c8d-0dc4a336cf55	2025-09-01	\N	\N	2.25	work	t	f	150.00	337.50	\N	Absorbeo tamquam decimus cur versus coaegresco.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-01 18:00:36.457	\N	2025-10-19 18:00:36.468228	2025-10-19 18:00:36.468228
1e441316-aceb-41e7-a744-71d8889e7876	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	405d4d05-841b-437d-af7d-70b66dda4cbc	219aa257-710f-4ef2-892d-39086a9690ed	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	2025-09-01	\N	\N	1.00	research	t	f	150.00	150.00	\N	Traho libero ustilo cura adficio veritas.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-01 18:00:36.457	\N	2025-10-19 18:00:36.471332	2025-10-19 18:00:36.471332
cfd43062-cfc0-4c4e-8a39-6600bb130524	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	088446c4-4542-4007-9887-b512bd3db05d	ca413110-b7e3-4734-a185-d21ea0960708	2025-09-01	\N	\N	2.25	training	t	f	120.00	270.00	\N	Adiuvo umerus tyrannus appello.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-01 18:00:36.457	\N	2025-10-19 18:00:36.474115	2025-10-19 18:00:36.474115
67386009-252d-4226-9fa6-4444251b3720	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	088446c4-4542-4007-9887-b512bd3db05d	d04961e2-5af7-4b9c-bb44-c37031dd6bfa	2025-09-01	\N	\N	3.50	training	t	f	120.00	420.00	\N	Adfero convoco soluta armarium considero.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-01 18:00:36.457	\N	2025-10-19 18:00:36.476899	2025-10-19 18:00:36.476899
41513ecb-0c10-449c-bb2d-dfcb52653161	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	0d0329f4-4b80-4899-8807-5854e9db312b	40ca5c4e-33d7-432f-a55c-b59c3010d7ef	9362cf11-827c-459a-8ffc-6634bd023508	2025-09-01	\N	\N	2.50	training	t	t	120.00	300.00	\N	Doloribus vespillo demulceo tenetur tutis verto argentum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-01 18:00:36.457	\N	2025-10-19 18:00:36.479865	2025-10-19 18:00:36.479865
c957c04d-5661-4137-85da-d50d62037460	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	eb1af1df-ce0a-4763-aaef-49b6b390beab	78882562-2120-44d2-9286-03e696abbf02	2025-09-01	\N	\N	1.75	work	t	t	110.00	192.50	\N	Agnitio temptatio abundans amor canto accommodo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-01 18:00:36.457	\N	2025-10-19 18:00:36.482792	2025-10-19 18:00:36.482792
6b0b58bf-cf6d-4b6c-9fe0-aa57ddf941d7	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	b7295600-5c20-4de2-8782-af87987c2bee	2849d1a9-72a4-4287-8114-b604140c71aa	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	2025-09-01	\N	\N	4.00	admin	t	t	110.00	440.00	\N	Adulatio vulariter magni vitiosus accusator uter debilito.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-01 18:00:36.457	\N	2025-10-19 18:00:36.485573	2025-10-19 18:00:36.485573
a18d6c72-d895-4da0-8638-6a8ced623334	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	6ecda653-6094-4502-9d1d-6e90d9ea99ed	4fb9cb0a-ca36-4af7-9203-ac1970ce555b	235b548d-f0a0-4899-9a7e-d6e9bec6db40	2025-09-01	\N	\N	1.50	training	t	f	110.00	165.00	\N	Concedo dolore arma tricesimus vero suggero nam vado.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-01 18:00:36.457	\N	2025-10-19 18:00:36.488484	2025-10-19 18:00:36.488484
876101bf-5b91-4f24-8a7d-43540d2b0e77	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	702b5a48-f7a9-464c-8833-1ff6577e50e6	6ebdfde2-aeab-4596-9744-cef10c12a313	ca413110-b7e3-4734-a185-d21ea0960708	2025-09-01	\N	\N	1.75	admin	t	f	85.00	148.75	\N	Ustulo delectatio auxilium minus bellicus sustineo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-01 18:00:36.457	\N	2025-10-19 18:00:36.491446	2025-10-19 18:00:36.491446
ffff6183-692a-4b58-9793-8c858fe25279	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	7ef8af5a-1080-42a2-988f-ddfa799c8070	5cf17315-4658-4a7f-9c23-b4f8268d8f84	a49c064a-0890-4c02-8734-07a3185e6c03	2025-09-01	\N	\N	3.00	training	t	f	85.00	255.00	\N	Admoveo blanditiis accusator degenero beatae enim apto aetas coniuratio vomer.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-01 18:00:36.457	\N	2025-10-19 18:00:36.494536	2025-10-19 18:00:36.494536
9d86b88a-f86c-4eca-94e6-8fc147557c09	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	6ecda653-6094-4502-9d1d-6e90d9ea99ed	6c88f260-519e-41e9-9fac-18a28b9a7901	d6d7e47b-cd48-48d8-a45a-fa75af1f9a52	2025-09-01	\N	\N	1.50	training	t	f	85.00	127.50	\N	Demulceo ultra antepono currus sollicito cupio nobis totidem venustas.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-01 18:00:36.457	\N	2025-10-19 18:00:36.497417	2025-10-19 18:00:36.497417
de5bf0fd-ae37-41ed-8990-fe2b63e18a09	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	65a6152e-a261-4a70-99fb-82f044e87d05	2105be2b-df4f-494a-bb20-548a7dbda952	e4487405-7859-40e9-8008-056d32fe6f10	2025-09-02	\N	\N	3.00	admin	f	f	150.00	450.00	\N	Cervus accommodo reprehenderit vigor.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-02 18:00:36.499	\N	2025-10-19 18:00:36.500034	2025-10-19 18:00:36.500034
ff313804-6941-4998-a1d3-7a5453b3b148	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	45b3d726-e151-4770-9b64-4653914bdaa5	be3f2d80-2e55-4bec-bd5e-02e5a00444a9	78882562-2120-44d2-9286-03e696abbf02	2025-09-02	\N	\N	3.50	work	f	f	150.00	525.00	\N	Victoria aurum voluntarius conspergo acquiro.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-02 18:00:36.499	\N	2025-10-19 18:00:36.502536	2025-10-19 18:00:36.502536
f9cfcd74-4bde-41c0-a7df-ff1b9d250a91	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	6a032ece-4f9e-405a-b48a-b28516d15fe1	1916b6af-0ab6-45d8-85ca-a9a6b331363c	d6d7e47b-cd48-48d8-a45a-fa75af1f9a52	2025-09-02	\N	\N	2.50	research	t	t	120.00	300.00	\N	Curso vilitas enim bardus caecus deduco defero sponte triduana.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-02 18:00:36.499	\N	2025-10-19 18:00:36.504874	2025-10-19 18:00:36.504874
d8ff7c37-c694-4979-a9fa-3b9bbe120e43	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	7ef8af5a-1080-42a2-988f-ddfa799c8070	5cf17315-4658-4a7f-9c23-b4f8268d8f84	29a61f52-d957-4207-b54b-7fc565a57541	2025-09-02	\N	\N	2.75	meeting	f	t	120.00	330.00	\N	Substantia sto tubineus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-02 18:00:36.499	\N	2025-10-19 18:00:36.507404	2025-10-19 18:00:36.507404
7100f893-f4c9-48f4-97e3-4e03682771b3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	8538cc30-f9e7-4b63-a885-56b23e16ecef	b3d1095b-3d51-444b-be35-f485afdb174f	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	2025-09-02	\N	\N	1.50	training	t	f	120.00	180.00	\N	Quo spes caelestis cauda.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-02 18:00:36.499	\N	2025-10-19 18:00:36.509856	2025-10-19 18:00:36.509856
9fec330b-2177-4b78-b729-0d7faf631407	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	6a032ece-4f9e-405a-b48a-b28516d15fe1	1916b6af-0ab6-45d8-85ca-a9a6b331363c	e4487405-7859-40e9-8008-056d32fe6f10	2025-09-02	\N	\N	0.50	admin	f	f	120.00	60.00	\N	Armarium tego atavus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-02 18:00:36.499	\N	2025-10-19 18:00:36.512363	2025-10-19 18:00:36.512363
cbc8d912-2653-4e53-a25d-b189b877254b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	b0a95e11-90ac-4ab3-b099-c4de69f498b8	8c94ef1c-f972-45ba-9aaa-1fa78ab3fc92	a0801828-5c53-41ef-9b3e-06db89d72e90	2025-09-02	\N	\N	3.75	admin	f	f	110.00	412.50	\N	Sunt abscido solus spectaculum trucido succedo tot.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-02 18:00:36.499	\N	2025-10-19 18:00:36.515913	2025-10-19 18:00:36.515913
0632faad-276d-4fad-8090-c30695cdf09a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	45b3d726-e151-4770-9b64-4653914bdaa5	2c1d5d5c-be1c-427c-b2ac-da3cc28b1680	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	2025-09-02	\N	\N	3.00	training	t	f	110.00	330.00	\N	Constans tactus aequitas ciminatio claudeo desino usus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-02 18:00:36.499	\N	2025-10-19 18:00:36.518329	2025-10-19 18:00:36.518329
45a31eb4-0517-430a-ad38-6e99a0cea752	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	0d0329f4-4b80-4899-8807-5854e9db312b	40ca5c4e-33d7-432f-a55c-b59c3010d7ef	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	2025-09-02	\N	\N	2.50	admin	f	f	85.00	212.50	\N	Ambulo vito celer beneficium bis labore derelinquo enim asporto abutor.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-02 18:00:36.499	\N	2025-10-19 18:00:36.520566	2025-10-19 18:00:36.520566
0845d5cc-7375-4416-81ce-067bbe4586d1	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	6ecda653-6094-4502-9d1d-6e90d9ea99ed	6c88f260-519e-41e9-9fac-18a28b9a7901	d6d7e47b-cd48-48d8-a45a-fa75af1f9a52	2025-09-02	\N	\N	3.50	research	t	t	85.00	297.50	\N	Tutamen voveo crapula ulciscor desolo cimentarius.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-02 18:00:36.499	\N	2025-10-19 18:00:36.522887	2025-10-19 18:00:36.522887
a2cc40ec-114f-4279-ae7b-1654d2e2e92f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	5e2204cd-be52-42a7-aa41-14fcf0e4a272	e2cd4da6-f171-436c-9c7e-a9c1c5436b98	2025-09-02	\N	\N	2.75	research	f	f	85.00	233.75	\N	Ulciscor cogito alii stella.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-02 18:00:36.499	\N	2025-10-19 18:00:36.525176	2025-10-19 18:00:36.525176
cb1811de-8bef-4745-8ea1-c405d84369fa	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	12edb785-268b-4219-840d-15b8f0df1198	f37ad203-1495-4aec-be30-1b2d7fe4dd70	79d01aa5-b680-4830-ab3a-5e3cb66edcfa	2025-09-03	\N	\N	2.25	admin	t	t	150.00	337.50	\N	Possimus defaeco vindico clementia constans esse.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-03 18:00:36.526	\N	2025-10-19 18:00:36.527824	2025-10-19 18:00:36.527824
4737b757-a158-4be3-b7fb-7903c7ab581f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	17f141c2-e297-4c93-9178-0fd819259c50	c7111387-5606-4d4b-88de-270766225b61	235b548d-f0a0-4899-9a7e-d6e9bec6db40	2025-09-03	\N	\N	2.75	training	f	t	150.00	412.50	\N	Coruscus esse voluptates aliqua caste.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-03 18:00:36.526	\N	2025-10-19 18:00:36.530729	2025-10-19 18:00:36.530729
50a1084a-4a26-45d8-a5a5-7c80e0a60768	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	584bab37-ccf2-484c-9a7f-7394e4b30ec6	f6f91297-d9d7-461b-bf97-34473b55f893	e2cd4da6-f171-436c-9c7e-a9c1c5436b98	2025-09-03	\N	\N	0.75	research	t	f	150.00	112.50	\N	Dolores cilicium trucido desipio creber soluta.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-03 18:00:36.526	\N	2025-10-19 18:00:36.533819	2025-10-19 18:00:36.533819
ce0ef303-6455-4dbb-91f5-304c30bbf24a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	702b5a48-f7a9-464c-8833-1ff6577e50e6	6ebdfde2-aeab-4596-9744-cef10c12a313	78882562-2120-44d2-9286-03e696abbf02	2025-09-03	\N	\N	2.00	admin	t	f	120.00	240.00	\N	Officia certus deficio vigilo cunae depono.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-03 18:00:36.526	\N	2025-10-19 18:00:36.536825	2025-10-19 18:00:36.536825
9b415847-32e1-44db-bd48-7ce9926c4f11	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	96a103f5-bc5b-43e1-b321-62fedda6eaa1	d6d7e47b-cd48-48d8-a45a-fa75af1f9a52	2025-09-03	\N	\N	0.50	training	t	f	120.00	60.00	\N	Velut defleo aetas cognatus vorago despecto ipsa verbera.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-03 18:00:36.526	\N	2025-10-19 18:00:36.541344	2025-10-19 18:00:36.541344
0cb9d8fd-14f2-4f76-960d-ff39df105ab3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	7ef8af5a-1080-42a2-988f-ddfa799c8070	1c9d17d2-a153-4f42-9604-129a162a1f0f	109283c7-55ef-4e05-bf53-c6efd1be486f	2025-09-03	\N	\N	1.00	research	t	f	120.00	120.00	\N	Est commodo conspergo adhuc argentum debitis.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-03 18:00:36.526	\N	2025-10-19 18:00:36.544405	2025-10-19 18:00:36.544405
6693a375-3e42-4194-b5c9-3c7fcd16718d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	0d0329f4-4b80-4899-8807-5854e9db312b	40ca5c4e-33d7-432f-a55c-b59c3010d7ef	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	2025-09-03	\N	\N	2.50	work	t	f	110.00	275.00	\N	Suggero dens doloremque audeo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-03 18:00:36.526	\N	2025-10-19 18:00:36.546531	2025-10-19 18:00:36.546531
03d2caf6-cdc8-4326-9e0b-9acd9f628061	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	0d0329f4-4b80-4899-8807-5854e9db312b	e60c944c-85a6-45da-b007-56b5244e0257	ff4a2600-29fe-4448-bec3-ea868988a9ed	2025-09-03	\N	\N	4.00	research	t	t	110.00	440.00	\N	Degenero bibo quos vis aetas.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-03 18:00:36.526	\N	2025-10-19 18:00:36.548403	2025-10-19 18:00:36.548403
d343a5aa-daa4-4510-b0b7-0dc7d5516dfd	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	7ef8af5a-1080-42a2-988f-ddfa799c8070	1c9d17d2-a153-4f42-9604-129a162a1f0f	996aa78c-cfd1-477f-8c30-d9489225b29e	2025-09-03	\N	\N	3.25	meeting	f	t	110.00	357.50	\N	Compello thalassinus velociter sodalitas id video omnis clarus advoco.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-03 18:00:36.526	\N	2025-10-19 18:00:36.550231	2025-10-19 18:00:36.550231
fda9b623-e4f9-41a8-95c1-999bc8901ead	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	4554e09d-4391-42a8-a2cd-9702bce80511	ae73110f-e045-44ac-85ff-51aa2eb8ce69	a0801828-5c53-41ef-9b3e-06db89d72e90	2025-09-03	\N	\N	2.75	work	f	f	110.00	302.50	\N	Ipsum deprecator spes alter causa aduro celo ultio adfectus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-03 18:00:36.526	\N	2025-10-19 18:00:36.552419	2025-10-19 18:00:36.552419
2a8fa9fe-fc79-4c7e-a78f-e0e800bb0ce1	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	98f9340d-eadb-45cd-bba2-115aa880f565	996aa78c-cfd1-477f-8c30-d9489225b29e	2025-09-03	\N	\N	3.50	work	f	t	110.00	385.00	\N	Arbustum depono succedo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-03 18:00:36.526	\N	2025-10-19 18:00:36.555514	2025-10-19 18:00:36.555514
858abd18-590f-47b5-af20-384df67c57ce	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	17f141c2-e297-4c93-9178-0fd819259c50	c7111387-5606-4d4b-88de-270766225b61	78882562-2120-44d2-9286-03e696abbf02	2025-09-03	\N	\N	0.75	meeting	t	f	85.00	63.75	\N	Speciosus despecto dolores eius theologus veniam cupiditate.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-03 18:00:36.526	\N	2025-10-19 18:00:36.559339	2025-10-19 18:00:36.559339
499f6890-07b0-491d-9dcb-a72822f78edc	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	a4464f5a-2125-46d9-9f58-7252c9adc16b	9068b493-e301-4f68-9bcd-ad7c1f9cbe03	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	2025-09-03	\N	\N	3.25	training	f	t	85.00	276.25	\N	Tenax tripudio chirographum demum tui strenuus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-03 18:00:36.526	\N	2025-10-19 18:00:36.562612	2025-10-19 18:00:36.562612
5a9cd504-d0a6-4f71-b01b-10e029bb8bd5	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	c8eb351f-daa9-48cf-bc62-2cef6338a122	e2cd4da6-f171-436c-9c7e-a9c1c5436b98	2025-09-03	\N	\N	1.00	research	t	t	85.00	85.00	\N	Cetera abeo barba stella vacuus denego vindico bellicus aliquid aduro.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-03 18:00:36.526	\N	2025-10-19 18:00:36.566947	2025-10-19 18:00:36.566947
1bb7b3ff-9c7a-4ad8-a102-ad9723ca4bfb	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	65a6152e-a261-4a70-99fb-82f044e87d05	b7a77905-edd5-451e-a92e-06976feeb638	ecfd2c2c-905b-4ef4-99a4-8949632b9ae9	2025-09-04	\N	\N	0.50	meeting	t	f	150.00	75.00	\N	Quisquam saepe desidero.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-04 18:00:36.569	\N	2025-10-19 18:00:36.570433	2025-10-19 18:00:36.570433
69ce9521-c1bf-4bc3-a474-612bd89dba5d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	d8601cb6-589f-456f-a2b2-1b986973a4bc	e2cd4da6-f171-436c-9c7e-a9c1c5436b98	2025-09-04	\N	\N	2.00	work	t	f	150.00	300.00	\N	Paens creo claudeo annus valeo via terra.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-04 18:00:36.569	\N	2025-10-19 18:00:36.573473	2025-10-19 18:00:36.573473
f4b32fe4-8581-4837-ba50-9a6bcc9ddda4	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	0d0329f4-4b80-4899-8807-5854e9db312b	e60c944c-85a6-45da-b007-56b5244e0257	391f7d87-df5d-4538-9b3e-31e07ac9347e	2025-09-04	\N	\N	2.50	meeting	t	f	150.00	375.00	\N	Qui amitto alveus approbo sodalitas tubineus sol voveo arto.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-04 18:00:36.569	\N	2025-10-19 18:00:36.576244	2025-10-19 18:00:36.576244
f2a0622f-e7cc-4d2e-b99f-e03f2d2cefd9	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	d69d0436-37d7-42a4-b907-3d9c3a091ea6	116f1e4b-b201-4dec-8d77-5e3b3695422f	79d01aa5-b680-4830-ab3a-5e3cb66edcfa	2025-09-04	\N	\N	3.75	meeting	t	f	150.00	562.50	\N	Terebro dolorum caries agnosco molestias.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-04 18:00:36.569	\N	2025-10-19 18:00:36.578635	2025-10-19 18:00:36.578635
81f3cab0-28bd-4051-b2c2-1e978e6f29d3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	c8eb351f-daa9-48cf-bc62-2cef6338a122	a49c064a-0890-4c02-8734-07a3185e6c03	2025-09-04	\N	\N	2.50	research	f	f	150.00	375.00	\N	Adamo solio deserunt quo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-04 18:00:36.569	\N	2025-10-19 18:00:36.582144	2025-10-19 18:00:36.582144
90b989f3-51dc-4bae-a010-42fda0e33724	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	b0a95e11-90ac-4ab3-b099-c4de69f498b8	8c94ef1c-f972-45ba-9aaa-1fa78ab3fc92	e2cd4da6-f171-436c-9c7e-a9c1c5436b98	2025-09-04	\N	\N	3.25	meeting	t	t	120.00	390.00	\N	Textilis appositus ratione corrumpo caute similique teneo cupio thymum bis.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-04 18:00:36.569	\N	2025-10-19 18:00:36.585164	2025-10-19 18:00:36.585164
0ed40108-f356-4dd5-addb-67ba3d751aad	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	6ecda653-6094-4502-9d1d-6e90d9ea99ed	6c88f260-519e-41e9-9fac-18a28b9a7901	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-09-04	\N	\N	2.00	meeting	t	t	120.00	240.00	\N	Civitas tepesco uter confido crur eveniet sono auctus eaque viriliter.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-04 18:00:36.569	\N	2025-10-19 18:00:36.587789	2025-10-19 18:00:36.587789
00017941-923e-4106-98c7-33db376415cf	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	12edb785-268b-4219-840d-15b8f0df1198	f37ad203-1495-4aec-be30-1b2d7fe4dd70	e4487405-7859-40e9-8008-056d32fe6f10	2025-09-04	\N	\N	4.00	meeting	t	f	120.00	480.00	\N	Delibero ipsam calculus cognatus ater audax vitiosus amo virgo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-04 18:00:36.569	\N	2025-10-19 18:00:36.590097	2025-10-19 18:00:36.590097
46d6f29c-3bca-45f2-8e3d-219251583b13	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	dc9252b7-2022-4822-a8b2-7ec227fe0ea4	79d01aa5-b680-4830-ab3a-5e3cb66edcfa	2025-09-04	\N	\N	1.75	admin	t	f	110.00	192.50	\N	Suadeo corporis laboriosam voluptatum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-04 18:00:36.569	\N	2025-10-19 18:00:36.592213	2025-10-19 18:00:36.592213
8857253d-09cc-43f4-81a1-28b0eba73a22	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	8538cc30-f9e7-4b63-a885-56b23e16ecef	b3d1095b-3d51-444b-be35-f485afdb174f	391f7d87-df5d-4538-9b3e-31e07ac9347e	2025-09-04	\N	\N	3.50	training	t	t	110.00	385.00	\N	Vergo confero totus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-04 18:00:36.569	\N	2025-10-19 18:00:36.594724	2025-10-19 18:00:36.594724
a78f01f8-b03e-4707-8885-77311f0c6b97	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	702b5a48-f7a9-464c-8833-1ff6577e50e6	6ebdfde2-aeab-4596-9744-cef10c12a313	29a61f52-d957-4207-b54b-7fc565a57541	2025-09-04	\N	\N	3.75	work	t	f	110.00	412.50	\N	Caries valens vulgivagus adulatio volutabrum cura considero demergo viscus audeo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-04 18:00:36.569	\N	2025-10-19 18:00:36.597137	2025-10-19 18:00:36.597137
ffb2df23-e5ae-4749-b06e-0e0e7f74f8ee	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	04465623-29cb-4298-8828-d1839e9cc00d	e4ce7abb-fb0c-42e1-a7c1-6419b4aa63ef	3f2e9a8e-bdfe-4d09-aced-e88cdc710462	2025-09-04	\N	\N	1.75	research	t	f	85.00	148.75	\N	Cornu conspergo armarium conculco cumque corrupti valens suasoria demitto.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-04 18:00:36.569	\N	2025-10-19 18:00:36.599567	2025-10-19 18:00:36.599567
93020f2a-c99e-47be-92f5-a7bf695d7145	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	04465623-29cb-4298-8828-d1839e9cc00d	e4ce7abb-fb0c-42e1-a7c1-6419b4aa63ef	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	2025-09-04	\N	\N	0.75	work	t	f	85.00	63.75	\N	Vesper concedo truculenter tamdiu nobis.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-04 18:00:36.569	\N	2025-10-19 18:00:36.602006	2025-10-19 18:00:36.602006
1dcd4c6a-d8d2-4c30-89c1-d0cd386ee378	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	b7295600-5c20-4de2-8782-af87987c2bee	d2f831e1-38ca-429c-9942-06db88f8dfc5	235b548d-f0a0-4899-9a7e-d6e9bec6db40	2025-09-04	\N	\N	0.75	work	f	f	85.00	63.75	\N	Supra voluptatem cedo urbs aspicio cupiditate pel bestia strues.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-04 18:00:36.569	\N	2025-10-19 18:00:36.604502	2025-10-19 18:00:36.604502
ee00024f-72d8-4f6a-8bb7-cf7a1d7b0052	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	dc9252b7-2022-4822-a8b2-7ec227fe0ea4	3f2e9a8e-bdfe-4d09-aced-e88cdc710462	2025-09-04	\N	\N	3.75	admin	t	f	85.00	318.75	\N	Beatae copia adiuvo adipisci.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-04 18:00:36.569	\N	2025-10-19 18:00:36.606855	2025-10-19 18:00:36.606855
42168637-80d4-4057-bc93-2c0d24f9362a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	405d4d05-841b-437d-af7d-70b66dda4cbc	9485b00c-4fc8-454f-984a-6908039db9f9	1ede1cc0-3627-404e-bb8a-487e028f4732	2025-09-04	\N	\N	1.75	research	t	t	85.00	148.75	\N	Aliquid corrigo virtus adiuvo aer quod thema candidus uberrime.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-04 18:00:36.569	\N	2025-10-19 18:00:36.609055	2025-10-19 18:00:36.609055
31803739-5153-4345-a753-dad4afcf5013	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	5515e216-ea3c-436b-95a5-6abf213c47ef	78882562-2120-44d2-9286-03e696abbf02	2025-09-05	\N	\N	1.25	training	t	f	150.00	187.50	\N	Contra decipio cunctatio cura anser vorago.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-05 18:00:36.61	\N	2025-10-19 18:00:36.611743	2025-10-19 18:00:36.611743
1ef18e74-6c48-451a-9e2b-4279bd9323b0	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	04465623-29cb-4298-8828-d1839e9cc00d	e4ce7abb-fb0c-42e1-a7c1-6419b4aa63ef	08ee5378-067c-4708-886c-34df4c200b23	2025-09-05	\N	\N	1.50	admin	t	t	150.00	225.00	\N	Delicate cariosus adicio timidus verbera.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-05 18:00:36.61	\N	2025-10-19 18:00:36.613996	2025-10-19 18:00:36.613996
9728371f-59b5-40cb-bccc-e9feed6992e4	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	4554e09d-4391-42a8-a2cd-9702bce80511	ae73110f-e045-44ac-85ff-51aa2eb8ce69	a8a65b80-dc4c-49f9-9c8d-0dc4a336cf55	2025-09-05	\N	\N	2.50	research	f	t	150.00	375.00	\N	Ter comis eligendi comitatus argentum distinctio patruus vulariter ars.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-05 18:00:36.61	\N	2025-10-19 18:00:36.616397	2025-10-19 18:00:36.616397
9ee88ea6-71bb-449a-9d1c-6aebbef8aa7a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	b7295600-5c20-4de2-8782-af87987c2bee	2849d1a9-72a4-4287-8114-b604140c71aa	a49c064a-0890-4c02-8734-07a3185e6c03	2025-09-05	\N	\N	3.50	work	f	t	150.00	525.00	\N	Subito agnosco exercitationem ait thermae cubo laudantium strues auxilium.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-05 18:00:36.61	\N	2025-10-19 18:00:36.618694	2025-10-19 18:00:36.618694
3c3dd8d2-5136-4213-965e-d0588f4095dd	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	2db210d6-c799-49db-b61d-9aff5f87f1f0	a96c9f4d-dc33-4af3-818d-8d729f0f8c1f	2025-09-05	\N	\N	2.50	meeting	f	t	120.00	300.00	\N	Amissio considero occaecati natus adopto.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-05 18:00:36.61	\N	2025-10-19 18:00:36.62099	2025-10-19 18:00:36.62099
837c811a-0b80-49b0-8ce9-54a79eb0e083	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	b7295600-5c20-4de2-8782-af87987c2bee	196a1b4b-9367-4b9f-baf6-717d312881a3	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-09-05	\N	\N	3.75	training	t	t	120.00	450.00	\N	Ancilla conturbo admitto aufero omnis curo aro aliqua expedita crastinus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-05 18:00:36.61	\N	2025-10-19 18:00:36.623189	2025-10-19 18:00:36.623189
c1b62b47-66e0-44f3-8b7e-cb9df9eb1d9e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	7ef8af5a-1080-42a2-988f-ddfa799c8070	1c9d17d2-a153-4f42-9604-129a162a1f0f	ecfd2c2c-905b-4ef4-99a4-8949632b9ae9	2025-09-05	\N	\N	0.75	research	t	t	110.00	82.50	\N	Collum ubi acer crapula veritatis dignissimos arca totam.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-05 18:00:36.61	\N	2025-10-19 18:00:36.625651	2025-10-19 18:00:36.625651
7d4a897d-31b0-4253-9f44-49ab2031e2fd	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	405d4d05-841b-437d-af7d-70b66dda4cbc	219aa257-710f-4ef2-892d-39086a9690ed	391f7d87-df5d-4538-9b3e-31e07ac9347e	2025-09-05	\N	\N	2.00	training	t	f	110.00	220.00	\N	Surgo clementia sophismata thalassinus aeger suffoco aut.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-05 18:00:36.61	\N	2025-10-19 18:00:36.628045	2025-10-19 18:00:36.628045
720928dd-bfcc-442e-b977-aa2fdda80b7a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	45b3d726-e151-4770-9b64-4653914bdaa5	449f8e23-33a0-4bf0-915e-cc79d13bc3a9	79d01aa5-b680-4830-ab3a-5e3cb66edcfa	2025-09-05	\N	\N	2.75	meeting	t	f	85.00	233.75	\N	Appono conitor aedificium appello baiulus suscipio assumenda.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-05 18:00:36.61	\N	2025-10-19 18:00:36.630821	2025-10-19 18:00:36.630821
700f50b1-fb49-4c3f-a76c-49f5fb9c9779	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	a4464f5a-2125-46d9-9f58-7252c9adc16b	a08b1624-6e7a-4a25-8f08-3b9b00adb6a0	391f7d87-df5d-4538-9b3e-31e07ac9347e	2025-09-05	\N	\N	1.50	meeting	t	t	85.00	127.50	\N	Eaque attero censura occaecati.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-05 18:00:36.61	\N	2025-10-19 18:00:36.633443	2025-10-19 18:00:36.633443
81003d90-1e1c-4562-ac3b-12a40e094adf	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	45b3d726-e151-4770-9b64-4653914bdaa5	be3f2d80-2e55-4bec-bd5e-02e5a00444a9	9362cf11-827c-459a-8ffc-6634bd023508	2025-09-05	\N	\N	3.75	research	f	t	85.00	318.75	\N	Venia contego arx sto verecundia adipiscor comitatus ater theca.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-05 18:00:36.61	\N	2025-10-19 18:00:36.635875	2025-10-19 18:00:36.635875
f33ba910-7aff-46d1-bbf6-5bc19b9ae3c0	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	405d4d05-841b-437d-af7d-70b66dda4cbc	4f8e956e-3c05-4a0d-8695-2014ee9b2f8a	d04961e2-5af7-4b9c-bb44-c37031dd6bfa	2025-09-08	\N	\N	3.50	meeting	t	t	150.00	525.00	\N	Vitiosus theca acerbitas ago derelinquo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-08 18:00:36.637	\N	2025-10-19 18:00:36.638313	2025-10-19 18:00:36.638313
01ec6a3d-bb4c-4c50-b0f6-528a5e1f69f2	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	4554e09d-4391-42a8-a2cd-9702bce80511	ae73110f-e045-44ac-85ff-51aa2eb8ce69	ef53422c-1305-4831-bf41-d85b2a76b0d5	2025-09-08	\N	\N	1.75	research	t	t	150.00	262.50	\N	Illum deleo beatus thesis natus itaque confero.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-08 18:00:36.637	\N	2025-10-19 18:00:36.641644	2025-10-19 18:00:36.641644
7e9ccfff-12b6-4e0a-825e-2f4ed32a5c3d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	405d4d05-841b-437d-af7d-70b66dda4cbc	9485b00c-4fc8-454f-984a-6908039db9f9	3f2e9a8e-bdfe-4d09-aced-e88cdc710462	2025-09-08	\N	\N	3.00	training	t	f	120.00	360.00	\N	Subiungo demoror supellex tamisium aequitas venia admitto tepidus depromo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-08 18:00:36.637	\N	2025-10-19 18:00:36.645111	2025-10-19 18:00:36.645111
6d263ff6-0777-4e34-a648-0d74dee41b22	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	b7295600-5c20-4de2-8782-af87987c2bee	196a1b4b-9367-4b9f-baf6-717d312881a3	a49c064a-0890-4c02-8734-07a3185e6c03	2025-09-08	\N	\N	2.75	training	f	t	120.00	330.00	\N	Solus cunae deduco sub absorbeo contigo confido nostrum stillicidium.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-08 18:00:36.637	\N	2025-10-19 18:00:36.649739	2025-10-19 18:00:36.649739
5218835d-ca8d-4647-8447-effa5f49c567	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	46859340-c8cf-4144-aa6c-28fbaf53fa0e	f9444b08-3c00-4407-98d8-3d654600142c	a0801828-5c53-41ef-9b3e-06db89d72e90	2025-09-08	\N	\N	2.50	meeting	f	f	120.00	300.00	\N	Magnam venia chirographum summa acceptus cilicium.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-08 18:00:36.637	\N	2025-10-19 18:00:36.654671	2025-10-19 18:00:36.654671
35caa78b-8643-421a-b1df-6eaa5e9ef3f1	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	b7295600-5c20-4de2-8782-af87987c2bee	2849d1a9-72a4-4287-8114-b604140c71aa	3f2e9a8e-bdfe-4d09-aced-e88cdc710462	2025-09-08	\N	\N	1.00	admin	t	f	120.00	120.00	\N	Verus custodia vinculum ter taedium.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-08 18:00:36.637	\N	2025-10-19 18:00:36.658677	2025-10-19 18:00:36.658677
58aa6d87-4189-48b0-bbce-abc0e25d05ae	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	04465623-29cb-4298-8828-d1839e9cc00d	e4ce7abb-fb0c-42e1-a7c1-6419b4aa63ef	18c91d63-8f9d-4974-ba97-a4079c7457d5	2025-09-08	\N	\N	3.00	admin	t	t	110.00	330.00	\N	Quis unde admitto utique adsuesco officia tristis suggero cuppedia virgo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-08 18:00:36.637	\N	2025-10-19 18:00:36.662102	2025-10-19 18:00:36.662102
9fdc9fcb-203e-4723-b666-4742d9a9d287	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	0d0329f4-4b80-4899-8807-5854e9db312b	40ca5c4e-33d7-432f-a55c-b59c3010d7ef	d04961e2-5af7-4b9c-bb44-c37031dd6bfa	2025-09-08	\N	\N	3.00	admin	t	f	110.00	330.00	\N	Spero abscido velut vero audio infit sufficio urbs.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-08 18:00:36.637	\N	2025-10-19 18:00:36.66545	2025-10-19 18:00:36.66545
bd34a4c5-ac31-4d82-8d73-d4bae180c290	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	6ecda653-6094-4502-9d1d-6e90d9ea99ed	6c88f260-519e-41e9-9fac-18a28b9a7901	1ede1cc0-3627-404e-bb8a-487e028f4732	2025-09-08	\N	\N	1.50	work	t	f	110.00	165.00	\N	Quibusdam defero cenaculum coadunatio vitiosus baiulus turbo desipio aranea canonicus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-08 18:00:36.637	\N	2025-10-19 18:00:36.670121	2025-10-19 18:00:36.670121
d137fa9e-e93a-4aa1-bb53-085fc7bb42fd	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	6ecda653-6094-4502-9d1d-6e90d9ea99ed	6c88f260-519e-41e9-9fac-18a28b9a7901	18c91d63-8f9d-4974-ba97-a4079c7457d5	2025-09-08	\N	\N	0.75	work	t	f	85.00	63.75	\N	Tendo calco crinis.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-08 18:00:36.637	\N	2025-10-19 18:00:36.677838	2025-10-19 18:00:36.677838
221e348f-663e-4a33-8d84-5c9936ed4299	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	04600664-34f3-4ae0-9a01-2da04b5bc5fc	1ede1cc0-3627-404e-bb8a-487e028f4732	2025-09-08	\N	\N	0.75	admin	t	t	85.00	63.75	\N	Volo vero cultellus votum enim deleo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-08 18:00:36.637	\N	2025-10-19 18:00:36.680994	2025-10-19 18:00:36.680994
1f0180e8-68d0-43c1-82df-d5da997057c9	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	2db210d6-c799-49db-b61d-9aff5f87f1f0	1ede1cc0-3627-404e-bb8a-487e028f4732	2025-09-08	\N	\N	1.00	work	f	f	85.00	85.00	\N	Vita explicabo undique degusto iste aegrus demo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-08 18:00:36.637	\N	2025-10-19 18:00:36.684314	2025-10-19 18:00:36.684314
7f6c11ce-e60e-46c8-9b65-cc0fbd756c0d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	67f62599-7f9f-44e8-bc18-d2ce08ea9919	ed074125-f8db-4b46-af39-96ce8eb67c4b	109283c7-55ef-4e05-bf53-c6efd1be486f	2025-09-08	\N	\N	3.25	research	t	f	85.00	276.25	\N	Advoco sono cenaculum comprehendo similique astrum volup.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-08 18:00:36.637	\N	2025-10-19 18:00:36.687345	2025-10-19 18:00:36.687345
4fce5656-2e79-48a5-8311-115a3660dff3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	8538cc30-f9e7-4b63-a885-56b23e16ecef	b3d1095b-3d51-444b-be35-f485afdb174f	29a61f52-d957-4207-b54b-7fc565a57541	2025-09-09	\N	\N	0.50	admin	t	f	150.00	75.00	\N	Adversus venia ipsum ullam votum derelinquo cruentus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-09 18:00:36.689	\N	2025-10-19 18:00:36.690408	2025-10-19 18:00:36.690408
1304bb5f-f426-46ea-ada5-57984edd8aaa	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	5515e216-ea3c-436b-95a5-6abf213c47ef	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-09-09	\N	\N	2.50	work	t	f	150.00	375.00	\N	Iusto terga bellum debitis patior arcesso demum versus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-09 18:00:36.689	\N	2025-10-19 18:00:36.700236	2025-10-19 18:00:36.700236
f8ddd013-fc70-42ce-b25c-9ca6714ff377	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	45b3d726-e151-4770-9b64-4653914bdaa5	2c1d5d5c-be1c-427c-b2ac-da3cc28b1680	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	2025-09-09	\N	\N	3.50	admin	t	f	150.00	525.00	\N	Tibi colligo articulus iure.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-09 18:00:36.689	\N	2025-10-19 18:00:36.707016	2025-10-19 18:00:36.707016
3a23b1a6-b52c-44f3-812a-bb4f55044016	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	07b65174-c767-4ace-ac22-e486eb422fa6	d04961e2-5af7-4b9c-bb44-c37031dd6bfa	2025-09-09	\N	\N	3.00	meeting	t	f	150.00	450.00	\N	Sodalitas occaecati subseco beatae provident acer ad torqueo vir.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-09 18:00:36.689	\N	2025-10-19 18:00:36.710305	2025-10-19 18:00:36.710305
de65a743-1508-4b89-ad33-c42a14b4f391	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	8538cc30-f9e7-4b63-a885-56b23e16ecef	b3d1095b-3d51-444b-be35-f485afdb174f	ecfd2c2c-905b-4ef4-99a4-8949632b9ae9	2025-09-09	\N	\N	0.75	research	t	t	120.00	90.00	\N	Vester alter arcesso vulnero terminatio comburo armarium impedit defessus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-09 18:00:36.689	\N	2025-10-19 18:00:36.712802	2025-10-19 18:00:36.712802
e187f9aa-f248-4f04-9119-04219382cd76	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	65a6152e-a261-4a70-99fb-82f044e87d05	b7a77905-edd5-451e-a92e-06976feeb638	ecfd2c2c-905b-4ef4-99a4-8949632b9ae9	2025-09-09	\N	\N	0.75	work	t	f	120.00	90.00	\N	Succedo provident dicta vociferor.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-09 18:00:36.689	\N	2025-10-19 18:00:36.715162	2025-10-19 18:00:36.715162
ca2a0b22-12f7-4548-84f7-690aeb132f1a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	b0a95e11-90ac-4ab3-b099-c4de69f498b8	269dca40-b352-4a09-9d7c-c735016a8c7d	ca413110-b7e3-4734-a185-d21ea0960708	2025-09-09	\N	\N	1.50	work	t	f	120.00	180.00	\N	Ancilla cedo vestigium esse omnis amitto amor tenus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-09 18:00:36.689	\N	2025-10-19 18:00:36.717781	2025-10-19 18:00:36.717781
9cf9cb05-1257-4b70-902b-9d47c54f3b87	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	0d0329f4-4b80-4899-8807-5854e9db312b	40ca5c4e-33d7-432f-a55c-b59c3010d7ef	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	2025-09-09	\N	\N	2.00	work	f	f	110.00	220.00	\N	Aeger quia aedificium video cetera culpo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-09 18:00:36.689	\N	2025-10-19 18:00:36.719768	2025-10-19 18:00:36.719768
aebba0ba-75a2-4ce0-a42f-ac3876d6af1a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	4554e09d-4391-42a8-a2cd-9702bce80511	ae73110f-e045-44ac-85ff-51aa2eb8ce69	08ee5378-067c-4708-886c-34df4c200b23	2025-09-09	\N	\N	1.50	meeting	t	f	110.00	165.00	\N	Victus convoco ut ex conservo officiis.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-09 18:00:36.689	\N	2025-10-19 18:00:36.721699	2025-10-19 18:00:36.721699
b4b6b509-b997-48f1-bdb2-c1c9852f7603	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	a4464f5a-2125-46d9-9f58-7252c9adc16b	a08b1624-6e7a-4a25-8f08-3b9b00adb6a0	a96c9f4d-dc33-4af3-818d-8d729f0f8c1f	2025-09-09	\N	\N	2.75	research	f	t	110.00	302.50	\N	Depraedor coma sodalitas aureus consuasor aspicio cornu abstergo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-09 18:00:36.689	\N	2025-10-19 18:00:36.723818	2025-10-19 18:00:36.723818
f11c0698-c38f-42bf-81ad-c8953bf0685d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	46859340-c8cf-4144-aa6c-28fbaf53fa0e	d486be12-5ed8-48b4-af34-79d9269f4c0b	29a61f52-d957-4207-b54b-7fc565a57541	2025-09-09	\N	\N	2.25	admin	t	f	110.00	247.50	\N	Accedo cito capto repudiandae hic recusandae auctus rerum stella.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-09 18:00:36.689	\N	2025-10-19 18:00:36.725982	2025-10-19 18:00:36.725982
927d1b81-a386-4b7b-9238-56c07669524f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	d69d0436-37d7-42a4-b907-3d9c3a091ea6	fe24fe87-1db5-4f06-9a5c-46757a20518d	29a61f52-d957-4207-b54b-7fc565a57541	2025-09-09	\N	\N	0.50	work	t	f	110.00	55.00	\N	Rerum verto curo convoco textor talus suggero demens.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-09 18:00:36.689	\N	2025-10-19 18:00:36.72813	2025-10-19 18:00:36.72813
57a3ab66-804c-4026-ab07-8e09cda47c9d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	4554e09d-4391-42a8-a2cd-9702bce80511	ae73110f-e045-44ac-85ff-51aa2eb8ce69	a49c064a-0890-4c02-8734-07a3185e6c03	2025-09-09	\N	\N	3.25	research	t	t	85.00	276.25	\N	Vito aetas vel confido cruentus verbum at tabula.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-09 18:00:36.689	\N	2025-10-19 18:00:36.730535	2025-10-19 18:00:36.730535
61dd9206-8c7b-4afa-899c-17bc6a485a53	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	d69d0436-37d7-42a4-b907-3d9c3a091ea6	fe24fe87-1db5-4f06-9a5c-46757a20518d	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-09-09	\N	\N	3.50	work	t	t	85.00	297.50	\N	Decimus corroboro taceo contigo tunc doloremque.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-09 18:00:36.689	\N	2025-10-19 18:00:36.732931	2025-10-19 18:00:36.732931
0dc2a8d8-569a-4d21-a65b-9438ed1e02f9	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	04465623-29cb-4298-8828-d1839e9cc00d	e4ce7abb-fb0c-42e1-a7c1-6419b4aa63ef	e4487405-7859-40e9-8008-056d32fe6f10	2025-09-09	\N	\N	1.00	admin	t	f	85.00	85.00	\N	Comis suscipit adfectus ascit suadeo stultus circumvenio degero.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-09 18:00:36.689	\N	2025-10-19 18:00:36.735827	2025-10-19 18:00:36.735827
e1da968d-bebb-4b9b-907c-4e23f18e1d69	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	b7295600-5c20-4de2-8782-af87987c2bee	196a1b4b-9367-4b9f-baf6-717d312881a3	cbf9b499-276b-4a28-999c-27388562c4f4	2025-09-09	\N	\N	4.00	meeting	t	f	85.00	340.00	\N	Admitto verumtamen incidunt audax thesaurus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-09 18:00:36.689	\N	2025-10-19 18:00:36.73905	2025-10-19 18:00:36.73905
4dfb105a-1b4e-4ac8-a8cc-fc4e1ddae603	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	b0a95e11-90ac-4ab3-b099-c4de69f498b8	269dca40-b352-4a09-9d7c-c735016a8c7d	d6d7e47b-cd48-48d8-a45a-fa75af1f9a52	2025-09-10	\N	\N	3.00	admin	t	t	150.00	450.00	\N	Avaritia amplexus curis.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-10 18:00:36.74	\N	2025-10-19 18:00:36.741744	2025-10-19 18:00:36.741744
54e5e013-bf22-436a-8da3-6a41f3b698aa	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	98f9340d-eadb-45cd-bba2-115aa880f565	ca413110-b7e3-4734-a185-d21ea0960708	2025-09-10	\N	\N	3.00	training	t	f	150.00	450.00	\N	Una bellicus tenus vox spiculum villa territo iste conspergo tener.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-10 18:00:36.74	\N	2025-10-19 18:00:36.744757	2025-10-19 18:00:36.744757
ce33afa4-a658-4c4c-9276-2fa4b607f9ba	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	98f9340d-eadb-45cd-bba2-115aa880f565	1ede1cc0-3627-404e-bb8a-487e028f4732	2025-09-10	\N	\N	2.00	admin	t	f	120.00	240.00	\N	Aspicio itaque patria clibanus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-10 18:00:36.74	\N	2025-10-19 18:00:36.748319	2025-10-19 18:00:36.748319
d0dbd22d-fb45-408d-b116-6c9e535657d7	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	6ecda653-6094-4502-9d1d-6e90d9ea99ed	4fb9cb0a-ca36-4af7-9203-ac1970ce555b	ef53422c-1305-4831-bf41-d85b2a76b0d5	2025-09-10	\N	\N	2.75	meeting	t	f	120.00	330.00	\N	Cilicium confero aestus benigne.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-10 18:00:36.74	\N	2025-10-19 18:00:36.752331	2025-10-19 18:00:36.752331
b22b6127-f997-49ce-af33-454afb41f4fb	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	17f141c2-e297-4c93-9178-0fd819259c50	c7111387-5606-4d4b-88de-270766225b61	a8a65b80-dc4c-49f9-9c8d-0dc4a336cf55	2025-09-10	\N	\N	2.50	training	t	f	120.00	300.00	\N	Utpote campana iure argumentum sto summa arbustum solum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-10 18:00:36.74	\N	2025-10-19 18:00:36.756633	2025-10-19 18:00:36.756633
fd228c22-3d01-4f1f-898c-3e0874de57d8	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	67f62599-7f9f-44e8-bc18-d2ce08ea9919	419cb8f8-8b70-44a5-883b-8fa92787aa46	235b548d-f0a0-4899-9a7e-d6e9bec6db40	2025-09-10	\N	\N	0.50	admin	f	f	120.00	60.00	\N	Creber urbanus anser umbra cattus damnatio aptus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-10 18:00:36.74	\N	2025-10-19 18:00:36.760507	2025-10-19 18:00:36.760507
eaa0fa61-8b48-424d-9135-e2ffef458a5b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	b0a95e11-90ac-4ab3-b099-c4de69f498b8	269dca40-b352-4a09-9d7c-c735016a8c7d	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-09-10	\N	\N	4.00	admin	t	t	120.00	480.00	\N	Amita succedo dolor crinis.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-10 18:00:36.74	\N	2025-10-19 18:00:36.763873	2025-10-19 18:00:36.763873
a5296f88-cc75-467c-9a87-73237c28807e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	4554e09d-4391-42a8-a2cd-9702bce80511	ae73110f-e045-44ac-85ff-51aa2eb8ce69	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	2025-09-10	\N	\N	2.00	training	t	f	110.00	220.00	\N	Vapulus ipsum animi custodia surculus suscipio crustulum vilicus corporis.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-10 18:00:36.74	\N	2025-10-19 18:00:36.7673	2025-10-19 18:00:36.7673
dc26f70b-37c3-4491-ac29-b718ae2f5938	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	5e2204cd-be52-42a7-aa41-14fcf0e4a272	ef53422c-1305-4831-bf41-d85b2a76b0d5	2025-09-10	\N	\N	3.50	training	t	t	110.00	385.00	\N	Terminatio doloremque tredecim cotidie absens vere vigor censura.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-10 18:00:36.74	\N	2025-10-19 18:00:36.77025	2025-10-19 18:00:36.77025
8fdb1d93-0c3f-428d-bec8-caf893d726dd	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	12edb785-268b-4219-840d-15b8f0df1198	f37ad203-1495-4aec-be30-1b2d7fe4dd70	ff4a2600-29fe-4448-bec3-ea868988a9ed	2025-09-10	\N	\N	2.75	work	f	f	85.00	233.75	\N	Adfero adulatio tonsor.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-10 18:00:36.74	\N	2025-10-19 18:00:36.772615	2025-10-19 18:00:36.772615
aa71e8ce-0bb0-4588-bb7c-f99912fa23c8	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	04465623-29cb-4298-8828-d1839e9cc00d	e4ce7abb-fb0c-42e1-a7c1-6419b4aa63ef	e2cd4da6-f171-436c-9c7e-a9c1c5436b98	2025-09-10	\N	\N	2.25	work	t	t	85.00	191.25	\N	Cilicium conventus tamquam cerno laborum balbus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-10 18:00:36.74	\N	2025-10-19 18:00:36.7751	2025-10-19 18:00:36.7751
0a661b03-2fe8-4f8b-8e9f-2dfd92cacd2a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	088446c4-4542-4007-9887-b512bd3db05d	29a61f52-d957-4207-b54b-7fc565a57541	2025-09-11	\N	\N	1.25	meeting	t	f	150.00	187.50	\N	Absque aduro comparo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-11 18:00:36.776	\N	2025-10-19 18:00:36.777936	2025-10-19 18:00:36.777936
69c4b454-e488-4a12-a1d9-0139f76f1b04	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	b7295600-5c20-4de2-8782-af87987c2bee	2849d1a9-72a4-4287-8114-b604140c71aa	3f2e9a8e-bdfe-4d09-aced-e88cdc710462	2025-09-11	\N	\N	1.75	training	t	t	150.00	262.50	\N	Contego aegrus molestiae cupressus timor veritas.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-11 18:00:36.776	\N	2025-10-19 18:00:36.780304	2025-10-19 18:00:36.780304
70c756fe-b64a-4631-b557-2481bf6d1bb8	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	2db210d6-c799-49db-b61d-9aff5f87f1f0	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	2025-09-11	\N	\N	3.00	research	f	f	150.00	450.00	\N	Atavus id vomer at caelum corroboro acidus aegre.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-11 18:00:36.776	\N	2025-10-19 18:00:36.782828	2025-10-19 18:00:36.782828
635d238b-dd8a-41f4-afa6-0125696030e9	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	46859340-c8cf-4144-aa6c-28fbaf53fa0e	f9444b08-3c00-4407-98d8-3d654600142c	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-09-11	\N	\N	2.25	work	t	t	150.00	337.50	\N	Acsi vilicus cultellus civitas curia vulgaris vilis coaegresco.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-11 18:00:36.776	\N	2025-10-19 18:00:36.785333	2025-10-19 18:00:36.785333
d6e0eefe-e008-4700-b28b-9d986bb70036	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	65a6152e-a261-4a70-99fb-82f044e87d05	b98cb032-3f5a-46db-ab39-de7d53570ae9	3f2e9a8e-bdfe-4d09-aced-e88cdc710462	2025-09-11	\N	\N	4.00	meeting	t	t	150.00	600.00	\N	Terminatio solus delinquo tenax.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-11 18:00:36.776	\N	2025-10-19 18:00:36.787952	2025-10-19 18:00:36.787952
38b8ec75-a68c-45cd-9286-4ae0b67b460a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	088446c4-4542-4007-9887-b512bd3db05d	a96c9f4d-dc33-4af3-818d-8d729f0f8c1f	2025-09-11	\N	\N	2.50	work	t	f	120.00	300.00	\N	Utor demitto atrocitas videlicet.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-11 18:00:36.776	\N	2025-10-19 18:00:36.790687	2025-10-19 18:00:36.790687
ee113fa1-fe76-4585-85e2-b1ea4a2da97a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	d8601cb6-589f-456f-a2b2-1b986973a4bc	d04961e2-5af7-4b9c-bb44-c37031dd6bfa	2025-09-11	\N	\N	2.00	work	t	f	120.00	240.00	\N	Adversus comparo vapulus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-11 18:00:36.776	\N	2025-10-19 18:00:36.793426	2025-10-19 18:00:36.793426
ad18091f-b816-46f6-91dd-583ad5aa058d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	17f141c2-e297-4c93-9178-0fd819259c50	af41070b-ce93-4cf4-88f6-19ed28a1f1fe	78882562-2120-44d2-9286-03e696abbf02	2025-09-11	\N	\N	1.25	work	f	f	120.00	150.00	\N	Celebrer patruus harum consuasor tutis amaritudo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-11 18:00:36.776	\N	2025-10-19 18:00:36.796094	2025-10-19 18:00:36.796094
e667c43b-e93d-46a2-a557-ccfe2836f9a9	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	6a032ece-4f9e-405a-b48a-b28516d15fe1	3d497ef7-35c9-4687-8476-96fbecc29f86	08ee5378-067c-4708-886c-34df4c200b23	2025-09-11	\N	\N	0.50	work	t	f	120.00	60.00	\N	Acidus currus demitto bellum abscido crastinus angelus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-11 18:00:36.776	\N	2025-10-19 18:00:36.799436	2025-10-19 18:00:36.799436
2000a0d7-adc3-4792-82c8-0c3c39e4388b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	702b5a48-f7a9-464c-8833-1ff6577e50e6	66d28217-b458-4ec3-9e88-eb34570556b7	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-09-11	\N	\N	0.75	work	f	f	120.00	90.00	\N	Super vehemens advenio fugit video eligendi tyrannus complectus consectetur tracto.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-11 18:00:36.776	\N	2025-10-19 18:00:36.802056	2025-10-19 18:00:36.802056
a3f9753b-7219-42da-9f5d-e573873c2e52	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	8538cc30-f9e7-4b63-a885-56b23e16ecef	b3d1095b-3d51-444b-be35-f485afdb174f	08ee5378-067c-4708-886c-34df4c200b23	2025-09-11	\N	\N	4.00	training	f	f	110.00	440.00	\N	Nam quam acies deripio claustrum ocer.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-11 18:00:36.776	\N	2025-10-19 18:00:36.805937	2025-10-19 18:00:36.805937
10762b65-3625-4324-b605-0445666d2320	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	45b3d726-e151-4770-9b64-4653914bdaa5	449f8e23-33a0-4bf0-915e-cc79d13bc3a9	78882562-2120-44d2-9286-03e696abbf02	2025-09-11	\N	\N	2.25	admin	t	f	110.00	247.50	\N	Argentum creo vehemens vicinus annus cariosus volo demoror agnitio.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-11 18:00:36.776	\N	2025-10-19 18:00:36.809917	2025-10-19 18:00:36.809917
db1a32d3-a6b3-429f-9c59-7066c1b71ce8	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	584bab37-ccf2-484c-9a7f-7394e4b30ec6	ff7b1e48-6594-4997-9b76-46ab909220e2	ca413110-b7e3-4734-a185-d21ea0960708	2025-09-11	\N	\N	0.75	meeting	t	f	110.00	82.50	\N	Cultellus surgo eum comis admiratio aeneus statim ex.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-11 18:00:36.776	\N	2025-10-19 18:00:36.814	2025-10-19 18:00:36.814
5dd0496d-f27d-481f-b2fa-707dae7df647	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	d69d0436-37d7-42a4-b907-3d9c3a091ea6	0b689153-0b45-4725-866b-5eac75a40ad8	78882562-2120-44d2-9286-03e696abbf02	2025-09-11	\N	\N	2.50	work	f	t	110.00	275.00	\N	Ante tam iusto tendo confido autus subnecto cubo video audio.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-11 18:00:36.776	\N	2025-10-19 18:00:36.818723	2025-10-19 18:00:36.818723
b3378d7b-f1be-4bac-9b8e-0c8696cbd223	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	8538cc30-f9e7-4b63-a885-56b23e16ecef	b3d1095b-3d51-444b-be35-f485afdb174f	a49c064a-0890-4c02-8734-07a3185e6c03	2025-09-11	\N	\N	1.75	research	t	f	110.00	192.50	\N	Cedo minus decipio abundans campana canis ullus cunabula cubitum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-11 18:00:36.776	\N	2025-10-19 18:00:36.822226	2025-10-19 18:00:36.822226
527b90c3-1554-4c73-988d-cd53de98ecdd	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	04600664-34f3-4ae0-9a01-2da04b5bc5fc	cbf9b499-276b-4a28-999c-27388562c4f4	2025-09-11	\N	\N	1.50	work	t	t	85.00	127.50	\N	Decor tantillus ipsa casso sunt.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-11 18:00:36.776	\N	2025-10-19 18:00:36.825336	2025-10-19 18:00:36.825336
c853195a-a03d-47a0-80f5-82055f92daae	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	6ecda653-6094-4502-9d1d-6e90d9ea99ed	6c88f260-519e-41e9-9fac-18a28b9a7901	78882562-2120-44d2-9286-03e696abbf02	2025-09-11	\N	\N	4.00	admin	f	f	85.00	340.00	\N	Statim summopere apud velut ciminatio thorax spectaculum subnecto sodalitas.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-11 18:00:36.776	\N	2025-10-19 18:00:36.828362	2025-10-19 18:00:36.828362
f65f123e-0497-4dc6-a582-5df0d361df98	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	d69d0436-37d7-42a4-b907-3d9c3a091ea6	fe24fe87-1db5-4f06-9a5c-46757a20518d	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	2025-09-12	\N	\N	2.25	training	t	f	150.00	337.50	\N	Delego tantillus corpus talus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-12 18:00:36.829	\N	2025-10-19 18:00:36.830737	2025-10-19 18:00:36.830737
b34f2c17-1b92-40bf-8489-96969dd16e24	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	46859340-c8cf-4144-aa6c-28fbaf53fa0e	f9444b08-3c00-4407-98d8-3d654600142c	3f2e9a8e-bdfe-4d09-aced-e88cdc710462	2025-09-12	\N	\N	2.25	training	t	f	150.00	337.50	\N	Animus sperno adiuvo dapifer adimpleo acsi virgo auxilium utroque.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-12 18:00:36.829	\N	2025-10-19 18:00:36.833144	2025-10-19 18:00:36.833144
a90443c8-e8cb-44d4-aa42-6c1f3191e4e0	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	5e2204cd-be52-42a7-aa41-14fcf0e4a272	a96c9f4d-dc33-4af3-818d-8d729f0f8c1f	2025-09-12	\N	\N	0.75	admin	f	f	150.00	112.50	\N	Iure alter numquam voluptate.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-12 18:00:36.829	\N	2025-10-19 18:00:36.835715	2025-10-19 18:00:36.835715
269f68a2-f32a-4329-b290-9af26dc166aa	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	d69d0436-37d7-42a4-b907-3d9c3a091ea6	0b689153-0b45-4725-866b-5eac75a40ad8	a49c064a-0890-4c02-8734-07a3185e6c03	2025-09-12	\N	\N	0.50	work	t	f	120.00	60.00	\N	Vaco suscipio torrens arbustum constans sortitus culpa arbustum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-12 18:00:36.829	\N	2025-10-19 18:00:36.839518	2025-10-19 18:00:36.839518
4a569c1d-d0fb-4cf2-980c-8c70f31e4074	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	0d0329f4-4b80-4899-8807-5854e9db312b	e60c944c-85a6-45da-b007-56b5244e0257	08ee5378-067c-4708-886c-34df4c200b23	2025-09-12	\N	\N	0.50	meeting	f	f	120.00	60.00	\N	Ciminatio vesica solutio basium.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-12 18:00:36.829	\N	2025-10-19 18:00:36.842629	2025-10-19 18:00:36.842629
b3ddad84-1ea0-4183-ad6d-c6cefc865823	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	17f141c2-e297-4c93-9178-0fd819259c50	80260d18-0de6-4cf6-af1d-5b4a1d17a6de	e2cd4da6-f171-436c-9c7e-a9c1c5436b98	2025-09-12	\N	\N	3.00	training	f	f	110.00	330.00	\N	Deprimo omnis usque autus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-12 18:00:36.829	\N	2025-10-19 18:00:36.846197	2025-10-19 18:00:36.846197
27ad1572-4267-4b67-812d-6395ca051fce	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	6b008063-17c8-4c31-893b-ef9f17e74f13	a96c9f4d-dc33-4af3-818d-8d729f0f8c1f	2025-09-12	\N	\N	2.50	meeting	t	f	110.00	275.00	\N	Dedecor creator vulgus congregatio abduco celebrer.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-12 18:00:36.829	\N	2025-10-19 18:00:36.85074	2025-10-19 18:00:36.85074
de1a8f47-1995-4868-9bcb-1126236bff1d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	702b5a48-f7a9-464c-8833-1ff6577e50e6	0da2984a-30cb-4fdf-a4f6-b38ff97be406	a0801828-5c53-41ef-9b3e-06db89d72e90	2025-09-12	\N	\N	3.75	meeting	t	f	110.00	412.50	\N	Accusamus vis talis contra.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-12 18:00:36.829	\N	2025-10-19 18:00:36.854714	2025-10-19 18:00:36.854714
1d49512a-83f2-4e25-9a4b-ed41f606ea35	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	6ecda653-6094-4502-9d1d-6e90d9ea99ed	6c88f260-519e-41e9-9fac-18a28b9a7901	ca413110-b7e3-4734-a185-d21ea0960708	2025-09-12	\N	\N	2.50	work	t	t	110.00	275.00	\N	Accusator tribuo audacia absens apud.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-12 18:00:36.829	\N	2025-10-19 18:00:36.860239	2025-10-19 18:00:36.860239
354e0319-1dff-463d-a620-370190682a51	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	6a032ece-4f9e-405a-b48a-b28516d15fe1	43f46d13-e4e7-4e0f-a62d-25d47b569d15	08ee5378-067c-4708-886c-34df4c200b23	2025-09-12	\N	\N	0.50	meeting	t	f	110.00	55.00	\N	Voluntarius dicta labore utique conforto cariosus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-12 18:00:36.829	\N	2025-10-19 18:00:36.864285	2025-10-19 18:00:36.864285
49f4e0a5-fd87-436c-8cd1-ad0558453941	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	4554e09d-4391-42a8-a2cd-9702bce80511	ae73110f-e045-44ac-85ff-51aa2eb8ce69	a0801828-5c53-41ef-9b3e-06db89d72e90	2025-09-12	\N	\N	2.75	training	t	t	85.00	233.75	\N	Usitas vomica corporis cubitum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-12 18:00:36.829	\N	2025-10-19 18:00:36.867438	2025-10-19 18:00:36.867438
94de4f12-db26-47c0-8406-6f7e4573950e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	584bab37-ccf2-484c-9a7f-7394e4b30ec6	598a25cc-7c96-4dd9-af0e-1e27762bf53a	ff4a2600-29fe-4448-bec3-ea868988a9ed	2025-09-12	\N	\N	3.00	research	t	f	85.00	255.00	\N	Admoneo laudantium conor.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-12 18:00:36.829	\N	2025-10-19 18:00:36.870946	2025-10-19 18:00:36.870946
e96c7f4b-7d92-4051-bc91-a6980e1259b8	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	6ecda653-6094-4502-9d1d-6e90d9ea99ed	4fb9cb0a-ca36-4af7-9203-ac1970ce555b	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	2025-09-12	\N	\N	3.50	research	t	f	85.00	297.50	\N	Demergo ara bellum coniecto amoveo pecus tot absconditus patior quos.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-12 18:00:36.829	\N	2025-10-19 18:00:36.875246	2025-10-19 18:00:36.875246
fb246088-cf1a-465d-b5bd-2c7e8fc3e471	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	6ecda653-6094-4502-9d1d-6e90d9ea99ed	4fb9cb0a-ca36-4af7-9203-ac1970ce555b	1ede1cc0-3627-404e-bb8a-487e028f4732	2025-09-12	\N	\N	3.75	work	t	f	85.00	318.75	\N	Fuga comptus alo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-12 18:00:36.829	\N	2025-10-19 18:00:36.878158	2025-10-19 18:00:36.878158
d94e5e5d-875b-46f3-a448-d0216ca20e47	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	702b5a48-f7a9-464c-8833-1ff6577e50e6	6ebdfde2-aeab-4596-9744-cef10c12a313	ecfd2c2c-905b-4ef4-99a4-8949632b9ae9	2025-09-12	\N	\N	4.00	research	f	t	85.00	340.00	\N	Consuasor constans vomer.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-12 18:00:36.829	\N	2025-10-19 18:00:36.88113	2025-10-19 18:00:36.88113
3a138279-c04f-4105-8bb2-3ea415a73807	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	7ef8af5a-1080-42a2-988f-ddfa799c8070	5cf17315-4658-4a7f-9c23-b4f8268d8f84	ef53422c-1305-4831-bf41-d85b2a76b0d5	2025-09-15	\N	\N	2.75	admin	f	t	150.00	412.50	\N	Cernuus ustilo suscipit antiquus canto acceptus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-15 18:00:36.883	\N	2025-10-19 18:00:36.884475	2025-10-19 18:00:36.884475
b3e31298-07c0-4fb8-802b-c4c3e976aa12	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	6ecda653-6094-4502-9d1d-6e90d9ea99ed	4fb9cb0a-ca36-4af7-9203-ac1970ce555b	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	2025-09-15	\N	\N	2.50	research	t	f	150.00	375.00	\N	Comminor tempora antea deputo alienus bene annus vicinus curiositas.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-15 18:00:36.883	\N	2025-10-19 18:00:36.887768	2025-10-19 18:00:36.887768
12e06fe4-0b35-45ba-b19a-440b8a5893ae	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	405d4d05-841b-437d-af7d-70b66dda4cbc	4f8e956e-3c05-4a0d-8695-2014ee9b2f8a	78882562-2120-44d2-9286-03e696abbf02	2025-09-15	\N	\N	2.25	research	t	t	120.00	270.00	\N	Ventus amita carus currus concido illo abundans timidus amplexus antiquus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-15 18:00:36.883	\N	2025-10-19 18:00:36.891306	2025-10-19 18:00:36.891306
110aca11-a874-4419-bd58-68b2ce144641	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	b0a95e11-90ac-4ab3-b099-c4de69f498b8	269dca40-b352-4a09-9d7c-c735016a8c7d	391f7d87-df5d-4538-9b3e-31e07ac9347e	2025-09-15	\N	\N	3.75	training	t	t	120.00	450.00	\N	Eaque minima asporto creber sui vesco delicate conitor verbera derideo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-15 18:00:36.883	\N	2025-10-19 18:00:36.8949	2025-10-19 18:00:36.8949
9df6f00a-514a-425e-856f-983e222596e3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	4554e09d-4391-42a8-a2cd-9702bce80511	ae73110f-e045-44ac-85ff-51aa2eb8ce69	a0801828-5c53-41ef-9b3e-06db89d72e90	2025-09-15	\N	\N	3.50	research	f	t	120.00	420.00	\N	A vito cribro adfero aspicio tripudio aegrus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-15 18:00:36.883	\N	2025-10-19 18:00:36.898936	2025-10-19 18:00:36.898936
69046a73-8e3f-41f6-9ddf-fb531c14b467	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	67f62599-7f9f-44e8-bc18-d2ce08ea9919	ed074125-f8db-4b46-af39-96ce8eb67c4b	ca413110-b7e3-4734-a185-d21ea0960708	2025-09-15	\N	\N	4.00	meeting	f	t	120.00	480.00	\N	Cultellus calcar apud veritas tabella verus temperantia.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-15 18:00:36.883	\N	2025-10-19 18:00:36.902929	2025-10-19 18:00:36.902929
fa2923a0-1bf0-4520-bfeb-d8a25dae2943	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	b0a95e11-90ac-4ab3-b099-c4de69f498b8	269dca40-b352-4a09-9d7c-c735016a8c7d	d6d7e47b-cd48-48d8-a45a-fa75af1f9a52	2025-09-15	\N	\N	3.25	work	t	f	120.00	390.00	\N	Adhaero sono convoco exercitationem templum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-15 18:00:36.883	\N	2025-10-19 18:00:36.907217	2025-10-19 18:00:36.907217
43a884ad-1371-440c-b186-4054024339f1	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	d69d0436-37d7-42a4-b907-3d9c3a091ea6	0b689153-0b45-4725-866b-5eac75a40ad8	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	2025-09-15	\N	\N	1.75	meeting	t	f	110.00	192.50	\N	Denuncio attollo summisse reprehenderit caries earum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-15 18:00:36.883	\N	2025-10-19 18:00:36.91123	2025-10-19 18:00:36.91123
1a8cb15f-d500-4797-81ed-e9d40e1b12e7	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	45b3d726-e151-4770-9b64-4653914bdaa5	be3f2d80-2e55-4bec-bd5e-02e5a00444a9	ff4a2600-29fe-4448-bec3-ea868988a9ed	2025-09-15	\N	\N	3.75	research	t	f	110.00	412.50	\N	Cuppedia textor vicissitudo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-15 18:00:36.883	\N	2025-10-19 18:00:36.915377	2025-10-19 18:00:36.915377
d9f1593d-c74e-463a-b0f7-7c68c18c3312	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	17f141c2-e297-4c93-9178-0fd819259c50	c7111387-5606-4d4b-88de-270766225b61	d6d7e47b-cd48-48d8-a45a-fa75af1f9a52	2025-09-15	\N	\N	3.50	admin	t	f	110.00	385.00	\N	Bestia celer vomer damnatio venia tristis.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-15 18:00:36.883	\N	2025-10-19 18:00:36.919911	2025-10-19 18:00:36.919911
7707fee7-427f-401d-aef9-352507627624	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	67f62599-7f9f-44e8-bc18-d2ce08ea9919	ed074125-f8db-4b46-af39-96ce8eb67c4b	a8a65b80-dc4c-49f9-9c8d-0dc4a336cf55	2025-09-15	\N	\N	2.00	meeting	t	f	110.00	220.00	\N	Taceo similique vacuus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-15 18:00:36.883	\N	2025-10-19 18:00:36.924191	2025-10-19 18:00:36.924191
17b34f63-a9c4-4d9f-b569-d677f6002816	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	702b5a48-f7a9-464c-8833-1ff6577e50e6	0da2984a-30cb-4fdf-a4f6-b38ff97be406	d04961e2-5af7-4b9c-bb44-c37031dd6bfa	2025-09-15	\N	\N	4.00	work	t	f	110.00	440.00	\N	Decens illo cresco talus pauci voluptates abeo stultus desparatus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-15 18:00:36.883	\N	2025-10-19 18:00:36.928305	2025-10-19 18:00:36.928305
e18e6c26-2652-41d1-b232-7b54de783e6f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	eb1af1df-ce0a-4763-aaef-49b6b390beab	ef53422c-1305-4831-bf41-d85b2a76b0d5	2025-09-15	\N	\N	3.75	training	t	f	85.00	318.75	\N	Utpote conservo suasoria teneo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-15 18:00:36.883	\N	2025-10-19 18:00:36.931828	2025-10-19 18:00:36.931828
e81ed63d-f820-4c33-8c67-e6cdd02eb9c4	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	088446c4-4542-4007-9887-b512bd3db05d	9362cf11-827c-459a-8ffc-6634bd023508	2025-09-15	\N	\N	1.50	training	f	f	85.00	127.50	\N	Atavus abstergo sufficio error animi stillicidium.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-15 18:00:36.883	\N	2025-10-19 18:00:36.934893	2025-10-19 18:00:36.934893
f056cc5b-f45c-46dd-aaae-f1b7228db408	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	67f62599-7f9f-44e8-bc18-d2ce08ea9919	ed074125-f8db-4b46-af39-96ce8eb67c4b	ca413110-b7e3-4734-a185-d21ea0960708	2025-09-15	\N	\N	3.00	admin	t	f	85.00	255.00	\N	Solus adstringo culpo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-15 18:00:36.883	\N	2025-10-19 18:00:36.937929	2025-10-19 18:00:36.937929
c986368f-c245-4ee7-b5d0-185da403bd06	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	2db210d6-c799-49db-b61d-9aff5f87f1f0	996aa78c-cfd1-477f-8c30-d9489225b29e	2025-09-16	\N	\N	2.75	training	t	f	150.00	412.50	\N	Sodalitas cura utrimque volubilis caelum subseco textus audeo uberrime.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-16 18:00:36.939	\N	2025-10-19 18:00:36.940713	2025-10-19 18:00:36.940713
cb960ff6-cf3b-4d35-83dc-8937fc328ce2	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	8538cc30-f9e7-4b63-a885-56b23e16ecef	b3d1095b-3d51-444b-be35-f485afdb174f	ff4a2600-29fe-4448-bec3-ea868988a9ed	2025-09-16	\N	\N	1.50	admin	t	f	150.00	225.00	\N	Aureus subvenio adsum attollo quod desidero arma.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-16 18:00:36.939	\N	2025-10-19 18:00:36.943246	2025-10-19 18:00:36.943246
11e2a562-f14b-47c9-b90e-acfca1434bb8	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	6a032ece-4f9e-405a-b48a-b28516d15fe1	7add02b8-5d73-4a39-8607-6f9d17b36fda	29a61f52-d957-4207-b54b-7fc565a57541	2025-09-16	\N	\N	2.00	research	t	f	120.00	240.00	\N	Quas deduco cibus vomito terebro balbus demoror ut taedium terreo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-16 18:00:36.939	\N	2025-10-19 18:00:36.945354	2025-10-19 18:00:36.945354
c4dad32f-b26f-4326-a46a-5b82915cc831	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	4554e09d-4391-42a8-a2cd-9702bce80511	ae73110f-e045-44ac-85ff-51aa2eb8ce69	a8a65b80-dc4c-49f9-9c8d-0dc4a336cf55	2025-09-16	\N	\N	2.50	meeting	t	f	120.00	300.00	\N	Dicta comis claudeo tibi thymbra sui volutabrum velit pecco adeo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-16 18:00:36.939	\N	2025-10-19 18:00:36.947477	2025-10-19 18:00:36.947477
1b94e3fd-a32f-4e9a-a887-fb90f387e205	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	04465623-29cb-4298-8828-d1839e9cc00d	e4ce7abb-fb0c-42e1-a7c1-6419b4aa63ef	ef53422c-1305-4831-bf41-d85b2a76b0d5	2025-09-16	\N	\N	2.25	training	t	t	120.00	270.00	\N	Thorax thesaurus substantia utroque.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-16 18:00:36.939	\N	2025-10-19 18:00:36.950316	2025-10-19 18:00:36.950316
b1a53d62-5b01-4e7c-af01-ca79920490f9	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	12edb785-268b-4219-840d-15b8f0df1198	e171fa0b-3143-48ec-962f-0917bf1886bf	ff4a2600-29fe-4448-bec3-ea868988a9ed	2025-09-16	\N	\N	3.75	research	t	f	110.00	412.50	\N	Sub cotidie vel vapulus subvenio ascit stillicidium vinitor.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-16 18:00:36.939	\N	2025-10-19 18:00:36.954114	2025-10-19 18:00:36.954114
64ac370f-36f6-4f86-8617-0b9a07041791	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	405d4d05-841b-437d-af7d-70b66dda4cbc	9485b00c-4fc8-454f-984a-6908039db9f9	cbf9b499-276b-4a28-999c-27388562c4f4	2025-09-16	\N	\N	1.25	research	t	t	110.00	137.50	\N	Universe absque varietas deserunt quasi toties comptus villa nulla.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-16 18:00:36.939	\N	2025-10-19 18:00:36.958034	2025-10-19 18:00:36.958034
8de17699-b679-463b-87eb-2243a64a1115	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	088446c4-4542-4007-9887-b512bd3db05d	cbf9b499-276b-4a28-999c-27388562c4f4	2025-09-16	\N	\N	2.00	meeting	t	t	85.00	170.00	\N	Autus cresco suffoco curo atque solum auxilium.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-16 18:00:36.939	\N	2025-10-19 18:00:36.961236	2025-10-19 18:00:36.961236
41d70fe5-a57f-48cf-a114-759557c9d696	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	5e2204cd-be52-42a7-aa41-14fcf0e4a272	08ee5378-067c-4708-886c-34df4c200b23	2025-09-16	\N	\N	0.75	work	t	f	85.00	63.75	\N	Depereo utrum desolo patria.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-16 18:00:36.939	\N	2025-10-19 18:00:36.964393	2025-10-19 18:00:36.964393
dda920e2-4eae-4179-912c-cce58055efca	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	65a6152e-a261-4a70-99fb-82f044e87d05	b7a77905-edd5-451e-a92e-06976feeb638	109283c7-55ef-4e05-bf53-c6efd1be486f	2025-09-17	\N	\N	0.75	work	t	f	150.00	112.50	\N	Deleo terebro viscus apud summisse.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-17 18:00:36.966	\N	2025-10-19 18:00:36.966967	2025-10-19 18:00:36.966967
1a756703-cea6-4add-be92-c141571bb6df	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	12edb785-268b-4219-840d-15b8f0df1198	e171fa0b-3143-48ec-962f-0917bf1886bf	3f2e9a8e-bdfe-4d09-aced-e88cdc710462	2025-09-17	\N	\N	3.75	admin	t	f	150.00	562.50	\N	Amet audio cursim suppellex terror sponte templum timor.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-17 18:00:36.966	\N	2025-10-19 18:00:36.969248	2025-10-19 18:00:36.969248
170ead2c-0c66-4b13-98d9-b569dec1b8a6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	67f62599-7f9f-44e8-bc18-d2ce08ea9919	9ec151a2-b6a4-433d-a21e-c94af23b785b	18c91d63-8f9d-4974-ba97-a4079c7457d5	2025-09-17	\N	\N	2.00	admin	t	f	150.00	300.00	\N	Deleo bardus cras ea.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-17 18:00:36.966	\N	2025-10-19 18:00:36.971437	2025-10-19 18:00:36.971437
5c03b207-43d1-488c-8db4-dc118bd9e7ce	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	a4464f5a-2125-46d9-9f58-7252c9adc16b	7041a9f2-cd04-4f9c-ab2c-96bfdd45e5ff	d6d7e47b-cd48-48d8-a45a-fa75af1f9a52	2025-09-17	\N	\N	2.00	meeting	f	f	120.00	240.00	\N	Vesco torrens arbor audax casus summa claudeo neque statim caries.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-17 18:00:36.966	\N	2025-10-19 18:00:36.973704	2025-10-19 18:00:36.973704
df1a1210-7885-4d5b-b994-5df517bc8d00	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	17f141c2-e297-4c93-9178-0fd819259c50	a18510b4-73e3-40ff-84b1-89c4a2e0bdac	3f2e9a8e-bdfe-4d09-aced-e88cdc710462	2025-09-17	\N	\N	1.50	research	t	t	120.00	180.00	\N	Degero teneo congregatio.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-17 18:00:36.966	\N	2025-10-19 18:00:36.976214	2025-10-19 18:00:36.976214
305a70aa-3966-4acd-a99e-ee5f64e0f770	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	6ecda653-6094-4502-9d1d-6e90d9ea99ed	4fb9cb0a-ca36-4af7-9203-ac1970ce555b	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-09-17	\N	\N	3.25	admin	t	t	120.00	390.00	\N	Verecundia ambitus desparatus unus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-17 18:00:36.966	\N	2025-10-19 18:00:36.979946	2025-10-19 18:00:36.979946
1637faf3-d631-462e-9fa1-149b2ce50a4a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	4554e09d-4391-42a8-a2cd-9702bce80511	ae73110f-e045-44ac-85ff-51aa2eb8ce69	ca413110-b7e3-4734-a185-d21ea0960708	2025-09-17	\N	\N	1.25	training	t	t	110.00	137.50	\N	Correptius harum alo sulum articulus pauci alias pectus tum torqueo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-17 18:00:36.966	\N	2025-10-19 18:00:36.984657	2025-10-19 18:00:36.984657
edc643cd-6d9b-4c28-95ef-df45325a913e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	46859340-c8cf-4144-aa6c-28fbaf53fa0e	d486be12-5ed8-48b4-af34-79d9269f4c0b	9362cf11-827c-459a-8ffc-6634bd023508	2025-09-17	\N	\N	1.50	admin	t	t	110.00	165.00	\N	Pauper contabesco uxor absum torrens tabernus aspernatur.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-17 18:00:36.966	\N	2025-10-19 18:00:36.988866	2025-10-19 18:00:36.988866
8227684f-fc16-408c-9b95-4a860995cdab	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	405d4d05-841b-437d-af7d-70b66dda4cbc	4f8e956e-3c05-4a0d-8695-2014ee9b2f8a	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	2025-09-17	\N	\N	2.25	admin	t	f	110.00	247.50	\N	Aeternus aperiam brevis laborum at ad.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-17 18:00:36.966	\N	2025-10-19 18:00:36.993546	2025-10-19 18:00:36.993546
144d7e25-819f-4cf2-bd40-401c22680d8a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	67f62599-7f9f-44e8-bc18-d2ce08ea9919	8c04c9d5-2992-4108-bc71-d0210b7972e2	1ede1cc0-3627-404e-bb8a-487e028f4732	2025-09-17	\N	\N	1.50	research	t	f	85.00	127.50	\N	Utor vobis cupio.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-17 18:00:36.966	\N	2025-10-19 18:00:36.997671	2025-10-19 18:00:36.997671
de004e1e-93c7-4bf2-bc47-98e2461ed610	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	5e2204cd-be52-42a7-aa41-14fcf0e4a272	9362cf11-827c-459a-8ffc-6634bd023508	2025-09-17	\N	\N	1.75	meeting	f	f	85.00	148.75	\N	Tabella repellendus creber veniam vinculum reiciendis.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-17 18:00:36.966	\N	2025-10-19 18:00:37.001371	2025-10-19 18:00:37.001371
a3c91371-b7e6-459b-b790-42f11896a763	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	98f9340d-eadb-45cd-bba2-115aa880f565	ca413110-b7e3-4734-a185-d21ea0960708	2025-09-17	\N	\N	2.00	training	t	t	85.00	170.00	\N	Veniam calco cattus trepide ulterius beatae utor laborum non tolero.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-17 18:00:36.966	\N	2025-10-19 18:00:37.00453	2025-10-19 18:00:37.00453
a5226ac1-22ac-4d42-b745-5cdf3314331c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	d69d0436-37d7-42a4-b907-3d9c3a091ea6	fe24fe87-1db5-4f06-9a5c-46757a20518d	79d01aa5-b680-4830-ab3a-5e3cb66edcfa	2025-09-17	\N	\N	1.25	meeting	f	f	85.00	106.25	\N	Aestivus vociferor trucido amicitia.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-17 18:00:36.966	\N	2025-10-19 18:00:37.007688	2025-10-19 18:00:37.007688
329c2319-44bf-41c8-8daa-d3ec834acd4f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	eb1af1df-ce0a-4763-aaef-49b6b390beab	109283c7-55ef-4e05-bf53-c6efd1be486f	2025-09-17	\N	\N	3.00	meeting	t	f	85.00	255.00	\N	Audentia viridis atrox depraedor arma statua officiis civis qui audax.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-17 18:00:36.966	\N	2025-10-19 18:00:37.010478	2025-10-19 18:00:37.010478
4b417abb-f8d5-4b3e-a5dc-ba49162ad562	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	65a6152e-a261-4a70-99fb-82f044e87d05	2105be2b-df4f-494a-bb20-548a7dbda952	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-09-18	\N	\N	3.75	admin	t	f	150.00	562.50	\N	Curiositas vester solutio doloribus calculus victoria vindico cur carmen velum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-18 18:00:37.012	\N	2025-10-19 18:00:37.013419	2025-10-19 18:00:37.013419
0bccf6f5-bd4a-42ff-b679-ea582ea7482f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	b0a95e11-90ac-4ab3-b099-c4de69f498b8	269dca40-b352-4a09-9d7c-c735016a8c7d	a49c064a-0890-4c02-8734-07a3185e6c03	2025-09-18	\N	\N	4.00	research	t	f	150.00	600.00	\N	Vigilo at adfectus tendo consequuntur carus aduro delectatio sodalitas voluntarius.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-18 18:00:37.012	\N	2025-10-19 18:00:37.015846	2025-10-19 18:00:37.015846
c02daa15-1b26-493a-ab29-e202ec1ea724	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	405d4d05-841b-437d-af7d-70b66dda4cbc	9485b00c-4fc8-454f-984a-6908039db9f9	a0801828-5c53-41ef-9b3e-06db89d72e90	2025-09-18	\N	\N	3.00	admin	t	f	150.00	450.00	\N	Eum cernuus textilis ratione pariatur tamisium.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-18 18:00:37.012	\N	2025-10-19 18:00:37.018208	2025-10-19 18:00:37.018208
0815d85e-de69-40f0-9654-7ff1d5e2c31b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	65a6152e-a261-4a70-99fb-82f044e87d05	b7a77905-edd5-451e-a92e-06976feeb638	996aa78c-cfd1-477f-8c30-d9489225b29e	2025-09-18	\N	\N	2.50	research	f	t	150.00	375.00	\N	Umbra demulceo acerbitas coniecto ullus abutor damnatio consequuntur quo pariatur.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-18 18:00:37.012	\N	2025-10-19 18:00:37.020481	2025-10-19 18:00:37.020481
609e6943-9994-44e1-b9a6-ff02a2620604	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	b0a95e11-90ac-4ab3-b099-c4de69f498b8	269dca40-b352-4a09-9d7c-c735016a8c7d	cbf9b499-276b-4a28-999c-27388562c4f4	2025-09-18	\N	\N	2.50	admin	t	t	120.00	300.00	\N	Aequus suscipio pax compono.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-18 18:00:37.012	\N	2025-10-19 18:00:37.022701	2025-10-19 18:00:37.022701
dabda4de-15b3-4972-b97a-443cc017ffa0	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	dc9252b7-2022-4822-a8b2-7ec227fe0ea4	d04961e2-5af7-4b9c-bb44-c37031dd6bfa	2025-09-18	\N	\N	2.25	research	t	t	120.00	270.00	\N	Adsidue vestrum cogito cohaero solitudo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-18 18:00:37.012	\N	2025-10-19 18:00:37.025273	2025-10-19 18:00:37.025273
f6a94933-3625-4c45-9933-b0c04b27e67f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	65a6152e-a261-4a70-99fb-82f044e87d05	b7a77905-edd5-451e-a92e-06976feeb638	235b548d-f0a0-4899-9a7e-d6e9bec6db40	2025-09-18	\N	\N	2.50	research	t	f	120.00	300.00	\N	Vulariter casso conitor substantia decor tergiversatio adimpleo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-18 18:00:37.012	\N	2025-10-19 18:00:37.027643	2025-10-19 18:00:37.027643
9562a078-ca6d-4ad6-ab6f-a81efda84ced	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	584bab37-ccf2-484c-9a7f-7394e4b30ec6	598a25cc-7c96-4dd9-af0e-1e27762bf53a	a8a65b80-dc4c-49f9-9c8d-0dc4a336cf55	2025-10-15	\N	\N	1.25	research	f	f	110.00	137.50	\N	Ex urbs textor quod totam talus defessus cribro cibo.	\N	draft	\N	\N	\N	\N	2025-10-19 18:00:37.801351	2025-10-19 18:00:37.801351
2f2bdbb5-c6d3-46a3-bca7-0299d7de0b3b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	4554e09d-4391-42a8-a2cd-9702bce80511	ae73110f-e045-44ac-85ff-51aa2eb8ce69	ecfd2c2c-905b-4ef4-99a4-8949632b9ae9	2025-09-18	\N	\N	1.50	work	t	t	110.00	165.00	\N	Conculco facere taceo accedo speculum trucido pariatur advoco aedificium.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-18 18:00:37.012	\N	2025-10-19 18:00:37.030106	2025-10-19 18:00:37.030106
bd706a6a-97e0-4083-9699-8643d236cd78	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	088446c4-4542-4007-9887-b512bd3db05d	08ee5378-067c-4708-886c-34df4c200b23	2025-09-18	\N	\N	1.50	work	t	f	110.00	165.00	\N	Auctus ad centum vado.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-18 18:00:37.012	\N	2025-10-19 18:00:37.035015	2025-10-19 18:00:37.035015
94cd0b7b-646b-445f-baec-8ea3afa75004	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	584bab37-ccf2-484c-9a7f-7394e4b30ec6	f6f91297-d9d7-461b-bf97-34473b55f893	ca413110-b7e3-4734-a185-d21ea0960708	2025-09-18	\N	\N	4.00	admin	t	f	110.00	440.00	\N	Quisquam vulgo labore stultus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-18 18:00:37.012	\N	2025-10-19 18:00:37.0398	2025-10-19 18:00:37.0398
0907e3a7-d4bb-45a2-8332-cafea2647d71	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	65a6152e-a261-4a70-99fb-82f044e87d05	b98cb032-3f5a-46db-ab39-de7d53570ae9	79d01aa5-b680-4830-ab3a-5e3cb66edcfa	2025-09-18	\N	\N	2.25	work	f	t	85.00	191.25	\N	Solum deputo ademptio aperte.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-18 18:00:37.012	\N	2025-10-19 18:00:37.043646	2025-10-19 18:00:37.043646
33fbba60-245f-4d54-b2f3-c0167af6c5af	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	45b3d726-e151-4770-9b64-4653914bdaa5	449f8e23-33a0-4bf0-915e-cc79d13bc3a9	29a61f52-d957-4207-b54b-7fc565a57541	2025-09-18	\N	\N	2.00	admin	t	f	85.00	170.00	\N	Bibo doloribus constans suppellex alioqui ago beatus urbs coruscus minima.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-18 18:00:37.012	\N	2025-10-19 18:00:37.047286	2025-10-19 18:00:37.047286
acbb9399-74e3-42e6-980c-0a47085f838b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	46859340-c8cf-4144-aa6c-28fbaf53fa0e	d486be12-5ed8-48b4-af34-79d9269f4c0b	235b548d-f0a0-4899-9a7e-d6e9bec6db40	2025-09-18	\N	\N	0.50	work	t	f	85.00	42.50	\N	Comburo in tactus studio perferendis vito tandem angelus vorago aliqua.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-18 18:00:37.012	\N	2025-10-19 18:00:37.050477	2025-10-19 18:00:37.050477
860d4081-ebc2-49f9-8e0f-febcec35c776	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	702b5a48-f7a9-464c-8833-1ff6577e50e6	0da2984a-30cb-4fdf-a4f6-b38ff97be406	ef53422c-1305-4831-bf41-d85b2a76b0d5	2025-09-19	\N	\N	1.25	admin	f	f	150.00	187.50	\N	Alienus pecus cariosus corrumpo adflicto pecus ater amplus suadeo coruscus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-19 18:00:37.052	\N	2025-10-19 18:00:37.053218	2025-10-19 18:00:37.053218
96ef6476-dff1-4f5f-91e0-a2b666e4a822	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	eb1af1df-ce0a-4763-aaef-49b6b390beab	a96c9f4d-dc33-4af3-818d-8d729f0f8c1f	2025-09-19	\N	\N	2.75	work	t	f	150.00	412.50	\N	Facilis aiunt utilis crur colo tantum apparatus nam.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-19 18:00:37.052	\N	2025-10-19 18:00:37.056928	2025-10-19 18:00:37.056928
7f17239e-8020-4b48-9c29-be9b3f5f8316	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	17f141c2-e297-4c93-9178-0fd819259c50	af41070b-ce93-4cf4-88f6-19ed28a1f1fe	391f7d87-df5d-4538-9b3e-31e07ac9347e	2025-09-19	\N	\N	1.50	meeting	t	f	150.00	225.00	\N	Terror coepi desipio deduco animadverto cuius vis necessitatibus occaecati.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-19 18:00:37.052	\N	2025-10-19 18:00:37.059715	2025-10-19 18:00:37.059715
1864d8e2-934c-4820-9f02-ee0deeb0567d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	7ef8af5a-1080-42a2-988f-ddfa799c8070	1c9d17d2-a153-4f42-9604-129a162a1f0f	18c91d63-8f9d-4974-ba97-a4079c7457d5	2025-09-19	\N	\N	3.00	research	t	f	150.00	450.00	\N	Aetas crustulum veniam appello audacia.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-19 18:00:37.052	\N	2025-10-19 18:00:37.062553	2025-10-19 18:00:37.062553
f442f344-444e-4398-a2b8-c10bc8ef2a1a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	65a6152e-a261-4a70-99fb-82f044e87d05	b7a77905-edd5-451e-a92e-06976feeb638	ef53422c-1305-4831-bf41-d85b2a76b0d5	2025-09-19	\N	\N	1.50	work	f	f	150.00	225.00	\N	Vestrum dicta ceno audeo vapulus ipsam aperiam trans spoliatio vomica.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-19 18:00:37.052	\N	2025-10-19 18:00:37.066004	2025-10-19 18:00:37.066004
3224310e-faa0-46c0-9866-d1afa41370d1	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	04465623-29cb-4298-8828-d1839e9cc00d	e4ce7abb-fb0c-42e1-a7c1-6419b4aa63ef	ef53422c-1305-4831-bf41-d85b2a76b0d5	2025-09-19	\N	\N	3.25	training	t	f	120.00	390.00	\N	Cubo voluptatum sono demonstro conspergo versus annus suppellex deprecator.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-19 18:00:37.052	\N	2025-10-19 18:00:37.070092	2025-10-19 18:00:37.070092
bc3b1a15-ad4e-4721-90ca-8be268439c5b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	17f141c2-e297-4c93-9178-0fd819259c50	c7111387-5606-4d4b-88de-270766225b61	79d01aa5-b680-4830-ab3a-5e3cb66edcfa	2025-09-19	\N	\N	3.50	research	f	f	120.00	420.00	\N	Vigor adulescens thalassinus barba conduco vestrum cernuus corrupti sub demo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-19 18:00:37.052	\N	2025-10-19 18:00:37.073512	2025-10-19 18:00:37.073512
e43f0974-ee3d-4377-aae5-a418566a6a0c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	5e2204cd-be52-42a7-aa41-14fcf0e4a272	ecfd2c2c-905b-4ef4-99a4-8949632b9ae9	2025-09-19	\N	\N	1.50	work	t	f	110.00	165.00	\N	Tot canonicus asper mollitia dedecor quidem carpo thermae.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-19 18:00:37.052	\N	2025-10-19 18:00:37.077502	2025-10-19 18:00:37.077502
afce62dd-3039-437e-bad6-cfc5584b16c2	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	eb1af1df-ce0a-4763-aaef-49b6b390beab	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	2025-09-19	\N	\N	0.75	admin	t	t	110.00	82.50	\N	Delinquo cupressus calcar earum appositus curvo communis cursim.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-19 18:00:37.052	\N	2025-10-19 18:00:37.081065	2025-10-19 18:00:37.081065
7414752a-83e9-4abb-87f9-a02f3ec11ae0	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	45b3d726-e151-4770-9b64-4653914bdaa5	92700c16-c146-4a6e-9610-46ac28f4b4c3	79d01aa5-b680-4830-ab3a-5e3cb66edcfa	2025-09-19	\N	\N	1.75	meeting	t	f	110.00	192.50	\N	Compello repellat canonicus derideo vorago stipes vociferor contego.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-19 18:00:37.052	\N	2025-10-19 18:00:37.084371	2025-10-19 18:00:37.084371
724564c1-8a34-4363-b79a-db7aefd051e9	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	46859340-c8cf-4144-aa6c-28fbaf53fa0e	d486be12-5ed8-48b4-af34-79d9269f4c0b	ecfd2c2c-905b-4ef4-99a4-8949632b9ae9	2025-09-19	\N	\N	3.00	admin	t	f	110.00	330.00	\N	Synagoga campana credo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-19 18:00:37.052	\N	2025-10-19 18:00:37.087626	2025-10-19 18:00:37.087626
def3038b-372d-4c64-a031-bb747001c11b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	04465623-29cb-4298-8828-d1839e9cc00d	e4ce7abb-fb0c-42e1-a7c1-6419b4aa63ef	a96c9f4d-dc33-4af3-818d-8d729f0f8c1f	2025-09-19	\N	\N	3.00	work	t	t	85.00	255.00	\N	Deduco volo amplitudo vinculum audio.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-19 18:00:37.052	\N	2025-10-19 18:00:37.090958	2025-10-19 18:00:37.090958
1b4f8554-0660-47e3-bb46-1fdf52163da9	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	dc9252b7-2022-4822-a8b2-7ec227fe0ea4	ff4a2600-29fe-4448-bec3-ea868988a9ed	2025-09-19	\N	\N	1.75	work	t	t	85.00	148.75	\N	Arcus aperio ultio tabella virtus taedium accusator veniam curo a.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-19 18:00:37.052	\N	2025-10-19 18:00:37.094153	2025-10-19 18:00:37.094153
49d6a4a9-b408-434e-8786-e5960367e8ef	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	12edb785-268b-4219-840d-15b8f0df1198	e171fa0b-3143-48ec-962f-0917bf1886bf	1ede1cc0-3627-404e-bb8a-487e028f4732	2025-09-19	\N	\N	0.50	training	t	t	85.00	42.50	\N	Communis vero volutabrum necessitatibus astrum succedo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-19 18:00:37.052	\N	2025-10-19 18:00:37.097003	2025-10-19 18:00:37.097003
8ef62e93-8b6a-45fa-8e82-3cf0ff675de8	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	67f62599-7f9f-44e8-bc18-d2ce08ea9919	9ec151a2-b6a4-433d-a21e-c94af23b785b	9362cf11-827c-459a-8ffc-6634bd023508	2025-09-19	\N	\N	1.00	research	t	t	85.00	85.00	\N	Amet vomer aduro spero suadeo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-19 18:00:37.052	\N	2025-10-19 18:00:37.101337	2025-10-19 18:00:37.101337
99ef46ca-e586-4518-bcb2-3e389495ce9f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	0d0329f4-4b80-4899-8807-5854e9db312b	e60c944c-85a6-45da-b007-56b5244e0257	a49c064a-0890-4c02-8734-07a3185e6c03	2025-09-22	\N	\N	2.00	training	t	f	150.00	300.00	\N	Cilicium vesco enim spiculum triumphus nesciunt vallum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-22 18:00:37.103	\N	2025-10-19 18:00:37.104288	2025-10-19 18:00:37.104288
5cc2f816-3f45-46c4-b938-0660c964609a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	b0a95e11-90ac-4ab3-b099-c4de69f498b8	269dca40-b352-4a09-9d7c-c735016a8c7d	78882562-2120-44d2-9286-03e696abbf02	2025-09-22	\N	\N	2.50	research	t	t	150.00	375.00	\N	Viridis expedita bibo civitas.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-22 18:00:37.103	\N	2025-10-19 18:00:37.107427	2025-10-19 18:00:37.107427
086d0f8a-9432-487d-9467-62a5e00a86c0	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	a4464f5a-2125-46d9-9f58-7252c9adc16b	49ae64ac-de52-4d18-a5d6-d73c5d5605c5	235b548d-f0a0-4899-9a7e-d6e9bec6db40	2025-09-22	\N	\N	3.00	work	t	f	120.00	360.00	\N	Thalassinus corroboro urbs tersus ambulo arcesso.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-22 18:00:37.103	\N	2025-10-19 18:00:37.110829	2025-10-19 18:00:37.110829
cc37dd2a-5fb4-4d24-959d-490ea22cef3c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	7ef8af5a-1080-42a2-988f-ddfa799c8070	1c9d17d2-a153-4f42-9604-129a162a1f0f	3f2e9a8e-bdfe-4d09-aced-e88cdc710462	2025-09-22	\N	\N	2.75	work	t	t	120.00	330.00	\N	Comparo atrox adficio.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-22 18:00:37.103	\N	2025-10-19 18:00:37.114649	2025-10-19 18:00:37.114649
df14d755-360e-41df-b05b-52393a17ee57	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	96a103f5-bc5b-43e1-b321-62fedda6eaa1	79d01aa5-b680-4830-ab3a-5e3cb66edcfa	2025-09-22	\N	\N	0.50	admin	t	t	120.00	60.00	\N	Ustulo conventus defluo placeat facilis cultellus sollicito aurum speciosus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-22 18:00:37.103	\N	2025-10-19 18:00:37.118878	2025-10-19 18:00:37.118878
808614b4-c9cf-4d22-a2f5-f48431ef182d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	702b5a48-f7a9-464c-8833-1ff6577e50e6	0da2984a-30cb-4fdf-a4f6-b38ff97be406	109283c7-55ef-4e05-bf53-c6efd1be486f	2025-09-22	\N	\N	3.75	meeting	t	f	120.00	450.00	\N	Temporibus demoror curriculum deripio.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-22 18:00:37.103	\N	2025-10-19 18:00:37.122638	2025-10-19 18:00:37.122638
cd8c486d-36be-419b-b65b-ca22742866d9	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	088446c4-4542-4007-9887-b512bd3db05d	d04961e2-5af7-4b9c-bb44-c37031dd6bfa	2025-09-22	\N	\N	0.75	training	t	t	110.00	82.50	\N	Infit traho argentum demo voco canis defaeco calculus valde patrocinor.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-22 18:00:37.103	\N	2025-10-19 18:00:37.125597	2025-10-19 18:00:37.125597
be552bcc-c7e1-4317-aa43-6e7acad459a3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	5e2204cd-be52-42a7-aa41-14fcf0e4a272	18c91d63-8f9d-4974-ba97-a4079c7457d5	2025-09-22	\N	\N	2.50	meeting	t	f	110.00	275.00	\N	Possimus attollo dapifer amplus valde adopto placeat quos speculum trucido.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-22 18:00:37.103	\N	2025-10-19 18:00:37.127632	2025-10-19 18:00:37.127632
0f0053c4-08ed-4a70-a742-596f7dc0ff38	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	088446c4-4542-4007-9887-b512bd3db05d	ca413110-b7e3-4734-a185-d21ea0960708	2025-09-22	\N	\N	2.50	work	t	f	110.00	275.00	\N	Voveo comminor basium ter adeptio benigne uter.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-22 18:00:37.103	\N	2025-10-19 18:00:37.130713	2025-10-19 18:00:37.130713
31117fe5-8cb6-4b2a-874f-653e2a42d730	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	8538cc30-f9e7-4b63-a885-56b23e16ecef	b3d1095b-3d51-444b-be35-f485afdb174f	29a61f52-d957-4207-b54b-7fc565a57541	2025-09-22	\N	\N	2.75	work	t	f	85.00	233.75	\N	Defendo coaegresco vester.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-22 18:00:37.103	\N	2025-10-19 18:00:37.134283	2025-10-19 18:00:37.134283
93a9f084-3661-4533-bae9-eaa8e029e8bd	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	088446c4-4542-4007-9887-b512bd3db05d	9362cf11-827c-459a-8ffc-6634bd023508	2025-09-22	\N	\N	1.75	research	t	f	85.00	148.75	\N	Carbo utrimque spes degusto eveniet copia colo placeat.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-22 18:00:37.103	\N	2025-10-19 18:00:37.137435	2025-10-19 18:00:37.137435
b34ae2bd-5402-4e55-bfd0-25d59344a438	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	67f62599-7f9f-44e8-bc18-d2ce08ea9919	9ec151a2-b6a4-433d-a21e-c94af23b785b	996aa78c-cfd1-477f-8c30-d9489225b29e	2025-09-22	\N	\N	0.50	meeting	t	f	85.00	42.50	\N	Hic accendo tui arca vito taceo crapula fugiat ambulo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-22 18:00:37.103	\N	2025-10-19 18:00:37.141232	2025-10-19 18:00:37.141232
bbd084bf-c7ca-417d-9828-d20acdaa3589	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	45b3d726-e151-4770-9b64-4653914bdaa5	2c1d5d5c-be1c-427c-b2ac-da3cc28b1680	29a61f52-d957-4207-b54b-7fc565a57541	2025-09-23	\N	\N	0.75	meeting	t	f	150.00	112.50	\N	Amplus absque accusator benigne.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-23 18:00:37.144	\N	2025-10-19 18:00:37.14515	2025-10-19 18:00:37.14515
2aa92346-83ff-425f-9b1b-7745f4ffc8c2	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	12edb785-268b-4219-840d-15b8f0df1198	e171fa0b-3143-48ec-962f-0917bf1886bf	996aa78c-cfd1-477f-8c30-d9489225b29e	2025-09-23	\N	\N	2.25	research	t	f	150.00	337.50	\N	Terminatio dolores cultellus cribro uredo sortitus chirographum adhuc comedo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-23 18:00:37.144	\N	2025-10-19 18:00:37.148605	2025-10-19 18:00:37.148605
0a0bdfb4-a3a1-4129-94ac-fd3d8dd5fbc8	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	17f141c2-e297-4c93-9178-0fd819259c50	c7111387-5606-4d4b-88de-270766225b61	235b548d-f0a0-4899-9a7e-d6e9bec6db40	2025-09-23	\N	\N	1.75	research	t	f	120.00	210.00	\N	Vulpes avarus compono suscipit.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-23 18:00:37.144	\N	2025-10-19 18:00:37.150845	2025-10-19 18:00:37.150845
1ddd8720-9f92-4319-b787-0d471d74ca76	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	d69d0436-37d7-42a4-b907-3d9c3a091ea6	116f1e4b-b201-4dec-8d77-5e3b3695422f	d04961e2-5af7-4b9c-bb44-c37031dd6bfa	2025-09-23	\N	\N	4.00	admin	t	t	120.00	480.00	\N	Vir cur adimpleo tot umquam.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-23 18:00:37.144	\N	2025-10-19 18:00:37.153035	2025-10-19 18:00:37.153035
f42b3057-bbc7-4d6f-a534-383545a7514d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	7ef8af5a-1080-42a2-988f-ddfa799c8070	1c9d17d2-a153-4f42-9604-129a162a1f0f	ef53422c-1305-4831-bf41-d85b2a76b0d5	2025-09-23	\N	\N	3.75	admin	t	t	120.00	450.00	\N	Degusto truculenter fugiat suscipio strenuus arbitro catena vero eum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-23 18:00:37.144	\N	2025-10-19 18:00:37.155662	2025-10-19 18:00:37.155662
672d26d5-7acb-464e-8e78-2d7ebcfcfecd	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	17f141c2-e297-4c93-9178-0fd819259c50	80260d18-0de6-4cf6-af1d-5b4a1d17a6de	a8a65b80-dc4c-49f9-9c8d-0dc4a336cf55	2025-09-23	\N	\N	1.75	meeting	t	t	110.00	192.50	\N	Appello beneficium spoliatio sordeo iusto tenuis labore conqueror somniculosus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-23 18:00:37.144	\N	2025-10-19 18:00:37.158435	2025-10-19 18:00:37.158435
e50948ab-587d-4334-bd75-506fe89016a9	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	6a032ece-4f9e-405a-b48a-b28516d15fe1	1916b6af-0ab6-45d8-85ca-a9a6b331363c	29a61f52-d957-4207-b54b-7fc565a57541	2025-09-23	\N	\N	2.25	work	t	t	110.00	247.50	\N	Charisma volup veniam tredecim adfero caelum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-23 18:00:37.144	\N	2025-10-19 18:00:37.161319	2025-10-19 18:00:37.161319
fe999b13-0026-4b4a-a533-e9e9f5549d84	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	2db210d6-c799-49db-b61d-9aff5f87f1f0	a0801828-5c53-41ef-9b3e-06db89d72e90	2025-09-23	\N	\N	3.50	work	f	f	110.00	385.00	\N	Allatus quas adsidue depopulo nobis.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-23 18:00:37.144	\N	2025-10-19 18:00:37.166	2025-10-19 18:00:37.166
2e2ddc9f-a64e-4e73-8bc5-1ff262e2861a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	65a6152e-a261-4a70-99fb-82f044e87d05	2105be2b-df4f-494a-bb20-548a7dbda952	235b548d-f0a0-4899-9a7e-d6e9bec6db40	2025-09-23	\N	\N	2.75	research	f	f	85.00	233.75	\N	Tutis coniecto utique.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-23 18:00:37.144	\N	2025-10-19 18:00:37.169099	2025-10-19 18:00:37.169099
a27cf303-0321-464b-b674-2ebfbb8298ed	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	0d0329f4-4b80-4899-8807-5854e9db312b	40ca5c4e-33d7-432f-a55c-b59c3010d7ef	109283c7-55ef-4e05-bf53-c6efd1be486f	2025-09-23	\N	\N	2.75	meeting	t	f	85.00	233.75	\N	Verbera in magnam sumptus caritas antepono.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-23 18:00:37.144	\N	2025-10-19 18:00:37.172298	2025-10-19 18:00:37.172298
6dbeba46-5f54-42dc-bd75-7d0dd897bd74	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	088446c4-4542-4007-9887-b512bd3db05d	ca413110-b7e3-4734-a185-d21ea0960708	2025-09-23	\N	\N	0.50	meeting	f	t	85.00	42.50	\N	Amicitia ambulo auxilium tam sublime varietas asperiores acervus stipes deprecator.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-23 18:00:37.144	\N	2025-10-19 18:00:37.176396	2025-10-19 18:00:37.176396
f1e72984-0a6d-44b7-9c3e-0c7fc6046b35	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	04465623-29cb-4298-8828-d1839e9cc00d	e4ce7abb-fb0c-42e1-a7c1-6419b4aa63ef	109283c7-55ef-4e05-bf53-c6efd1be486f	2025-09-24	\N	\N	1.50	work	t	f	150.00	225.00	\N	Absconditus quo vulticulus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-24 18:00:37.178	\N	2025-10-19 18:00:37.180194	2025-10-19 18:00:37.180194
1cb60a22-ab79-4677-aa26-da46f64ce902	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	0d0329f4-4b80-4899-8807-5854e9db312b	40ca5c4e-33d7-432f-a55c-b59c3010d7ef	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	2025-09-24	\N	\N	0.50	training	t	f	150.00	75.00	\N	Accusamus peccatus celebrer turpis contra vel aequus culpo nemo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-24 18:00:37.178	\N	2025-10-19 18:00:37.183294	2025-10-19 18:00:37.183294
c7d55b72-7902-49aa-a72a-4b5fb8a5f955	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	d69d0436-37d7-42a4-b907-3d9c3a091ea6	fe24fe87-1db5-4f06-9a5c-46757a20518d	9362cf11-827c-459a-8ffc-6634bd023508	2025-09-24	\N	\N	3.50	admin	t	f	150.00	525.00	\N	Vaco casus delego adflicto taceo subiungo curis.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-24 18:00:37.178	\N	2025-10-19 18:00:37.186149	2025-10-19 18:00:37.186149
065d515f-2a0f-4259-9766-5f44208909c2	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	584bab37-ccf2-484c-9a7f-7394e4b30ec6	ddc09723-5f7f-4f23-a202-0b6243ef63f9	ff4a2600-29fe-4448-bec3-ea868988a9ed	2025-09-24	\N	\N	2.00	admin	t	f	150.00	300.00	\N	Suspendo quaerat blanditiis cruciamentum cometes.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-24 18:00:37.178	\N	2025-10-19 18:00:37.188635	2025-10-19 18:00:37.188635
38fa43ee-5a5b-499a-879b-ad471fed05e7	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	17f141c2-e297-4c93-9178-0fd819259c50	af41070b-ce93-4cf4-88f6-19ed28a1f1fe	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	2025-10-17	\N	\N	4.00	work	t	f	85.00	340.00	\N	Condico crudelis vox sollers.	\N	draft	\N	\N	\N	\N	2025-10-19 18:00:37.889851	2025-10-19 18:00:37.889851
f24d8c55-43a5-4a29-b7dd-a694fd80fc30	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	65a6152e-a261-4a70-99fb-82f044e87d05	b7a77905-edd5-451e-a92e-06976feeb638	cbf9b499-276b-4a28-999c-27388562c4f4	2025-09-24	\N	\N	2.25	work	f	f	150.00	337.50	\N	Inflammatio vinum annus cogo thermae usque accusantium depulso expedita.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-24 18:00:37.178	\N	2025-10-19 18:00:37.191033	2025-10-19 18:00:37.191033
787f8ec3-335a-489b-a598-e67eb5b2f354	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	7ef8af5a-1080-42a2-988f-ddfa799c8070	1c9d17d2-a153-4f42-9604-129a162a1f0f	d04961e2-5af7-4b9c-bb44-c37031dd6bfa	2025-09-24	\N	\N	3.75	training	t	t	120.00	450.00	\N	Convoco arguo tero traho cerno tergo desino adamo urbs curatio.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-24 18:00:37.178	\N	2025-10-19 18:00:37.193132	2025-10-19 18:00:37.193132
94edf85c-d3fc-482e-8772-ec1c2076d03a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	04465623-29cb-4298-8828-d1839e9cc00d	e4ce7abb-fb0c-42e1-a7c1-6419b4aa63ef	235b548d-f0a0-4899-9a7e-d6e9bec6db40	2025-09-24	\N	\N	0.75	meeting	t	f	120.00	90.00	\N	Supplanto coepi soleo suffoco attonbitus nisi defendo teneo validus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-24 18:00:37.178	\N	2025-10-19 18:00:37.195397	2025-10-19 18:00:37.195397
acce02d9-fa1e-4ab7-8de8-8e7b58a5f421	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	46859340-c8cf-4144-aa6c-28fbaf53fa0e	d486be12-5ed8-48b4-af34-79d9269f4c0b	d04961e2-5af7-4b9c-bb44-c37031dd6bfa	2025-09-24	\N	\N	1.00	admin	t	f	110.00	110.00	\N	Condico quisquam vobis.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-24 18:00:37.178	\N	2025-10-19 18:00:37.197569	2025-10-19 18:00:37.197569
bc4a6555-5708-4049-8c2e-cd6506be1171	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	5e2204cd-be52-42a7-aa41-14fcf0e4a272	79d01aa5-b680-4830-ab3a-5e3cb66edcfa	2025-09-24	\N	\N	3.25	training	t	f	110.00	357.50	\N	Cura pecco stipes ademptio combibo viriliter socius.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-24 18:00:37.178	\N	2025-10-19 18:00:37.199583	2025-10-19 18:00:37.199583
c525a86b-67b0-4a4a-877d-dc1ed359d863	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	12edb785-268b-4219-840d-15b8f0df1198	f37ad203-1495-4aec-be30-1b2d7fe4dd70	a8a65b80-dc4c-49f9-9c8d-0dc4a336cf55	2025-09-24	\N	\N	3.25	training	t	f	110.00	357.50	\N	Despecto super tamisium votum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-24 18:00:37.178	\N	2025-10-19 18:00:37.202201	2025-10-19 18:00:37.202201
50a367b7-c9bb-4060-9477-7189158c70ba	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	12edb785-268b-4219-840d-15b8f0df1198	e171fa0b-3143-48ec-962f-0917bf1886bf	1ede1cc0-3627-404e-bb8a-487e028f4732	2025-09-24	\N	\N	1.75	admin	f	t	85.00	148.75	\N	Capitulus trepide voluptate arceo cauda abbas audacia provident.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-24 18:00:37.178	\N	2025-10-19 18:00:37.204959	2025-10-19 18:00:37.204959
16a9ee34-287c-4bd6-bf57-5de63b7fc998	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	a4464f5a-2125-46d9-9f58-7252c9adc16b	b09b8a10-2b29-4fa3-b57f-c69d46364489	a49c064a-0890-4c02-8734-07a3185e6c03	2025-09-24	\N	\N	4.00	research	t	f	85.00	340.00	\N	Pecto crapula laudantium colo praesentium capto succedo sursum voro.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-24 18:00:37.178	\N	2025-10-19 18:00:37.208404	2025-10-19 18:00:37.208404
c5030414-3080-4e78-9f8f-e6a78947137f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	96a103f5-bc5b-43e1-b321-62fedda6eaa1	78882562-2120-44d2-9286-03e696abbf02	2025-09-24	\N	\N	0.75	training	t	f	85.00	63.75	\N	Absum auctor minus derideo stips ascit a.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-24 18:00:37.178	\N	2025-10-19 18:00:37.21279	2025-10-19 18:00:37.21279
b478e8ac-5e10-418c-a60e-2509f24cca03	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	702b5a48-f7a9-464c-8833-1ff6577e50e6	6ebdfde2-aeab-4596-9744-cef10c12a313	78882562-2120-44d2-9286-03e696abbf02	2025-09-25	\N	\N	0.75	meeting	t	f	150.00	112.50	\N	Voco averto desolo tabesco torrens thesaurus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-25 18:00:37.215	\N	2025-10-19 18:00:37.217043	2025-10-19 18:00:37.217043
8854beda-33d0-409d-81f4-efb6a6a81252	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	6ecda653-6094-4502-9d1d-6e90d9ea99ed	4fb9cb0a-ca36-4af7-9203-ac1970ce555b	08ee5378-067c-4708-886c-34df4c200b23	2025-09-25	\N	\N	1.75	meeting	t	f	150.00	262.50	\N	Accusamus demergo cubo campana delectatio urbs conqueror contra omnis.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-25 18:00:37.215	\N	2025-10-19 18:00:37.22024	2025-10-19 18:00:37.22024
b2ccd251-99de-4192-a41c-2bd50b50f4e6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	d69d0436-37d7-42a4-b907-3d9c3a091ea6	20222077-caa4-4444-b803-1f75d617ee85	e4487405-7859-40e9-8008-056d32fe6f10	2025-09-25	\N	\N	0.50	research	t	f	120.00	60.00	\N	Conor crapula enim vomito.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-25 18:00:37.215	\N	2025-10-19 18:00:37.223235	2025-10-19 18:00:37.223235
2786dfd0-6815-4135-a6d2-4fef75664221	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	8538cc30-f9e7-4b63-a885-56b23e16ecef	b3d1095b-3d51-444b-be35-f485afdb174f	996aa78c-cfd1-477f-8c30-d9489225b29e	2025-09-25	\N	\N	3.75	training	t	f	120.00	450.00	\N	Adipisci acies acquiro.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-25 18:00:37.215	\N	2025-10-19 18:00:37.225958	2025-10-19 18:00:37.225958
c92a1d0b-7923-4211-97ad-b42ff662d914	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	a4464f5a-2125-46d9-9f58-7252c9adc16b	b09b8a10-2b29-4fa3-b57f-c69d46364489	ff4a2600-29fe-4448-bec3-ea868988a9ed	2025-09-25	\N	\N	2.50	meeting	t	t	110.00	275.00	\N	Animi voluptates balbus aliquam coma vinco.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-25 18:00:37.215	\N	2025-10-19 18:00:37.228563	2025-10-19 18:00:37.228563
9393b338-c03f-4dff-998e-f7be4a2c966e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	46859340-c8cf-4144-aa6c-28fbaf53fa0e	d486be12-5ed8-48b4-af34-79d9269f4c0b	a96c9f4d-dc33-4af3-818d-8d729f0f8c1f	2025-09-25	\N	\N	1.00	training	f	f	110.00	110.00	\N	Votum crux comprehendo ulterius appono caelum voco.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-25 18:00:37.215	\N	2025-10-19 18:00:37.231176	2025-10-19 18:00:37.231176
74de2427-ff03-47ba-a514-49c79a9b56ad	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	45b3d726-e151-4770-9b64-4653914bdaa5	449f8e23-33a0-4bf0-915e-cc79d13bc3a9	d04961e2-5af7-4b9c-bb44-c37031dd6bfa	2025-09-25	\N	\N	1.00	admin	t	f	110.00	110.00	\N	Depereo thorax aperiam ancilla textilis tepesco totam turba terebro animus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-25 18:00:37.215	\N	2025-10-19 18:00:37.233881	2025-10-19 18:00:37.233881
1b007403-4c58-4f6d-8568-3e92458aa02c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	65a6152e-a261-4a70-99fb-82f044e87d05	2105be2b-df4f-494a-bb20-548a7dbda952	391f7d87-df5d-4538-9b3e-31e07ac9347e	2025-09-25	\N	\N	1.75	admin	t	t	110.00	192.50	\N	Vulnus vetus clarus vesica tondeo aetas tergiversatio calcar tepidus vos.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-25 18:00:37.215	\N	2025-10-19 18:00:37.236586	2025-10-19 18:00:37.236586
88ab5a5a-cd25-4e66-a0e9-01806a610cee	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	405d4d05-841b-437d-af7d-70b66dda4cbc	219aa257-710f-4ef2-892d-39086a9690ed	29a61f52-d957-4207-b54b-7fc565a57541	2025-09-25	\N	\N	2.50	training	t	f	85.00	212.50	\N	Itaque esse cunctatio uter canto adiuvo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-25 18:00:37.215	\N	2025-10-19 18:00:37.239	2025-10-19 18:00:37.239
167b50d4-db6c-456c-96ff-554595c797a4	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	4554e09d-4391-42a8-a2cd-9702bce80511	ae73110f-e045-44ac-85ff-51aa2eb8ce69	29a61f52-d957-4207-b54b-7fc565a57541	2025-09-25	\N	\N	2.00	research	t	f	85.00	170.00	\N	Voluptas barba accusantium.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-25 18:00:37.215	\N	2025-10-19 18:00:37.241315	2025-10-19 18:00:37.241315
854fd6dd-39d9-4a87-b80b-f67156a4ae29	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	405d4d05-841b-437d-af7d-70b66dda4cbc	9485b00c-4fc8-454f-984a-6908039db9f9	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	2025-09-25	\N	\N	2.00	training	t	t	85.00	170.00	\N	Adfero basium accendo hic crustulum cena sodalitas varius comburo laborum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-25 18:00:37.215	\N	2025-10-19 18:00:37.243682	2025-10-19 18:00:37.243682
5bd0f344-11dd-47e1-99ae-c32b675633a3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	a4464f5a-2125-46d9-9f58-7252c9adc16b	b09b8a10-2b29-4fa3-b57f-c69d46364489	ca413110-b7e3-4734-a185-d21ea0960708	2025-09-25	\N	\N	2.75	research	t	f	85.00	233.75	\N	Caput animi uter supellex consectetur civis validus harum avaritia.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-25 18:00:37.215	\N	2025-10-19 18:00:37.246117	2025-10-19 18:00:37.246117
f29bcb03-a5bf-482b-b8f3-18a5438fc637	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	6a032ece-4f9e-405a-b48a-b28516d15fe1	43f46d13-e4e7-4e0f-a62d-25d47b569d15	08ee5378-067c-4708-886c-34df4c200b23	2025-09-26	\N	\N	2.00	research	t	f	150.00	300.00	\N	Terreo tabula talus vehemens atque.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-26 18:00:37.247	\N	2025-10-19 18:00:37.248204	2025-10-19 18:00:37.248204
19f42378-86d8-4c5b-bd9a-d851e5f39843	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	6ecda653-6094-4502-9d1d-6e90d9ea99ed	6c88f260-519e-41e9-9fac-18a28b9a7901	ef53422c-1305-4831-bf41-d85b2a76b0d5	2025-09-26	\N	\N	3.25	research	t	f	150.00	487.50	\N	Undique saepe somniculosus cursus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-26 18:00:37.247	\N	2025-10-19 18:00:37.250536	2025-10-19 18:00:37.250536
326dfc02-33c7-480f-90ad-bcbeef8e24cd	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	46859340-c8cf-4144-aa6c-28fbaf53fa0e	f9444b08-3c00-4407-98d8-3d654600142c	391f7d87-df5d-4538-9b3e-31e07ac9347e	2025-09-26	\N	\N	3.75	admin	t	f	150.00	562.50	\N	Theatrum usitas eos ver defero bellum adfero bestia damnatio nesciunt.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-26 18:00:37.247	\N	2025-10-19 18:00:37.252616	2025-10-19 18:00:37.252616
b39b7f44-32d4-4dfe-add8-d1f816bf83be	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	65a6152e-a261-4a70-99fb-82f044e87d05	b7a77905-edd5-451e-a92e-06976feeb638	d6d7e47b-cd48-48d8-a45a-fa75af1f9a52	2025-09-26	\N	\N	1.75	research	t	f	120.00	210.00	\N	Acies ulciscor distinctio cetera talio absconditus aspernatur.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-26 18:00:37.247	\N	2025-10-19 18:00:37.25459	2025-10-19 18:00:37.25459
99ce8f79-ed3c-40b3-8e0f-72f38885b72d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	6ecda653-6094-4502-9d1d-6e90d9ea99ed	6c88f260-519e-41e9-9fac-18a28b9a7901	109283c7-55ef-4e05-bf53-c6efd1be486f	2025-09-26	\N	\N	1.25	research	t	t	120.00	150.00	\N	Alioqui clamo conicio cogo ut casso carus complectus delicate tui.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-26 18:00:37.247	\N	2025-10-19 18:00:37.256746	2025-10-19 18:00:37.256746
b3b60e23-0ff4-41c1-bd82-08a99d5c9df7	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	b7295600-5c20-4de2-8782-af87987c2bee	d2f831e1-38ca-429c-9942-06db88f8dfc5	996aa78c-cfd1-477f-8c30-d9489225b29e	2025-09-26	\N	\N	1.50	training	f	t	110.00	165.00	\N	Capillus totidem depulso commodo calculus civitas cupiditate trucido.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-26 18:00:37.247	\N	2025-10-19 18:00:37.258795	2025-10-19 18:00:37.258795
c9aba398-a71b-4ae3-b0bb-3459d0173d5d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	a4464f5a-2125-46d9-9f58-7252c9adc16b	49ae64ac-de52-4d18-a5d6-d73c5d5605c5	391f7d87-df5d-4538-9b3e-31e07ac9347e	2025-09-26	\N	\N	2.50	meeting	t	t	110.00	275.00	\N	Demonstro ab constans calcar vos concido tergum via.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-26 18:00:37.247	\N	2025-10-19 18:00:37.261375	2025-10-19 18:00:37.261375
28ad750d-6532-4883-a8dd-ef2e45700b15	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	65a6152e-a261-4a70-99fb-82f044e87d05	b98cb032-3f5a-46db-ab39-de7d53570ae9	29a61f52-d957-4207-b54b-7fc565a57541	2025-09-26	\N	\N	1.00	meeting	t	f	110.00	110.00	\N	Magnam conitor cumque cur cupiditas sto volubilis vociferor.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-26 18:00:37.247	\N	2025-10-19 18:00:37.263584	2025-10-19 18:00:37.263584
f444e2be-3469-4993-9975-4983ceee6036	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	67f62599-7f9f-44e8-bc18-d2ce08ea9919	419cb8f8-8b70-44a5-883b-8fa92787aa46	cbf9b499-276b-4a28-999c-27388562c4f4	2025-09-26	\N	\N	0.75	admin	t	t	110.00	82.50	\N	Cimentarius adaugeo nobis verbera vociferor curriculum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-26 18:00:37.247	\N	2025-10-19 18:00:37.265436	2025-10-19 18:00:37.265436
5470f251-50d4-4fc4-bda5-b9dd29c81c96	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	17f141c2-e297-4c93-9178-0fd819259c50	80260d18-0de6-4cf6-af1d-5b4a1d17a6de	996aa78c-cfd1-477f-8c30-d9489225b29e	2025-09-26	\N	\N	3.00	research	t	t	85.00	255.00	\N	Libero defero dedecor bestia.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-26 18:00:37.247	\N	2025-10-19 18:00:37.267207	2025-10-19 18:00:37.267207
f0d3ebe4-7cc6-428d-a58f-09c428b8bb57	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	04465623-29cb-4298-8828-d1839e9cc00d	e4ce7abb-fb0c-42e1-a7c1-6419b4aa63ef	1ede1cc0-3627-404e-bb8a-487e028f4732	2025-09-26	\N	\N	1.00	meeting	t	f	85.00	85.00	\N	Adipisci cena aegre appono suffragium.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-26 18:00:37.247	\N	2025-10-19 18:00:37.270571	2025-10-19 18:00:37.270571
3d12df7f-db65-4ba4-aa41-fd5fb6fb134e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	7ef8af5a-1080-42a2-988f-ddfa799c8070	5cf17315-4658-4a7f-9c23-b4f8268d8f84	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	2025-09-26	\N	\N	3.50	admin	t	t	85.00	297.50	\N	Uterque taceo quis vestrum tollo cruciamentum tutamen thymum tutamen.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-26 18:00:37.247	\N	2025-10-19 18:00:37.272988	2025-10-19 18:00:37.272988
d52c0d67-2805-4e58-a382-35bc393d3e38	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	7ef8af5a-1080-42a2-988f-ddfa799c8070	1c9d17d2-a153-4f42-9604-129a162a1f0f	ef53422c-1305-4831-bf41-d85b2a76b0d5	2025-09-29	\N	\N	1.75	training	t	t	150.00	262.50	\N	Arca appello vesica distinctio adopto coruscus alter consequuntur adinventitias.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-29 18:00:37.274	\N	2025-10-19 18:00:37.275468	2025-10-19 18:00:37.275468
8b9a15c2-5c84-4aa1-855f-d85565fdea6c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	b7295600-5c20-4de2-8782-af87987c2bee	196a1b4b-9367-4b9f-baf6-717d312881a3	ef53422c-1305-4831-bf41-d85b2a76b0d5	2025-09-29	\N	\N	3.00	work	t	t	150.00	450.00	\N	Caute approbo delectus corpus casus verus soluta.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-29 18:00:37.274	\N	2025-10-19 18:00:37.278598	2025-10-19 18:00:37.278598
d84b1434-605e-4c83-82ac-eeda27166710	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	eb1af1df-ce0a-4763-aaef-49b6b390beab	ca413110-b7e3-4734-a185-d21ea0960708	2025-09-29	\N	\N	3.50	admin	t	t	120.00	420.00	\N	Pax sonitus considero dapifer doloremque tener possimus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-29 18:00:37.274	\N	2025-10-19 18:00:37.281839	2025-10-19 18:00:37.281839
04fc0999-9324-49c4-ae62-8e28d34c269c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	eb1af1df-ce0a-4763-aaef-49b6b390beab	391f7d87-df5d-4538-9b3e-31e07ac9347e	2025-09-29	\N	\N	0.50	meeting	f	f	120.00	60.00	\N	Taedium thymbra caecus advoco cattus tabella armarium.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-29 18:00:37.274	\N	2025-10-19 18:00:37.284914	2025-10-19 18:00:37.284914
7820713e-1675-4cd3-b565-76a6ca14f743	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	088446c4-4542-4007-9887-b512bd3db05d	ecfd2c2c-905b-4ef4-99a4-8949632b9ae9	2025-09-29	\N	\N	3.75	research	t	f	120.00	450.00	\N	Dapifer turpis sublime asper thymbra terreo video.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-29 18:00:37.274	\N	2025-10-19 18:00:37.288209	2025-10-19 18:00:37.288209
53d1861f-e5ad-4e8c-821b-d1450157ed2b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	6a032ece-4f9e-405a-b48a-b28516d15fe1	1916b6af-0ab6-45d8-85ca-a9a6b331363c	18c91d63-8f9d-4974-ba97-a4079c7457d5	2025-09-29	\N	\N	2.25	training	t	t	120.00	270.00	\N	Concido claro pauci suppellex termes subnecto tot assentator sperno distinctio.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-29 18:00:37.274	\N	2025-10-19 18:00:37.291516	2025-10-19 18:00:37.291516
426fd5c1-9e1c-4665-b158-aac30ba80c49	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	67f62599-7f9f-44e8-bc18-d2ce08ea9919	8c04c9d5-2992-4108-bc71-d0210b7972e2	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-09-29	\N	\N	3.75	research	t	t	120.00	450.00	\N	Vero tutamen caute spiculum tamen verbera cresco totidem tergiversatio.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-29 18:00:37.274	\N	2025-10-19 18:00:37.29493	2025-10-19 18:00:37.29493
15933ccc-8ce3-4e49-8f54-43bf7dc4504f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	0d0329f4-4b80-4899-8807-5854e9db312b	40ca5c4e-33d7-432f-a55c-b59c3010d7ef	391f7d87-df5d-4538-9b3e-31e07ac9347e	2025-09-29	\N	\N	2.50	training	t	f	110.00	275.00	\N	Terebro sapiente adiuvo sui blanditiis dicta.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-29 18:00:37.274	\N	2025-10-19 18:00:37.298285	2025-10-19 18:00:37.298285
adaa3071-7089-40ca-8616-6d9ba7f2adf2	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	6ecda653-6094-4502-9d1d-6e90d9ea99ed	4fb9cb0a-ca36-4af7-9203-ac1970ce555b	235b548d-f0a0-4899-9a7e-d6e9bec6db40	2025-09-29	\N	\N	0.75	work	t	f	110.00	82.50	\N	Aspernatur impedit cresco ver placeat nostrum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-29 18:00:37.274	\N	2025-10-19 18:00:37.300793	2025-10-19 18:00:37.300793
e03ed4ca-1994-4018-8890-8942c32696d4	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	6a032ece-4f9e-405a-b48a-b28516d15fe1	43f46d13-e4e7-4e0f-a62d-25d47b569d15	a96c9f4d-dc33-4af3-818d-8d729f0f8c1f	2025-09-29	\N	\N	0.50	research	f	f	85.00	42.50	\N	Templum illum copia cogito tondeo aestas hic.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-29 18:00:37.274	\N	2025-10-19 18:00:37.304465	2025-10-19 18:00:37.304465
d6df22fc-c20c-4cba-ab6b-72fa1488f96d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	a4464f5a-2125-46d9-9f58-7252c9adc16b	49ae64ac-de52-4d18-a5d6-d73c5d5605c5	79d01aa5-b680-4830-ab3a-5e3cb66edcfa	2025-09-29	\N	\N	1.75	work	t	t	85.00	148.75	\N	Adipiscor versus aedificium victoria solutio doloribus natus minus repellendus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-29 18:00:37.274	\N	2025-10-19 18:00:37.308906	2025-10-19 18:00:37.308906
8463947c-be3f-4cc6-9e7f-13fb92f1cecb	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	d8601cb6-589f-456f-a2b2-1b986973a4bc	9362cf11-827c-459a-8ffc-6634bd023508	2025-09-29	\N	\N	0.75	research	t	f	85.00	63.75	\N	Desparatus neque demum corporis.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-29 18:00:37.274	\N	2025-10-19 18:00:37.312424	2025-10-19 18:00:37.312424
e8d4fe30-0daf-425a-9009-48ed97e76d8d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	7ef8af5a-1080-42a2-988f-ddfa799c8070	1c9d17d2-a153-4f42-9604-129a162a1f0f	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	2025-09-30	\N	\N	2.00	meeting	t	f	150.00	300.00	\N	Antiquus claustrum texo nesciunt solutio vesper stillicidium coma tremo alias.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-30 18:00:37.315	\N	2025-10-19 18:00:37.31681	2025-10-19 18:00:37.31681
50b14be0-f941-47f1-afcd-74e4158bbe9a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	45b3d726-e151-4770-9b64-4653914bdaa5	449f8e23-33a0-4bf0-915e-cc79d13bc3a9	d04961e2-5af7-4b9c-bb44-c37031dd6bfa	2025-09-30	\N	\N	2.75	admin	t	f	150.00	412.50	\N	Clementia contigo sopor acerbitas sono.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-30 18:00:37.315	\N	2025-10-19 18:00:37.321116	2025-10-19 18:00:37.321116
4de45c1d-ae1c-4771-ac10-07cbeae56b25	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	04600664-34f3-4ae0-9a01-2da04b5bc5fc	ca413110-b7e3-4734-a185-d21ea0960708	2025-09-30	\N	\N	1.50	admin	f	t	120.00	180.00	\N	Cur beatus bardus vesica deleniti nisi caelum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-30 18:00:37.315	\N	2025-10-19 18:00:37.32552	2025-10-19 18:00:37.32552
bb699be3-0418-4de0-9f71-3167a61068fd	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	d69d0436-37d7-42a4-b907-3d9c3a091ea6	20222077-caa4-4444-b803-1f75d617ee85	a8a65b80-dc4c-49f9-9c8d-0dc4a336cf55	2025-09-30	\N	\N	3.00	meeting	f	f	120.00	360.00	\N	Acceptus video universe tam vereor texo cupressus uxor taceo vesco.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-30 18:00:37.315	\N	2025-10-19 18:00:37.328776	2025-10-19 18:00:37.328776
bf52a92a-f5a3-4a82-bdef-9c830574720e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	96a103f5-bc5b-43e1-b321-62fedda6eaa1	a49c064a-0890-4c02-8734-07a3185e6c03	2025-09-30	\N	\N	2.50	training	t	t	110.00	275.00	\N	Labore solus testimonium decor decimus volutabrum atqui atqui vallum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-30 18:00:37.315	\N	2025-10-19 18:00:37.331821	2025-10-19 18:00:37.331821
00d6f57f-8968-433b-96f2-eba2aa041dc0	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	5e2204cd-be52-42a7-aa41-14fcf0e4a272	ff4a2600-29fe-4448-bec3-ea868988a9ed	2025-09-30	\N	\N	3.00	work	t	f	110.00	330.00	\N	Aestivus currus ademptio crebro utroque alias neque.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-30 18:00:37.315	\N	2025-10-19 18:00:37.334855	2025-10-19 18:00:37.334855
2f989cdd-fd90-4d7a-a13f-684f3142ad5c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	702b5a48-f7a9-464c-8833-1ff6577e50e6	0da2984a-30cb-4fdf-a4f6-b38ff97be406	ecfd2c2c-905b-4ef4-99a4-8949632b9ae9	2025-09-30	\N	\N	0.50	research	f	t	110.00	55.00	\N	Angulus laborum libero vallum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-30 18:00:37.315	\N	2025-10-19 18:00:37.337611	2025-10-19 18:00:37.337611
e59a4e36-cafe-4409-84ad-f5c1611ac4a6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	2db210d6-c799-49db-b61d-9aff5f87f1f0	d04961e2-5af7-4b9c-bb44-c37031dd6bfa	2025-09-30	\N	\N	3.75	admin	t	f	85.00	318.75	\N	Talio voro est exercitationem calco degenero.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-30 18:00:37.315	\N	2025-10-19 18:00:37.340462	2025-10-19 18:00:37.340462
f8bcd9d2-d0ff-4255-9214-b275fa11fe18	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	088446c4-4542-4007-9887-b512bd3db05d	78882562-2120-44d2-9286-03e696abbf02	2025-09-30	\N	\N	2.50	research	t	t	85.00	212.50	\N	Vulticulus campana vigor taedium vereor consuasor textor esse pecco abbas.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-30 18:00:37.315	\N	2025-10-19 18:00:37.343287	2025-10-19 18:00:37.343287
f5146ce5-9dde-4216-9935-ddc9a1af8cc9	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	5515e216-ea3c-436b-95a5-6abf213c47ef	a49c064a-0890-4c02-8734-07a3185e6c03	2025-09-30	\N	\N	1.00	work	f	f	85.00	85.00	\N	Cresco carus cinis vir colligo trans sustineo carus ancilla paens.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-30 18:00:37.315	\N	2025-10-19 18:00:37.345951	2025-10-19 18:00:37.345951
a9ea1b3b-a78f-47a1-a1ab-3de782bd5bf1	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	405d4d05-841b-437d-af7d-70b66dda4cbc	4f8e956e-3c05-4a0d-8695-2014ee9b2f8a	a0801828-5c53-41ef-9b3e-06db89d72e90	2025-09-30	\N	\N	2.50	admin	f	t	85.00	212.50	\N	Concedo molestias agnitio vulgaris collum vinum vitiosus strenuus auxilium apud.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-30 18:00:37.315	\N	2025-10-19 18:00:37.349727	2025-10-19 18:00:37.349727
cddddc57-5048-4b99-aa30-328c03a27aca	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	04465623-29cb-4298-8828-d1839e9cc00d	e4ce7abb-fb0c-42e1-a7c1-6419b4aa63ef	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	2025-09-30	\N	\N	0.50	training	f	f	85.00	42.50	\N	Clibanus alioqui cariosus vel arto candidus viduo corpus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-09-30 18:00:37.315	\N	2025-10-19 18:00:37.354112	2025-10-19 18:00:37.354112
b61f8250-9d4c-4636-b4d2-b8a4e29befea	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	12edb785-268b-4219-840d-15b8f0df1198	e171fa0b-3143-48ec-962f-0917bf1886bf	e2cd4da6-f171-436c-9c7e-a9c1c5436b98	2025-10-01	\N	\N	2.00	work	f	t	150.00	300.00	\N	Nulla cito arto vis crastinus timidus ex rem.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-01 18:00:37.356	\N	2025-10-19 18:00:37.357936	2025-10-19 18:00:37.357936
ee5b4329-e892-41b2-91fe-a7b6320cb312	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	5e2204cd-be52-42a7-aa41-14fcf0e4a272	a8a65b80-dc4c-49f9-9c8d-0dc4a336cf55	2025-10-01	\N	\N	1.75	meeting	t	f	150.00	262.50	\N	Alias certus spes toties.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-01 18:00:37.356	\N	2025-10-19 18:00:37.361627	2025-10-19 18:00:37.361627
d4c9a380-ad18-448a-a313-876a5cc7f69d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	4554e09d-4391-42a8-a2cd-9702bce80511	ae73110f-e045-44ac-85ff-51aa2eb8ce69	d04961e2-5af7-4b9c-bb44-c37031dd6bfa	2025-10-01	\N	\N	2.00	research	t	t	120.00	240.00	\N	Abutor animi sublime vulgus aestas vox.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-01 18:00:37.356	\N	2025-10-19 18:00:37.365785	2025-10-19 18:00:37.365785
db6f0b49-b0e9-4ed4-9ec5-ef187b64a8df	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	702b5a48-f7a9-464c-8833-1ff6577e50e6	66d28217-b458-4ec3-9e88-eb34570556b7	235b548d-f0a0-4899-9a7e-d6e9bec6db40	2025-10-01	\N	\N	1.75	work	t	f	120.00	210.00	\N	Crux antea ascisco.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-01 18:00:37.356	\N	2025-10-19 18:00:37.369153	2025-10-19 18:00:37.369153
2c05b939-ba67-474a-9161-769e9bf52958	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	088446c4-4542-4007-9887-b512bd3db05d	a49c064a-0890-4c02-8734-07a3185e6c03	2025-10-01	\N	\N	3.00	meeting	t	t	120.00	360.00	\N	Civis est numquam atrox tumultus tabella coma aegrotatio umerus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-01 18:00:37.356	\N	2025-10-19 18:00:37.374388	2025-10-19 18:00:37.374388
e6c4a400-f888-4e21-9119-0498a20ab7e8	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	d69d0436-37d7-42a4-b907-3d9c3a091ea6	116f1e4b-b201-4dec-8d77-5e3b3695422f	a49c064a-0890-4c02-8734-07a3185e6c03	2025-10-01	\N	\N	3.00	research	t	t	120.00	360.00	\N	Atque acervus torqueo canis supplanto patrocinor tonsor sunt turpis spero.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-01 18:00:37.356	\N	2025-10-19 18:00:37.377696	2025-10-19 18:00:37.377696
96cabdcf-c73b-4e54-88d6-3f53219540bb	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	46859340-c8cf-4144-aa6c-28fbaf53fa0e	f9444b08-3c00-4407-98d8-3d654600142c	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-10-01	\N	\N	3.25	admin	f	f	120.00	390.00	\N	Custodia voluptatem vestrum curiositas cernuus deleo inventore tendo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-01 18:00:37.356	\N	2025-10-19 18:00:37.381298	2025-10-19 18:00:37.381298
7041ca53-c9ea-4304-8f2c-348733208995	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	a4464f5a-2125-46d9-9f58-7252c9adc16b	7041a9f2-cd04-4f9c-ab2c-96bfdd45e5ff	a8a65b80-dc4c-49f9-9c8d-0dc4a336cf55	2025-10-01	\N	\N	3.75	meeting	t	f	110.00	412.50	\N	Attero confugo earum inventore ceno modi spoliatio.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-01 18:00:37.356	\N	2025-10-19 18:00:37.385411	2025-10-19 18:00:37.385411
0eaacdec-f46d-482d-9803-c8e70e9a2447	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	12edb785-268b-4219-840d-15b8f0df1198	e171fa0b-3143-48ec-962f-0917bf1886bf	391f7d87-df5d-4538-9b3e-31e07ac9347e	2025-10-01	\N	\N	3.25	research	t	f	110.00	357.50	\N	Ventito video tenus aequus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-01 18:00:37.356	\N	2025-10-19 18:00:37.389326	2025-10-19 18:00:37.389326
4f7bf169-301c-47a2-802e-b175e0dc11de	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	584bab37-ccf2-484c-9a7f-7394e4b30ec6	71b851af-8542-47e4-9ff8-304ed5983a0b	ca413110-b7e3-4734-a185-d21ea0960708	2025-10-01	\N	\N	4.00	work	t	f	85.00	340.00	\N	Convoco pecto cunctatio assumenda balbus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-01 18:00:37.356	\N	2025-10-19 18:00:37.392899	2025-10-19 18:00:37.392899
6b9055a0-006e-4a29-9196-c477f1f8b5b6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	b7295600-5c20-4de2-8782-af87987c2bee	2849d1a9-72a4-4287-8114-b604140c71aa	78882562-2120-44d2-9286-03e696abbf02	2025-10-01	\N	\N	1.50	work	t	f	85.00	127.50	\N	Curatio facere templum delicate confero substantia illum ulciscor.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-01 18:00:37.356	\N	2025-10-19 18:00:37.396715	2025-10-19 18:00:37.396715
4658f546-bec1-4a96-9050-05fb42dc728c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	2db210d6-c799-49db-b61d-9aff5f87f1f0	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	2025-10-02	\N	\N	3.50	meeting	f	t	150.00	525.00	\N	Dapifer aureus tamdiu conturbo vestrum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-02 18:00:37.398	\N	2025-10-19 18:00:37.399833	2025-10-19 18:00:37.399833
5b226c79-447e-45a2-971d-10d07cd79408	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	12edb785-268b-4219-840d-15b8f0df1198	e171fa0b-3143-48ec-962f-0917bf1886bf	996aa78c-cfd1-477f-8c30-d9489225b29e	2025-10-02	\N	\N	1.00	meeting	t	t	150.00	150.00	\N	Thema demonstro tres architecto tenax theca porro.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-02 18:00:37.398	\N	2025-10-19 18:00:37.402819	2025-10-19 18:00:37.402819
3d2acf56-3f81-4297-8433-f410410fdc92	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	eb1af1df-ce0a-4763-aaef-49b6b390beab	d04961e2-5af7-4b9c-bb44-c37031dd6bfa	2025-10-02	\N	\N	2.00	training	t	t	150.00	300.00	\N	Vir valeo tutamen.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-02 18:00:37.398	\N	2025-10-19 18:00:37.407717	2025-10-19 18:00:37.407717
ee3556bb-213b-4970-8037-3d1f474dd6b3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	dc9252b7-2022-4822-a8b2-7ec227fe0ea4	a49c064a-0890-4c02-8734-07a3185e6c03	2025-10-02	\N	\N	2.00	admin	t	f	150.00	300.00	\N	Quibusdam soleo sodalitas suffoco addo alienus nemo abundans despecto ventosus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-02 18:00:37.398	\N	2025-10-19 18:00:37.409893	2025-10-19 18:00:37.409893
0ad42bc2-6b54-4649-909d-6d4fb64cb3c1	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	7ef8af5a-1080-42a2-988f-ddfa799c8070	5cf17315-4658-4a7f-9c23-b4f8268d8f84	ecfd2c2c-905b-4ef4-99a4-8949632b9ae9	2025-10-02	\N	\N	2.75	training	t	t	120.00	330.00	\N	Torqueo atqui ter accusantium ara suus illo sunt calculus spiritus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-02 18:00:37.398	\N	2025-10-19 18:00:37.411767	2025-10-19 18:00:37.411767
7881d3d5-2ee2-48ed-afe5-3a61c37cff55	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	98f9340d-eadb-45cd-bba2-115aa880f565	ecfd2c2c-905b-4ef4-99a4-8949632b9ae9	2025-10-02	\N	\N	1.00	training	t	f	120.00	120.00	\N	Cursim spiculum solium adamo depraedor quis crapula antepono auxilium.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-02 18:00:37.398	\N	2025-10-19 18:00:37.413746	2025-10-19 18:00:37.413746
487ba9f5-0ca9-4bef-bfc8-dc295512fc90	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	46859340-c8cf-4144-aa6c-28fbaf53fa0e	d486be12-5ed8-48b4-af34-79d9269f4c0b	ff4a2600-29fe-4448-bec3-ea868988a9ed	2025-10-02	\N	\N	1.75	work	t	t	120.00	210.00	\N	Speculum angustus tyrannus aeneus vulticulus ventus atrocitas itaque cerno.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-02 18:00:37.398	\N	2025-10-19 18:00:37.415653	2025-10-19 18:00:37.415653
2bc6311f-e582-4b9f-9225-7a46a2eeeabd	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	702b5a48-f7a9-464c-8833-1ff6577e50e6	0da2984a-30cb-4fdf-a4f6-b38ff97be406	a96c9f4d-dc33-4af3-818d-8d729f0f8c1f	2025-10-02	\N	\N	0.50	meeting	t	f	120.00	60.00	\N	Inflammatio summisse copiose crepusculum abstergo certus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-02 18:00:37.398	\N	2025-10-19 18:00:37.418082	2025-10-19 18:00:37.418082
f1e1f739-f4fd-4cc8-871a-77249262a642	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	4554e09d-4391-42a8-a2cd-9702bce80511	ae73110f-e045-44ac-85ff-51aa2eb8ce69	235b548d-f0a0-4899-9a7e-d6e9bec6db40	2025-10-02	\N	\N	3.75	meeting	t	f	110.00	412.50	\N	Clarus vereor veniam tardus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-02 18:00:37.398	\N	2025-10-19 18:00:37.420562	2025-10-19 18:00:37.420562
be65ad52-a43d-43db-810b-787a2b76bc04	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	67f62599-7f9f-44e8-bc18-d2ce08ea9919	419cb8f8-8b70-44a5-883b-8fa92787aa46	d04961e2-5af7-4b9c-bb44-c37031dd6bfa	2025-10-02	\N	\N	0.75	work	t	t	110.00	82.50	\N	Vindico cognatus surgo quas nihil tertius cedo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-02 18:00:37.398	\N	2025-10-19 18:00:37.422285	2025-10-19 18:00:37.422285
11e5736c-13fc-462d-bb30-465411a4c98d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	04600664-34f3-4ae0-9a01-2da04b5bc5fc	235b548d-f0a0-4899-9a7e-d6e9bec6db40	2025-10-02	\N	\N	3.75	work	t	f	110.00	412.50	\N	Defluo aggredior cetera civitas defetiscor validus ago.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-02 18:00:37.398	\N	2025-10-19 18:00:37.42406	2025-10-19 18:00:37.42406
94d097f0-2b12-4fd7-b92d-fac609ef5f79	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	12edb785-268b-4219-840d-15b8f0df1198	f37ad203-1495-4aec-be30-1b2d7fe4dd70	78882562-2120-44d2-9286-03e696abbf02	2025-10-02	\N	\N	0.75	training	f	f	110.00	82.50	\N	Sono tempora victoria cogo arbustum ascisco crinis.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-02 18:00:37.398	\N	2025-10-19 18:00:37.42707	2025-10-19 18:00:37.42707
45bb5983-d342-4ac6-ae63-ecba09f5b255	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	d8601cb6-589f-456f-a2b2-1b986973a4bc	a96c9f4d-dc33-4af3-818d-8d729f0f8c1f	2025-10-02	\N	\N	0.50	training	t	t	110.00	55.00	\N	Tutis vomer corrigo viriliter pectus compono solium amitto abeo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-02 18:00:37.398	\N	2025-10-19 18:00:37.430856	2025-10-19 18:00:37.430856
b207913a-9874-4182-9856-c2f6730f9af7	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	12edb785-268b-4219-840d-15b8f0df1198	e171fa0b-3143-48ec-962f-0917bf1886bf	e4487405-7859-40e9-8008-056d32fe6f10	2025-10-02	\N	\N	1.50	work	t	f	85.00	127.50	\N	Benigne strenuus tenus dapifer deludo accendo speculum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-02 18:00:37.398	\N	2025-10-19 18:00:37.434546	2025-10-19 18:00:37.434546
42b60955-888d-4013-a2df-a857c2401991	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	6a032ece-4f9e-405a-b48a-b28516d15fe1	43f46d13-e4e7-4e0f-a62d-25d47b569d15	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-10-02	\N	\N	1.25	training	t	f	85.00	106.25	\N	Baiulus succurro cohaero paulatim thymbra quod.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-02 18:00:37.398	\N	2025-10-19 18:00:37.43762	2025-10-19 18:00:37.43762
a0ae3a0b-3712-4fb9-b560-f593c805bb4a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	7ef8af5a-1080-42a2-988f-ddfa799c8070	5cf17315-4658-4a7f-9c23-b4f8268d8f84	e2cd4da6-f171-436c-9c7e-a9c1c5436b98	2025-10-02	\N	\N	1.75	training	t	f	85.00	148.75	\N	Coniuratio vado adulescens.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-02 18:00:37.398	\N	2025-10-19 18:00:37.440634	2025-10-19 18:00:37.440634
5bdc70ef-3c4c-464e-84c6-c0cb0dff4879	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	d69d0436-37d7-42a4-b907-3d9c3a091ea6	20222077-caa4-4444-b803-1f75d617ee85	ecfd2c2c-905b-4ef4-99a4-8949632b9ae9	2025-10-03	\N	\N	1.00	training	t	t	150.00	150.00	\N	Commodo audacia consectetur.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-03 18:00:37.442	\N	2025-10-19 18:00:37.44323	2025-10-19 18:00:37.44323
f722fbb7-e4d1-44f0-9ebb-405f9c438893	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	5e2204cd-be52-42a7-aa41-14fcf0e4a272	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-10-03	\N	\N	1.25	research	f	f	150.00	187.50	\N	Admitto asporto compono timidus super inflammatio voluptate truculenter curtus adaugeo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-03 18:00:37.442	\N	2025-10-19 18:00:37.445684	2025-10-19 18:00:37.445684
9a7707c4-e381-4db6-a002-763d3ec1707e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	7ef8af5a-1080-42a2-988f-ddfa799c8070	5cf17315-4658-4a7f-9c23-b4f8268d8f84	ef53422c-1305-4831-bf41-d85b2a76b0d5	2025-10-03	\N	\N	1.25	admin	t	f	150.00	187.50	\N	Defendo agnitio amoveo cui consequatur vesper tabula.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-03 18:00:37.442	\N	2025-10-19 18:00:37.449444	2025-10-19 18:00:37.449444
de437b88-04fc-4f76-b1bf-d4cfed168a44	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	65a6152e-a261-4a70-99fb-82f044e87d05	b7a77905-edd5-451e-a92e-06976feeb638	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-10-03	\N	\N	2.50	research	t	t	120.00	300.00	\N	Vapulus candidus alii utique sono cupiditate astrum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-03 18:00:37.442	\N	2025-10-19 18:00:37.453369	2025-10-19 18:00:37.453369
9f99dcdf-72c4-479e-8ccd-4720c40cadb4	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	dc9252b7-2022-4822-a8b2-7ec227fe0ea4	78882562-2120-44d2-9286-03e696abbf02	2025-10-03	\N	\N	3.25	meeting	t	f	120.00	390.00	\N	Statua ara dolor.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-03 18:00:37.442	\N	2025-10-19 18:00:37.45787	2025-10-19 18:00:37.45787
0d40600f-c116-40cc-9f2d-e6bae91ae70a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	17f141c2-e297-4c93-9178-0fd819259c50	af41070b-ce93-4cf4-88f6-19ed28a1f1fe	78882562-2120-44d2-9286-03e696abbf02	2025-10-03	\N	\N	2.75	meeting	t	f	120.00	330.00	\N	Tenax vociferor coruscus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-03 18:00:37.442	\N	2025-10-19 18:00:37.461467	2025-10-19 18:00:37.461467
7afaa303-a659-4d03-aff5-a4211f1ee2bf	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	6ecda653-6094-4502-9d1d-6e90d9ea99ed	6c88f260-519e-41e9-9fac-18a28b9a7901	d04961e2-5af7-4b9c-bb44-c37031dd6bfa	2025-10-03	\N	\N	3.00	work	t	t	110.00	330.00	\N	Suscipit adduco tergo caterva deduco color sustineo uxor.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-03 18:00:37.442	\N	2025-10-19 18:00:37.466588	2025-10-19 18:00:37.466588
3afc33cc-5585-4931-a122-a9d6c9434d07	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	5e2204cd-be52-42a7-aa41-14fcf0e4a272	a96c9f4d-dc33-4af3-818d-8d729f0f8c1f	2025-10-03	\N	\N	1.75	research	t	f	110.00	192.50	\N	Conatus agnosco tabesco vulariter modi temperantia.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-03 18:00:37.442	\N	2025-10-19 18:00:37.470179	2025-10-19 18:00:37.470179
c6a27100-31e2-43ff-a2da-77def2b76563	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	65a6152e-a261-4a70-99fb-82f044e87d05	b7a77905-edd5-451e-a92e-06976feeb638	a96c9f4d-dc33-4af3-818d-8d729f0f8c1f	2025-10-03	\N	\N	1.00	admin	t	t	85.00	85.00	\N	Deleo dolorem adflicto titulus voluptatum corpus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-03 18:00:37.442	\N	2025-10-19 18:00:37.472875	2025-10-19 18:00:37.472875
0643e530-5db6-4b5a-9a9e-01612f9c91c3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	d69d0436-37d7-42a4-b907-3d9c3a091ea6	116f1e4b-b201-4dec-8d77-5e3b3695422f	e4487405-7859-40e9-8008-056d32fe6f10	2025-10-03	\N	\N	3.50	admin	t	t	85.00	297.50	\N	Volup vilicus aperio civitas culpo cito corrupti vulpes.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-03 18:00:37.442	\N	2025-10-19 18:00:37.475083	2025-10-19 18:00:37.475083
f2b4c82f-2243-4008-b263-fc7c76a81b75	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	6b008063-17c8-4c31-893b-ef9f17e74f13	a8a65b80-dc4c-49f9-9c8d-0dc4a336cf55	2025-10-06	\N	\N	2.50	meeting	t	f	150.00	375.00	\N	Defero claro caecus vulgus compello cultellus denuo aufero speculum quisquam.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-06 18:00:37.476	\N	2025-10-19 18:00:37.47772	2025-10-19 18:00:37.47772
5d176dad-7fbc-4b3c-8f32-e3ca80ae2f6f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	b7295600-5c20-4de2-8782-af87987c2bee	d2f831e1-38ca-429c-9942-06db88f8dfc5	18c91d63-8f9d-4974-ba97-a4079c7457d5	2025-10-06	\N	\N	3.00	meeting	f	t	150.00	450.00	\N	Peior abbas speciosus absorbeo terga.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-06 18:00:37.476	\N	2025-10-19 18:00:37.479955	2025-10-19 18:00:37.479955
1e648b80-0278-4dd3-ba8f-c11e8e015b41	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	7ef8af5a-1080-42a2-988f-ddfa799c8070	1c9d17d2-a153-4f42-9604-129a162a1f0f	d04961e2-5af7-4b9c-bb44-c37031dd6bfa	2025-10-06	\N	\N	1.25	admin	t	f	150.00	187.50	\N	Velum tolero comedo deficio aliquid credo degenero comburo ducimus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-06 18:00:37.476	\N	2025-10-19 18:00:37.484081	2025-10-19 18:00:37.484081
0ca36906-4333-4ae8-8c10-a5d98db190c1	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	a4464f5a-2125-46d9-9f58-7252c9adc16b	b09b8a10-2b29-4fa3-b57f-c69d46364489	08ee5378-067c-4708-886c-34df4c200b23	2025-10-06	\N	\N	2.75	training	f	f	150.00	412.50	\N	Comburo sto reprehenderit.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-06 18:00:37.476	\N	2025-10-19 18:00:37.487686	2025-10-19 18:00:37.487686
e32a170a-3c79-4470-8d57-f0695f93de67	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	584bab37-ccf2-484c-9a7f-7394e4b30ec6	71b851af-8542-47e4-9ff8-304ed5983a0b	e2cd4da6-f171-436c-9c7e-a9c1c5436b98	2025-10-06	\N	\N	1.75	training	f	f	150.00	262.50	\N	Subvenio adsuesco deprimo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-06 18:00:37.476	\N	2025-10-19 18:00:37.4916	2025-10-19 18:00:37.4916
cd1d1bbb-5cda-4af2-a340-baa37d568399	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	6a032ece-4f9e-405a-b48a-b28516d15fe1	1916b6af-0ab6-45d8-85ca-a9a6b331363c	ef53422c-1305-4831-bf41-d85b2a76b0d5	2025-10-06	\N	\N	1.00	meeting	f	f	120.00	120.00	\N	Cursus aureus audio ab vespillo subito maxime aestivus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-06 18:00:37.476	\N	2025-10-19 18:00:37.494978	2025-10-19 18:00:37.494978
c41d57f9-f7fb-4fcc-b167-003ae7946d0b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	17f141c2-e297-4c93-9178-0fd819259c50	a18510b4-73e3-40ff-84b1-89c4a2e0bdac	08ee5378-067c-4708-886c-34df4c200b23	2025-10-06	\N	\N	1.25	work	t	f	120.00	150.00	\N	Casus vigilo baiulus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-06 18:00:37.476	\N	2025-10-19 18:00:37.49809	2025-10-19 18:00:37.49809
f1a18cbb-906c-473f-b2a5-37e62dc03831	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	12edb785-268b-4219-840d-15b8f0df1198	f37ad203-1495-4aec-be30-1b2d7fe4dd70	3f2e9a8e-bdfe-4d09-aced-e88cdc710462	2025-10-06	\N	\N	1.25	research	t	t	120.00	150.00	\N	Earum vivo spes caelestis nemo impedit subiungo quibusdam.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-06 18:00:37.476	\N	2025-10-19 18:00:37.500664	2025-10-19 18:00:37.500664
b3ec3658-f9b0-4488-aafb-90c1885b2777	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	405d4d05-841b-437d-af7d-70b66dda4cbc	219aa257-710f-4ef2-892d-39086a9690ed	235b548d-f0a0-4899-9a7e-d6e9bec6db40	2025-10-06	\N	\N	3.75	work	t	f	120.00	450.00	\N	Auctor vindico abutor depraedor somniculosus vapulus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-06 18:00:37.476	\N	2025-10-19 18:00:37.503249	2025-10-19 18:00:37.503249
5f2a8f51-1af6-4625-b15d-f41c2c82ca0e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	6a032ece-4f9e-405a-b48a-b28516d15fe1	1916b6af-0ab6-45d8-85ca-a9a6b331363c	a0801828-5c53-41ef-9b3e-06db89d72e90	2025-10-06	\N	\N	3.75	training	t	f	110.00	412.50	\N	Abduco terror tui.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-06 18:00:37.476	\N	2025-10-19 18:00:37.506317	2025-10-19 18:00:37.506317
cd993b8f-1288-4d6b-85cb-1a417d701289	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	67f62599-7f9f-44e8-bc18-d2ce08ea9919	9ec151a2-b6a4-433d-a21e-c94af23b785b	9362cf11-827c-459a-8ffc-6634bd023508	2025-10-06	\N	\N	2.50	admin	f	t	110.00	275.00	\N	Sed tabula vito verus acies bestia.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-06 18:00:37.476	\N	2025-10-19 18:00:37.508453	2025-10-19 18:00:37.508453
cc9980d4-02a2-4813-af7c-d96156f83f73	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	6a032ece-4f9e-405a-b48a-b28516d15fe1	1916b6af-0ab6-45d8-85ca-a9a6b331363c	1ede1cc0-3627-404e-bb8a-487e028f4732	2025-10-06	\N	\N	2.00	admin	f	f	110.00	220.00	\N	Stipes audacia recusandae patrocinor.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-06 18:00:37.476	\N	2025-10-19 18:00:37.510975	2025-10-19 18:00:37.510975
33a1b2fa-1dff-4e0b-9f2f-02c23b9ba3cf	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	45b3d726-e151-4770-9b64-4653914bdaa5	be3f2d80-2e55-4bec-bd5e-02e5a00444a9	ff4a2600-29fe-4448-bec3-ea868988a9ed	2025-10-06	\N	\N	1.75	work	t	t	85.00	148.75	\N	Voluptates advenio molestiae aegre.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-06 18:00:37.476	\N	2025-10-19 18:00:37.513595	2025-10-19 18:00:37.513595
40f81565-404c-40e9-8401-929ff62d36ca	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	46859340-c8cf-4144-aa6c-28fbaf53fa0e	d486be12-5ed8-48b4-af34-79d9269f4c0b	a0801828-5c53-41ef-9b3e-06db89d72e90	2025-10-06	\N	\N	1.75	work	t	t	85.00	148.75	\N	Enim denego odio quo coaegresco civitas adinventitias nemo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-06 18:00:37.476	\N	2025-10-19 18:00:37.515808	2025-10-19 18:00:37.515808
9a37f65e-9db4-4353-96b1-5c20db50a194	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	088446c4-4542-4007-9887-b512bd3db05d	78882562-2120-44d2-9286-03e696abbf02	2025-10-06	\N	\N	3.50	meeting	t	t	85.00	297.50	\N	Tolero cribro pariatur.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-06 18:00:37.476	\N	2025-10-19 18:00:37.518325	2025-10-19 18:00:37.518325
2a09cf0d-89db-4325-86f4-e4b5f16a19a6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	5e2204cd-be52-42a7-aa41-14fcf0e4a272	79d01aa5-b680-4830-ab3a-5e3cb66edcfa	2025-10-06	\N	\N	0.75	admin	t	f	85.00	63.75	\N	Constans tempore adhaero cras alter sono vulticulus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-06 18:00:37.476	\N	2025-10-19 18:00:37.521375	2025-10-19 18:00:37.521375
86bffe17-76ad-4bd6-b097-4e54db2d83a6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	584bab37-ccf2-484c-9a7f-7394e4b30ec6	71b851af-8542-47e4-9ff8-304ed5983a0b	ef53422c-1305-4831-bf41-d85b2a76b0d5	2025-10-06	\N	\N	1.25	training	t	t	85.00	106.25	\N	Urbanus culpo theologus sufficio collum subvenio adeo tenuis.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-06 18:00:37.476	\N	2025-10-19 18:00:37.525248	2025-10-19 18:00:37.525248
337eac31-6d7a-44ae-b4ab-98f4cb30d8c9	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	07b65174-c767-4ace-ac22-e486eb422fa6	a96c9f4d-dc33-4af3-818d-8d729f0f8c1f	2025-10-07	\N	\N	1.50	research	t	f	150.00	225.00	\N	Thema utrum aufero apud dignissimos patrocinor crux arbor.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-07 18:00:37.527	\N	2025-10-19 18:00:37.529291	2025-10-19 18:00:37.529291
8340a9e2-ec27-4a17-9d77-e0478756e27b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	405d4d05-841b-437d-af7d-70b66dda4cbc	4f8e956e-3c05-4a0d-8695-2014ee9b2f8a	1ede1cc0-3627-404e-bb8a-487e028f4732	2025-10-07	\N	\N	2.00	meeting	t	f	150.00	300.00	\N	Demens cupio cruentus vestrum adstringo depopulo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-07 18:00:37.527	\N	2025-10-19 18:00:37.533295	2025-10-19 18:00:37.533295
191dcc8e-c14a-45d5-b588-44e06e4956b2	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	4554e09d-4391-42a8-a2cd-9702bce80511	ae73110f-e045-44ac-85ff-51aa2eb8ce69	08ee5378-067c-4708-886c-34df4c200b23	2025-10-07	\N	\N	1.75	training	t	f	150.00	262.50	\N	Vomer voluptates decor thesaurus tersus terreo condico aggredior coniecto.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-07 18:00:37.527	\N	2025-10-19 18:00:37.538	2025-10-19 18:00:37.538
64e5b448-b712-4ba3-8865-fcaf2c7d6f44	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	088446c4-4542-4007-9887-b512bd3db05d	a0801828-5c53-41ef-9b3e-06db89d72e90	2025-10-07	\N	\N	1.25	work	t	t	120.00	150.00	\N	Debitis sollers somniculosus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-07 18:00:37.527	\N	2025-10-19 18:00:37.541135	2025-10-19 18:00:37.541135
01a22e45-1be7-4ca5-bd0f-d7c601630578	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	7ef8af5a-1080-42a2-988f-ddfa799c8070	5cf17315-4658-4a7f-9c23-b4f8268d8f84	e2cd4da6-f171-436c-9c7e-a9c1c5436b98	2025-10-07	\N	\N	3.25	training	t	f	120.00	390.00	\N	Crebro cubo ademptio sollicito pariatur cuppedia sperno apostolus concido civitas.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-07 18:00:37.527	\N	2025-10-19 18:00:37.545871	2025-10-19 18:00:37.545871
5486c0b8-7990-4382-8727-00df57b35980	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	088446c4-4542-4007-9887-b512bd3db05d	e2cd4da6-f171-436c-9c7e-a9c1c5436b98	2025-10-07	\N	\N	1.50	meeting	t	f	120.00	180.00	\N	Virgo recusandae adiuvo comitatus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-07 18:00:37.527	\N	2025-10-19 18:00:37.548789	2025-10-19 18:00:37.548789
2d9987fb-f029-4f6c-88ae-2c52f4e72562	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	4554e09d-4391-42a8-a2cd-9702bce80511	ae73110f-e045-44ac-85ff-51aa2eb8ce69	a49c064a-0890-4c02-8734-07a3185e6c03	2025-10-07	\N	\N	0.75	admin	t	f	120.00	90.00	\N	Subiungo stipes subiungo antiquus neque benigne curto tego aveho.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-07 18:00:37.527	\N	2025-10-19 18:00:37.551771	2025-10-19 18:00:37.551771
5c1765e1-c609-4dd2-83d5-ce55990688e3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	584bab37-ccf2-484c-9a7f-7394e4b30ec6	674b7e91-de7b-4a7d-a519-8e8315afb5eb	391f7d87-df5d-4538-9b3e-31e07ac9347e	2025-10-07	\N	\N	1.75	admin	f	t	110.00	192.50	\N	Compono earum summisse dicta verbera tolero deprecator utor absque.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-07 18:00:37.527	\N	2025-10-19 18:00:37.554891	2025-10-19 18:00:37.554891
6d11b236-36e8-41a6-b70d-9dd3365c2999	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	98f9340d-eadb-45cd-bba2-115aa880f565	e2cd4da6-f171-436c-9c7e-a9c1c5436b98	2025-10-07	\N	\N	3.25	research	t	t	110.00	357.50	\N	Attonbitus quam angelus cado.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-07 18:00:37.527	\N	2025-10-19 18:00:37.557881	2025-10-19 18:00:37.557881
cab1836b-7ab5-43d2-9461-9169a3a7daed	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	702b5a48-f7a9-464c-8833-1ff6577e50e6	6ebdfde2-aeab-4596-9744-cef10c12a313	a49c064a-0890-4c02-8734-07a3185e6c03	2025-10-07	\N	\N	1.25	training	t	f	85.00	106.25	\N	Virga ratione aeternus qui tenetur exercitationem totidem adfectus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-07 18:00:37.527	\N	2025-10-19 18:00:37.561318	2025-10-19 18:00:37.561318
c48bfbf5-1bfe-4c39-be07-bcd2b269a9c2	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	eb1af1df-ce0a-4763-aaef-49b6b390beab	a96c9f4d-dc33-4af3-818d-8d729f0f8c1f	2025-10-07	\N	\N	1.25	research	t	f	85.00	106.25	\N	Arceo nihil crux vesco asperiores tamdiu abeo addo nisi sed.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-07 18:00:37.527	\N	2025-10-19 18:00:37.56458	2025-10-19 18:00:37.56458
dd36bb69-8071-4413-9b86-6458f1977b70	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	5515e216-ea3c-436b-95a5-6abf213c47ef	79d01aa5-b680-4830-ab3a-5e3cb66edcfa	2025-10-07	\N	\N	1.00	training	t	f	85.00	85.00	\N	Adflicto aegrotatio balbus vulpes doloribus aestas dolor territo eum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-07 18:00:37.527	\N	2025-10-19 18:00:37.568189	2025-10-19 18:00:37.568189
c20eb689-fbbf-4945-984e-5f263bf60ba1	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	2db210d6-c799-49db-b61d-9aff5f87f1f0	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	2025-10-07	\N	\N	2.00	training	t	t	85.00	170.00	\N	Libero utrimque at timidus catena teres.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-07 18:00:37.527	\N	2025-10-19 18:00:37.570606	2025-10-19 18:00:37.570606
c7009e18-fe56-4062-b190-9d9ee06fedb1	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	12edb785-268b-4219-840d-15b8f0df1198	f37ad203-1495-4aec-be30-1b2d7fe4dd70	ef53422c-1305-4831-bf41-d85b2a76b0d5	2025-10-08	\N	\N	2.75	research	f	f	150.00	412.50	\N	Vulgus causa tendo carpo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-08 18:00:37.572	\N	2025-10-19 18:00:37.573072	2025-10-19 18:00:37.573072
c6495711-3242-439f-bc22-bd11212026c1	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	12edb785-268b-4219-840d-15b8f0df1198	e171fa0b-3143-48ec-962f-0917bf1886bf	e4487405-7859-40e9-8008-056d32fe6f10	2025-10-08	\N	\N	2.00	meeting	t	t	150.00	300.00	\N	Utrimque copiose amor aveho cohors unus virga adipisci atque decipio.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-08 18:00:37.572	\N	2025-10-19 18:00:37.576131	2025-10-19 18:00:37.576131
c28f7709-b786-4ecb-9f68-4ed5707e1ad6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	584bab37-ccf2-484c-9a7f-7394e4b30ec6	71b851af-8542-47e4-9ff8-304ed5983a0b	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	2025-10-08	\N	\N	4.00	research	t	t	120.00	480.00	\N	Via ancilla aeternus bibo vitae carmen.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-08 18:00:37.572	\N	2025-10-19 18:00:37.579396	2025-10-19 18:00:37.579396
fd22c818-2ade-4db3-8725-3d9c0ccacf51	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	4554e09d-4391-42a8-a2cd-9702bce80511	ae73110f-e045-44ac-85ff-51aa2eb8ce69	78882562-2120-44d2-9286-03e696abbf02	2025-10-08	\N	\N	2.50	admin	t	f	120.00	300.00	\N	Nihil ventito spectaculum tum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-08 18:00:37.572	\N	2025-10-19 18:00:37.581878	2025-10-19 18:00:37.581878
ed9160d7-0c82-483e-89e1-463d8610217f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	46859340-c8cf-4144-aa6c-28fbaf53fa0e	d486be12-5ed8-48b4-af34-79d9269f4c0b	18c91d63-8f9d-4974-ba97-a4079c7457d5	2025-10-08	\N	\N	0.50	research	t	f	120.00	60.00	\N	Temporibus cognomen torrens adfero thesaurus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-08 18:00:37.572	\N	2025-10-19 18:00:37.584072	2025-10-19 18:00:37.584072
e1645a7c-755e-4be5-9028-ad21863f8d09	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	405d4d05-841b-437d-af7d-70b66dda4cbc	9485b00c-4fc8-454f-984a-6908039db9f9	9362cf11-827c-459a-8ffc-6634bd023508	2025-10-08	\N	\N	1.00	meeting	f	t	120.00	120.00	\N	Abutor versus usitas accommodo defessus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-08 18:00:37.572	\N	2025-10-19 18:00:37.58736	2025-10-19 18:00:37.58736
ffcbe867-dd53-47c5-bd2c-21a15cb5dfbe	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	b0a95e11-90ac-4ab3-b099-c4de69f498b8	8c94ef1c-f972-45ba-9aaa-1fa78ab3fc92	79d01aa5-b680-4830-ab3a-5e3cb66edcfa	2025-10-08	\N	\N	4.00	research	t	t	110.00	440.00	\N	Abundans valeo deduco summa delectus fugit surculus infit urbs.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-08 18:00:37.572	\N	2025-10-19 18:00:37.590464	2025-10-19 18:00:37.590464
a0e318a4-2b44-4233-8431-56a47f19bf03	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	a4464f5a-2125-46d9-9f58-7252c9adc16b	a08b1624-6e7a-4a25-8f08-3b9b00adb6a0	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	2025-10-08	\N	\N	2.75	training	f	t	110.00	302.50	\N	Copiose dens pecto solutio sponte decipio.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-08 18:00:37.572	\N	2025-10-19 18:00:37.593394	2025-10-19 18:00:37.593394
013d88ff-2c7b-4806-bf89-c7664f125d93	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	b0a95e11-90ac-4ab3-b099-c4de69f498b8	8c94ef1c-f972-45ba-9aaa-1fa78ab3fc92	3f2e9a8e-bdfe-4d09-aced-e88cdc710462	2025-10-08	\N	\N	2.25	admin	t	f	110.00	247.50	\N	Verbera constans advoco complectus debitis adnuo vos absorbeo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-08 18:00:37.572	\N	2025-10-19 18:00:37.596862	2025-10-19 18:00:37.596862
3845d2b7-8070-4e8f-b7c0-134738d5bdce	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	67f62599-7f9f-44e8-bc18-d2ce08ea9919	9ec151a2-b6a4-433d-a21e-c94af23b785b	ef53422c-1305-4831-bf41-d85b2a76b0d5	2025-10-08	\N	\N	3.25	research	t	t	110.00	357.50	\N	Conicio tempore claro tamen amissio deleo deleniti conscendo celo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-08 18:00:37.572	\N	2025-10-19 18:00:37.601138	2025-10-19 18:00:37.601138
79019d98-7e8c-494e-af37-9ab0a7c99fe4	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	46859340-c8cf-4144-aa6c-28fbaf53fa0e	f9444b08-3c00-4407-98d8-3d654600142c	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-10-08	\N	\N	2.25	admin	t	f	85.00	191.25	\N	Ager alo amicitia truculenter delibero calamitas aranea.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-08 18:00:37.572	\N	2025-10-19 18:00:37.606322	2025-10-19 18:00:37.606322
93c2a0b6-6810-41ba-88d8-ccb98b2152a9	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	67f62599-7f9f-44e8-bc18-d2ce08ea9919	8c04c9d5-2992-4108-bc71-d0210b7972e2	109283c7-55ef-4e05-bf53-c6efd1be486f	2025-10-08	\N	\N	2.00	meeting	t	t	85.00	170.00	\N	Veritas unde uterque tamdiu victoria quisquam laboriosam triduana voco sophismata.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-08 18:00:37.572	\N	2025-10-19 18:00:37.60978	2025-10-19 18:00:37.60978
fb18cc94-8391-4064-9859-f4583692ab85	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	d69d0436-37d7-42a4-b907-3d9c3a091ea6	fe24fe87-1db5-4f06-9a5c-46757a20518d	ecfd2c2c-905b-4ef4-99a4-8949632b9ae9	2025-10-08	\N	\N	2.00	work	t	f	85.00	170.00	\N	Tredecim bene cruentus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-08 18:00:37.572	\N	2025-10-19 18:00:37.613279	2025-10-19 18:00:37.613279
0673be2a-c81a-46fa-8168-e99cf4e80729	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	7ef8af5a-1080-42a2-988f-ddfa799c8070	1c9d17d2-a153-4f42-9604-129a162a1f0f	1ede1cc0-3627-404e-bb8a-487e028f4732	2025-10-09	\N	\N	3.00	training	t	t	150.00	450.00	\N	Conitor admoneo una ago alioqui advoco modi.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-09 18:00:37.615	\N	2025-10-19 18:00:37.617297	2025-10-19 18:00:37.617297
40a409a3-c12a-4ec5-acca-deaa00467f55	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	b7295600-5c20-4de2-8782-af87987c2bee	d2f831e1-38ca-429c-9942-06db88f8dfc5	ff4a2600-29fe-4448-bec3-ea868988a9ed	2025-10-09	\N	\N	2.25	training	t	f	150.00	337.50	\N	Cras repudiandae considero pauper.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-09 18:00:37.615	\N	2025-10-19 18:00:37.620526	2025-10-19 18:00:37.620526
15fcf5f2-3faf-4cbe-8149-b12ff80c64fd	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	584bab37-ccf2-484c-9a7f-7394e4b30ec6	7a582f98-6d3d-44d5-9796-ba1d12c49f62	cbf9b499-276b-4a28-999c-27388562c4f4	2025-10-09	\N	\N	2.50	research	t	f	150.00	375.00	\N	Aranea thymum tot aliquam tabella cernuus viduo adfero damnatio autus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-09 18:00:37.615	\N	2025-10-19 18:00:37.622991	2025-10-19 18:00:37.622991
cc9ba664-9b88-44c8-974f-fb1b506a7e93	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	d8601cb6-589f-456f-a2b2-1b986973a4bc	08ee5378-067c-4708-886c-34df4c200b23	2025-10-09	\N	\N	0.50	meeting	t	t	150.00	75.00	\N	Summopere absorbeo urbanus suffragium territo volo thalassinus paens arcus vestrum.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-09 18:00:37.615	\N	2025-10-19 18:00:37.625402	2025-10-19 18:00:37.625402
220edc45-ebb3-4b46-ad27-34183c51b9e4	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	96a103f5-bc5b-43e1-b321-62fedda6eaa1	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-10-09	\N	\N	1.50	research	f	f	150.00	225.00	\N	Aveho arto repudiandae.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-09 18:00:37.615	\N	2025-10-19 18:00:37.629382	2025-10-19 18:00:37.629382
21dd910e-3cdb-416c-90e8-8247d1faf659	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	65a6152e-a261-4a70-99fb-82f044e87d05	b7a77905-edd5-451e-a92e-06976feeb638	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	2025-10-09	\N	\N	2.25	training	t	f	120.00	270.00	\N	Ceno vicissitudo aptus copia calamitas beatae tonsor crastinus casso cohaero.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-09 18:00:37.615	\N	2025-10-19 18:00:37.632887	2025-10-19 18:00:37.632887
c29d4627-11f0-4623-9a2d-9e7a5142ef23	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	a4464f5a-2125-46d9-9f58-7252c9adc16b	b09b8a10-2b29-4fa3-b57f-c69d46364489	ff4a2600-29fe-4448-bec3-ea868988a9ed	2025-10-09	\N	\N	3.75	research	t	f	120.00	450.00	\N	Vado cupressus nobis benevolentia.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-09 18:00:37.615	\N	2025-10-19 18:00:37.636688	2025-10-19 18:00:37.636688
6f4c4971-0096-41cc-aa7b-4e49469959ee	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	0d0329f4-4b80-4899-8807-5854e9db312b	40ca5c4e-33d7-432f-a55c-b59c3010d7ef	08ee5378-067c-4708-886c-34df4c200b23	2025-10-09	\N	\N	0.75	admin	t	t	110.00	82.50	\N	Super argentum cunctatio bibo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-09 18:00:37.615	\N	2025-10-19 18:00:37.639883	2025-10-19 18:00:37.639883
8c4c40f4-7693-49bc-806a-5121b585f341	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	98f9340d-eadb-45cd-bba2-115aa880f565	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-10-09	\N	\N	1.50	research	t	f	110.00	165.00	\N	Eveniet attero occaecati tamquam tabernus spiculum cenaculum charisma.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-09 18:00:37.615	\N	2025-10-19 18:00:37.642789	2025-10-19 18:00:37.642789
2c196fa4-a9cf-49c7-9843-b52b0568f318	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	2db210d6-c799-49db-b61d-9aff5f87f1f0	9362cf11-827c-459a-8ffc-6634bd023508	2025-10-09	\N	\N	2.50	work	t	f	110.00	275.00	\N	Animi credo libero amiculum aggero adhuc doloribus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-09 18:00:37.615	\N	2025-10-19 18:00:37.645759	2025-10-19 18:00:37.645759
21666e2a-ff8b-4673-8a4a-50dfd3ae9822	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	6a032ece-4f9e-405a-b48a-b28516d15fe1	062f6587-cb37-4a01-aa03-004703abe1e2	29a61f52-d957-4207-b54b-7fc565a57541	2025-10-09	\N	\N	2.00	work	f	t	110.00	220.00	\N	Nam uredo ventus sono utrimque sperno decet assumenda.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-09 18:00:37.615	\N	2025-10-19 18:00:37.648751	2025-10-19 18:00:37.648751
264c9903-5de1-4938-a9c1-26963e73f5ea	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	8538cc30-f9e7-4b63-a885-56b23e16ecef	b3d1095b-3d51-444b-be35-f485afdb174f	ecfd2c2c-905b-4ef4-99a4-8949632b9ae9	2025-10-09	\N	\N	0.75	admin	t	t	85.00	63.75	\N	Clibanus averto ipsam vox.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-09 18:00:37.615	\N	2025-10-19 18:00:37.651448	2025-10-19 18:00:37.651448
e3b5ffa2-6f85-4a8d-b5ad-fbe65e9f43c8	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	04600664-34f3-4ae0-9a01-2da04b5bc5fc	ef53422c-1305-4831-bf41-d85b2a76b0d5	2025-10-09	\N	\N	1.25	admin	t	f	85.00	106.25	\N	Ullus eligendi nemo minima adimpleo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-09 18:00:37.615	\N	2025-10-19 18:00:37.654493	2025-10-19 18:00:37.654493
d2c2eeb9-ffd6-408c-bba7-d497a1d2cdce	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	eb1af1df-ce0a-4763-aaef-49b6b390beab	ecfd2c2c-905b-4ef4-99a4-8949632b9ae9	2025-10-09	\N	\N	2.00	admin	t	f	85.00	170.00	\N	Universe claudeo speciosus tollo alioqui validus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-09 18:00:37.615	\N	2025-10-19 18:00:37.657632	2025-10-19 18:00:37.657632
ccd97636-e3d7-44ca-805b-d60e1625ad48	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	6a032ece-4f9e-405a-b48a-b28516d15fe1	43f46d13-e4e7-4e0f-a62d-25d47b569d15	d6d7e47b-cd48-48d8-a45a-fa75af1f9a52	2025-10-09	\N	\N	0.50	admin	t	f	85.00	42.50	\N	Solvo defetiscor adfero at cumque teres.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-09 18:00:37.615	\N	2025-10-19 18:00:37.660765	2025-10-19 18:00:37.660765
f9e5a9da-a157-4a43-99ab-f971536db6e8	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	45b3d726-e151-4770-9b64-4653914bdaa5	449f8e23-33a0-4bf0-915e-cc79d13bc3a9	9362cf11-827c-459a-8ffc-6634bd023508	2025-10-10	\N	\N	1.75	meeting	t	t	150.00	262.50	\N	Denique ascit abduco subseco crudelis animadverto.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-10 18:00:37.662	\N	2025-10-19 18:00:37.664512	2025-10-19 18:00:37.664512
06ebbeb4-936e-497c-800c-9fc74929fb9a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	6ecda653-6094-4502-9d1d-6e90d9ea99ed	4fb9cb0a-ca36-4af7-9203-ac1970ce555b	e2cd4da6-f171-436c-9c7e-a9c1c5436b98	2025-10-10	\N	\N	4.00	research	t	f	150.00	600.00	\N	Clarus beatae aspicio auditor.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-10 18:00:37.662	\N	2025-10-19 18:00:37.669665	2025-10-19 18:00:37.669665
8837ff51-fbc6-4ab2-b21f-35d51d5ba636	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	b0a95e11-90ac-4ab3-b099-c4de69f498b8	8c94ef1c-f972-45ba-9aaa-1fa78ab3fc92	d04961e2-5af7-4b9c-bb44-c37031dd6bfa	2025-10-10	\N	\N	1.25	meeting	t	f	150.00	187.50	\N	Vestrum solio vetus valetudo congregatio velociter vergo.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-10 18:00:37.662	\N	2025-10-19 18:00:37.674813	2025-10-19 18:00:37.674813
5bec4dfc-731a-4f8e-aeeb-f8463b1c7892	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	46859340-c8cf-4144-aa6c-28fbaf53fa0e	d486be12-5ed8-48b4-af34-79d9269f4c0b	ef53422c-1305-4831-bf41-d85b2a76b0d5	2025-10-10	\N	\N	2.75	meeting	t	t	150.00	412.50	\N	Altus spero vilitas paens cubo clam arceo tamisium quia.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-10 18:00:37.662	\N	2025-10-19 18:00:37.67977	2025-10-19 18:00:37.67977
2023190a-7fae-4c3b-8dee-2352854bf476	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	0d0329f4-4b80-4899-8807-5854e9db312b	e60c944c-85a6-45da-b007-56b5244e0257	08ee5378-067c-4708-886c-34df4c200b23	2025-10-10	\N	\N	2.00	admin	f	f	120.00	240.00	\N	Tenax saepe attero vicinus ventosus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-10 18:00:37.662	\N	2025-10-19 18:00:37.684992	2025-10-19 18:00:37.684992
fb888477-84f9-4a36-946c-43260b825840	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	d69d0436-37d7-42a4-b907-3d9c3a091ea6	20222077-caa4-4444-b803-1f75d617ee85	79d01aa5-b680-4830-ab3a-5e3cb66edcfa	2025-10-10	\N	\N	4.00	training	t	f	120.00	480.00	\N	Surculus tubineus adduco rerum tracto ad denique optio thema.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-10 18:00:37.662	\N	2025-10-19 18:00:37.688913	2025-10-19 18:00:37.688913
8690b62b-cb0b-42a3-94f3-c9e651a86d77	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	67f62599-7f9f-44e8-bc18-d2ce08ea9919	419cb8f8-8b70-44a5-883b-8fa92787aa46	996aa78c-cfd1-477f-8c30-d9489225b29e	2025-10-10	\N	\N	1.00	research	t	t	120.00	120.00	\N	Conqueror vilis vomito nihil.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-10 18:00:37.662	\N	2025-10-19 18:00:37.692189	2025-10-19 18:00:37.692189
82f6c146-7c29-4b4b-bc26-6a3328c9e801	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	45b3d726-e151-4770-9b64-4653914bdaa5	be3f2d80-2e55-4bec-bd5e-02e5a00444a9	ef53422c-1305-4831-bf41-d85b2a76b0d5	2025-10-10	\N	\N	3.50	research	t	t	110.00	385.00	\N	Cinis conservo a audentia coadunatio unus cultellus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-10 18:00:37.662	\N	2025-10-19 18:00:37.695036	2025-10-19 18:00:37.695036
d6d858f4-61a6-4f56-a5dc-8a8f5039ecbc	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	6ecda653-6094-4502-9d1d-6e90d9ea99ed	4fb9cb0a-ca36-4af7-9203-ac1970ce555b	a96c9f4d-dc33-4af3-818d-8d729f0f8c1f	2025-10-10	\N	\N	1.00	meeting	t	f	110.00	110.00	\N	Vespillo quidem terebro viscus contabesco adopto delinquo strenuus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-10 18:00:37.662	\N	2025-10-19 18:00:37.697641	2025-10-19 18:00:37.697641
4ca6077d-2f2f-4c66-919c-13a97033e5cb	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	5515e216-ea3c-436b-95a5-6abf213c47ef	391f7d87-df5d-4538-9b3e-31e07ac9347e	2025-10-10	\N	\N	0.75	admin	t	f	85.00	63.75	\N	Sonitus calamitas omnis utilis comis aeneus callide.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-10 18:00:37.662	\N	2025-10-19 18:00:37.703393	2025-10-19 18:00:37.703393
0c292511-5f4a-4315-9dec-f618a1ca9bf4	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	8538cc30-f9e7-4b63-a885-56b23e16ecef	b3d1095b-3d51-444b-be35-f485afdb174f	d04961e2-5af7-4b9c-bb44-c37031dd6bfa	2025-10-10	\N	\N	2.00	meeting	f	f	85.00	170.00	\N	Vesper paens super bis vacuus deleniti suscipit.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-10 18:00:37.662	\N	2025-10-19 18:00:37.70684	2025-10-19 18:00:37.70684
79701f3e-20a1-4f5b-8372-8559a0611a94	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	04465623-29cb-4298-8828-d1839e9cc00d	e4ce7abb-fb0c-42e1-a7c1-6419b4aa63ef	109283c7-55ef-4e05-bf53-c6efd1be486f	2025-10-10	\N	\N	1.25	work	t	t	85.00	106.25	\N	Vel sono aestivus varius soleo uredo thymbra cattus.	\N	approved	\N	a2adaa31-8f59-409a-b39b-72568022adb4	2025-10-10 18:00:37.662	\N	2025-10-19 18:00:37.709193	2025-10-19 18:00:37.709193
aa5a6d63-28cf-4155-a18b-a26666c39491	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	17f141c2-e297-4c93-9178-0fd819259c50	af41070b-ce93-4cf4-88f6-19ed28a1f1fe	ecfd2c2c-905b-4ef4-99a4-8949632b9ae9	2025-10-13	\N	\N	3.75	work	f	f	150.00	562.50	\N	Tricesimus accendo sufficio spero denuo adinventitias vereor asporto caterva.	\N	submitted	\N	\N	\N	\N	2025-10-19 18:00:37.711012	2025-10-19 18:00:37.711012
b5080d52-7ef0-47c7-afcc-89235bc5b5e7	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	67f62599-7f9f-44e8-bc18-d2ce08ea9919	9ec151a2-b6a4-433d-a21e-c94af23b785b	ef53422c-1305-4831-bf41-d85b2a76b0d5	2025-10-13	\N	\N	2.25	admin	t	f	150.00	337.50	\N	Arguo vulticulus ager adaugeo.	\N	rejected	\N	\N	\N	\N	2025-10-19 18:00:37.712705	2025-10-19 18:00:37.712705
b1d06545-3055-49db-98ed-92bf3aeee3f3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	7ef8af5a-1080-42a2-988f-ddfa799c8070	1c9d17d2-a153-4f42-9604-129a162a1f0f	e4487405-7859-40e9-8008-056d32fe6f10	2025-10-13	\N	\N	2.00	meeting	t	t	120.00	240.00	\N	Compello titulus caste crur sufficio alter cariosus utroque suadeo tollo.	\N	rejected	\N	\N	\N	\N	2025-10-19 18:00:37.714504	2025-10-19 18:00:37.714504
ef7ece4a-cc55-45bb-81d1-fb99e6396f65	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	7ef8af5a-1080-42a2-988f-ddfa799c8070	1c9d17d2-a153-4f42-9604-129a162a1f0f	391f7d87-df5d-4538-9b3e-31e07ac9347e	2025-10-13	\N	\N	1.75	research	t	t	120.00	210.00	\N	Turba vomica cauda tot compello caute aetas.	\N	draft	\N	\N	\N	\N	2025-10-19 18:00:37.716644	2025-10-19 18:00:37.716644
f84b3f12-b416-4827-9d4c-00c47704d3ff	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	12edb785-268b-4219-840d-15b8f0df1198	e171fa0b-3143-48ec-962f-0917bf1886bf	08ee5378-067c-4708-886c-34df4c200b23	2025-10-13	\N	\N	1.25	research	t	f	120.00	150.00	\N	Vicinus saepe iusto vereor adnuo cornu confugo.	\N	rejected	\N	\N	\N	\N	2025-10-19 18:00:37.718881	2025-10-19 18:00:37.718881
77e4cef6-f87a-4376-8f27-9a61c285803d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	0d0329f4-4b80-4899-8807-5854e9db312b	e60c944c-85a6-45da-b007-56b5244e0257	a96c9f4d-dc33-4af3-818d-8d729f0f8c1f	2025-10-13	\N	\N	0.75	admin	t	t	110.00	82.50	\N	Summisse assumenda pel tabesco argumentum defungo thesis.	\N	submitted	\N	\N	\N	\N	2025-10-19 18:00:37.722187	2025-10-19 18:00:37.722187
49dfdc11-8474-4e68-945e-188a5457cb35	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	088446c4-4542-4007-9887-b512bd3db05d	391f7d87-df5d-4538-9b3e-31e07ac9347e	2025-10-13	\N	\N	2.00	training	t	t	110.00	220.00	\N	Agnitio defetiscor testimonium umerus minima patruus antepono ascisco.	\N	rejected	\N	\N	\N	\N	2025-10-19 18:00:37.724756	2025-10-19 18:00:37.724756
80fa3f2d-db4d-4a48-9a91-d97940ae4583	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	d69d0436-37d7-42a4-b907-3d9c3a091ea6	20222077-caa4-4444-b803-1f75d617ee85	18c91d63-8f9d-4974-ba97-a4079c7457d5	2025-10-13	\N	\N	1.75	training	t	t	110.00	192.50	\N	Accendo abduco contra.	\N	rejected	\N	\N	\N	\N	2025-10-19 18:00:37.727117	2025-10-19 18:00:37.727117
5a71b24c-ef78-49eb-bd9d-dd76bb56bb79	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	5e2204cd-be52-42a7-aa41-14fcf0e4a272	08ee5378-067c-4708-886c-34df4c200b23	2025-10-13	\N	\N	0.50	training	t	f	110.00	55.00	\N	Curvo virgo circumvenio condico verto deorsum hic volaticus bardus.	\N	draft	\N	\N	\N	\N	2025-10-19 18:00:37.729372	2025-10-19 18:00:37.729372
5dabac23-9f00-45b7-a343-b8fa1d1af6e9	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	6a032ece-4f9e-405a-b48a-b28516d15fe1	1916b6af-0ab6-45d8-85ca-a9a6b331363c	391f7d87-df5d-4538-9b3e-31e07ac9347e	2025-10-13	\N	\N	1.25	meeting	f	f	110.00	137.50	\N	Condico demitto suadeo terra contigo cervus carcer.	\N	submitted	\N	\N	\N	\N	2025-10-19 18:00:37.731851	2025-10-19 18:00:37.731851
23734a5a-91c9-44a4-81f1-7e5042da4406	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	6a032ece-4f9e-405a-b48a-b28516d15fe1	4d9083ba-923c-467a-8bdb-8b651cd6d7d7	79d01aa5-b680-4830-ab3a-5e3cb66edcfa	2025-10-13	\N	\N	0.75	meeting	f	t	85.00	63.75	\N	Vinum tribuo vita deprimo viriliter.	\N	draft	\N	\N	\N	\N	2025-10-19 18:00:37.734196	2025-10-19 18:00:37.734196
d9ed4d84-5fd0-451a-a755-5206ac47ae5e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	65a6152e-a261-4a70-99fb-82f044e87d05	b7a77905-edd5-451e-a92e-06976feeb638	996aa78c-cfd1-477f-8c30-d9489225b29e	2025-10-13	\N	\N	4.00	research	t	f	85.00	340.00	\N	Dedecor chirographum omnis cilicium caelestis.	\N	draft	\N	\N	\N	\N	2025-10-19 18:00:37.736437	2025-10-19 18:00:37.736437
0e846b7c-438a-4be8-afd2-d520fa0c5eac	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	67f62599-7f9f-44e8-bc18-d2ce08ea9919	ed074125-f8db-4b46-af39-96ce8eb67c4b	996aa78c-cfd1-477f-8c30-d9489225b29e	2025-10-13	\N	\N	3.50	meeting	t	f	85.00	297.50	\N	Facilis vicissitudo sopor dolorem.	\N	submitted	\N	\N	\N	\N	2025-10-19 18:00:37.738609	2025-10-19 18:00:37.738609
4cd15602-00b7-4bd0-9976-8c0bd950c1f8	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	12edb785-268b-4219-840d-15b8f0df1198	e171fa0b-3143-48ec-962f-0917bf1886bf	cbf383a1-3a73-4bdb-a85b-9a084b64b6ed	2025-10-14	\N	\N	3.75	meeting	t	t	150.00	562.50	\N	Abscido ipsa crudelis una.	\N	submitted	\N	\N	\N	\N	2025-10-19 18:00:37.740589	2025-10-19 18:00:37.740589
00601e8c-fa2f-489c-8c25-8de479d8c459	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	67f62599-7f9f-44e8-bc18-d2ce08ea9919	8c04c9d5-2992-4108-bc71-d0210b7972e2	e4487405-7859-40e9-8008-056d32fe6f10	2025-10-14	\N	\N	1.25	meeting	t	f	150.00	187.50	\N	Deporto textilis caecus via.	\N	approved	\N	\N	\N	\N	2025-10-19 18:00:37.742368	2025-10-19 18:00:37.742368
a04905e2-cb95-4269-9fd9-20466bd358b1	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	a4464f5a-2125-46d9-9f58-7252c9adc16b	a08b1624-6e7a-4a25-8f08-3b9b00adb6a0	996aa78c-cfd1-477f-8c30-d9489225b29e	2025-10-14	\N	\N	1.00	admin	t	f	150.00	150.00	\N	Ulciscor desparatus accusator sumptus cumque despecto facilis.	\N	draft	\N	\N	\N	\N	2025-10-19 18:00:37.744085	2025-10-19 18:00:37.744085
4efbe082-d075-4de5-a4eb-a40d8a267b00	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	65a6152e-a261-4a70-99fb-82f044e87d05	b7a77905-edd5-451e-a92e-06976feeb638	79d01aa5-b680-4830-ab3a-5e3cb66edcfa	2025-10-14	\N	\N	3.50	work	t	f	150.00	525.00	\N	Abeo pecto beatus cras arcesso candidus.	\N	approved	\N	\N	\N	\N	2025-10-19 18:00:37.746147	2025-10-19 18:00:37.746147
d064bc8b-fb5c-4c47-bc88-6017e00eee06	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	5e2204cd-be52-42a7-aa41-14fcf0e4a272	a96c9f4d-dc33-4af3-818d-8d729f0f8c1f	2025-10-14	\N	\N	1.75	admin	t	f	120.00	210.00	\N	Cohaero quas canonicus cunctatio tricesimus arbor cavus utrum.	\N	draft	\N	\N	\N	\N	2025-10-19 18:00:37.747927	2025-10-19 18:00:37.747927
e63ca150-f010-442f-ab22-938e42dc254d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	a4464f5a-2125-46d9-9f58-7252c9adc16b	49ae64ac-de52-4d18-a5d6-d73c5d5605c5	a0801828-5c53-41ef-9b3e-06db89d72e90	2025-10-14	\N	\N	2.50	work	t	f	120.00	300.00	\N	Cedo barba spoliatio aeneus corporis coniecto auxilium.	\N	draft	\N	\N	\N	\N	2025-10-19 18:00:37.749627	2025-10-19 18:00:37.749627
5ad6951b-a474-4817-98e1-ba48db164c0a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	b7295600-5c20-4de2-8782-af87987c2bee	2849d1a9-72a4-4287-8114-b604140c71aa	79d01aa5-b680-4830-ab3a-5e3cb66edcfa	2025-10-14	\N	\N	2.00	work	f	t	110.00	220.00	\N	Creber arto voco animus deleniti valetudo viriliter xiphias commodi.	\N	submitted	\N	\N	\N	\N	2025-10-19 18:00:37.751295	2025-10-19 18:00:37.751295
3286cd62-91de-486e-985a-2d460bd4d80f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	46859340-c8cf-4144-aa6c-28fbaf53fa0e	f9444b08-3c00-4407-98d8-3d654600142c	a0801828-5c53-41ef-9b3e-06db89d72e90	2025-10-14	\N	\N	1.75	admin	t	t	110.00	192.50	\N	Video conatus eaque auxilium nemo reprehenderit turba adduco custodia.	\N	approved	\N	\N	\N	\N	2025-10-19 18:00:37.753033	2025-10-19 18:00:37.753033
1f82772b-c0ce-4424-b7bd-0668a88051db	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	dc9252b7-2022-4822-a8b2-7ec227fe0ea4	9362cf11-827c-459a-8ffc-6634bd023508	2025-10-14	\N	\N	3.75	meeting	t	f	110.00	412.50	\N	Ulterius capitulus caveo atrocitas carbo.	\N	rejected	\N	\N	\N	\N	2025-10-19 18:00:37.754582	2025-10-19 18:00:37.754582
f849e440-005d-46a0-bf1f-ac1f69a50eb6	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	5e2204cd-be52-42a7-aa41-14fcf0e4a272	08ee5378-067c-4708-886c-34df4c200b23	2025-10-14	\N	\N	3.50	research	f	f	110.00	385.00	\N	Voveo curtus sodalitas verbera textilis aeternus crebro argumentum abstergo toties.	\N	submitted	\N	\N	\N	\N	2025-10-19 18:00:37.756072	2025-10-19 18:00:37.756072
d23d181a-0e1f-4f04-96c9-a6e3c8394c2b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	17f141c2-e297-4c93-9178-0fd819259c50	c7111387-5606-4d4b-88de-270766225b61	78882562-2120-44d2-9286-03e696abbf02	2025-10-14	\N	\N	3.75	research	t	f	110.00	412.50	\N	Derelinquo maiores sopor vero tersus.	\N	draft	\N	\N	\N	\N	2025-10-19 18:00:37.758571	2025-10-19 18:00:37.758571
b84ebc93-3427-4aaa-8c11-4387f7c81a9b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	04465623-29cb-4298-8828-d1839e9cc00d	e4ce7abb-fb0c-42e1-a7c1-6419b4aa63ef	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	2025-10-14	\N	\N	1.75	work	f	t	85.00	148.75	\N	Ubi titulus aurum terga clamo.	\N	draft	\N	\N	\N	\N	2025-10-19 18:00:37.761981	2025-10-19 18:00:37.761981
9f9d07c1-3e08-4b11-b4c7-55371dec7e19	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	b7295600-5c20-4de2-8782-af87987c2bee	196a1b4b-9367-4b9f-baf6-717d312881a3	a8a65b80-dc4c-49f9-9c8d-0dc4a336cf55	2025-10-14	\N	\N	1.25	research	t	t	85.00	106.25	\N	Modi alii venio audax combibo cognomen causa calamitas.	\N	rejected	\N	\N	\N	\N	2025-10-19 18:00:37.765653	2025-10-19 18:00:37.765653
21bca5b5-b62a-4c0e-8dad-baa23472576f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	b0a95e11-90ac-4ab3-b099-c4de69f498b8	269dca40-b352-4a09-9d7c-c735016a8c7d	18c91d63-8f9d-4974-ba97-a4079c7457d5	2025-10-14	\N	\N	1.25	admin	t	t	85.00	106.25	\N	Curia terga defero compono tergeo administratio voluptas curiositas audax magnam.	\N	draft	\N	\N	\N	\N	2025-10-19 18:00:37.769802	2025-10-19 18:00:37.769802
067bb2d4-5967-42a2-81e3-52519a730b95	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	6a032ece-4f9e-405a-b48a-b28516d15fe1	1916b6af-0ab6-45d8-85ca-a9a6b331363c	9362cf11-827c-459a-8ffc-6634bd023508	2025-10-15	\N	\N	0.75	meeting	f	f	150.00	112.50	\N	Aliqua umquam vir defaeco.	\N	approved	\N	\N	\N	\N	2025-10-19 18:00:37.772967	2025-10-19 18:00:37.772967
c41d08dc-b953-41c0-97f0-8dff215c7537	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	67f62599-7f9f-44e8-bc18-d2ce08ea9919	419cb8f8-8b70-44a5-883b-8fa92787aa46	9362cf11-827c-459a-8ffc-6634bd023508	2025-10-15	\N	\N	0.50	admin	t	t	150.00	75.00	\N	Capto verto unus nemo admoneo dedico vero vulgus.	\N	rejected	\N	\N	\N	\N	2025-10-19 18:00:37.77679	2025-10-19 18:00:37.77679
123abcc6-7664-4a05-bede-111ec557eb37	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	17f141c2-e297-4c93-9178-0fd819259c50	c7111387-5606-4d4b-88de-270766225b61	29a61f52-d957-4207-b54b-7fc565a57541	2025-10-15	\N	\N	3.25	admin	t	f	150.00	487.50	\N	Agnosco umbra curis perspiciatis ambitus sui vicissitudo.	\N	draft	\N	\N	\N	\N	2025-10-19 18:00:37.782374	2025-10-19 18:00:37.782374
01c15caa-48bd-430e-8eee-a74d87bd18a8	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	6a032ece-4f9e-405a-b48a-b28516d15fe1	062f6587-cb37-4a01-aa03-004703abe1e2	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-10-15	\N	\N	3.75	work	t	f	120.00	450.00	\N	At balbus temporibus earum amita appono sollicito beatae ustulo talio.	\N	approved	\N	\N	\N	\N	2025-10-19 18:00:37.787355	2025-10-19 18:00:37.787355
e9d77a87-93fc-4f24-b8fe-66dc24686af4	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	65a6152e-a261-4a70-99fb-82f044e87d05	b98cb032-3f5a-46db-ab39-de7d53570ae9	a49c064a-0890-4c02-8734-07a3185e6c03	2025-10-15	\N	\N	0.50	work	t	f	120.00	60.00	\N	Solus thesis speciosus labore.	\N	draft	\N	\N	\N	\N	2025-10-19 18:00:37.790501	2025-10-19 18:00:37.790501
ca637c1f-d1b0-4dff-84bf-a1693ce544bc	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	6a032ece-4f9e-405a-b48a-b28516d15fe1	3d497ef7-35c9-4687-8476-96fbecc29f86	391f7d87-df5d-4538-9b3e-31e07ac9347e	2025-10-15	\N	\N	1.00	training	t	f	110.00	110.00	\N	Commodi modi angustus demens error callide vitium officia tibi.	\N	approved	\N	\N	\N	\N	2025-10-19 18:00:37.792778	2025-10-19 18:00:37.792778
c06f1595-1668-4842-82ec-1856dbb2138b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	17f141c2-e297-4c93-9178-0fd819259c50	80260d18-0de6-4cf6-af1d-5b4a1d17a6de	a0801828-5c53-41ef-9b3e-06db89d72e90	2025-10-15	\N	\N	1.00	training	t	f	110.00	110.00	\N	Virgo consectetur asper denuo vestrum tribuo vix.	\N	draft	\N	\N	\N	\N	2025-10-19 18:00:37.795003	2025-10-19 18:00:37.795003
a80ddbdf-58a8-4213-98ee-2d1917b5bee1	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	405d4d05-841b-437d-af7d-70b66dda4cbc	9485b00c-4fc8-454f-984a-6908039db9f9	ecfd2c2c-905b-4ef4-99a4-8949632b9ae9	2025-10-15	\N	\N	2.75	admin	t	f	110.00	302.50	\N	Ago tardus defendo blandior aequus beneficium vallum odit.	\N	rejected	\N	\N	\N	\N	2025-10-19 18:00:37.797189	2025-10-19 18:00:37.797189
ae4baace-ef9b-409c-83a0-2c20072e3df9	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	0d0329f4-4b80-4899-8807-5854e9db312b	40ca5c4e-33d7-432f-a55c-b59c3010d7ef	1ede1cc0-3627-404e-bb8a-487e028f4732	2025-10-15	\N	\N	3.75	admin	t	t	85.00	318.75	\N	Tenus velut sursum conduco maxime cornu paens vomito defluo adfero.	\N	draft	\N	\N	\N	\N	2025-10-19 18:00:37.803627	2025-10-19 18:00:37.803627
6a069e33-a3ab-4d6a-b915-249a5d7001ce	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	584bab37-ccf2-484c-9a7f-7394e4b30ec6	ddc09723-5f7f-4f23-a202-0b6243ef63f9	a8a65b80-dc4c-49f9-9c8d-0dc4a336cf55	2025-10-15	\N	\N	3.50	admin	t	f	85.00	297.50	\N	Culpa solitudo amplitudo universe strues.	\N	rejected	\N	\N	\N	\N	2025-10-19 18:00:37.806933	2025-10-19 18:00:37.806933
14330ad3-4f91-44f5-99fb-ca57be85d4d2	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	d8601cb6-589f-456f-a2b2-1b986973a4bc	a0801828-5c53-41ef-9b3e-06db89d72e90	2025-10-16	\N	\N	4.00	meeting	f	f	150.00	600.00	\N	Culpa aeger bene ancilla abutor cura ipsum comedo distinctio.	\N	rejected	\N	\N	\N	\N	2025-10-19 18:00:37.809455	2025-10-19 18:00:37.809455
74a62e35-8e51-4791-ba2d-af21c5e2917e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	46859340-c8cf-4144-aa6c-28fbaf53fa0e	d486be12-5ed8-48b4-af34-79d9269f4c0b	d6d7e47b-cd48-48d8-a45a-fa75af1f9a52	2025-10-16	\N	\N	3.00	training	t	f	150.00	450.00	\N	Volva strenuus virga viduo facilis cuppedia ascit labore alter.	\N	submitted	\N	\N	\N	\N	2025-10-19 18:00:37.812221	2025-10-19 18:00:37.812221
0047ad15-3485-45d3-9499-c1c4679a3160	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	8538cc30-f9e7-4b63-a885-56b23e16ecef	b3d1095b-3d51-444b-be35-f485afdb174f	391f7d87-df5d-4538-9b3e-31e07ac9347e	2025-10-16	\N	\N	3.50	work	f	t	150.00	525.00	\N	Virgo ad quibusdam labore iusto antiquus alii suasoria.	\N	draft	\N	\N	\N	\N	2025-10-19 18:00:37.815463	2025-10-19 18:00:37.815463
d002a8e8-bdf4-4939-9d3c-e364ce89c5b3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	89991ea8-6047-4c5e-ad0c-c8d532ce1c8b	d8601cb6-589f-456f-a2b2-1b986973a4bc	a96c9f4d-dc33-4af3-818d-8d729f0f8c1f	2025-10-16	\N	\N	1.00	meeting	t	f	120.00	120.00	\N	Statua sit cedo reiciendis accusamus altus tertius aiunt triduana adipisci.	\N	rejected	\N	\N	\N	\N	2025-10-19 18:00:37.818293	2025-10-19 18:00:37.818293
d5c94807-dae8-4bef-9e0b-f605703dd500	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	584bab37-ccf2-484c-9a7f-7394e4b30ec6	7a582f98-6d3d-44d5-9796-ba1d12c49f62	08ee5378-067c-4708-886c-34df4c200b23	2025-10-16	\N	\N	2.50	meeting	f	f	120.00	300.00	\N	Cattus suspendo adsum adulatio spiritus uter tabernus vesper vito.	\N	draft	\N	\N	\N	\N	2025-10-19 18:00:37.821181	2025-10-19 18:00:37.821181
fdf291d4-1ee5-4710-b8a7-5ca70d119079	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	04465623-29cb-4298-8828-d1839e9cc00d	e4ce7abb-fb0c-42e1-a7c1-6419b4aa63ef	e4487405-7859-40e9-8008-056d32fe6f10	2025-10-16	\N	\N	3.50	meeting	t	f	120.00	420.00	\N	Templum tyrannus tempus vae argentum tenus studio.	\N	approved	\N	\N	\N	\N	2025-10-19 18:00:37.823805	2025-10-19 18:00:37.823805
54d799de-0fe9-4d6b-89f1-3a92aa6116cd	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	5e2204cd-be52-42a7-aa41-14fcf0e4a272	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-10-16	\N	\N	1.25	admin	t	f	120.00	150.00	\N	Thermae sollers viriliter occaecati coma.	\N	approved	\N	\N	\N	\N	2025-10-19 18:00:37.826358	2025-10-19 18:00:37.826358
24109c0b-c2fb-4d30-92ca-3ee924ecafff	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	17f141c2-e297-4c93-9178-0fd819259c50	80260d18-0de6-4cf6-af1d-5b4a1d17a6de	08ee5378-067c-4708-886c-34df4c200b23	2025-10-16	\N	\N	4.00	admin	t	t	110.00	440.00	\N	Aspernatur venio aestus.	\N	approved	\N	\N	\N	\N	2025-10-19 18:00:37.829392	2025-10-19 18:00:37.829392
16a21fc0-d291-46b0-9857-5cd0b26142cd	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	d69d0436-37d7-42a4-b907-3d9c3a091ea6	20222077-caa4-4444-b803-1f75d617ee85	3f2e9a8e-bdfe-4d09-aced-e88cdc710462	2025-10-16	\N	\N	3.00	meeting	t	f	110.00	330.00	\N	Ceno utrimque abundans vindico.	\N	submitted	\N	\N	\N	\N	2025-10-19 18:00:37.832012	2025-10-19 18:00:37.832012
62ed091d-7786-47c9-a7e0-0e7faf0bcb55	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	8538cc30-f9e7-4b63-a885-56b23e16ecef	b3d1095b-3d51-444b-be35-f485afdb174f	996aa78c-cfd1-477f-8c30-d9489225b29e	2025-10-16	\N	\N	1.25	research	t	f	110.00	137.50	\N	Alienus adulescens civitas.	\N	submitted	\N	\N	\N	\N	2025-10-19 18:00:37.834573	2025-10-19 18:00:37.834573
c1eac6d8-3fd2-4c29-af3e-eae5f02e584e	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	04465623-29cb-4298-8828-d1839e9cc00d	e4ce7abb-fb0c-42e1-a7c1-6419b4aa63ef	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-10-16	\N	\N	1.00	research	t	t	85.00	85.00	\N	Paens theca cogito vorax cubo arbustum aestas vitium anser.	\N	draft	\N	\N	\N	\N	2025-10-19 18:00:37.836973	2025-10-19 18:00:37.836973
fb778457-ec32-4c60-a153-7be76f1ee55d	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	4c4c8a41-856b-41b4-9a6f-cb70e6a3a6b4	5e2204cd-be52-42a7-aa41-14fcf0e4a272	d6d7e47b-cd48-48d8-a45a-fa75af1f9a52	2025-10-16	\N	\N	4.00	training	t	t	85.00	340.00	\N	Cornu cavus amitto vindico patria textilis accommodo curo argentum.	\N	submitted	\N	\N	\N	\N	2025-10-19 18:00:37.839432	2025-10-19 18:00:37.839432
3a8f8eb8-d926-4328-a6c6-610c39bddbce	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	45b3d726-e151-4770-9b64-4653914bdaa5	92700c16-c146-4a6e-9610-46ac28f4b4c3	a8a65b80-dc4c-49f9-9c8d-0dc4a336cf55	2025-10-16	\N	\N	2.25	training	t	f	85.00	191.25	\N	Admoveo tempora voluptates utroque.	\N	submitted	\N	\N	\N	\N	2025-10-19 18:00:37.842226	2025-10-19 18:00:37.842226
aa608a5a-dad4-4310-9351-c579020dba9c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	46859340-c8cf-4144-aa6c-28fbaf53fa0e	f9444b08-3c00-4407-98d8-3d654600142c	e2cd4da6-f171-436c-9c7e-a9c1c5436b98	2025-10-16	\N	\N	1.25	training	f	f	85.00	106.25	\N	Reiciendis laudantium demo vomica voro coaegresco vergo arbitro conor.	\N	approved	\N	\N	\N	\N	2025-10-19 18:00:37.846115	2025-10-19 18:00:37.846115
1283737a-d723-45ae-96ff-80131e783728	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	a4464f5a-2125-46d9-9f58-7252c9adc16b	7041a9f2-cd04-4f9c-ab2c-96bfdd45e5ff	9362cf11-827c-459a-8ffc-6634bd023508	2025-10-16	\N	\N	1.25	work	t	f	85.00	106.25	\N	Explicabo atavus neque eos accusantium thymum.	\N	draft	\N	\N	\N	\N	2025-10-19 18:00:37.848554	2025-10-19 18:00:37.848554
64c804c3-532f-4051-9044-7e5c9aa5e6ae	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	46f2f706-8455-47eb-9d08-a3a8fea6bf0b	dc9252b7-2022-4822-a8b2-7ec227fe0ea4	a96c9f4d-dc33-4af3-818d-8d729f0f8c1f	2025-10-17	\N	\N	3.50	admin	t	f	150.00	525.00	\N	Texo alias toties aspernatur ustulo facilis deripio desipio atqui.	\N	rejected	\N	\N	\N	\N	2025-10-19 18:00:37.850703	2025-10-19 18:00:37.850703
e8e4e865-9183-4ed5-beeb-42b964f98f72	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	8538cc30-f9e7-4b63-a885-56b23e16ecef	b3d1095b-3d51-444b-be35-f485afdb174f	ca413110-b7e3-4734-a185-d21ea0960708	2025-10-17	\N	\N	2.00	research	t	f	150.00	300.00	\N	Cedo veniam tum verecundia repellendus.	\N	approved	\N	\N	\N	\N	2025-10-19 18:00:37.852786	2025-10-19 18:00:37.852786
392a07c6-25a8-42ba-acb4-500704787ac5	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	bbb2cdbe-7c1d-4791-8596-3b3d0ba77987	96a103f5-bc5b-43e1-b321-62fedda6eaa1	9362cf11-827c-459a-8ffc-6634bd023508	2025-10-17	\N	\N	0.75	meeting	t	t	150.00	112.50	\N	Sodalitas tutamen utique aufero adeptio patruus.	\N	submitted	\N	\N	\N	\N	2025-10-19 18:00:37.854602	2025-10-19 18:00:37.854602
eb85909c-d6c9-421c-901c-0a89fa47197b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	a2adaa31-8f59-409a-b39b-72568022adb4	04465623-29cb-4298-8828-d1839e9cc00d	e4ce7abb-fb0c-42e1-a7c1-6419b4aa63ef	996aa78c-cfd1-477f-8c30-d9489225b29e	2025-10-17	\N	\N	3.75	meeting	t	f	150.00	562.50	\N	Carbo patria omnis curo.	\N	approved	\N	\N	\N	\N	2025-10-19 18:00:37.856546	2025-10-19 18:00:37.856546
a63930eb-67b7-4bda-893a-704a4d57e97b	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	67f62599-7f9f-44e8-bc18-d2ce08ea9919	9ec151a2-b6a4-433d-a21e-c94af23b785b	08ee5378-067c-4708-886c-34df4c200b23	2025-10-17	\N	\N	0.75	meeting	t	f	120.00	90.00	\N	Pecus iure crepusculum depopulo quae caelum coadunatio degenero vero.	\N	rejected	\N	\N	\N	\N	2025-10-19 18:00:37.859138	2025-10-19 18:00:37.859138
bfa6f50c-716c-43c0-8afd-361c479b4d30	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	d6f36046-e274-4776-a3d7-58eadb9d96b0	17f141c2-e297-4c93-9178-0fd819259c50	af41070b-ce93-4cf4-88f6-19ed28a1f1fe	18c91d63-8f9d-4974-ba97-a4079c7457d5	2025-10-17	\N	\N	1.75	training	t	t	120.00	210.00	\N	Veniam voluptate vomer creber.	\N	draft	\N	\N	\N	\N	2025-10-19 18:00:37.863206	2025-10-19 18:00:37.863206
5509282d-62f0-4d3e-813f-8d6029eaf2fe	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	088446c4-4542-4007-9887-b512bd3db05d	b5a89f3d-4b09-4b0c-9d74-f3d4dd8f321a	2025-10-17	\N	\N	0.50	work	f	f	110.00	55.00	\N	Ait conqueror deprimo viscus acsi spectaculum ventus itaque compono triumphus.	\N	submitted	\N	\N	\N	\N	2025-10-19 18:00:37.867843	2025-10-19 18:00:37.867843
891bf535-7540-48e7-a24f-5cec193741ee	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	7ef8af5a-1080-42a2-988f-ddfa799c8070	5cf17315-4658-4a7f-9c23-b4f8268d8f84	235b548d-f0a0-4899-9a7e-d6e9bec6db40	2025-10-17	\N	\N	3.50	work	t	f	110.00	385.00	\N	Expedita atavus arto sponte.	\N	draft	\N	\N	\N	\N	2025-10-19 18:00:37.871636	2025-10-19 18:00:37.871636
f0fea953-35b6-4d48-af74-3be6629592f3	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	4554e09d-4391-42a8-a2cd-9702bce80511	ae73110f-e045-44ac-85ff-51aa2eb8ce69	78882562-2120-44d2-9286-03e696abbf02	2025-10-17	\N	\N	3.75	work	t	f	110.00	412.50	\N	Caute caelestis abeo harum vomer cernuus cubitum sub neque.	\N	approved	\N	\N	\N	\N	2025-10-19 18:00:37.875546	2025-10-19 18:00:37.875546
4f830299-7bd8-48b0-8b12-6ae8b7898386	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	d1bc8d6b-3cc1-47c9-baf4-5a2d379606be	088446c4-4542-4007-9887-b512bd3db05d	ff4a2600-29fe-4448-bec3-ea868988a9ed	2025-10-17	\N	\N	2.25	meeting	t	f	110.00	247.50	\N	Ventus catena antiquus talio universe bellicus.	\N	submitted	\N	\N	\N	\N	2025-10-19 18:00:37.879149	2025-10-19 18:00:37.879149
312bba0e-002f-4fab-bb65-5ece67a4b490	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	c4f75303-a973-43e1-8f69-dfc6500c302c	6ecda653-6094-4502-9d1d-6e90d9ea99ed	4fb9cb0a-ca36-4af7-9203-ac1970ce555b	b8a07222-b44a-4e21-8e8d-19ab9cca5ec8	2025-10-17	\N	\N	2.50	work	t	t	110.00	275.00	\N	Aegrus sulum nemo degero.	\N	approved	\N	\N	\N	\N	2025-10-19 18:00:37.882054	2025-10-19 18:00:37.882054
0023e53b-205f-488e-a1f2-973efa858e80	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	a4464f5a-2125-46d9-9f58-7252c9adc16b	b09b8a10-2b29-4fa3-b57f-c69d46364489	79d01aa5-b680-4830-ab3a-5e3cb66edcfa	2025-10-17	\N	\N	0.75	admin	t	t	85.00	63.75	\N	Creptio absque architecto.	\N	draft	\N	\N	\N	\N	2025-10-19 18:00:37.885335	2025-10-19 18:00:37.885335
b90e3ec6-3377-4c1e-941d-d9b6ddd8131a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	6ecda653-6094-4502-9d1d-6e90d9ea99ed	4fb9cb0a-ca36-4af7-9203-ac1970ce555b	1ede1cc0-3627-404e-bb8a-487e028f4732	2025-10-17	\N	\N	0.75	admin	t	f	85.00	63.75	\N	Curto coruscus fuga cimentarius benigne crinis bellicus approbo synagoga cohibeo.	\N	approved	\N	\N	\N	\N	2025-10-19 18:00:37.893621	2025-10-19 18:00:37.893621
641facfd-6844-48ad-b94f-6daad2957d9a	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	8538cc30-f9e7-4b63-a885-56b23e16ecef	b3d1095b-3d51-444b-be35-f485afdb174f	9362cf11-827c-459a-8ffc-6634bd023508	2025-10-17	\N	\N	1.50	training	t	t	85.00	127.50	\N	Sumo demergo spargo arx odio textilis volubilis cupressus tumultus.	\N	draft	\N	\N	\N	\N	2025-10-19 18:00:37.896945	2025-10-19 18:00:37.896945
d9a74bd4-987a-4b2f-a0f3-97a0ce5abd83	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	0409f8de-7e1d-4245-96c2-02a3b1c90a81	b0a95e11-90ac-4ab3-b099-c4de69f498b8	269dca40-b352-4a09-9d7c-c735016a8c7d	d04961e2-5af7-4b9c-bb44-c37031dd6bfa	2025-10-17	\N	\N	2.00	training	t	f	85.00	170.00	\N	Cibus subvenio culpa solum talis audentia virtus depulso defluo tam.	\N	rejected	\N	\N	\N	\N	2025-10-19 18:00:37.899288	2025-10-19 18:00:37.899288
\.


--
-- Data for Name: user_favorites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_favorites (id, user_id, link_id, created_at) FROM stdin;
\.


--
-- Data for Name: user_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_permissions (id, tenant_id, user_id, module, can_view, can_create, can_edit, can_delete, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, tenant_id, email, email_verified, name, first_name, last_name, image, role, status, is_active, hourly_rate, created_at, updated_at) FROM stdin;
a2adaa31-8f59-409a-b39b-72568022adb4	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	joe@pageivy.com	t	Joe Test	Joe	Test	\N	admin	active	t	150.00	2025-10-19 18:00:33.88655	2025-10-19 18:00:33.88655
d6f36046-e274-4776-a3d7-58eadb9d96b0	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	sarah.johnson@demo.com	t	Sarah Johnson	Sarah	Johnson	\N	accountant	active	t	120.00	2025-10-19 18:00:33.88655	2025-10-19 18:00:33.88655
c4f75303-a973-43e1-8f69-dfc6500c302c	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	mike.chen@demo.com	t	Mike Chen	Mike	Chen	\N	accountant	active	t	110.00	2025-10-19 18:00:33.88655	2025-10-19 18:00:33.88655
0409f8de-7e1d-4245-96c2-02a3b1c90a81	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	emily.davis@demo.com	t	Emily Davis	Emily	Davis	\N	member	active	t	85.00	2025-10-19 18:00:33.88655	2025-10-19 18:00:33.88655
\.


--
-- Data for Name: verification; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.verification (id, identifier, value, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: workflow_stages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.workflow_stages (id, workflow_id, name, description, stage_order, is_required, estimated_hours, checklist_items, auto_complete, requires_approval, metadata, created_at, updated_at) FROM stdin;
aec923f2-d4a6-4060-8e49-1a5a1482d2df	965823ac-8815-43cb-b52d-be3d11bee333	Gather Documents	Stage 1 of Annual Tax Return Process	1	t	2.00	[{"id": "item-0", "text": "Bank statements", "isRequired": true}, {"id": "item-1", "text": "Receipts", "isRequired": true}, {"id": "item-2", "text": "P60s", "isRequired": true}, {"id": "item-3", "text": "P45s if applicable", "isRequired": true}, {"id": "item-4", "text": "P11D benefits forms", "isRequired": true}]	f	f	\N	2025-10-19 18:00:38.271638	2025-10-19 18:00:38.271638
aa2984e2-c354-482a-8ffd-948cfe7bfe24	965823ac-8815-43cb-b52d-be3d11bee333	Data Entry	Stage 2 of Annual Tax Return Process	2	t	4.00	[{"id": "item-0", "text": "Enter employment income", "isRequired": true}, {"id": "item-1", "text": "Enter self-employment income", "isRequired": true}, {"id": "item-2", "text": "Enter expenses", "isRequired": true}, {"id": "item-3", "text": "Enter deductions", "isRequired": true}, {"id": "item-4", "text": "Enter pension contributions", "isRequired": true}]	f	f	\N	2025-10-19 18:00:38.277232	2025-10-19 18:00:38.277232
27b97b3e-8afe-434e-99a4-74f92e70cbf0	965823ac-8815-43cb-b52d-be3d11bee333	Review & Calculations	Stage 3 of Annual Tax Return Process	3	t	3.00	[{"id": "item-0", "text": "Review all entries", "isRequired": true}, {"id": "item-1", "text": "Calculate tax liability", "isRequired": true}, {"id": "item-2", "text": "Apply tax reliefs", "isRequired": true}, {"id": "item-3", "text": "Check for errors", "isRequired": true}, {"id": "item-4", "text": "Optimize deductions", "isRequired": true}]	f	f	\N	2025-10-19 18:00:38.280638	2025-10-19 18:00:38.280638
d4159728-18e5-40ef-b7a6-6a194a28f6c9	965823ac-8815-43cb-b52d-be3d11bee333	Client Approval	Stage 4 of Annual Tax Return Process	4	t	1.00	[{"id": "item-0", "text": "Prepare summary", "isRequired": true}, {"id": "item-1", "text": "Send to client", "isRequired": true}, {"id": "item-2", "text": "Get written approval", "isRequired": true}]	f	t	\N	2025-10-19 18:00:38.283823	2025-10-19 18:00:38.283823
88185047-7c3d-4411-b3b2-aaeb501c2102	965823ac-8815-43cb-b52d-be3d11bee333	Submit to HMRC	Stage 5 of Annual Tax Return Process	5	t	1.00	[{"id": "item-0", "text": "Final review", "isRequired": true}, {"id": "item-1", "text": "Submit online", "isRequired": true}, {"id": "item-2", "text": "Get confirmation", "isRequired": true}, {"id": "item-3", "text": "Save reference", "isRequired": true}, {"id": "item-4", "text": "Update records", "isRequired": true}]	f	f	\N	2025-10-19 18:00:38.287529	2025-10-19 18:00:38.287529
5048a100-6ae3-46ef-96a4-a2c4c092eaa1	6624a9f6-9886-4b3d-a8fc-0bcc0ecfd112	Gather Invoices	Stage 1 of VAT Return Process	1	t	2.00	[{"id": "item-0", "text": "Collect sales invoices", "isRequired": true}, {"id": "item-1", "text": "Collect purchase invoices", "isRequired": true}, {"id": "item-2", "text": "Download bank statements", "isRequired": true}, {"id": "item-3", "text": "Gather receipts", "isRequired": true}]	f	f	\N	2025-10-19 18:00:38.29524	2025-10-19 18:00:38.29524
2d98c84a-f422-4eb6-b6c7-04fc2089596f	6624a9f6-9886-4b3d-a8fc-0bcc0ecfd112	Calculate VAT	Stage 2 of VAT Return Process	2	t	3.00	[{"id": "item-0", "text": "Calculate output VAT", "isRequired": true}, {"id": "item-1", "text": "Calculate input VAT", "isRequired": true}, {"id": "item-2", "text": "Apply VAT schemes", "isRequired": true}, {"id": "item-3", "text": "Check partial exemption", "isRequired": true}]	f	f	\N	2025-10-19 18:00:38.298418	2025-10-19 18:00:38.298418
dc4544f9-4bda-420f-ba07-64266bbd43a6	6624a9f6-9886-4b3d-a8fc-0bcc0ecfd112	Review Transactions	Stage 3 of VAT Return Process	3	t	2.00	[{"id": "item-0", "text": "Review all entries", "isRequired": true}, {"id": "item-1", "text": "Check VAT rates", "isRequired": true}, {"id": "item-2", "text": "Verify calculations", "isRequired": true}, {"id": "item-3", "text": "Reconcile with accounts", "isRequired": true}]	f	f	\N	2025-10-19 18:00:38.300893	2025-10-19 18:00:38.300893
c83fd9d9-282c-4277-94ac-50a39fdbc95c	6624a9f6-9886-4b3d-a8fc-0bcc0ecfd112	Submit to HMRC	Stage 4 of VAT Return Process	4	t	1.00	[{"id": "item-0", "text": "Complete VAT return", "isRequired": true}, {"id": "item-1", "text": "Submit online", "isRequired": true}, {"id": "item-2", "text": "Get confirmation", "isRequired": true}, {"id": "item-3", "text": "Schedule payment", "isRequired": true}, {"id": "item-4", "text": "File documents", "isRequired": true}]	f	f	\N	2025-10-19 18:00:38.302941	2025-10-19 18:00:38.302941
056061d3-463c-43ac-90cd-6e398c308ca1	acbad2fb-595b-462b-82fc-f2f04f43fc67	Trial Balance	Stage 1 of Annual Accounts Preparation	1	t	4.00	[{"id": "item-0", "text": "Prepare trial balance", "isRequired": true}, {"id": "item-1", "text": "Review GL accounts", "isRequired": true}, {"id": "item-2", "text": "Clear suspense accounts", "isRequired": true}, {"id": "item-3", "text": "Review reconciliations", "isRequired": true}]	f	f	\N	2025-10-19 18:00:38.308296	2025-10-19 18:00:38.308296
82f0ab8a-3101-41ce-9496-490f7c2943a2	acbad2fb-595b-462b-82fc-f2f04f43fc67	Draft Accounts	Stage 2 of Annual Accounts Preparation	2	t	6.00	[{"id": "item-0", "text": "Prepare P&L", "isRequired": true}, {"id": "item-1", "text": "Prepare balance sheet", "isRequired": true}, {"id": "item-2", "text": "Calculate tax provision", "isRequired": true}, {"id": "item-3", "text": "Draft notes to accounts", "isRequired": true}, {"id": "item-4", "text": "Prepare directors report", "isRequired": true}]	f	f	\N	2025-10-19 18:00:38.310557	2025-10-19 18:00:38.310557
259fd615-2211-4582-a609-948349a63f94	acbad2fb-595b-462b-82fc-f2f04f43fc67	Review & Adjustments	Stage 3 of Annual Accounts Preparation	3	t	4.00	[{"id": "item-0", "text": "Review draft accounts", "isRequired": true}, {"id": "item-1", "text": "Post adjusting entries", "isRequired": true}, {"id": "item-2", "text": "Update tax computation", "isRequired": true}, {"id": "item-3", "text": "Review compliance", "isRequired": true}, {"id": "item-4", "text": "Internal quality check", "isRequired": true}]	f	f	\N	2025-10-19 18:00:38.312284	2025-10-19 18:00:38.312284
868335a9-9fbd-4262-a41b-5c5cb1ab1c7f	acbad2fb-595b-462b-82fc-f2f04f43fc67	Director Approval	Stage 4 of Annual Accounts Preparation	4	t	2.00	[{"id": "item-0", "text": "Present to directors", "isRequired": true}, {"id": "item-1", "text": "Explain key changes", "isRequired": true}, {"id": "item-2", "text": "Get board approval", "isRequired": true}, {"id": "item-3", "text": "Obtain signatures", "isRequired": true}]	f	t	\N	2025-10-19 18:00:38.313862	2025-10-19 18:00:38.313862
e83edffe-554c-4b38-a1e2-a215f8cfc3d1	acbad2fb-595b-462b-82fc-f2f04f43fc67	File Accounts	Stage 5 of Annual Accounts Preparation	5	t	2.00	[{"id": "item-0", "text": "File with Companies House", "isRequired": true}, {"id": "item-1", "text": "Submit to HMRC", "isRequired": true}, {"id": "item-2", "text": "Send to shareholders", "isRequired": true}, {"id": "item-3", "text": "Update statutory books", "isRequired": true}, {"id": "item-4", "text": "Archive documents", "isRequired": true}]	f	f	\N	2025-10-19 18:00:38.315328	2025-10-19 18:00:38.315328
862129fa-26ed-4750-b835-a1209aaa6d08	f08a8f24-3be0-4086-bd5c-a4eb1cf19811	Collect Timesheets	Stage 1 of Payroll Processing	1	t	1.00	[{"id": "item-0", "text": "Gather timesheets", "isRequired": true}, {"id": "item-1", "text": "Review overtime", "isRequired": true}, {"id": "item-2", "text": "Check leave records", "isRequired": true}, {"id": "item-3", "text": "Verify hours worked", "isRequired": true}]	f	f	\N	2025-10-19 18:00:38.318809	2025-10-19 18:00:38.318809
2e10f021-accf-4909-837b-0d3af1f204a5	f08a8f24-3be0-4086-bd5c-a4eb1cf19811	Calculate Wages	Stage 2 of Payroll Processing	2	t	2.00	[{"id": "item-0", "text": "Calculate gross pay", "isRequired": true}, {"id": "item-1", "text": "Apply deductions", "isRequired": true}, {"id": "item-2", "text": "Calculate PAYE", "isRequired": true}, {"id": "item-3", "text": "Calculate NI", "isRequired": true}, {"id": "item-4", "text": "Process benefits", "isRequired": true}]	f	f	\N	2025-10-19 18:00:38.320453	2025-10-19 18:00:38.320453
2eb6af96-46f6-4005-8443-1d90f31d610b	f08a8f24-3be0-4086-bd5c-a4eb1cf19811	Process Deductions	Stage 3 of Payroll Processing	3	t	1.00	[{"id": "item-0", "text": "Student loans", "isRequired": true}, {"id": "item-1", "text": "Pension contributions", "isRequired": true}, {"id": "item-2", "text": "Court orders", "isRequired": true}, {"id": "item-3", "text": "Union fees", "isRequired": true}, {"id": "item-4", "text": "Other deductions", "isRequired": true}]	f	f	\N	2025-10-19 18:00:38.321967	2025-10-19 18:00:38.321967
61d9a903-d81b-4685-8ee3-be77beeebe83	f08a8f24-3be0-4086-bd5c-a4eb1cf19811	Submit RTI	Stage 4 of Payroll Processing	4	t	1.00	[{"id": "item-0", "text": "Prepare FPS", "isRequired": true}, {"id": "item-1", "text": "Submit to HMRC", "isRequired": true}, {"id": "item-2", "text": "Get confirmation", "isRequired": true}, {"id": "item-3", "text": "Update records", "isRequired": true}]	f	f	\N	2025-10-19 18:00:38.32389	2025-10-19 18:00:38.32389
f02844f1-01e6-46c0-b95b-5da855ba1954	f08a8f24-3be0-4086-bd5c-a4eb1cf19811	Issue Payslips	Stage 5 of Payroll Processing	5	t	1.00	[{"id": "item-0", "text": "Generate payslips", "isRequired": true}, {"id": "item-1", "text": "Review for accuracy", "isRequired": true}, {"id": "item-2", "text": "Send to employees", "isRequired": true}, {"id": "item-3", "text": "Process payments", "isRequired": true}, {"id": "item-4", "text": "File copies", "isRequired": true}]	f	f	\N	2025-10-19 18:00:38.325747	2025-10-19 18:00:38.325747
8e7dc108-3181-4886-8e69-1193c426e1f7	4a29c5cf-69ba-4639-b91a-08f3851b5397	Review Requirements	Stage 1 of Compliance Review	1	t	2.00	[{"id": "item-0", "text": "Identify regulations", "isRequired": true}, {"id": "item-1", "text": "Check updates", "isRequired": true}, {"id": "item-2", "text": "Review deadlines", "isRequired": true}, {"id": "item-3", "text": "Assess scope", "isRequired": true}]	f	f	\N	2025-10-19 18:00:38.329739	2025-10-19 18:00:38.329739
8ff05f7d-3045-4123-8cb5-30611b5bfcb9	4a29c5cf-69ba-4639-b91a-08f3851b5397	Gather Documentation	Stage 2 of Compliance Review	2	t	3.00	[{"id": "item-0", "text": "Collect policies", "isRequired": true}, {"id": "item-1", "text": "Gather records", "isRequired": true}, {"id": "item-2", "text": "Review procedures", "isRequired": true}, {"id": "item-3", "text": "Interview staff", "isRequired": true}]	f	f	\N	2025-10-19 18:00:38.331272	2025-10-19 18:00:38.331272
2780d177-b2b9-4b82-84bc-130d95adf77a	4a29c5cf-69ba-4639-b91a-08f3851b5397	Check Compliance	Stage 3 of Compliance Review	3	t	4.00	[{"id": "item-0", "text": "Test controls", "isRequired": true}, {"id": "item-1", "text": "Review documentation", "isRequired": true}, {"id": "item-2", "text": "Check procedures", "isRequired": true}, {"id": "item-3", "text": "Identify gaps", "isRequired": true}]	f	f	\N	2025-10-19 18:00:38.332697	2025-10-19 18:00:38.332697
3de3c46d-684e-4cce-abbf-2f06ba880e0e	4a29c5cf-69ba-4639-b91a-08f3851b5397	Document Findings	Stage 4 of Compliance Review	4	t	2.00	[{"id": "item-0", "text": "Write report", "isRequired": true}, {"id": "item-1", "text": "Document issues", "isRequired": true}, {"id": "item-2", "text": "Recommend actions", "isRequired": true}, {"id": "item-3", "text": "Set priorities", "isRequired": true}]	f	f	\N	2025-10-19 18:00:38.334108	2025-10-19 18:00:38.334108
77456a24-f5c2-418f-98f5-2ceb6b60f53e	4a29c5cf-69ba-4639-b91a-08f3851b5397	Submit Report	Stage 5 of Compliance Review	5	t	1.00	[{"id": "item-0", "text": "Finalize report", "isRequired": true}, {"id": "item-1", "text": "Management review", "isRequired": true}, {"id": "item-2", "text": "Submit to board", "isRequired": true}, {"id": "item-3", "text": "File documentation", "isRequired": true}]	f	f	\N	2025-10-19 18:00:38.335578	2025-10-19 18:00:38.335578
8fc49151-f9f3-4c30-8cd0-5d8c459062c4	c9013c22-350c-46aa-b8c4-8a71da338337	Initial Review	Stage 1 of Document Review Process	1	t	1.00	[{"id": "item-0", "text": "Check completeness", "isRequired": true}, {"id": "item-1", "text": "Verify format", "isRequired": true}, {"id": "item-2", "text": "Review scope", "isRequired": true}, {"id": "item-3", "text": "Check references", "isRequired": true}]	f	f	\N	2025-10-19 18:00:38.339334	2025-10-19 18:00:38.339334
0e879dc4-55a1-406f-8577-58442fcddf7d	c9013c22-350c-46aa-b8c4-8a71da338337	Detailed Analysis	Stage 2 of Document Review Process	2	t	2.00	[{"id": "item-0", "text": "Check accuracy", "isRequired": true}, {"id": "item-1", "text": "Verify calculations", "isRequired": true}, {"id": "item-2", "text": "Review compliance", "isRequired": true}, {"id": "item-3", "text": "Check consistency", "isRequired": true}]	f	f	\N	2025-10-19 18:00:38.340798	2025-10-19 18:00:38.340798
94c8875b-195d-4c1f-8fe8-c3e14024c49a	c9013c22-350c-46aa-b8c4-8a71da338337	Quality Check	Stage 3 of Document Review Process	3	t	1.00	[{"id": "item-0", "text": "Grammar check", "isRequired": true}, {"id": "item-1", "text": "Format review", "isRequired": true}, {"id": "item-2", "text": "Cross-reference", "isRequired": true}, {"id": "item-3", "text": "Fact check", "isRequired": true}]	f	f	\N	2025-10-19 18:00:38.342372	2025-10-19 18:00:38.342372
f007e68f-c7c0-454d-b1af-bdd38e45970b	c9013c22-350c-46aa-b8c4-8a71da338337	Final Approval	Stage 4 of Document Review Process	4	t	1.00	[{"id": "item-0", "text": "Final review", "isRequired": true}, {"id": "item-1", "text": "Get approval", "isRequired": true}, {"id": "item-2", "text": "Document decision", "isRequired": true}, {"id": "item-3", "text": "Archive copy", "isRequired": true}]	f	t	\N	2025-10-19 18:00:38.34406	2025-10-19 18:00:38.34406
efae45d3-adc3-4b7e-b790-cdf771e92d4f	6784d58d-be43-45ac-88e5-3232d67c5172	Initial Setup	Stage 1 of New Client Onboarding	1	t	1.00	[{"id": "item-0", "text": "Create client record", "isRequired": true}, {"id": "item-1", "text": "Set up folders", "isRequired": true}, {"id": "item-2", "text": "Send welcome email", "isRequired": true}, {"id": "item-3", "text": "Schedule meeting", "isRequired": true}]	f	f	\N	2025-10-19 18:00:38.347668	2025-10-19 18:00:38.347668
eae559d4-abc6-4f28-b28d-12e90927ed05	6784d58d-be43-45ac-88e5-3232d67c5172	Document Collection	Stage 2 of New Client Onboarding	2	t	2.00	[{"id": "item-0", "text": "ID verification", "isRequired": true}, {"id": "item-1", "text": "Engagement letter", "isRequired": true}, {"id": "item-2", "text": "Bank details", "isRequired": true}, {"id": "item-3", "text": "Tax information", "isRequired": true}, {"id": "item-4", "text": "Company documents", "isRequired": true}]	f	f	\N	2025-10-19 18:00:38.34933	2025-10-19 18:00:38.34933
b91e0b28-f938-4851-8f0e-7ba22990ea17	6784d58d-be43-45ac-88e5-3232d67c5172	Service Configuration	Stage 3 of New Client Onboarding	3	t	1.00	[{"id": "item-0", "text": "Assign services", "isRequired": true}, {"id": "item-1", "text": "Set rates", "isRequired": true}, {"id": "item-2", "text": "Create schedule", "isRequired": true}, {"id": "item-3", "text": "Set up billing", "isRequired": true}]	f	f	\N	2025-10-19 18:00:38.350958	2025-10-19 18:00:38.350958
e74fd7b8-12ff-4fad-bf04-e587f84d10e0	6784d58d-be43-45ac-88e5-3232d67c5172	System Access	Stage 4 of New Client Onboarding	4	t	1.00	[{"id": "item-0", "text": "Portal access", "isRequired": true}, {"id": "item-1", "text": "Document sharing", "isRequired": true}, {"id": "item-2", "text": "Communication setup", "isRequired": true}, {"id": "item-3", "text": "Training provided", "isRequired": true}]	f	f	\N	2025-10-19 18:00:38.352607	2025-10-19 18:00:38.352607
b1ca67dc-a72a-45a5-8f3b-d5e50512cdd1	51c831a7-42a0-4a9e-8e8a-69e873269a4f	Transaction Import	Stage 1 of Monthly Bookkeeping	1	t	1.00	[{"id": "item-0", "text": "Import bank", "isRequired": true}, {"id": "item-1", "text": "Import credit cards", "isRequired": true}, {"id": "item-2", "text": "Import expenses", "isRequired": true}, {"id": "item-3", "text": "Import invoices", "isRequired": true}]	f	f	\N	2025-10-19 18:00:38.356169	2025-10-19 18:00:38.356169
1d1ae58a-f516-4477-96a3-609cdead8389	51c831a7-42a0-4a9e-8e8a-69e873269a4f	Categorization	Stage 2 of Monthly Bookkeeping	2	t	2.00	[{"id": "item-0", "text": "Categorize transactions", "isRequired": true}, {"id": "item-1", "text": "Match receipts", "isRequired": true}, {"id": "item-2", "text": "Flag queries", "isRequired": true}, {"id": "item-3", "text": "Code to accounts", "isRequired": true}]	f	f	\N	2025-10-19 18:00:38.357754	2025-10-19 18:00:38.357754
7e7f0440-eb36-4504-8a5f-9af384b292b0	51c831a7-42a0-4a9e-8e8a-69e873269a4f	Reconciliation	Stage 3 of Monthly Bookkeeping	3	t	2.00	[{"id": "item-0", "text": "Bank reconciliation", "isRequired": true}, {"id": "item-1", "text": "Credit card reconciliation", "isRequired": true}, {"id": "item-2", "text": "VAT reconciliation", "isRequired": true}, {"id": "item-3", "text": "Balance sheet review", "isRequired": true}]	f	f	\N	2025-10-19 18:00:38.359468	2025-10-19 18:00:38.359468
f0ce48f2-7a9b-40e4-a410-435fabd178ee	51c831a7-42a0-4a9e-8e8a-69e873269a4f	Reporting	Stage 4 of Monthly Bookkeeping	4	t	1.00	[{"id": "item-0", "text": "P&L report", "isRequired": true}, {"id": "item-1", "text": "Balance sheet", "isRequired": true}, {"id": "item-2", "text": "Cash flow", "isRequired": true}, {"id": "item-3", "text": "Send to client", "isRequired": true}, {"id": "item-4", "text": "File reports", "isRequired": true}]	f	f	\N	2025-10-19 18:00:38.361961	2025-10-19 18:00:38.361961
\.


--
-- Data for Name: workflows; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.workflows (id, tenant_id, name, description, type, trigger, is_active, estimated_days, service_component_id, config, conditions, actions, metadata, created_at, updated_at, created_by_id) FROM stdin;
965823ac-8815-43cb-b52d-be3d11bee333	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Annual Tax Return Process	Standard workflow for completing annual tax returns	task_template	manual	t	14	\N	{}	\N	\N	\N	2025-10-19 18:00:38.267555	2025-10-19 18:00:38.267555	a2adaa31-8f59-409a-b39b-72568022adb4
6624a9f6-9886-4b3d-a8fc-0bcc0ecfd112	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	VAT Return Process	Quarterly VAT return preparation and submission	task_template	schedule	t	5	\N	{}	\N	\N	\N	2025-10-19 18:00:38.291653	2025-10-19 18:00:38.291653	a2adaa31-8f59-409a-b39b-72568022adb4
acbad2fb-595b-462b-82fc-f2f04f43fc67	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Annual Accounts Preparation	Complete annual accounts preparation and filing	task_template	manual	t	21	\N	{}	\N	\N	\N	2025-10-19 18:00:38.305	2025-10-19 18:00:38.305	a2adaa31-8f59-409a-b39b-72568022adb4
f08a8f24-3be0-4086-bd5c-a4eb1cf19811	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Payroll Processing	Monthly payroll processing workflow	task_template	schedule	t	2	\N	{}	\N	\N	\N	2025-10-19 18:00:38.316892	2025-10-19 18:00:38.316892	a2adaa31-8f59-409a-b39b-72568022adb4
4a29c5cf-69ba-4639-b91a-08f3851b5397	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Compliance Review	Regulatory compliance check workflow	task_template	manual	t	10	\N	{}	\N	\N	\N	2025-10-19 18:00:38.3277	2025-10-19 18:00:38.3277	a2adaa31-8f59-409a-b39b-72568022adb4
c9013c22-350c-46aa-b8c4-8a71da338337	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Document Review Process	Standard document review and approval workflow	task_template	manual	t	3	\N	{}	\N	\N	\N	2025-10-19 18:00:38.337371	2025-10-19 18:00:38.337371	a2adaa31-8f59-409a-b39b-72568022adb4
6784d58d-be43-45ac-88e5-3232d67c5172	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	New Client Onboarding	Complete onboarding process for new clients	task_template	manual	t	7	\N	{}	\N	\N	\N	2025-10-19 18:00:38.34593	2025-10-19 18:00:38.34593	a2adaa31-8f59-409a-b39b-72568022adb4
51c831a7-42a0-4a9e-8e8a-69e873269a4f	e175e19a-58c7-4a4f-8f4f-c0e7307165f7	Monthly Bookkeeping	Standard monthly bookkeeping workflow	task_template	schedule	t	3	\N	{}	\N	\N	\N	2025-10-19 18:00:38.354398	2025-10-19 18:00:38.354398	a2adaa31-8f59-409a-b39b-72568022adb4
\.


--
-- Data for Name: xero_connections; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.xero_connections (id, tenant_id, client_id, access_token, refresh_token, expires_at, xero_tenant_id, xero_tenant_name, xero_organisation_id, is_active, last_sync_at, sync_status, sync_error, created_at, updated_at, connected_by) FROM stdin;
\.


--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE SET; Schema: drizzle; Owner: -
--

SELECT pg_catalog.setval('drizzle.__drizzle_migrations_id_seq', 2, true);


--
-- Name: __drizzle_migrations __drizzle_migrations_pkey; Type: CONSTRAINT; Schema: drizzle; Owner: -
--

ALTER TABLE ONLY drizzle.__drizzle_migrations
    ADD CONSTRAINT __drizzle_migrations_pkey PRIMARY KEY (id);


--
-- Name: account account_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT account_pkey PRIMARY KEY (id);


--
-- Name: activity_logs activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_pkey PRIMARY KEY (id);


--
-- Name: aml_checks aml_checks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aml_checks
    ADD CONSTRAINT aml_checks_pkey PRIMARY KEY (id);


--
-- Name: calendar_event_attendees calendar_event_attendees_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_event_attendees
    ADD CONSTRAINT calendar_event_attendees_pkey PRIMARY KEY (id);


--
-- Name: calendar_events calendar_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_events
    ADD CONSTRAINT calendar_events_pkey PRIMARY KEY (id);


--
-- Name: client_contacts client_contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_contacts
    ADD CONSTRAINT client_contacts_pkey PRIMARY KEY (id);


--
-- Name: client_directors client_directors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_directors
    ADD CONSTRAINT client_directors_pkey PRIMARY KEY (id);


--
-- Name: client_portal_access client_portal_access_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_portal_access
    ADD CONSTRAINT client_portal_access_pkey PRIMARY KEY (id);


--
-- Name: client_portal_account client_portal_account_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_portal_account
    ADD CONSTRAINT client_portal_account_pkey PRIMARY KEY (id);


--
-- Name: client_portal_invitations client_portal_invitations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_portal_invitations
    ADD CONSTRAINT client_portal_invitations_pkey PRIMARY KEY (id);


--
-- Name: client_portal_invitations client_portal_invitations_token_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_portal_invitations
    ADD CONSTRAINT client_portal_invitations_token_unique UNIQUE (token);


--
-- Name: client_portal_session client_portal_session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_portal_session
    ADD CONSTRAINT client_portal_session_pkey PRIMARY KEY (id);


--
-- Name: client_portal_session client_portal_session_token_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_portal_session
    ADD CONSTRAINT client_portal_session_token_unique UNIQUE (token);


--
-- Name: client_portal_users client_portal_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_portal_users
    ADD CONSTRAINT client_portal_users_pkey PRIMARY KEY (id);


--
-- Name: client_portal_verification client_portal_verification_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_portal_verification
    ADD CONSTRAINT client_portal_verification_pkey PRIMARY KEY (id);


--
-- Name: client_pscs client_pscs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_pscs
    ADD CONSTRAINT client_pscs_pkey PRIMARY KEY (id);


--
-- Name: client_services client_services_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_services
    ADD CONSTRAINT client_services_pkey PRIMARY KEY (id);


--
-- Name: client_transaction_data client_transaction_data_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_transaction_data
    ADD CONSTRAINT client_transaction_data_pkey PRIMARY KEY (id);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- Name: compliance compliance_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compliance
    ADD CONSTRAINT compliance_pkey PRIMARY KEY (id);


--
-- Name: document_signatures document_signatures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_signatures
    ADD CONSTRAINT document_signatures_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: feedback feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_pkey PRIMARY KEY (id);


--
-- Name: invitations invitations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invitations
    ADD CONSTRAINT invitations_pkey PRIMARY KEY (id);


--
-- Name: invitations invitations_token_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invitations
    ADD CONSTRAINT invitations_token_unique UNIQUE (token);


--
-- Name: invoice_items invoice_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: kyc_verifications kyc_verifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kyc_verifications
    ADD CONSTRAINT kyc_verifications_pkey PRIMARY KEY (id);


--
-- Name: leads leads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_pkey PRIMARY KEY (id);


--
-- Name: message_thread_participants message_thread_participants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_thread_participants
    ADD CONSTRAINT message_thread_participants_pkey PRIMARY KEY (id);


--
-- Name: message_threads message_threads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_threads
    ADD CONSTRAINT message_threads_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: onboarding_responses onboarding_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.onboarding_responses
    ADD CONSTRAINT onboarding_responses_pkey PRIMARY KEY (id);


--
-- Name: onboarding_sessions onboarding_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.onboarding_sessions
    ADD CONSTRAINT onboarding_sessions_pkey PRIMARY KEY (id);


--
-- Name: onboarding_tasks onboarding_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.onboarding_tasks
    ADD CONSTRAINT onboarding_tasks_pkey PRIMARY KEY (id);


--
-- Name: portal_categories portal_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_categories
    ADD CONSTRAINT portal_categories_pkey PRIMARY KEY (id);


--
-- Name: portal_links portal_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_links
    ADD CONSTRAINT portal_links_pkey PRIMARY KEY (id);


--
-- Name: pricing_rules pricing_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_rules
    ADD CONSTRAINT pricing_rules_pkey PRIMARY KEY (id);


--
-- Name: proposal_services proposal_services_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proposal_services
    ADD CONSTRAINT proposal_services_pkey PRIMARY KEY (id);


--
-- Name: proposal_signatures proposal_signatures_docuseal_submission_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proposal_signatures
    ADD CONSTRAINT proposal_signatures_docuseal_submission_id_unique UNIQUE (docuseal_submission_id);


--
-- Name: proposal_signatures proposal_signatures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proposal_signatures
    ADD CONSTRAINT proposal_signatures_pkey PRIMARY KEY (id);


--
-- Name: proposals proposals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proposals
    ADD CONSTRAINT proposals_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (id);


--
-- Name: service_components service_components_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_components
    ADD CONSTRAINT service_components_pkey PRIMARY KEY (id);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: session session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_pkey PRIMARY KEY (id);


--
-- Name: session session_token_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_token_unique UNIQUE (token);


--
-- Name: task_workflow_instances task_workflow_instances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_workflow_instances
    ADD CONSTRAINT task_workflow_instances_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_slug_unique UNIQUE (slug);


--
-- Name: time_entries time_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entries
    ADD CONSTRAINT time_entries_pkey PRIMARY KEY (id);


--
-- Name: user_favorites user_favorites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_favorites
    ADD CONSTRAINT user_favorites_pkey PRIMARY KEY (id);


--
-- Name: user_permissions user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_pkey PRIMARY KEY (id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: verification verification_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verification
    ADD CONSTRAINT verification_pkey PRIMARY KEY (id);


--
-- Name: workflow_stages workflow_stages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_stages
    ADD CONSTRAINT workflow_stages_pkey PRIMARY KEY (id);


--
-- Name: workflows workflows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT workflows_pkey PRIMARY KEY (id);


--
-- Name: xero_connections xero_connections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.xero_connections
    ADD CONSTRAINT xero_connections_pkey PRIMARY KEY (id);


--
-- Name: calendar_event_attendees_event_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX calendar_event_attendees_event_user_idx ON public.calendar_event_attendees USING btree (event_id, user_id);


--
-- Name: calendar_event_attendees_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX calendar_event_attendees_status_idx ON public.calendar_event_attendees USING btree (status);


--
-- Name: calendar_event_attendees_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX calendar_event_attendees_user_idx ON public.calendar_event_attendees USING btree (user_id);


--
-- Name: calendar_events_client_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX calendar_events_client_idx ON public.calendar_events USING btree (client_id);


--
-- Name: calendar_events_start_time_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX calendar_events_start_time_idx ON public.calendar_events USING btree (start_time);


--
-- Name: calendar_events_task_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX calendar_events_task_idx ON public.calendar_events USING btree (task_id);


--
-- Name: calendar_events_tenant_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX calendar_events_tenant_idx ON public.calendar_events USING btree (tenant_id);


--
-- Name: calendar_events_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX calendar_events_type_idx ON public.calendar_events USING btree (type);


--
-- Name: client_portal_access_client_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX client_portal_access_client_idx ON public.client_portal_access USING btree (client_id);


--
-- Name: client_portal_access_tenant_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX client_portal_access_tenant_idx ON public.client_portal_access USING btree (tenant_id);


--
-- Name: client_portal_access_user_client_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX client_portal_access_user_client_idx ON public.client_portal_access USING btree (portal_user_id, client_id);


--
-- Name: client_portal_invitations_email_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX client_portal_invitations_email_idx ON public.client_portal_invitations USING btree (email);


--
-- Name: client_portal_invitations_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX client_portal_invitations_status_idx ON public.client_portal_invitations USING btree (status);


--
-- Name: client_portal_invitations_tenant_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX client_portal_invitations_tenant_idx ON public.client_portal_invitations USING btree (tenant_id);


--
-- Name: client_portal_invitations_token_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX client_portal_invitations_token_idx ON public.client_portal_invitations USING btree (token);


--
-- Name: client_portal_users_email_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX client_portal_users_email_idx ON public.client_portal_users USING btree (email);


--
-- Name: client_portal_users_tenant_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX client_portal_users_tenant_idx ON public.client_portal_users USING btree (tenant_id);


--
-- Name: idx_activity_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_activity_created ON public.activity_logs USING btree (created_at);


--
-- Name: idx_activity_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_activity_created_at ON public.activity_logs USING btree (created_at DESC);


--
-- Name: idx_activity_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_activity_entity ON public.activity_logs USING btree (entity_type, entity_id);


--
-- Name: idx_activity_tenant_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_activity_tenant_entity ON public.activity_logs USING btree (tenant_id, entity_type, entity_id);


--
-- Name: idx_activity_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_activity_user ON public.activity_logs USING btree (user_id);


--
-- Name: idx_aml_check_check_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_aml_check_check_id ON public.aml_checks USING btree (check_id);


--
-- Name: idx_aml_check_client; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_aml_check_client ON public.aml_checks USING btree (client_id);


--
-- Name: idx_aml_check_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_aml_check_session ON public.aml_checks USING btree (onboarding_session_id);


--
-- Name: idx_aml_check_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_aml_check_status ON public.aml_checks USING btree (status);


--
-- Name: idx_aml_check_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_aml_check_tenant ON public.aml_checks USING btree (tenant_id);


--
-- Name: idx_client_contact; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_client_contact ON public.client_contacts USING btree (client_id);


--
-- Name: idx_client_director; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_client_director ON public.client_directors USING btree (client_id);


--
-- Name: idx_client_manager; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_client_manager ON public.clients USING btree (account_manager_id);


--
-- Name: idx_client_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_client_name ON public.clients USING btree (name);


--
-- Name: idx_client_psc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_client_psc ON public.client_pscs USING btree (client_id);


--
-- Name: idx_client_service; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_client_service ON public.client_services USING btree (client_id, service_component_id);


--
-- Name: idx_client_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_client_status ON public.clients USING btree (status);


--
-- Name: idx_compliance_assignee; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_compliance_assignee ON public.compliance USING btree (assigned_to_id);


--
-- Name: idx_compliance_client; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_compliance_client ON public.compliance USING btree (client_id);


--
-- Name: idx_compliance_due_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_compliance_due_date ON public.compliance USING btree (due_date);


--
-- Name: idx_compliance_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_compliance_status ON public.compliance USING btree (status);


--
-- Name: idx_compliance_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_compliance_type ON public.compliance USING btree (type);


--
-- Name: idx_director_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_director_active ON public.client_directors USING btree (is_active);


--
-- Name: idx_document_client; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_document_client ON public.documents USING btree (client_id);


--
-- Name: idx_document_parent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_document_parent ON public.documents USING btree (parent_id);


--
-- Name: idx_document_path; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_document_path ON public.documents USING btree (path);


--
-- Name: idx_document_share_token; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_document_share_token ON public.documents USING btree (share_token);


--
-- Name: idx_document_signature_document; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_document_signature_document ON public.document_signatures USING btree (document_id);


--
-- Name: idx_document_signature_submission; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_document_signature_submission ON public.document_signatures USING btree (docuseal_submission_id);


--
-- Name: idx_document_task; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_document_task ON public.documents USING btree (task_id);


--
-- Name: idx_feedback_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_feedback_created_at ON public.feedback USING btree (created_at);


--
-- Name: idx_feedback_tenant_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_feedback_tenant_status ON public.feedback USING btree (tenant_id, status);


--
-- Name: idx_feedback_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_feedback_type ON public.feedback USING btree (type, status);


--
-- Name: idx_feedback_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_feedback_user ON public.feedback USING btree (user_id);


--
-- Name: idx_invitation_email_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invitation_email_tenant ON public.invitations USING btree (email, tenant_id);


--
-- Name: idx_invitation_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invitation_status ON public.invitations USING btree (status);


--
-- Name: idx_invitation_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_invitation_token ON public.invitations USING btree (token);


--
-- Name: idx_invoice_client; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoice_client ON public.invoices USING btree (client_id);


--
-- Name: idx_invoice_due_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoice_due_date ON public.invoices USING btree (due_date);


--
-- Name: idx_invoice_due_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoice_due_status ON public.invoices USING btree (due_date, status) WHERE (status = ANY (ARRAY['sent'::public.invoice_status, 'overdue'::public.invoice_status]));


--
-- Name: idx_invoice_item_invoice; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoice_item_invoice ON public.invoice_items USING btree (invoice_id);


--
-- Name: idx_invoice_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoice_status ON public.invoices USING btree (status);


--
-- Name: idx_kyc_verification_client; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_kyc_verification_client ON public.kyc_verifications USING btree (client_id);


--
-- Name: idx_kyc_verification_lemverify_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_kyc_verification_lemverify_id ON public.kyc_verifications USING btree (lemverify_id);


--
-- Name: idx_kyc_verification_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_kyc_verification_session ON public.kyc_verifications USING btree (onboarding_session_id);


--
-- Name: idx_kyc_verification_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_kyc_verification_status ON public.kyc_verifications USING btree (status);


--
-- Name: idx_kyc_verification_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_kyc_verification_tenant ON public.kyc_verifications USING btree (tenant_id);


--
-- Name: idx_lead_assigned; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_lead_assigned ON public.leads USING btree (assigned_to_id);


--
-- Name: idx_lead_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_lead_created ON public.leads USING btree (created_at);


--
-- Name: idx_lead_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_lead_email ON public.leads USING btree (email);


--
-- Name: idx_lead_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_lead_status ON public.leads USING btree (status);


--
-- Name: idx_lead_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_lead_tenant ON public.leads USING btree (tenant_id);


--
-- Name: idx_message_thread_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_message_thread_time ON public.messages USING btree (thread_id, created_at DESC);


--
-- Name: idx_onboarding_response_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_onboarding_response_session ON public.onboarding_responses USING btree (onboarding_session_id);


--
-- Name: idx_onboarding_response_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_onboarding_response_tenant ON public.onboarding_responses USING btree (tenant_id);


--
-- Name: idx_onboarding_session_assigned; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_onboarding_session_assigned ON public.onboarding_sessions USING btree (assigned_to_id);


--
-- Name: idx_onboarding_session_client; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_onboarding_session_client ON public.onboarding_sessions USING btree (client_id);


--
-- Name: idx_onboarding_session_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_onboarding_session_status ON public.onboarding_sessions USING btree (status);


--
-- Name: idx_onboarding_session_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_onboarding_session_tenant ON public.onboarding_sessions USING btree (tenant_id);


--
-- Name: idx_onboarding_task_assigned; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_onboarding_task_assigned ON public.onboarding_tasks USING btree (assigned_to_id);


--
-- Name: idx_onboarding_task_done; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_onboarding_task_done ON public.onboarding_tasks USING btree (done);


--
-- Name: idx_onboarding_task_sequence; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_onboarding_task_sequence ON public.onboarding_tasks USING btree (session_id, sequence);


--
-- Name: idx_onboarding_task_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_onboarding_task_session ON public.onboarding_tasks USING btree (session_id);


--
-- Name: idx_parent_task; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_parent_task ON public.tasks USING btree (parent_task_id);


--
-- Name: idx_permissions_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_permissions_tenant ON public.user_permissions USING btree (tenant_id);


--
-- Name: idx_portal_categories_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_portal_categories_active ON public.portal_categories USING btree (is_active);


--
-- Name: idx_portal_categories_sort; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_portal_categories_sort ON public.portal_categories USING btree (sort_order);


--
-- Name: idx_portal_categories_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_portal_categories_tenant ON public.portal_categories USING btree (tenant_id);


--
-- Name: idx_portal_links_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_portal_links_active ON public.portal_links USING btree (is_active);


--
-- Name: idx_portal_links_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_portal_links_category ON public.portal_links USING btree (category_id);


--
-- Name: idx_portal_links_internal; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_portal_links_internal ON public.portal_links USING btree (is_internal);


--
-- Name: idx_portal_links_sort; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_portal_links_sort ON public.portal_links USING btree (sort_order);


--
-- Name: idx_portal_links_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_portal_links_tenant ON public.portal_links USING btree (tenant_id);


--
-- Name: idx_pricing_rule_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pricing_rule_active ON public.pricing_rules USING btree (is_active);


--
-- Name: idx_pricing_rule_component; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pricing_rule_component ON public.pricing_rules USING btree (component_id);


--
-- Name: idx_pricing_rule_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pricing_rule_type ON public.pricing_rules USING btree (rule_type);


--
-- Name: idx_primary_contact; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_primary_contact ON public.client_contacts USING btree (client_id, is_primary);


--
-- Name: idx_proposal_client; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_proposal_client ON public.proposals USING btree (client_id);


--
-- Name: idx_proposal_client_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_proposal_client_status ON public.proposals USING btree (client_id, status);


--
-- Name: idx_proposal_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_proposal_created ON public.proposals USING btree (created_at);


--
-- Name: idx_proposal_lead; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_proposal_lead ON public.proposals USING btree (lead_id);


--
-- Name: idx_proposal_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_proposal_number ON public.proposals USING btree (tenant_id, proposal_number);


--
-- Name: idx_proposal_service_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_proposal_service_code ON public.proposal_services USING btree (component_code);


--
-- Name: idx_proposal_service_proposal; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_proposal_service_proposal ON public.proposal_services USING btree (proposal_id);


--
-- Name: idx_proposal_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_proposal_status ON public.proposals USING btree (status);


--
-- Name: idx_proposal_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_proposal_tenant ON public.proposals USING btree (tenant_id);


--
-- Name: idx_psc_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_psc_active ON public.client_pscs USING btree (is_active);


--
-- Name: idx_role_module; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_role_module ON public.role_permissions USING btree (tenant_id, role, module);


--
-- Name: idx_service_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_service_category ON public.services USING btree (category);


--
-- Name: idx_service_component_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_service_component_active ON public.service_components USING btree (is_active);


--
-- Name: idx_service_component_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_service_component_category ON public.service_components USING btree (category);


--
-- Name: idx_service_component_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_service_component_code ON public.service_components USING btree (tenant_id, code);


--
-- Name: idx_signature_docuseal; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_signature_docuseal ON public.proposal_signatures USING btree (docuseal_submission_id);


--
-- Name: idx_signature_proposal; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_signature_proposal ON public.proposal_signatures USING btree (proposal_id);


--
-- Name: idx_stage_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stage_order ON public.workflow_stages USING btree (workflow_id, stage_order);


--
-- Name: idx_stage_workflow; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stage_workflow ON public.workflow_stages USING btree (workflow_id);


--
-- Name: idx_task_assignee; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_task_assignee ON public.tasks USING btree (assigned_to_id);


--
-- Name: idx_task_client; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_task_client ON public.tasks USING btree (client_id);


--
-- Name: idx_task_due_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_task_due_date ON public.tasks USING btree (due_date);


--
-- Name: idx_task_due_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_task_due_status ON public.tasks USING btree (due_date, status) WHERE (status = ANY (ARRAY['pending'::public.task_status, 'in_progress'::public.task_status]));


--
-- Name: idx_task_progress; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_task_progress ON public.tasks USING btree (progress);


--
-- Name: idx_task_reviewer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_task_reviewer ON public.tasks USING btree (reviewer_id);


--
-- Name: idx_task_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_task_status ON public.tasks USING btree (status);


--
-- Name: idx_task_workflow_instance; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_task_workflow_instance ON public.task_workflow_instances USING btree (task_id);


--
-- Name: idx_tenant_client_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_tenant_client_code ON public.clients USING btree (tenant_id, client_code);


--
-- Name: idx_tenant_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_tenant_email ON public.users USING btree (tenant_id, email);


--
-- Name: idx_tenant_invoice_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_tenant_invoice_number ON public.invoices USING btree (tenant_id, invoice_number);


--
-- Name: idx_tenant_service_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_tenant_service_code ON public.services USING btree (tenant_id, code);


--
-- Name: idx_time_entry_billable; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_time_entry_billable ON public.time_entries USING btree (billable, billed);


--
-- Name: idx_time_entry_client; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_time_entry_client ON public.time_entries USING btree (client_id);


--
-- Name: idx_time_entry_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_time_entry_status ON public.time_entries USING btree (status);


--
-- Name: idx_time_entry_task; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_time_entry_task ON public.time_entries USING btree (task_id);


--
-- Name: idx_time_entry_user_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_time_entry_user_date ON public.time_entries USING btree (user_id, date);


--
-- Name: idx_transaction_data_client; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transaction_data_client ON public.client_transaction_data USING btree (client_id);


--
-- Name: idx_transaction_data_lead; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transaction_data_lead ON public.client_transaction_data USING btree (lead_id);


--
-- Name: idx_transaction_data_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transaction_data_tenant ON public.client_transaction_data USING btree (tenant_id);


--
-- Name: idx_user_favorites_link; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_favorites_link ON public.user_favorites USING btree (link_id);


--
-- Name: idx_user_favorites_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_favorites_user ON public.user_favorites USING btree (user_id);


--
-- Name: idx_user_link_favorite; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_user_link_favorite ON public.user_favorites USING btree (user_id, link_id);


--
-- Name: idx_user_module; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_user_module ON public.user_permissions USING btree (user_id, module);


--
-- Name: idx_user_role; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_role ON public.users USING btree (role);


--
-- Name: idx_workflow_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_workflow_active ON public.workflows USING btree (is_active);


--
-- Name: idx_workflow_instance; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_workflow_instance ON public.task_workflow_instances USING btree (workflow_id);


--
-- Name: idx_workflow_instance_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_workflow_instance_status ON public.task_workflow_instances USING btree (status);


--
-- Name: idx_workflow_service; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_workflow_service ON public.workflows USING btree (service_component_id);


--
-- Name: idx_workflow_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_workflow_type ON public.workflows USING btree (type);


--
-- Name: idx_xero_client; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_xero_client ON public.xero_connections USING btree (client_id);


--
-- Name: idx_xero_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_xero_tenant ON public.xero_connections USING btree (tenant_id);


--
-- Name: message_thread_participants_participant_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX message_thread_participants_participant_idx ON public.message_thread_participants USING btree (participant_type, participant_id);


--
-- Name: message_thread_participants_thread_participant_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX message_thread_participants_thread_participant_idx ON public.message_thread_participants USING btree (thread_id, participant_type, participant_id);


--
-- Name: message_thread_participants_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX message_thread_participants_user_idx ON public.message_thread_participants USING btree (user_id);


--
-- Name: message_threads_client_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX message_threads_client_idx ON public.message_threads USING btree (client_id);


--
-- Name: message_threads_last_message_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX message_threads_last_message_idx ON public.message_threads USING btree (last_message_at);


--
-- Name: message_threads_tenant_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX message_threads_tenant_idx ON public.message_threads USING btree (tenant_id);


--
-- Name: message_threads_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX message_threads_type_idx ON public.message_threads USING btree (type);


--
-- Name: messages_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX messages_created_at_idx ON public.messages USING btree (created_at);


--
-- Name: messages_sender_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX messages_sender_idx ON public.messages USING btree (sender_type, sender_id);


--
-- Name: messages_thread_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX messages_thread_idx ON public.messages USING btree (thread_id);


--
-- Name: messages_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX messages_user_idx ON public.messages USING btree (user_id);


--
-- Name: notifications_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notifications_created_at_idx ON public.notifications USING btree (created_at);


--
-- Name: notifications_tenant_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notifications_tenant_idx ON public.notifications USING btree (tenant_id);


--
-- Name: notifications_user_is_read_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notifications_user_is_read_idx ON public.notifications USING btree (user_id, is_read);


--
-- Name: account account_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT account_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: activity_logs activity_logs_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: activity_logs activity_logs_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: aml_checks aml_checks_approved_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aml_checks
    ADD CONSTRAINT aml_checks_approved_by_users_id_fk FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: aml_checks aml_checks_client_id_clients_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aml_checks
    ADD CONSTRAINT aml_checks_client_id_clients_id_fk FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: aml_checks aml_checks_onboarding_session_id_onboarding_sessions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aml_checks
    ADD CONSTRAINT aml_checks_onboarding_session_id_onboarding_sessions_id_fk FOREIGN KEY (onboarding_session_id) REFERENCES public.onboarding_sessions(id) ON DELETE CASCADE;


--
-- Name: aml_checks aml_checks_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aml_checks
    ADD CONSTRAINT aml_checks_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: calendar_event_attendees calendar_event_attendees_event_id_calendar_events_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_event_attendees
    ADD CONSTRAINT calendar_event_attendees_event_id_calendar_events_id_fk FOREIGN KEY (event_id) REFERENCES public.calendar_events(id) ON DELETE CASCADE;


--
-- Name: calendar_event_attendees calendar_event_attendees_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_event_attendees
    ADD CONSTRAINT calendar_event_attendees_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: calendar_events calendar_events_client_id_clients_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_events
    ADD CONSTRAINT calendar_events_client_id_clients_id_fk FOREIGN KEY (client_id) REFERENCES public.clients(id);


--
-- Name: calendar_events calendar_events_compliance_id_compliance_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_events
    ADD CONSTRAINT calendar_events_compliance_id_compliance_id_fk FOREIGN KEY (compliance_id) REFERENCES public.compliance(id);


--
-- Name: calendar_events calendar_events_created_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_events
    ADD CONSTRAINT calendar_events_created_by_users_id_fk FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: calendar_events calendar_events_task_id_tasks_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_events
    ADD CONSTRAINT calendar_events_task_id_tasks_id_fk FOREIGN KEY (task_id) REFERENCES public.tasks(id);


--
-- Name: calendar_events calendar_events_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_events
    ADD CONSTRAINT calendar_events_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: client_contacts client_contacts_client_id_clients_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_contacts
    ADD CONSTRAINT client_contacts_client_id_clients_id_fk FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: client_contacts client_contacts_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_contacts
    ADD CONSTRAINT client_contacts_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: client_directors client_directors_client_id_clients_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_directors
    ADD CONSTRAINT client_directors_client_id_clients_id_fk FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: client_directors client_directors_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_directors
    ADD CONSTRAINT client_directors_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: client_portal_access client_portal_access_client_id_clients_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_portal_access
    ADD CONSTRAINT client_portal_access_client_id_clients_id_fk FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: client_portal_access client_portal_access_granted_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_portal_access
    ADD CONSTRAINT client_portal_access_granted_by_users_id_fk FOREIGN KEY (granted_by) REFERENCES public.users(id);


--
-- Name: client_portal_access client_portal_access_portal_user_id_client_portal_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_portal_access
    ADD CONSTRAINT client_portal_access_portal_user_id_client_portal_users_id_fk FOREIGN KEY (portal_user_id) REFERENCES public.client_portal_users(id) ON DELETE CASCADE;


--
-- Name: client_portal_access client_portal_access_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_portal_access
    ADD CONSTRAINT client_portal_access_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: client_portal_account client_portal_account_client_id_clients_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_portal_account
    ADD CONSTRAINT client_portal_account_client_id_clients_id_fk FOREIGN KEY (client_id) REFERENCES public.clients(id);


--
-- Name: client_portal_account client_portal_account_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_portal_account
    ADD CONSTRAINT client_portal_account_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: client_portal_account client_portal_account_user_id_client_portal_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_portal_account
    ADD CONSTRAINT client_portal_account_user_id_client_portal_users_id_fk FOREIGN KEY (user_id) REFERENCES public.client_portal_users(id) ON DELETE CASCADE;


--
-- Name: client_portal_invitations client_portal_invitations_invited_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_portal_invitations
    ADD CONSTRAINT client_portal_invitations_invited_by_users_id_fk FOREIGN KEY (invited_by) REFERENCES public.users(id);


--
-- Name: client_portal_invitations client_portal_invitations_revoked_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_portal_invitations
    ADD CONSTRAINT client_portal_invitations_revoked_by_users_id_fk FOREIGN KEY (revoked_by) REFERENCES public.users(id);


--
-- Name: client_portal_invitations client_portal_invitations_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_portal_invitations
    ADD CONSTRAINT client_portal_invitations_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: client_portal_session client_portal_session_client_id_clients_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_portal_session
    ADD CONSTRAINT client_portal_session_client_id_clients_id_fk FOREIGN KEY (client_id) REFERENCES public.clients(id);


--
-- Name: client_portal_session client_portal_session_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_portal_session
    ADD CONSTRAINT client_portal_session_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: client_portal_session client_portal_session_user_id_client_portal_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_portal_session
    ADD CONSTRAINT client_portal_session_user_id_client_portal_users_id_fk FOREIGN KEY (user_id) REFERENCES public.client_portal_users(id) ON DELETE CASCADE;


--
-- Name: client_portal_users client_portal_users_invited_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_portal_users
    ADD CONSTRAINT client_portal_users_invited_by_users_id_fk FOREIGN KEY (invited_by) REFERENCES public.users(id);


--
-- Name: client_portal_users client_portal_users_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_portal_users
    ADD CONSTRAINT client_portal_users_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: client_portal_verification client_portal_verification_client_id_clients_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_portal_verification
    ADD CONSTRAINT client_portal_verification_client_id_clients_id_fk FOREIGN KEY (client_id) REFERENCES public.clients(id);


--
-- Name: client_portal_verification client_portal_verification_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_portal_verification
    ADD CONSTRAINT client_portal_verification_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: client_pscs client_pscs_client_id_clients_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_pscs
    ADD CONSTRAINT client_pscs_client_id_clients_id_fk FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: client_pscs client_pscs_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_pscs
    ADD CONSTRAINT client_pscs_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: client_services client_services_client_id_clients_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_services
    ADD CONSTRAINT client_services_client_id_clients_id_fk FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: client_services client_services_service_component_id_service_components_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_services
    ADD CONSTRAINT client_services_service_component_id_service_components_id_fk FOREIGN KEY (service_component_id) REFERENCES public.service_components(id) ON DELETE CASCADE;


--
-- Name: client_services client_services_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_services
    ADD CONSTRAINT client_services_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: client_transaction_data client_transaction_data_client_id_clients_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_transaction_data
    ADD CONSTRAINT client_transaction_data_client_id_clients_id_fk FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: client_transaction_data client_transaction_data_lead_id_leads_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_transaction_data
    ADD CONSTRAINT client_transaction_data_lead_id_leads_id_fk FOREIGN KEY (lead_id) REFERENCES public.leads(id) ON DELETE SET NULL;


--
-- Name: client_transaction_data client_transaction_data_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_transaction_data
    ADD CONSTRAINT client_transaction_data_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: clients clients_account_manager_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_account_manager_id_users_id_fk FOREIGN KEY (account_manager_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: clients clients_created_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_created_by_users_id_fk FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: clients clients_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: compliance compliance_assigned_to_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compliance
    ADD CONSTRAINT compliance_assigned_to_id_users_id_fk FOREIGN KEY (assigned_to_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: compliance compliance_client_id_clients_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compliance
    ADD CONSTRAINT compliance_client_id_clients_id_fk FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: compliance compliance_created_by_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compliance
    ADD CONSTRAINT compliance_created_by_id_users_id_fk FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: compliance compliance_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compliance
    ADD CONSTRAINT compliance_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: document_signatures document_signatures_document_id_documents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_signatures
    ADD CONSTRAINT document_signatures_document_id_documents_id_fk FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: document_signatures document_signatures_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_signatures
    ADD CONSTRAINT document_signatures_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: documents documents_client_id_clients_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_client_id_clients_id_fk FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: documents documents_task_id_tasks_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_task_id_tasks_id_fk FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: documents documents_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: documents documents_uploaded_by_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_uploaded_by_id_users_id_fk FOREIGN KEY (uploaded_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: feedback feedback_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: invitations invitations_invited_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invitations
    ADD CONSTRAINT invitations_invited_by_users_id_fk FOREIGN KEY (invited_by) REFERENCES public.users(id);


--
-- Name: invitations invitations_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invitations
    ADD CONSTRAINT invitations_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: invoice_items invoice_items_invoice_id_invoices_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_invoice_id_invoices_id_fk FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE CASCADE;


--
-- Name: invoice_items invoice_items_service_component_id_service_components_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_service_component_id_service_components_id_fk FOREIGN KEY (service_component_id) REFERENCES public.service_components(id) ON DELETE SET NULL;


--
-- Name: invoice_items invoice_items_time_entry_id_time_entries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_time_entry_id_time_entries_id_fk FOREIGN KEY (time_entry_id) REFERENCES public.time_entries(id) ON DELETE SET NULL;


--
-- Name: invoices invoices_client_id_clients_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_client_id_clients_id_fk FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE RESTRICT;


--
-- Name: invoices invoices_created_by_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_created_by_id_users_id_fk FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: invoices invoices_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: kyc_verifications kyc_verifications_approved_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kyc_verifications
    ADD CONSTRAINT kyc_verifications_approved_by_users_id_fk FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: kyc_verifications kyc_verifications_client_id_clients_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kyc_verifications
    ADD CONSTRAINT kyc_verifications_client_id_clients_id_fk FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: kyc_verifications kyc_verifications_onboarding_session_id_onboarding_sessions_id_; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kyc_verifications
    ADD CONSTRAINT kyc_verifications_onboarding_session_id_onboarding_sessions_id_ FOREIGN KEY (onboarding_session_id) REFERENCES public.onboarding_sessions(id) ON DELETE CASCADE;


--
-- Name: kyc_verifications kyc_verifications_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kyc_verifications
    ADD CONSTRAINT kyc_verifications_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: leads leads_assigned_to_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_assigned_to_id_users_id_fk FOREIGN KEY (assigned_to_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: leads leads_converted_to_client_id_clients_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_converted_to_client_id_clients_id_fk FOREIGN KEY (converted_to_client_id) REFERENCES public.clients(id) ON DELETE SET NULL;


--
-- Name: leads leads_created_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_created_by_users_id_fk FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: leads leads_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: message_thread_participants message_thread_participants_thread_id_message_threads_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_thread_participants
    ADD CONSTRAINT message_thread_participants_thread_id_message_threads_id_fk FOREIGN KEY (thread_id) REFERENCES public.message_threads(id) ON DELETE CASCADE;


--
-- Name: message_thread_participants message_thread_participants_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_thread_participants
    ADD CONSTRAINT message_thread_participants_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: message_threads message_threads_client_id_clients_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_threads
    ADD CONSTRAINT message_threads_client_id_clients_id_fk FOREIGN KEY (client_id) REFERENCES public.clients(id);


--
-- Name: message_threads message_threads_created_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_threads
    ADD CONSTRAINT message_threads_created_by_users_id_fk FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: message_threads message_threads_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_threads
    ADD CONSTRAINT message_threads_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: messages messages_thread_id_message_threads_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_thread_id_message_threads_id_fk FOREIGN KEY (thread_id) REFERENCES public.message_threads(id) ON DELETE CASCADE;


--
-- Name: messages messages_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: notifications notifications_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: notifications notifications_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: onboarding_responses onboarding_responses_onboarding_session_id_onboarding_sessions_; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.onboarding_responses
    ADD CONSTRAINT onboarding_responses_onboarding_session_id_onboarding_sessions_ FOREIGN KEY (onboarding_session_id) REFERENCES public.onboarding_sessions(id) ON DELETE CASCADE;


--
-- Name: onboarding_responses onboarding_responses_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.onboarding_responses
    ADD CONSTRAINT onboarding_responses_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: onboarding_sessions onboarding_sessions_assigned_to_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.onboarding_sessions
    ADD CONSTRAINT onboarding_sessions_assigned_to_id_users_id_fk FOREIGN KEY (assigned_to_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: onboarding_sessions onboarding_sessions_client_id_clients_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.onboarding_sessions
    ADD CONSTRAINT onboarding_sessions_client_id_clients_id_fk FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: onboarding_sessions onboarding_sessions_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.onboarding_sessions
    ADD CONSTRAINT onboarding_sessions_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: onboarding_tasks onboarding_tasks_assigned_to_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.onboarding_tasks
    ADD CONSTRAINT onboarding_tasks_assigned_to_id_users_id_fk FOREIGN KEY (assigned_to_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: onboarding_tasks onboarding_tasks_session_id_onboarding_sessions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.onboarding_tasks
    ADD CONSTRAINT onboarding_tasks_session_id_onboarding_sessions_id_fk FOREIGN KEY (session_id) REFERENCES public.onboarding_sessions(id) ON DELETE CASCADE;


--
-- Name: onboarding_tasks onboarding_tasks_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.onboarding_tasks
    ADD CONSTRAINT onboarding_tasks_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: portal_categories portal_categories_created_by_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_categories
    ADD CONSTRAINT portal_categories_created_by_id_users_id_fk FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: portal_categories portal_categories_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_categories
    ADD CONSTRAINT portal_categories_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: portal_links portal_links_category_id_portal_categories_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_links
    ADD CONSTRAINT portal_links_category_id_portal_categories_id_fk FOREIGN KEY (category_id) REFERENCES public.portal_categories(id) ON DELETE CASCADE;


--
-- Name: portal_links portal_links_created_by_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_links
    ADD CONSTRAINT portal_links_created_by_id_users_id_fk FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: portal_links portal_links_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_links
    ADD CONSTRAINT portal_links_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: pricing_rules pricing_rules_component_id_service_components_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_rules
    ADD CONSTRAINT pricing_rules_component_id_service_components_id_fk FOREIGN KEY (component_id) REFERENCES public.service_components(id) ON DELETE CASCADE;


--
-- Name: pricing_rules pricing_rules_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_rules
    ADD CONSTRAINT pricing_rules_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: proposal_services proposal_services_proposal_id_proposals_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proposal_services
    ADD CONSTRAINT proposal_services_proposal_id_proposals_id_fk FOREIGN KEY (proposal_id) REFERENCES public.proposals(id) ON DELETE CASCADE;


--
-- Name: proposal_services proposal_services_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proposal_services
    ADD CONSTRAINT proposal_services_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: proposal_signatures proposal_signatures_proposal_id_proposals_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proposal_signatures
    ADD CONSTRAINT proposal_signatures_proposal_id_proposals_id_fk FOREIGN KEY (proposal_id) REFERENCES public.proposals(id) ON DELETE CASCADE;


--
-- Name: proposal_signatures proposal_signatures_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proposal_signatures
    ADD CONSTRAINT proposal_signatures_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: proposals proposals_client_id_clients_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proposals
    ADD CONSTRAINT proposals_client_id_clients_id_fk FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE SET NULL;


--
-- Name: proposals proposals_created_by_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proposals
    ADD CONSTRAINT proposals_created_by_id_users_id_fk FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: proposals proposals_lead_id_leads_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proposals
    ADD CONSTRAINT proposals_lead_id_leads_id_fk FOREIGN KEY (lead_id) REFERENCES public.leads(id) ON DELETE SET NULL;


--
-- Name: proposals proposals_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proposals
    ADD CONSTRAINT proposals_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: service_components service_components_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_components
    ADD CONSTRAINT service_components_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: services services_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: session session_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: task_workflow_instances task_workflow_instances_current_stage_id_workflow_stages_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_workflow_instances
    ADD CONSTRAINT task_workflow_instances_current_stage_id_workflow_stages_id_fk FOREIGN KEY (current_stage_id) REFERENCES public.workflow_stages(id) ON DELETE SET NULL;


--
-- Name: task_workflow_instances task_workflow_instances_task_id_tasks_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_workflow_instances
    ADD CONSTRAINT task_workflow_instances_task_id_tasks_id_fk FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_workflow_instances task_workflow_instances_workflow_id_workflows_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_workflow_instances
    ADD CONSTRAINT task_workflow_instances_workflow_id_workflows_id_fk FOREIGN KEY (workflow_id) REFERENCES public.workflows(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_assigned_to_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_assigned_to_id_users_id_fk FOREIGN KEY (assigned_to_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: tasks tasks_client_id_clients_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_client_id_clients_id_fk FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE SET NULL;


--
-- Name: tasks tasks_created_by_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_created_by_id_users_id_fk FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: tasks tasks_reviewer_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_reviewer_id_users_id_fk FOREIGN KEY (reviewer_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: tasks tasks_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: time_entries time_entries_approved_by_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entries
    ADD CONSTRAINT time_entries_approved_by_id_users_id_fk FOREIGN KEY (approved_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: time_entries time_entries_client_id_clients_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entries
    ADD CONSTRAINT time_entries_client_id_clients_id_fk FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE SET NULL;


--
-- Name: time_entries time_entries_service_component_id_service_components_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entries
    ADD CONSTRAINT time_entries_service_component_id_service_components_id_fk FOREIGN KEY (service_component_id) REFERENCES public.service_components(id) ON DELETE SET NULL;


--
-- Name: time_entries time_entries_task_id_tasks_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entries
    ADD CONSTRAINT time_entries_task_id_tasks_id_fk FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: time_entries time_entries_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entries
    ADD CONSTRAINT time_entries_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: time_entries time_entries_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entries
    ADD CONSTRAINT time_entries_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_favorites user_favorites_link_id_portal_links_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_favorites
    ADD CONSTRAINT user_favorites_link_id_portal_links_id_fk FOREIGN KEY (link_id) REFERENCES public.portal_links(id) ON DELETE CASCADE;


--
-- Name: user_favorites user_favorites_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_favorites
    ADD CONSTRAINT user_favorites_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_permissions user_permissions_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: user_permissions user_permissions_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: workflow_stages workflow_stages_workflow_id_workflows_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_stages
    ADD CONSTRAINT workflow_stages_workflow_id_workflows_id_fk FOREIGN KEY (workflow_id) REFERENCES public.workflows(id) ON DELETE CASCADE;


--
-- Name: workflows workflows_created_by_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT workflows_created_by_id_users_id_fk FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: workflows workflows_service_component_id_service_components_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT workflows_service_component_id_service_components_id_fk FOREIGN KEY (service_component_id) REFERENCES public.service_components(id) ON DELETE SET NULL;


--
-- Name: workflows workflows_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT workflows_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: xero_connections xero_connections_client_id_clients_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.xero_connections
    ADD CONSTRAINT xero_connections_client_id_clients_id_fk FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: xero_connections xero_connections_connected_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.xero_connections
    ADD CONSTRAINT xero_connections_connected_by_users_id_fk FOREIGN KEY (connected_by) REFERENCES public.users(id);


--
-- Name: xero_connections xero_connections_tenant_id_tenants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.xero_connections
    ADD CONSTRAINT xero_connections_tenant_id_tenants_id_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict heqFcjMCWBiWikpDNwmySyGkz7WD8sdMsfmeAgqLuPyXov9MArvV4w2EG9eaEjm

